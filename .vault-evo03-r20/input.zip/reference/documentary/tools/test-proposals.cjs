'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {build,propose}=require('./propose-catalog.cjs');const root=process.argv[2],d=fs.readFileSync(path.join(root,'review/individual-dossiers.jsonl')),l=fs.readFileSync(path.join(root,'inputs/ledger-original.jsonl')),rows=d.toString().trimEnd().split('\n').map(JSON.parse);const p=build(d,l);assert.equal(p.length,1095);assert.ok(p.every(r=>r.productionApproved===false&&r.activation===false&&r.restrictions.noProductionUse));console.log('PASS zero approvals');
const r=structuredClone(rows[0]);r.composition.name+=' altered';assert.throws(()=>propose(r));console.log('PASS composition tamper');
const q=structuredClone(rows[0]);q.rawEvidence.food.description+=' altered';assert.throws(()=>propose(q));console.log('PASS evidence tamper');
const t=structuredClone(rows[0]);t.identity.id+='9';assert.throws(()=>propose(t));console.log('PASS identity tamper');
const x=structuredClone(rows[0]);x.decision='approved';assert.throws(()=>propose(x));console.log('PASS approval rejected');
assert.throws(()=>build(Buffer.concat([d,Buffer.from(' ')]),l));assert.throws(()=>build(d,Buffer.concat([l,Buffer.from(' ')])));console.log('PASS source and ledger pins');
assert.equal(p.filter(x=>x.restrictions.blockConsumptionUntilEdibleBasisVerified).length,498);assert.equal(p.filter(x=>x.category==='QUARENTENA_NECESSARIA').length,3);console.log('PASS unknown basis and quarantine');
assert.ok(p.every(x=>x.documentedKnownFields.length+x.notQuantifiedFields.length===28));assert.ok(p.every(x=>x.restrictions.noInferredZero&&x.restrictions.noInferredPreparation&&x.restrictions.noFoodEquivalence));console.log('PASS coverage and restrictions');
