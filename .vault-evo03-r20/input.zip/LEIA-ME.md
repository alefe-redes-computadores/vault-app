# VAULT Evolution Macro03 R26 — correção causal dos harnesses, LAB ONLY

R25 Action 46069174923, envelope a3cf60081b0f53fe8bbb14754526c5a7cec97f05: 8/10 lanes PASS. Falharam browser e macro02-host. Três artefatos baixados e hashes conferidos: browser 15232282869 f0178e8f5115315f07bff2fe2815b7c884977bef69b506ab1117053fa06b5834; host 15231942811 f495dd5d481a92b25fa996ef509e7d12e2f5620701a8b3d4210b71dbe49f5990; Dexie 15231882619 835b374d6fdcb62530a971156c68dd0e606529d7d0dc9c66b95726a04e6184d0. Recibo idêntico nos três: SHA256 b8ba7e5c77be64d6df6ecbd9cf159cace4efdfc5fbbe5693ce566d2793078df5. R26 exige `cmp` integral desse recibo na montagem local e CI. Payload R24 original preservado; materializador, 102 paths de app, guardas clínicos, testes funcionais, 21 assertions de host e gates preservados.

## Causa dos três bloqueios Vital
- Recovery: FAILURE-context.txt contém `LAB INIT ERROR Error: Canonical V60 stores missing`.
- Consumer: 12 falhas com `V60 expected`, fase bootstrap-failure.
- Catalog: screenshot original `LAB STOP: Error: Unexpected canonical version`.
- Upgrade Dexie real R25: `R20_REAL_DEXIE_UPGRADE_PASS 60 61`. Correção estritamente nas três fixtures ativas, exige versão exata 61 e seis stores (recipes, versions, drafts, ACK, syncQueue, enrollment). R19-recovery label V60->V61. Não adapta fixtures históricas inativas nem relaxa verificações.

## Causa provável do 404 de host e prova
Export Next real lista `/saude/vital` e quatro subrotas; Macro02 original passou até `MACRO02_ACTIVE_PREMIUM_BROWSER_PG17_GATE_PASS`. O resolvedor de teste converte a pasta `saude/vital` em `saude/vital/index.html` e procura `index.html.html`, perdendo `saude/vital.html`. Reproduzido localmente com layout sintético. Corrigir apenas o resolvedor do harness, pinado pelo blob 460cd7e8bfb1781b608ce68f7479be00d8b640c5; confirmar seis arquivos distintos no export real em CI, preservar 404 real e regras REST/PG. Não é correção no app ou no servidor de produção. A prova definitiva da causa é o CI real.

## Validação local
8 testes Python novos, 14 testes Node do resolvedor, 30 testes de guardas emitidos (objeto DB simulado), 12 testes R25 reexecutados = 64 casos; 3 TSX transpiled (sintaxe, não TSC integral). Chromium local bloqueado por política ERR_BLOCKED_BY_ADMINISTRATOR; não declarado PASS. O script de teste sintético Chromium está incluso para ambiente autorizado; os dez gates originais reais continuam obrigatórios em Actions. Nenhum teste funcional foi removido ou reduzido. As oito lanes R25 aprovadas serão reexecutadas também.

## Base histórica, não release
R26 deliberadamente usa exatamente o host 109b116e997de0087883c5b0a7deb94143d97ef3 da R25. A main avançou para 68038275b278e44ee65f6aebfd2792c7d4f5e2ef com dois commits H01 (7 paths); build 46072993647 FAILURE, geometria em execução no momento da consulta. Não absorver uma base ainda não certificada. O executor exige que a main observada seja descendente do host e não mude durante préflight; push exclusivo em nova branch lab, sem reset/force/merge/main/deploy. A nova main precisa de reconciliação e validação próprias depois da R26, não se considera atualizada por este laboratório. Exportador geral inalterado. Aprovação do catálogo, 95 bloqueios documentais, revisão privacidade, 36/23 rastreabilidade histórica e homologação física/dois dispositivos continuam pendentes.
