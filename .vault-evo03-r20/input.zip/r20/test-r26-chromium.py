import pathlib,subprocess,os
from playwright.sync_api import sync_playwright
p=pathlib.Path(__file__).resolve().parent
proc=subprocess.Popen(['node',str(p/'test-r26-http.cjs')],stdout=subprocess.PIPE,text=True)
try:
 port=int(proc.stdout.readline().strip());base=f'http://127.0.0.1:{port}'
 routes=['/saude/minha-saude','/saude/vital','/saude/vital/treinos','/saude/vital/nutricao','/saude/vital/evolucao','/saude/vital/planos']
 count=0
 with sync_playwright() as pw:
  args={'headless':True,'args':['--no-sandbox']}
  if os.environ.get('R26_CHROMIUM_BIN'):args['executable_path']=os.environ['R26_CHROMIUM_BIN']
  browser=pw.chromium.launch(**args)
  for w in [320,390,430]:
   page=browser.new_page(viewport={'width':w,'height':850})
   for route in routes:
    res=page.goto(base+route+'?return_to=%2Fsaude%2Fminha-saude');assert res.status==200;assert page.locator('h1').inner_text()==route;count+=1
   res=page.goto(base+'/saude/vital/absent');assert res.status==404;assert page.locator('body').inner_text()=='not found';count+=1;page.close()
  browser.close()
 print('R26_SYNTHETIC_STATIC_CHROMIUM_PASS',count)
finally:
 proc.terminate();proc.wait(timeout=10)
