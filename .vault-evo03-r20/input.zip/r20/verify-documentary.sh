#!/usr/bin/env bash
set -euo pipefail
[[ $# == 1 ]]; src=$(realpath "$1");work=$(mktemp -d);trap 'rm -rf -- "$work"' EXIT
node "$src/tools/test-proposals.cjs" "$src"
node "$src/tools/propose-catalog.cjs" "$src" "$work" > "$work/summary.log"
cmp "$src/review/proposals.jsonl" "$work/proposals.jsonl"
cmp "$src/review/summary.json" "$work/summary.json"
python3 - "$work/summary.json" <<'PY'
import json,sys
v=json.load(open(sys.argv[1]));assert v['records']==1095 and v['productionApproved']==0 and v['activation'] is False
print('R20_DOCUMENTARY_REPRODUCTION_PASS 1095 ZERO_APPROVALS')
PY
