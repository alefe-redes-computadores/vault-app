#!/usr/bin/env python3
"""A narrowly scoped review proposal; no second writer or recovery authority."""
import hashlib,json,pathlib,sys
from reconcile import check,digest,blob,filemap,read
P=pathlib.Path
PATH='lib/export.ts'
ORIGINAL_BLOB='4b0852b1a394b3f898a219dadb023328ef18edf0'
BEFORE=b"import {TABLES as VITAL_TABLES} from '@/lib/vital/model';"
AFTER=b"import {ALL_VITAL_TABLES as VITAL_TABLES} from '@/lib/vital/model';"

def proposal(source):
 check(source is not None,'global export missing')
 check(source.count(BEFORE)==1 and AFTER not in source,'global export anchor drift; manual review')
 check(source.count(b'VITAL_TABLES.map(')==2,'global export table enumeration changed')
 check(source.count(b'db.transaction("r", tables, async () => {')==1,'global export transaction changed')
 check(source.count(b".filter(r=>r.user_id===userId&&ownedPeople.has(r.person_id))")>=1,'global export account/person filter changed')
 result=source.replace(BEFORE,AFTER)
 check(result.replace(AFTER,BEFORE)==source,'export proposal inverse mismatch')
 return result

def preview(source):
 new=proposal(source)
 return {'status':'PROPOSAL_ONLY_NO_APPROVAL','path':PATH,'pre_sha256':digest(source),'post_sha256':digest(new),'pre_git_blob':blob(source),'post_git_blob':blob(new),'scope':'EXISTING_JSON_EXPORT_READ_ONLY_NOT_RESTORE','reason':'Include recipe identities and immutable versions in the existing account/person-filtered snapshot; preserve the same read transaction and separate encrypted Vital recovery authority. Requires explicit privacy and Guardian review.'}

def apply(candidate,receipt,decision):
 """Only the reversible one-line change may be authorized by this supplemental lane."""
 check(isinstance(decision,dict),'global export decision missing')
 check(decision.get('decision')=='GUARDIAN_AND_OWNER_REVIEWED_GLOBAL_EXPORT','global export not reviewed')
 check(isinstance(decision.get('reason'),str) and decision['reason'].strip() and not decision['reason'].startswith('PENDING'),'missing global export review reason')
 original=read(candidate,PATH);check(original is not None,'global export missing')
 # A joint tree may already contain the same proposal; still require exact reviewed pre/post hashes.
 if AFTER in original:
  check(original.count(AFTER)==1 and BEFORE not in original,'ambiguous export import')
  check(proposal(original.replace(AFTER,BEFORE))==original,'existing global export not equivalent')
  new=original
 else:new=proposal(original)
 check(decision.get('pre_sha256')==digest(original) and decision.get('post_sha256')==digest(new),'global export pre/post approval mismatch')
 expected={k:tuple(v) for k,v in receipt['expected_tree'].items()};check(filemap(candidate)==expected,'candidate changed before supplemental proposal')
 path=candidate/PATH;path.write_bytes(new);expected[PATH]=(blob(new),expected[PATH][1]);check(filemap(candidate)==expected,'unexpected supplemental tree change')
 receipt['expected_tree']={k:list(v) for k,v in sorted(expected.items())};receipt['supplemental_review']={'path':PATH,'decision':decision['decision'],'reason':decision['reason'],'pre_sha256':digest(original),'post_sha256':digest(new),'clinical_writer_changed':False,'restore_authority_changed':False,'production_authority':False}
 return receipt

if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='preview':
  src=P(sys.argv[2]).read_bytes();out=P(sys.argv[3]);out.mkdir(parents=True,exist_ok=False);(out/'export.proposed.ts').write_bytes(proposal(src));(out/'export-review.json').write_text(json.dumps(preview(src),indent=2)+'\n');print('R20_EXPORT_PROPOSAL_ONLY',blob(src),blob(proposal(src)))
 elif mode=='apply':
  candidate=P(sys.argv[2]);receipt=P(sys.argv[3]);m=json.loads(P(sys.argv[4]).read_text());r=apply(candidate,json.loads(receipt.read_text()),m.get('global_export_review'));receipt.write_text(json.dumps(r,indent=2)+'\n');print('R20_GLOBAL_EXPORT_REVIEWED_READ_ONLY')
 else:raise SystemExit('invalid mode')
