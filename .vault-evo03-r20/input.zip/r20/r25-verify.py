#!/usr/bin/env python3
import os,json,sys,urllib.request,importlib,pathlib
v=importlib.import_module('verify-runs')
refs=[(46063005416,'d2a024e72b0a4796ed06ae3064b538c2960d2aeb','VAULT Stability + Macro02 unified R3 CAS - LAB ONLY',('active-pg17','active-browser','H01-H07 Chromium antes e depois (loopback)','release-contracts','Validar e gerar APK')),(46066564778,'109b116e997de0087883c5b0a7deb94143d97ef3','Compilar APK Vault',('Validar e gerar APK',)),(46067729931,'36591d56fbf5431f5aa20643c55760a9b0811cc9','VAULT Macro03 R24 — exact coverage causal proof (LAB ONLY)',('server-review',)),*v.FIXED.values()]
def verify(fetch):
 return [v.verify_one(fetch(f'actions/runs/{id}'),fetch(f'actions/runs/{id}/jobs?per_page=100'),id,sha,name,jobs) for id,sha,name,jobs in refs]
if __name__=='__main__':
 v.check(os.environ.get('GITHUB_ACTIONS')=='true' and os.environ.get('GITHUB_REF')=='refs/heads/vault/lab/evolution03-20261126-r25' and os.environ.get('GITHUB_REPOSITORY')==v.REPO,'STOP lab only')
 token=os.environ['R20_READ_TOKEN']
 def fetch(endpoint):
  req=urllib.request.Request(f'https://api.github.com/repos/{v.REPO}/{endpoint}',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'vault-r25-review'});return json.load(urllib.request.urlopen(req,timeout=30))
 pathlib.Path(sys.argv[1]).write_text(json.dumps(verify(fetch),indent=2,ensure_ascii=False)+'\n');print('R25_CERTIFIED_RUNS_PASS',len(refs))
