import importlib, pathlib, tempfile, unittest, subprocess, json, re, zipfile, hashlib, os
from provenance import source_binding
from reconcile import Blocked,validate_manifest
u=importlib.import_module('contract-union')
P=pathlib.Path
class Provenance(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.repo=P(self.t.name);self.git('init','-q');self.git('config','user.name','Test');self.git('config','user.email','test@example.invalid');(self.repo/'code').write_text('source');self.git('add','code');self.git('commit','-qm','source');self.source=self.git('rev-parse','HEAD');self.tree=self.git('rev-parse','HEAD^{tree}');(self.repo/'code').write_text('envelope');self.git('commit','-qam','envelope');self.envelope=self.git('rev-parse','HEAD');(self.repo/'code').write_text('other');self.git('commit','-qam','other');self.other=self.git('rev-parse','HEAD')
 def tearDown(self):self.t.cleanup()
 def git(self,*args):return subprocess.check_output(['git','-C',str(self.repo),*args],text=True).strip()
 def test_exact_parent(self):self.assertEqual(source_binding(self.repo,self.source,self.envelope,self.tree)['source_sha'],self.source)
 def test_same_head(self):self.assertEqual(source_binding(self.repo,self.source,self.source,self.tree)['run_sha'],self.source)
 def test_wrong_tree(self):
  with self.assertRaises(Blocked):source_binding(self.repo,self.source,self.envelope,self.git('rev-parse',self.envelope+'^{tree}'))
 def test_not_direct_parent(self):
  with self.assertRaises(Blocked):source_binding(self.repo,self.source,self.other,self.tree)
 def test_symbolic_ref_rejected(self):
  with self.assertRaises(Blocked):source_binding(self.repo,'HEAD',self.envelope,self.tree)
 def test_template_remains_blocked(self):
  with self.assertRaises(Blocked):validate_manifest(json.loads((P(__file__).parent/'approved-host.TEMPLATE.json').read_text()))
class ContractUnion(unittest.TestCase):
 a='scripts/test-a.cjs';b='scripts/test-b.mjs';c='scripts/test-c.cjs'
 def test_parse_inline_and_comment(self):self.assertEqual(u.parse('const contracts = [\n "'+self.a+'", "'+self.b+'", // preserved\n];'),[self.a,self.b])
 def test_duplicate_fails(self):
  with self.assertRaises(Blocked):u.parse('const contracts = ["'+self.a+'", "'+self.a+'"];')
 def test_dynamic_fails(self):
  with self.assertRaises(Blocked):u.parse('const contracts = ["'+self.a+'",...other];')
 def test_missing_same_count_fails(self):
  with self.assertRaises(Blocked):u.union([[self.a,self.b]],[self.a,self.c])
 def test_union_accepts_new(self):self.assertEqual(u.union([[self.a,self.b],[self.b,self.c]],[self.a,self.b,self.c,'scripts/test-d.cjs']),{self.a,self.b,self.c})
 def log(self,ns):return '\n'.join([*[f'=== {n} ===' for n in [*ns,*u.EXTRAS]],f'V63_COLETA_INTEGRAL_APROVADA | executadas={len(ns)} | falhas=0',f'VAULT RELEASE GATE V63: {len(ns)} CONTRATOS OK','V70 SUPER INTEGRITY + UX: OK','VAULT V70 FINAL — COMPLETUDE CONTRACT OK'])
 def test_log_correct(self):self.assertEqual(u.execution(self.log([self.a,self.b]),[self.a,self.b]),4)
 def test_log_missing_heading(self):
  with self.assertRaises(Blocked):u.execution(self.log([self.a,self.c]),[self.a,self.b])
 def test_log_failure_marker(self):
  with self.assertRaises(Blocked):u.execution(self.log([self.a])+ '\nV63_FALHA | exit=1 | '+self.a,[self.a])
 def test_log_incomplete_collection(self):
  with self.assertRaises(Blocked):u.execution(self.log([self.a]).replace('falhas=0','falhas=1'),[self.a])
 def test_log_missing_extension(self):
  with self.assertRaises(Blocked):u.execution(self.log([self.a]).replace('=== scripts/test-vault-static-offline-guard.cjs ===',''),[self.a])
 def test_real_stability_log(self):
  p=P(os.environ['R20_STABILITY_LOG_ZIP']);self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),'9cf29b1c3821b606f4e63ba613435595d72d371a6c165a3afa0f2b42e4082528');s=zipfile.ZipFile(p).read('V63-STRICT.log').decode();names=re.findall(r'^=== (scripts/[A-Za-z0-9_./-]+\.(?:cjs|mjs|js))(?: \([^\n]*\))? ===\s*$',s,re.M);self.assertEqual(len(names),586);self.assertEqual(len(set(names)),586);self.assertEqual(u.execution(s,names[:584]),586)
if __name__=='__main__':unittest.main(verbosity=2)
