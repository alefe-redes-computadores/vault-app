#!/usr/bin/env python3
"""Adapt only lab fixtures to the proven additive V60 -> V61 upgrade. No app edits."""
import hashlib,json,pathlib,sys
P=pathlib.Path
SCHEMA=b"if(db.verno!==61||!['vital_recipes','vital_recipe_versions','vital_drafts','vital_sync_ack','syncQueue','macro02_device_enrollment'].every(n=>db.tables.some(t=>t.name===n)))throw Error('Canonical V61 stores missing');"
CHANGES={
 'premium-r12-canonical-fixture.tsx':('32dab30d44ffa68f24d04f0d46ac89f24672e3e96efc35974c0d47480f0a955b',b"if(db.verno!==60||!['vital_recipes','vital_recipe_versions','vital_drafts','vital_sync_ack','syncQueue'].every(n=>db.tables.some(t=>t.name===n)))throw Error('Canonical V60 stores missing');"),
 'premium-r17-catalog-fixture.tsx':('492753b80c0f8ed4d26b0c8391f2da22b11f64ae36fad855c82b7138c46af614',b"if(db.verno!==60)throw Error('Unexpected canonical version');"),
 'r13-consumer-fixture.tsx':('3146d3d068accd75cbe554db5ffecb123894158c2103593d19641cd16961dcae',b"if(db.verno!==60)throw Error('V60 expected');")}
def sha(b):return hashlib.sha256(b).hexdigest()
def adapt(tools):
 changes={}
 for name,(digest,old) in CHANGES.items():
  p=tools/name;a=p.read_bytes();assert sha(a)==digest and a.count(old)==1 and SCHEMA not in a,name
  b=a.replace(old,SCHEMA);assert b.count(SCHEMA)==1 and b.replace(SCHEMA,old)==a,name
  changes[name]=(p,a,b)
 # Label only, preserving the already-adapted R26 branch guard.
 p=tools/'r19-recovery.cjs';a=p.read_bytes();old=b'F2_RECIPE_AND_LABEL_JOURNEY_CANONICAL_V60_SYNTHETIC_AUTH_NO_ACTIVATION';new=old.replace(b'V60',b'V61')
 original=a.replace(b'refs/heads/vault/lab/evolution03-20261126-r26',b'refs/heads/vault/lab/evolution03-20261126-r191')
 assert sha(original)=='88e024c9f4347ca720a8a546490115551d612140bdb0527e7f1e06faa7a94dd8' and a.count(old)==1 and new not in a
 b=a.replace(old,new);assert b.replace(new,old)==a;changes[p.name]=(p,a,b)
 for p,a,b in changes.values():p.write_bytes(b)
 return {n:{'before':sha(a),'after':sha(b)} for n,(p,a,b) in changes.items()}
if __name__=='__main__':
 out=adapt(P(sys.argv[1])/'tools');P(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print('R26_FIXTURE_SCHEMA_ONLY',len(out))
