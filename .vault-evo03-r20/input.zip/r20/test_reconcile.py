import pathlib, tempfile, unittest, subprocess, json, sys, hashlib, shutil
from unittest.mock import patch
import reconcile as r
P=pathlib.Path;ROOT=P(__file__).parent.parent
class TestHelpers(unittest.TestCase):
 def hostdb(self):
  a=(ROOT/'payload/patch/preimage/lib/db/index.ts').read_bytes();s=b'this.version(59).stores({...VITAL_STORES, vital_drafts:DRAFT_STORE, vital_sync_ack:VITAL_ACK_STORE});';assert a.count(s)==1
  return a.replace(s,s+b"\n    this.version(60).stores({macro02_device_enrollment:'account_id'});")
 def test_db_full_historical_with_enrollment(self):
  a=self.hostdb(); b=r.dexie_proposal(a); self.assertEqual(b.count(b'this.version(61).stores(VITAL_RECIPE_STORES);'),1);self.assertIn(b"this.version(60).stores({macro02_device_enrollment:'account_id'});",b)
  self.assertEqual(b.replace(b'\n    // Macro03 R20: additive recipe stores; no capability activation.\n    this.version(61).stores(VITAL_RECIPE_STORES);',b'').replace(b'VITAL_STORES, VITAL_RECIPE_STORES',b'VITAL_STORES',1),a)
 def test_db_future_version(self):
  a=self.hostdb().replace(b"this.version(60).stores({macro02_device_enrollment:'account_id'});",b"this.version(60).stores({macro02_device_enrollment:'account_id'});\n    this.version(61).stores({other:'id'});");self.assertIn(b'this.version(62).stores(VITAL_RECIPE_STORES);',r.dexie_proposal(a))
 def test_db_duplicates_and_missing(self):
  a=self.hostdb()
  for bad in [a.replace(b'this.version(60)',b'this.version(59)'),a.replace(b'macro02_device_enrollment',b'other'),a.replace(b"'@/lib/vital/storage-dexie'",b"'other'"),a+b'\nthis.version(61).stores({other:\'id\'}).upgrade(fn);',a+b'\nthis.version(foo).stores({});',r.dexie_proposal(a)]:
   with self.subTest(bad=hashlib.sha256(bad).hexdigest()),self.assertRaises(r.Blocked):r.dexie_proposal(bad)
 def test_types(self):
  a=b'    | "doseLogs"\n    | "vital_meals"\n    | "foo"\n';b=r.types_proposal(a);self.assertEqual(b.replace(b'    | "vital_recipes"\n    | "vital_recipe_versions"\n',b''),a)
  for bad in [b,a+a,b'no anchor']:
   with self.assertRaises(r.Blocked):r.types_proposal(bad)
 def test_decisions(self):
  for old,new,host,want in [(b'a',b'b',b'a','exact-certified-preimage'),(b'a',b'b',b'b','already-identical'),(b'a',b'b',b'c','collision'),(None,b'b',None,'exact-certified-preimage'),(None,b'b',b'c','collision'),(b'a',None,b'a','exact-certified-preimage'),(b'a',None,None,'already-identical')]:
   self.assertEqual(r.decide(old,new,host)[0],want)
 def test_unsafe_paths(self):
  for k in ['../foo','/x','.git/config','a/../b','a//b','a\\b','']:
   with self.assertRaises(r.Blocked):r.safe_path(k)
 def test_manifest_prohibitions(self):
  m={'status':'GUARDIAN_AND_OWNER_APPROVED_ISOLATED_INTEGRATION','scope':'LAB_ONLY_NO_DEPLOY_NO_MIGRATION_NO_ACTIVATION','macro03_sha':r.CERT,'host_sha':'a'*40,'host_run_sha':'a'*40,'host_source_tree':'e'*40,'stability_sha':'b'*40,'stability_source_sha':'b'*40,'stability_source_tree':'e'*40,'macro02_sha':'c'*40,'macro02_source_sha':'c'*40,'macro02_source_tree':'e'*40,'guardian_receipt':'G','owner_receipt':'O','host_reconciliation_receipt':'H','stability_run':1,'macro02_run':2,'host_run':3,'resolutions':{},'host_resolutions':{}}
  r.validate_manifest(m)
  for k,v in [('host_sha',r.BASE),('status','PENDING'),('scope','PRODUCTION'),('macro03_sha','a'*40),('guardian_receipt','PENDING'),('host_run',0),('stability_sha','main'),('resolutions',[])]:
   with self.subTest(key=k),self.assertRaises(r.Blocked):r.validate_manifest({**m,k:v})
 def test_joint_host_exact_union(self):
  a={'a':('x','100644'),'b':('y','100644')};b={**a,'a':('X','100644')};c={**a,'b':('Y','100644')};d={**b,'b':('Y','100644')};q=r.audit_host_maps(a,b,c,d,{});self.assertEqual(q['unresolved'],[]);self.assertEqual(len(q['rows']),2)
 def test_joint_host_does_not_accept_missing_or_divergent(self):
  a={'a':('x','100644'),'b':('y','100644')};b={**a,'a':('X','100644')};c={**a,'a':('Z','100644'),'b':('Y','100644')};q=r.audit_host_maps(a,b,c,b,{});self.assertEqual(q['unresolved'],['a','b']);entries={k:list(v['a']) for k,v in [('base',a),('stability',b),('macro02',c),('host',b)]};v={'a':{'decision':'GUARDIAN_REVIEWED_HOST_COMPOSITION','entries':entries,'reason':'review'}};q=r.audit_host_maps(a,b,c,b,v);self.assertEqual(q['unresolved'],['b'])
 def test_joint_host_unreviewed_addition(self):
  q=r.audit_host_maps({}, {}, {}, {'new':('x','100644')},{});self.assertEqual(q['unresolved'],['new'])

class TestFull(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.t=P(self.tmp.name);self.repo=self.t/'repo';self.repo.mkdir();self.git('init','-q');self.git('config','user.name','Test');self.git('config','user.email','test@example.invalid');self.p=self.t/'payload';(self.p/'tools').mkdir(parents=True)
  for i in range(102):(self.repo/f'f{i}').write_bytes(f'base {i}'.encode())
  (self.repo/'keep').write_bytes(b'untouched');(self.repo/'keep').chmod(0o755);self.git('add','.');self.git('commit','-qm','base');self.base=self.git('rev-parse','HEAD').strip();self.cert='d'*40
  self.receipt={'target_sha':self.base,'changed_paths':102,'receipts':[{'path':f'f{i}','target_pre_sha256':r.digest(f'base {i}'.encode()),'candidate_post_sha256':r.digest(f'candidate {i}'.encode())} for i in range(102)]}
  (self.p/'receipt.json').write_text(json.dumps(self.receipt));(self.p/'tools/reanchor-review-tree.py').write_text('import sys,pathlib,shutil,json\n_,repo,old,new,report=sys.argv\nshutil.copytree(old,new)\nfor i in range(102): (pathlib.Path(new)/f"f{i}").write_bytes(f"candidate {i}".encode())\nshutil.copyfile(pathlib.Path(__file__).parents[1]/"receipt.json",report)\n')
  (self.repo/'host-extra').write_bytes(b'host owns');self.git('add','host-extra');self.git('commit','-qm','host');self.host=self.git('rev-parse','HEAD').strip();self.oldmap=r.filemap(self.repo) if False else self.git('status','--porcelain');self.patch=patch.multiple(r,BASE=self.base,CERT=self.cert);self.patch.start()
 def tearDown(self):self.patch.stop();self.tmp.cleanup()
 def git(self,*args):return subprocess.check_output(['git','-C',str(self.repo),*args],text=True)
 def manifest(self):return {'status':'GUARDIAN_AND_OWNER_APPROVED_ISOLATED_INTEGRATION','scope':'LAB_ONLY_NO_DEPLOY_NO_MIGRATION_NO_ACTIVATION','macro03_sha':self.cert,'host_sha':self.host,'host_run_sha':self.host,'host_source_tree':'e'*40,'stability_sha':self.host,'stability_source_sha':self.host,'stability_source_tree':'e'*40,'macro02_sha':self.host,'macro02_source_sha':self.host,'macro02_source_tree':'e'*40,'guardian_receipt':'G','owner_receipt':'O','host_reconciliation_receipt':'H','stability_run':1,'macro02_run':2,'host_run':3,'resolutions':{},'host_resolutions':{}}
 def runreconcile(self,m=None,res=None):return r.reconcile(self.repo,self.p,self.receipt,self.host,self.t/'candidate',self.t/'report.json',m,res)
 def test_no_manifest_no_candidate(self):
  q=self.runreconcile();self.assertEqual(q['status'],'BLOCKED_COLLISIONS_OR_NO_APPROVAL');self.assertFalse((self.t/'candidate').exists())
 def test_full_overlay(self):
  q=self.runreconcile(self.manifest());self.assertEqual(q['status'],'INTEGRATED_REVIEW_ONLY');self.assertEqual(q['candidate_files'],104);self.assertEqual((self.t/'candidate/f101').read_bytes(),b'candidate 101');self.assertEqual((self.t/'candidate/host-extra').read_bytes(),b'host owns');self.assertTrue((self.t/'candidate/keep').stat().st_mode&0o100);self.assertEqual(self.git('status','--porcelain'),self.oldmap)
 def collision(self):
  (self.repo/'f0').write_bytes(b'host divergent');self.git('add','f0');self.git('commit','-qm','collision');self.host=self.git('rev-parse','HEAD').strip()
 def test_collision_blocks(self):
  self.collision();q=self.runreconcile(self.manifest());self.assertEqual(q['unresolved'],['f0']);self.assertFalse((self.t/'candidate').exists())
 def test_reviewed_resolution(self):
  self.collision();d=self.t/'res';d.mkdir();(d/'f0').write_bytes(b'composed');m=self.manifest();m['resolutions']['f0']={'decision':'GUARDIAN_REVIEWED_COMPOSED','reason':'synthetic test','host_sha256':r.digest(b'host divergent'),'certified_sha256':r.digest(b'candidate 0'),'post_sha256':r.digest(b'composed')};q=self.runreconcile(m,d);self.assertEqual(q['status'],'INTEGRATED_REVIEW_ONLY');self.assertEqual((self.t/'candidate/f0').read_bytes(),b'composed')
 def test_bad_resolution_hash(self):
  self.collision();d=self.t/'res';d.mkdir();(d/'f0').write_bytes(b'tampered');m=self.manifest();m['resolutions']['f0']={'decision':'GUARDIAN_REVIEWED_COMPOSED','reason':'synthetic','host_sha256':r.digest(b'host divergent'),'certified_sha256':r.digest(b'candidate 0'),'post_sha256':r.digest(b'composed')}
  with self.assertRaises(r.Blocked):self.runreconcile(m,d)
  self.assertFalse((self.t/'candidate').exists())
 def test_existing_target_refused(self):
  (self.t/'candidate').mkdir()
  with self.assertRaises(r.Blocked):self.runreconcile(self.manifest())
 def test_tampered_receipt_refused(self):
  self.receipt['receipts'][0]['candidate_post_sha256']='f'*64
  with self.assertRaises(r.Blocked):self.runreconcile(self.manifest())
 def test_git_mode_preserved(self):
  self.git('update-index','--chmod=+x','f0');self.git('commit','-qm','mode');self.host=self.git('rev-parse','HEAD').strip();q=self.runreconcile(self.manifest());self.assertEqual(q['unresolved'],['f0'])
if __name__=='__main__':unittest.main(verbosity=2)
