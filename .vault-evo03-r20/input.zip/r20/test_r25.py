import unittest,importlib, pathlib, tempfile,json,shutil
from unittest.mock import patch
import reconcile as r
m=importlib.import_module('r25-materialize');v=importlib.import_module('r25-verify');P=pathlib.Path
class Overlay(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.p=P(self.t.name);self.old=self.p/'old';self.new=self.p/'new';self.host=self.p/'host';self.dest=self.p/'candidate'
  for p in (self.old,self.new,self.host):p.mkdir()
  pre=b"import { VITAL_STORES } from '@/lib/vital/storage-dexie';\n    this.version(59).stores({...VITAL_STORES, vital_drafts:DRAFT_STORE, vital_sync_ack:VITAL_ACK_STORE});\n"
  post=pre.replace(b'VITAL_STORES }',b'VITAL_STORES, VITAL_RECIPE_STORES }').replace(b'\n',b'\n',1)+b'    // Macro03: additive recipe storage only; no writer or capability enabled by schema registration.\n    this.version(60).stores(VITAL_RECIPE_STORES);\n'
  ty=b'    | "vital_meals"\n'
  changes={'lib/db/index.ts':(pre,post,pre+b"    this.version(60).stores({macro02_device_enrollment:'account_id'});\n"),'lib/types.ts':(ty,r.types_proposal(ty),b'    | "macro02_device_enrollment"\n'+ty)}
  changes.update({f'lib/f{i}.ts':(f'pre {i}'.encode(),f'post {i}'.encode(),f'pre {i}'.encode()) for i in range(99)});changes['lib/added.ts']=(None,b'new',None)
  self.rows=[]
  for k,(a,b,c) in changes.items():
   for root,data in [(self.old,a),(self.new,b),(self.host,c)]:
    if data is None:continue
    p=root/k;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   self.rows.append({'path':k,'target_pre_sha256':r.digest(a),'target_pre_git_blob':r.blob(a),'candidate_post_sha256':r.digest(b),'candidate_post_git_blob':r.blob(b)})
  for root in (self.old,self.new,self.host):
   p=root/'lib/export.ts';p.write_bytes(b'export original')
   p=root/'keep.sh';p.write_bytes(b'keep mode');p.chmod(0o755)
  (self.host/'host-extra').write_bytes(b'host-owned')
  self.receipt={'changed_paths':102,'receipts':self.rows};self.patcher=patch.object(m,'COLLISIONS',{k:r.blob((self.host/k).read_bytes()) for k in m.COLLISIONS});self.patcher.start()
 def tearDown(self):self.patcher.stop();self.t.cleanup()
 def run_overlay(self):return m.overlay(self.old,self.new,self.host,self.receipt,self.dest)
 def test_overlay_102_preserves_host_and_modes(self):
  before=r.filemap(self.host);out=self.run_overlay();self.assertEqual(out['collision_count'],2);self.assertEqual(out['status'],'LAB_PROPOSAL_ONLY');self.assertFalse(out['guardian_approval']);self.assertFalse(out['production_authority']);self.assertEqual(r.filemap(self.host),before);self.assertEqual((self.dest/'lib/export.ts').read_bytes(),b'export original');self.assertIn(b'this.version(61)',(self.dest/'lib/db/index.ts').read_bytes());self.assertIn(b'macro02_device_enrollment',(self.dest/'lib/types.ts').read_bytes());self.assertTrue((self.dest/'keep.sh').stat().st_mode&0o100);self.assertEqual((self.dest/'host-extra').read_bytes(),b'host-owned');self.assertEqual((self.dest/'lib/added.ts').read_bytes(),b'new')
 def test_third_collision_blocks(self):
  (self.host/'lib/f0.ts').write_bytes(b'changed')
  with self.assertRaises(r.Blocked):self.run_overlay()
  self.assertFalse(self.dest.exists())
 def test_collision_blob_drift_blocks(self):
  (self.host/'lib/db/index.ts').write_bytes(b'changed')
  with self.assertRaises(r.Blocked):self.run_overlay()
  self.assertFalse(self.dest.exists())
 def test_mode_drift_blocks(self):
  (self.host/'lib/f0.ts').chmod(0o755)
  with self.assertRaises(r.Blocked):self.run_overlay()
 def test_receipt_drift_blocks(self):
  self.rows[5]['candidate_post_sha256']='f'*64
  with self.assertRaises(r.Blocked):self.run_overlay()
 def test_unaccounted_cert_change_blocks(self):
  (self.new/'extra').write_bytes(b'not in receipt')
  with self.assertRaises(r.Blocked):self.run_overlay()
 def test_duplicate_path_blocks(self):
  self.rows[-1]=self.rows[0]
  with self.assertRaises(r.Blocked):self.run_overlay()
 def test_existing_destination_blocks(self):
  self.dest.mkdir()
  with self.assertRaises(r.Blocked):self.run_overlay()
class Provenance(unittest.TestCase):
 def fixture(self):
  d={}
  for id,sha,name,jobs in v.refs:
   k=f'actions/runs/{id}';d[k]={'id':id,'head_sha':sha,'name':name,'status':'completed','conclusion':'success','repository':{'full_name':'alefe-redes-computadores/vault-app'}};d[k+'/jobs?per_page=100']={'total_count':len(jobs),'jobs':[{'id':i,'head_sha':sha,'name':j,'status':'completed','conclusion':'success'} for i,j in enumerate(jobs)]}
  return d
 def test_all_six_runs(self):self.assertEqual(len(v.verify(self.fixture().__getitem__)),6)
 def test_wrong_job(self):
  d=self.fixture();d['actions/runs/46063005416/jobs?per_page=100']['jobs'][0]['conclusion']='failure'
  with self.assertRaises(r.Blocked):v.verify(d.__getitem__)
 def test_wrong_source(self):
  d=self.fixture();d['actions/runs/46066564778']['head_sha']='a'*40
  with self.assertRaises(r.Blocked):v.verify(d.__getitem__)
 def test_wrong_repo(self):
  d=self.fixture();d['actions/runs/46067729931']['repository']['full_name']='wrong/repo'
  with self.assertRaises(r.Blocked):v.verify(d.__getitem__)
if __name__=='__main__':unittest.main(verbosity=2)
