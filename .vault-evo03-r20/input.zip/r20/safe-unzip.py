import sys,pathlib,zipfile,stat
root=pathlib.Path(sys.argv[2]);
def require(ok,msg):
 if not ok:raise SystemExit('STOP archive: '+msg)
require(root.is_dir() and not root.is_symlink() and not any(root.iterdir()),'output must be empty')
with zipfile.ZipFile(sys.argv[1]) as z:
 names=z.namelist();require(len(names)==len(set(names)),'duplicate names');require(sum(i.file_size for i in z.infolist())<100_000_000,'size limit')
 for i in z.infolist():
  p=pathlib.PurePosixPath(i.filename);mode=i.external_attr>>16
  require(bool(p.parts) and not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not any(x.lower()=='.git' for x in p.parts),'unsafe path '+i.filename)
  require(not stat.S_ISLNK(mode),'symlink '+i.filename)
 z.extractall(root)
