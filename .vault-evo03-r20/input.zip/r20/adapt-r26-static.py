#!/usr/bin/env python3
"""Change only the exact static-file resolver in the certified Macro02 UI harness."""
import hashlib,pathlib,sys,json
P=pathlib.Path
OLD=b" if(fs.existsSync(f)&&fs.statSync(f).isDirectory())f=path.join(f,'index.html');if(!fs.existsSync(f)&&fs.existsSync(f+'.html'))f+='.html';\n if(!fs.existsSync(f)){res.writeHead(404);return res.end('not found');}"
NEW=b" f=require('./static-export-resolver.cjs')(f);\n if(!f){res.writeHead(404);return res.end('not found');}"
def blob(a):return hashlib.sha1(b'blob '+str(len(a)).encode()+b'\0'+a).hexdigest()
def adapt(a):
 assert blob(a)=='460cd7e8bfb1781b608ce68f7479be00d8b640c5','certified Macro02 harness drift'
 assert a.count(OLD)==1 and NEW not in a
 b=a.replace(OLD,NEW);assert b.replace(NEW,OLD)==a
 return b
if __name__=='__main__':
 p=P(sys.argv[1])/'browser.cjs';a=p.read_bytes();b=adapt(a);p.write_bytes(b);print('R26_STATIC_RESOLVER_ONLY',blob(a),blob(b))
