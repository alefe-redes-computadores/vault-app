'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),resolve=require('./static-export-resolver.cjs');
const root=path.resolve(process.argv[2]);const routes=['/saude/minha-saude','/saude/vital','/saude/vital/treinos','/saude/vital/nutricao','/saude/vital/evolucao','/saude/vital/planos'];const rows=[];
for(const route of routes){const p=path.resolve(root,'.'+route),f=resolve(p);assert.ok(f&&fs.statSync(f).isFile()&&f.startsWith(root+path.sep),`real export missing ${route}`);assert.match(fs.readFileSync(f,'utf8'),/<!DOCTYPE html>|<html/i);rows.push({route,file:path.relative(root,f),directoryExists:fs.existsSync(p)&&fs.statSync(p).isDirectory()});}
assert.equal(resolve(path.join(root,'saude/vital/__r26_nonexistent_route__')),null);assert.equal(new Set(rows.map(r=>r.file)).size,6);console.log(JSON.stringify(rows));console.log('R26_STATIC_EXPORT_ROUTES_PASS',rows.length);
