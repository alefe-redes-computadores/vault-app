import unittest, pathlib, tempfile, importlib, zipfile,hashlib, json,shutil
P=pathlib.Path; root=P(__file__).resolve().parent.parent
f=importlib.import_module('adapt-r26-fixtures');s=importlib.import_module('adapt-r26-static')
class Fixtures(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.p=P(self.t.name);self.tools=self.p/'tools';self.tools.mkdir()
  with zipfile.ZipFile(root/'reference/payload-r24.zip') as z:
   for n in (*f.CHANGES,'r19-recovery.cjs'):
    b=z.read('tools/'+n)
    if n=='r19-recovery.cjs':b=b.replace(b'20261126-r191',b'20261126-r26')
    (self.tools/n).write_bytes(b)
  self.before={p.name:p.read_bytes() for p in self.tools.iterdir()}
 def tearDown(self):self.t.cleanup()
 def test_exact_three_guards_and_one_label(self):
  out=f.adapt(self.tools);self.assertEqual(len(out),4)
  for n,(_,old) in f.CHANGES.items():
   b=(self.tools/n).read_bytes();self.assertEqual(b.replace(f.SCHEMA,old),self.before[n]);self.assertEqual(b.count(f.SCHEMA),1)
  self.assertEqual((self.tools/'r19-recovery.cjs').read_bytes().replace(b'CANONICAL_V61_SYNTHETIC',b'CANONICAL_V60_SYNTHETIC'),self.before['r19-recovery.cjs'])
 def test_source_drift_blocked_before_any_write(self):
  p=self.tools/'r13-consumer-fixture.tsx';p.write_bytes(p.read_bytes()+b'\n')
  with self.assertRaises(AssertionError):f.adapt(self.tools)
  self.assertEqual((self.tools/'premium-r12-canonical-fixture.tsx').read_bytes(),self.before['premium-r12-canonical-fixture.tsx'])
 def test_recovery_drift_blocks_all_writes(self):
  p=self.tools/'r19-recovery.cjs';p.write_bytes(p.read_bytes()+b'\n')
  with self.assertRaises(AssertionError):f.adapt(self.tools)
  self.assertEqual((self.tools/'premium-r17-catalog-fixture.tsx').read_bytes(),self.before['premium-r17-catalog-fixture.tsx'])
 def test_repeat_blocked(self):
  f.adapt(self.tools)
  with self.assertRaises(AssertionError):f.adapt(self.tools)
 def test_strict_version_not_minimum(self):self.assertIn(b'db.verno!==61',f.SCHEMA);self.assertNotIn(b'>=',f.SCHEMA)
 def test_no_unknown_static_source(self):
  with self.assertRaises(AssertionError):s.adapt(s.OLD)
 def test_receipt_bound_to_actual_r25(self):
  a=(root/'reference/r25-materialization.json').read_bytes();self.assertEqual(hashlib.sha256(a).hexdigest(),'b8ba7e5c77be64d6df6ecbd9cf159cace4efdfc5fbbe5693ce566d2793078df5');j=json.loads(a);self.assertEqual(len(j['rows']),102);self.assertEqual(j['collision_count'],2);self.assertFalse(j['production_authority']);self.assertFalse(j['guardian_approval'])
 def test_payload_unchanged(self):self.assertEqual(hashlib.sha256((root/'reference/payload-r24.zip').read_bytes()).hexdigest(),'5d9db24b7344dc5bcaa80a3c980850e1d72ae0498d1dd9bd889761d1a7f98658')
if __name__=='__main__':unittest.main(verbosity=2)
