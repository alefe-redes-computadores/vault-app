import pathlib,tempfile,unittest,importlib,sys,json
from reconcile import Blocked,filemap,digest,blob
x=importlib.import_module('export-review');P=pathlib.Path
class ExportProposal(unittest.TestCase):
 def setUp(self):
  self.source=(P(__file__).parent.parent/'reference/export-macro02.ts').read_bytes();self.new=x.proposal(self.source);self.tmp=tempfile.TemporaryDirectory();self.root=P(self.tmp.name);(self.root/'lib').mkdir();(self.root/x.PATH).write_bytes(self.source);(self.root/'keep').write_text('unchanged');self.receipt={'expected_tree':{k:list(v) for k,v in filemap(self.root).items()}};self.decision={'decision':'GUARDIAN_AND_OWNER_REVIEWED_GLOBAL_EXPORT','reason':'SYNTHETIC TEST ONLY','pre_sha256':digest(self.source),'post_sha256':digest(self.new)}
 def tearDown(self):self.tmp.cleanup()
 def test_exact_git_blob(self):self.assertEqual(blob(self.source),x.ORIGINAL_BLOB);self.assertEqual(self.new.replace(x.AFTER,x.BEFORE),self.source)
 def test_proposal_not_approval(self):self.assertEqual(x.preview(self.source)['status'],'PROPOSAL_ONLY_NO_APPROVAL')
 def test_no_decision(self):
  with self.assertRaises(Blocked):x.apply(self.root,self.receipt,None)
  self.assertEqual((self.root/x.PATH).read_bytes(),self.source)
 def test_wrong_postimage(self):
  with self.assertRaises(Blocked):x.apply(self.root,self.receipt,{**self.decision,'post_sha256':'f'*64})
  self.assertEqual((self.root/x.PATH).read_bytes(),self.source)
 def test_wrong_preimage(self):
  with self.assertRaises(Blocked):x.apply(self.root,self.receipt,{**self.decision,'pre_sha256':'f'*64})
 def test_unchanged_elsewhere(self):
  old=filemap(self.root);r=x.apply(self.root,self.receipt,self.decision);self.assertEqual((self.root/x.PATH).read_bytes(),self.new);self.assertEqual(filemap(self.root),{**old,x.PATH:(blob(self.new),old[x.PATH][1])});self.assertFalse(r['supplemental_review']['restore_authority_changed'])
 def test_drift_detection(self):
  for text in [self.source.replace(x.BEFORE,b'bad'),self.source.replace(b'VITAL_TABLES.map(',b'OTHER.map(',1),self.source.replace(b'db.transaction("r",',b'db.transaction("rw",'),self.source.replace(b'ownedPeople.has(r.person_id)',b'true')]:
   with self.subTest(text=digest(text)),self.assertRaises(Blocked):x.proposal(text)
 def test_already_in_host_needs_exact_review(self):
  (self.root/x.PATH).write_bytes(self.new);self.receipt['expected_tree']={k:list(v) for k,v in filemap(self.root).items()}
  with self.assertRaises(Blocked):x.apply(self.root,self.receipt,self.decision)
  decision={**self.decision,'pre_sha256':digest(self.new)};x.apply(self.root,self.receipt,decision);self.assertEqual((self.root/x.PATH).read_bytes(),self.new)
 def test_tree_drift(self):
  (self.root/'keep').write_text('changed')
  with self.assertRaises(Blocked):x.apply(self.root,self.receipt,self.decision)
 def test_pending_not_approved(self):
  with self.assertRaises(Blocked):x.apply(self.root,self.receipt,{**self.decision,'reason':'PENDING'})
if __name__=='__main__':unittest.main(verbosity=2)
