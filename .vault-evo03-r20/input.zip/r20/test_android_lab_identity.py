import importlib,unittest,tempfile,zipfile,pathlib
from reconcile import Blocked
m=importlib.import_module('android-lab-identity')
class Identity(unittest.TestCase):
 gradle='android {\n defaultConfig {\n applicationId "com.alefejohsefe.vault"\n }\n}\n'
 def test_isolated_suffix(self):self.assertEqual(m.apply(self.gradle).removesuffix(m.SUFFIX),self.gradle)
 def test_existing_suffix(self):
  with self.assertRaises(Blocked):m.apply(m.apply(self.gradle))
 def test_wrong_app(self):
  with self.assertRaises(Blocked):m.apply(self.gradle.replace(m.APP,'other.app'))
 def test_duplicate_base(self):
  with self.assertRaises(Blocked):m.apply(self.gradle+self.gradle)
 def test_badging(self):m.verify_badging("package: name='com.alefejohsefe.vault.r20lab'\nuses-permission: name='android.permission.health.READ_NUTRITION'\n")
 def test_production_apk_blocked(self):
  with self.assertRaises(Blocked):m.verify_badging("package: name='com.alefejohsefe.vault'\nuses-permission: name='android.permission.health.READ_NUTRITION'\n")
 def test_missing_permission(self):
  with self.assertRaises(Blocked):m.verify_badging("package: name='com.alefejohsefe.vault.r20lab'\n")
 def test_dex_sentinels(self):
  # synthetic ZIP tests parser only, not APK/Dex compilation.
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'fake.apk';classes=['VaultNutritionCapturePlugin','VaultNutritionFileProvider','VaultHealthConnectPlugin','VaultApkUpdaterPlugin'];data=[('L'+m.APP.replace('.','/')+'/'+n+';').encode() for n in classes]
   with zipfile.ZipFile(p,'w') as z:z.writestr('classes.dex',b'\x00'.join(data))
   m.verify_dex(p)
   with zipfile.ZipFile(p,'w') as z:z.writestr('classes.dex',data[0])
   with self.assertRaises(Blocked):m.verify_dex(p)
if __name__=='__main__':unittest.main(verbosity=2)
