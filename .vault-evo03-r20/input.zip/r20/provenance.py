#!/usr/bin/env python3
"""Exact source/tree vs Actions envelope, no deployment or Git writes."""
import json,sys,pathlib,subprocess,re
from reconcile import check,HEX
P=pathlib.Path

def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def source_binding(repo,source,envelope,tree):
 for v in (source,envelope,tree):check(isinstance(v,str) and HEX.fullmatch(v),'invalid provenance SHA')
 check(git(repo,'rev-parse',source+'^{commit}')==source,'source commit mismatch')
 check(git(repo,'rev-parse',envelope+'^{commit}')==envelope,'envelope commit mismatch')
 check(git(repo,'rev-parse',source+'^{tree}')==tree,'source tree mismatch')
 if source!=envelope:
  parents=git(repo,'show','-s','--format=%P',envelope).split()
  check(len(parents)==1 and parents[0]==source,'source is not the exact single parent of envelope')
 return {'source_sha':source,'source_tree':tree,'run_sha':envelope}

def binding_fields(m,kind):
 return (m[kind+'_source_sha'] if kind!='host' else m['host_sha'],m[kind+'_sha'] if kind!='host' else m['host_run_sha'],m[kind+'_source_tree'])

def verify(repo,m):return {k:source_binding(repo,*binding_fields(m,k)) for k in ('stability','macro02','host')}
if __name__=='__main__':
 repo,manifest,out=sys.argv[1:];m=json.loads(P(manifest).read_text());result=verify(repo,m);P(out).write_text(json.dumps(result,indent=2)+'\n');print('R20_EXACT_SOURCE_ENVELOPE_BINDINGS_PASS',len(result))
