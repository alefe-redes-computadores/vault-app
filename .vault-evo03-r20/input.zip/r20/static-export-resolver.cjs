'use strict';
// For a path already validated inside the static export root. A directory
// of child pages does not shadow the parent route's actual sibling .html.
const fs=require('node:fs'),path=require('node:path');
const file=p=>{try{return fs.statSync(p).isFile()}catch(e){if(['ENOENT','ENOTDIR'].includes(e.code))return false;throw e}};
module.exports=function resolveStaticFile(f){
 if(file(f))return f;
 const index=path.join(f,'index.html');if(file(index))return index;
 const sibling=f+'.html';if(file(sibling))return sibling;
 return null;
};
