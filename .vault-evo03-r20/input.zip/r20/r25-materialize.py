#!/usr/bin/env python3
"""Create only a disposable LAB PROPOSAL, never an approved host or productive release."""
import pathlib as pl,sys,json,tempfile,shutil,subprocess,hashlib
import reconcile as r
P=pl.Path
HOST='109b116e997de0087883c5b0a7deb94143d97ef3'
TREE='f91ae395bce3e4dd47ce84a3730898a35d50050d'
UNIFIED='d2a024e72b0a4796ed06ae3064b538c2960d2aeb'
COLLISIONS={'lib/db/index.ts':'70fc74cb35ff87fedf35d88a9f27045b68cf880a','lib/types.ts':'41c50f1fac242ac45ff94cc25f8cba10fab45f7d'}

def compose(k,old,new,host):
 r.check(r.blob(host)==COLLISIONS[k],'host collision drift '+k)
 if k=='lib/db/index.ts':
  old_anchor=b'this.version(59).stores({...VITAL_STORES, vital_drafts:DRAFT_STORE, vital_sync_ack:VITAL_ACK_STORE});'
  pre=b"import { VITAL_STORES } from '@/lib/vital/storage-dexie';"
  post=b"import { VITAL_STORES, VITAL_RECIPE_STORES } from '@/lib/vital/storage-dexie';"
  original_delta=old.replace(pre,post).replace(old_anchor,old_anchor+b'\n    // Macro03: additive recipe storage only; no writer or capability enabled by schema registration.\n    this.version(60).stores(VITAL_RECIPE_STORES);')
  r.check(original_delta==new,'certified DB delta changed')
  out=r.dexie_proposal(host)
  r.check(out.count(b'this.version(61).stores(VITAL_RECIPE_STORES);')==1,'expected exact schema 61')
  return out
 r.check(r.types_proposal(old)==new,'certified type delta changed');return r.types_proposal(host)

def overlay(old,new,host,receipt,dest):
 r.check(not dest.exists(),'candidate already exists');initial=r.filemap(host);prev=r.filemap(old);cert=r.filemap(new)
 rows=[];updates={};collisions=set()
 r.check(receipt['changed_paths']==102 and len(receipt['receipts'])==102 and len({x['path'] for x in receipt['receipts']})==102,'exact receipt required')
 for row in receipt['receipts']:
  k=row['path'];a,b,c=(r.read(x,k) for x in (old,new,host))
  r.check(r.digest(a)==row['target_pre_sha256'] and r.digest(b)==row['candidate_post_sha256'] and r.blob(a)==row['target_pre_git_blob'] and r.blob(b)==row['candidate_post_git_blob'],'certified bytes changed '+k)
  if k in COLLISIONS:
   r.check(initial.get(k,('',''))[1]==prev.get(k,('',''))[1],'mode collision '+k);d=compose(k,a,b,c);decision='additive-proposal-pending-guardian';collisions.add(k)
  else:
   r.check(c==a and initial.get(k)==prev.get(k),'unexpected host collision '+k);d=b;decision='exact-certified-preimage'
  updates[k]=d;rows.append({'path':k,'decision':decision,'host_sha256':r.digest(c),'certified_sha256':r.digest(b),'post_sha256':r.digest(d)})
 r.check(collisions==set(COLLISIONS),'expected collision set mismatch')
 r.check(set(updates)=={k for k in set(prev)|set(cert) if prev.get(k)!=cert.get(k)},'unaccounted certified change')
 expected=dict(initial);shutil.copytree(host,dest)
 try:
  for k,b in updates.items():
   q=dest/k
   if b is None:q.unlink();expected.pop(k,None);continue
   mode=initial.get(k,cert[k])[1];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);q.chmod(0o755 if mode=='100755' else 0o644);expected[k]=(r.blob(b),mode)
  r.check(r.filemap(dest)==expected and r.filemap(host)==initial,'unexpected candidate or host change')
  r.check(r.read(dest,'lib/export.ts')==r.read(host,'lib/export.ts'),'privacy review bypassed')
 except BaseException:shutil.rmtree(dest);raise
 return {'status':'LAB_PROPOSAL_ONLY','host_sha':HOST,'host_tree':TREE,'guardian_approval':False,'production_authority':False,'rows':rows,'expected_tree':{k:list(v) for k,v in sorted(expected.items())},'candidate_files':len(expected),'collision_count':len(collisions),'global_export':'UNCHANGED_PENDING_PRIVACY_REVIEW'}

def main():
 repo,lab,stage,evidence=map(P,sys.argv[1:]);repo=repo.resolve();lab=lab.resolve();stage=stage.resolve();evidence=evidence.resolve()
 r.check(repo not in lab.parents and repo not in evidence.parents,'unsafe output')
 r.check(r.git(repo,'rev-parse',HOST+'^{tree}').decode().strip()==TREE,'host tree drift')
 r.check(r.git(repo,'rev-parse',UNIFIED+'^').decode().strip()==HOST,'unified run source drift')
 receipt=json.loads((stage/'reference/r191-reanchor.json').read_text())
 with tempfile.TemporaryDirectory(prefix='vault-r25-') as td:
  t=P(td);old=t/'old';new=t/'certified';host=t/'host';report=t/'receipt.json';r.archive(repo,r.BASE,old);r.archive(repo,HOST,host)
  subprocess.run(['python3',str(lab/'tools/reanchor-review-tree.py'),str(repo),str(old),str(new),str(report)],check=True)
  r.check(json.loads(report.read_text())==receipt,'R24/R191 reanchor receipt changed')
  result=overlay(old,new,host,receipt,lab/'candidate')
  audit=r.audit_host_maps(r.tree(repo,r.BASE),r.tree(repo,'b5d956ce4a011f43f6ccb3a5ac6be284e41fbaf0'),r.tree(repo,'471caebe7965eda437ee0b2ee274d20ba819b0b2'),r.tree(repo,HOST),{})
  r.check(len(audit['rows'])==236 and len(audit['unresolved'])==34,'host audit drift')
  result['joint_host_audit']=audit
  for f in (lab/'tests/fixture-lib').rglob('*.ts'):
   k=f.relative_to(lab/'tests/fixture-lib');r.check(f.read_bytes()==(lab/'candidate/lib'/k).read_bytes(),'fixture/runtime drift '+str(k))
  (lab/'r20-receipt.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');shutil.copyfile(lab/'r20-receipt.json',evidence/'r25-materialization.json')
  print('R25_LAB_PROPOSAL_ONLY',len(result['rows']),result['collision_count'],result['candidate_files'])
if __name__=='__main__':main()
