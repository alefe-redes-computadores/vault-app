'use strict';
const assert=require('node:assert/strict'),test=require('node:test'),fs=require('node:fs'),path=require('node:path');
// Read the actual guard emitted in the three adapted fixture files.
const tools=process.argv[2];if(!tools)throw Error('fixture directory required');
const names=['premium-r12-canonical-fixture.tsx','premium-r17-catalog-fixture.tsx','r13-consumer-fixture.tsx'];
const required=['vital_recipes','vital_recipe_versions','vital_drafts','vital_sync_ack','syncQueue','macro02_device_enrollment'];
for(const n of names){const source=fs.readFileSync(path.join(tools,n),'utf8');const matches=[...source.matchAll(/if\(db\.verno!==61\|\|!\[.*?\]\.every\(n=>db\.tables\.some\(t=>t\.name===n\)\)\)throw Error\('Canonical V61 stores missing'\);/g)];assert.equal(matches.length,1);const check=new Function('db',matches[0][0]);const db=(verno,tables=required)=>({verno,tables:tables.map(name=>({name}))});test(n+' exact 61 accepts all required tables',()=>assert.doesNotThrow(()=>check(db(61))));for(const ver of [59,60,62])test(n+' rejects version '+ver,()=>assert.throws(()=>check(db(ver)),/Canonical V61 stores missing/));for(const table of required)test(n+' rejects missing '+table,()=>assert.throws(()=>check(db(61,required.filter(x=>x!==table))),/Canonical V61 stores missing/));}
