'use strict';
// Called AFTER all original Macro02 active-Premium assertions, using the same
// actual Next export, authenticated synthetic profile, real browser + IndexedDB.
module.exports=async({page,navigate,local,assert,screenshot})=>{
 const results=[];const route=async(expected,back)=>{await page.waitForURL(u=>u.pathname.replace(/\/$/,'')===expected&&(!back||u.searchParams.get('return_to')===back),{timeout:60000});};
 const hub=()=>page.getByRole('heading',{name:'Meu dia',exact:true});const nav=()=>page.getByRole('navigation',{name:'Navegação interna do Vital'});const back=()=>page.getByRole('button',{name:'Voltar',exact:true}).first();
 const pendingClinical=s=>s.queue.filter(q=>q.payload?.macro02_atomic||q.payload?.macro02_compound||q.payload?.macro02_metadata).map(q=>q.id).sort();const before=await local();
 for(const width of [320,390,430]){await page.setViewportSize({width,height:850});await navigate('/saude/minha-saude');const entry=page.getByRole('region',{name:'Acesso permanente ao Vital'}).getByRole('button',{name:'Abrir Vital',exact:true});await entry.waitFor({timeout:60000});await entry.click();await route('/saude/vital','/saude/minha-saude');await hub().waitFor({timeout:60000});assert.equal(await page.getByRole('button',{name:'Escanear alimento',exact:true}).count(),0,'F2 must remain locked');assert.equal(await page.getByRole('button',{name:/^Receitas culinárias/}).count(),0);results.push([width,'real-global-entry']);
 for(const [label,dest] of [['Treinos','treinos'],['Nutrição','nutricao'],['Evolução','evolucao'],['Planos','planos']]){await nav().getByRole('button',{name:label,exact:true}).click();await route('/saude/vital/'+dest,'/saude/vital');await nav().getByRole('button',{name:label,exact:true}).waitFor();assert.equal(await nav().getByRole('button',{name:label,exact:true}).getAttribute('aria-current'),'page');await back().click();await route('/saude/vital');await hub().waitFor();assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));results.push([width,dest]);}
 await page.getByRole('button',{name:'Configurações do Vital',exact:true}).click();await page.waitForURL(u=>u.pathname.replace(/\/$/,'')==='/saude/vital'&&u.searchParams.get('view')==='settings');await page.getByText('Cópia cifrada e recuperação',{exact:true}).waitFor();await back().click();await route('/saude/vital');await hub().waitFor();results.push([width,'settings']);
 await navigate('/saude/vital?return_to=%2Fsaude%2Fminha-saude');await hub().waitFor();await back().click();await route('/saude/minha-saude');await entry.waitFor();results.push([width,'real-context-return']);await screenshot('r20-vital-global-'+width);
 }
 // Reattach the already certified inspection bundle, only read clinical state.
 return {results,beforePending:pendingClinical(before)};
};
