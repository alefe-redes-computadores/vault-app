#!/usr/bin/env bash
# Owner-authorized, disposable lab proposal only. No production release, no migration or activation.
set -euo pipefail
unset PYTHONOPTIMIZE
[[ $# == 3 ]] || { echo 'Usage: launch-r25.sh EXISTING_REPO INPUT.zip EXPECTED_SHA256'; exit 2; }
repo=$(realpath "$1"); input=$(realpath "$2"); expected=$3
[[ $expected =~ ^[0-9a-f]{64}$ && $(sha256sum "$input" | cut -d' ' -f1) == "$expected" ]] || { echo 'STOP input SHA';exit 2; }
origin=$(git -C "$repo" remote get-url origin);case "$origin" in https://github.com/alefe-redes-computadores/vault-app|https://github.com/alefe-redes-computadores/vault-app.git|git@github.com:alefe-redes-computadores/vault-app.git|ssh://git@github.com/alefe-redes-computadores/vault-app.git) ;; *) echo 'STOP wrong origin';exit 2;;esac
host=109b116e997de0087883c5b0a7deb94143d97ef3;branch=vault/lab/evolution03-20261126-r26
remote_main(){ git ls-remote --exit-code "$origin" refs/heads/main | cut -f1; }
remote_head=$(remote_main)
[[ $remote_head =~ ^[0-9a-f]{40}$ ]] || { echo 'STOP unable to pin remote main';exit 2; }
set +e;git ls-remote --exit-code --heads "$origin" "refs/heads/$branch" >/dev/null;rc=$?;set -e;[[ $rc == 2 ]] || { echo 'STOP branch exists or remote unavailable';exit 2; }
work=$(mktemp -d);trap 'rm -rf -- "$work"' EXIT
mkdir "$work/input";python3 "$(dirname "$0")/safe-unzip.py" "$input" "$work/input"
(cd "$work/input";sha256sum -c SHA256SUMS.txt >/dev/null)
PYTHONDONTWRITEBYTECODE=1 python3 "$work/input/r20/test_r25.py"
PYTHONDONTWRITEBYTECODE=1 python3 "$work/input/r20/test_r26.py"
git clone --no-local --no-checkout "$repo" "$work/repo"
cd "$work/repo"
git fetch --no-tags "$origin" "$remote_head" "$host" a3cf60081b0f53fe8bbb14754526c5a7cec97f05 bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b d2a024e72b0a4796ed06ae3064b538c2960d2aeb b5d956ce4a011f43f6ccb3a5ac6be284e41fbaf0 471caebe7965eda437ee0b2ee274d20ba819b0b2 36591d56fbf5431f5aa20643c55760a9b0811cc9
git merge-base --is-ancestor "$host" "$remote_head" || { echo 'STOP main is not descended from R25 host';exit 2; }
[[ $(git rev-parse a3cf60081b0f53fe8bbb14754526c5a7cec97f05^) == "$host" ]] || { echo 'STOP R25 ancestry';exit 2; }
[[ $(git show a3cf60081b0f53fe8bbb14754526c5a7cec97f05:.vault-evo03-r20/input.sha256 | cut -d' ' -f1) == 3b88dbc00c5a9f166239c37fcd78e1fe264e78ae308cc2218dc82ab48236bbdd ]] || { echo 'STOP R25 payload identity';exit 2; }
printf 'R26_HISTORICAL_HOST=%s OBSERVED_MAIN=%s NO_MAIN_WRITE\n' "$host" "$remote_head"
# No app changes on the owner's checkout; no npm or Android build on phone.
mkdir "$work/lab" "$work/evidence"
python3 "$work/input/r20/safe-unzip.py" "$work/input/reference/payload-r24.zip" "$work/lab"
(cd "$work/lab";sha256sum -c CI-SHA256SUMS.txt >/dev/null)
python3 "$work/input/r20/r25-materialize.py" "$PWD" "$work/lab" "$work/input" "$work/evidence"
cmp "$work/lab/r20-receipt.json" "$work/input/reference/r25-materialization.json"
python3 "$work/input/r20/contract-union.py" "$PWD" "$work/input/reference/source-manifest.json" "$work/lab/candidate" - "$work/evidence/v63-union.json"
# Keep actual preflight receipts in downloads, not in app tree. No private user data or credentials.
reportdir=$(dirname "$input"); if [[ -n ${R25_REPORT_DIR:-} ]];then reportdir=$R25_REPORT_DIR;fi
mkdir -p "$reportdir"; report=$(mktemp "$reportdir/VAULT-R26-PREFLIGHT.XXXXXX.json");cp "$work/evidence/r25-materialization.json" "$report";printf 'R26_PREFLIGHT_RECEIPT=%s\n' "$report"
# The actual envelope contains only test tooling. App source assembled in RUNNER_TEMP.
git checkout --detach "$host"
mkdir -p .vault-evo03-r20 .github/workflows
cp "$input" .vault-evo03-r20/input.zip;printf '%s  .vault-evo03-r20/input.zip\n' "$expected" > .vault-evo03-r20/input.sha256
cp "$work/input/r20/prepare.sh" .vault-evo03-r20/prepare.sh
cp "$work/input/r20/workflow.yml" .github/workflows/vault-evolution03-r26-review.yml
printf '{"git":{"deploymentEnabled":false},"ignoreCommand":"exit 0"}\n' > vercel.json
git add -- .vault-evo03-r20/input.zip .vault-evo03-r20/input.sha256 .vault-evo03-r20/prepare.sh .github/workflows/vault-evolution03-r26-review.yml vercel.json
git diff --cached --check
git -c user.name='VAULT Guardian Laboratory' -c user.email='vault-guardian-lab@users.noreply.github.com' commit -m 'test(vault): Macro03 R26 identical integrated proposal - fixture schema and static resolver - laboratory only, no activation'
[[ $(remote_main) == "$remote_head" ]] || { echo 'STOP main moved during preflight; repeat with fresh ancestry check';exit 2; }
git push "$origin" "HEAD:refs/heads/$branch"
printf 'LAB BRANCH=%s COMMIT=%s\n' "$branch" "$(git rev-parse HEAD)"
