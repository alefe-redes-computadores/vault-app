#!/usr/bin/env bash
# Owner-authorized, disposable lab proposal only. No production release, no migration or activation.
set -euo pipefail
unset PYTHONOPTIMIZE
[[ $# == 3 ]] || { echo 'Usage: launch-r25.sh EXISTING_REPO INPUT.zip EXPECTED_SHA256'; exit 2; }
repo=$(realpath "$1"); input=$(realpath "$2"); expected=$3
[[ $expected =~ ^[0-9a-f]{64}$ && $(sha256sum "$input" | cut -d' ' -f1) == "$expected" ]] || { echo 'STOP input SHA';exit 2; }
origin=$(git -C "$repo" remote get-url origin);case "$origin" in https://github.com/alefe-redes-computadores/vault-app|https://github.com/alefe-redes-computadores/vault-app.git|git@github.com:alefe-redes-computadores/vault-app.git|ssh://git@github.com/alefe-redes-computadores/vault-app.git) ;; *) echo 'STOP wrong origin';exit 2;;esac
host=109b116e997de0087883c5b0a7deb94143d97ef3;branch=vault/lab/evolution03-20261126-r25
remote_main(){ git ls-remote --exit-code "$origin" refs/heads/main | cut -f1; }
[[ $(remote_main) == "$host" ]] || { echo 'STOP main advanced; reconcile exact new source';exit 2; }
set +e;git ls-remote --exit-code --heads "$origin" "refs/heads/$branch" >/dev/null;rc=$?;set -e;[[ $rc == 2 ]] || { echo 'STOP branch exists or remote unavailable';exit 2; }
work=$(mktemp -d);trap 'rm -rf -- "$work"' EXIT
mkdir "$work/input";python3 "$(dirname "$0")/safe-unzip.py" "$input" "$work/input"
(cd "$work/input";sha256sum -c SHA256SUMS.txt >/dev/null)
PYTHONDONTWRITEBYTECODE=1 python3 "$work/input/r20/test_r25.py"
git clone --no-local --no-checkout "$repo" "$work/repo"
cd "$work/repo"
git fetch --no-tags "$origin" "$host" bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b d2a024e72b0a4796ed06ae3064b538c2960d2aeb b5d956ce4a011f43f6ccb3a5ac6be284e41fbaf0 471caebe7965eda437ee0b2ee274d20ba819b0b2 36591d56fbf5431f5aa20643c55760a9b0811cc9
# No app changes on the owner's checkout; no npm or Android build on phone.
mkdir "$work/lab" "$work/evidence"
python3 "$work/input/r20/safe-unzip.py" "$work/input/reference/payload-r24.zip" "$work/lab"
(cd "$work/lab";sha256sum -c CI-SHA256SUMS.txt >/dev/null)
python3 "$work/input/r20/r25-materialize.py" "$PWD" "$work/lab" "$work/input" "$work/evidence"
python3 "$work/input/r20/contract-union.py" "$PWD" "$work/input/reference/source-manifest.json" "$work/lab/candidate" - "$work/evidence/v63-union.json"
# Keep actual preflight receipts in downloads, not in app tree. No private user data or credentials.
reportdir=$(dirname "$input"); if [[ -n ${R25_REPORT_DIR:-} ]];then reportdir=$R25_REPORT_DIR;fi
mkdir -p "$reportdir"; report=$(mktemp "$reportdir/VAULT-R25-PREFLIGHT.XXXXXX.json");cp "$work/evidence/r25-materialization.json" "$report";printf 'R25_PREFLIGHT_RECEIPT=%s\n' "$report"
# The actual envelope contains only test tooling. App source assembled in RUNNER_TEMP.
git checkout --detach "$host"
mkdir -p .vault-evo03-r20 .github/workflows
cp "$input" .vault-evo03-r20/input.zip;printf '%s  .vault-evo03-r20/input.zip\n' "$expected" > .vault-evo03-r20/input.sha256
cp "$work/input/r20/prepare.sh" .vault-evo03-r20/prepare.sh
cp "$work/input/r20/workflow.yml" .github/workflows/vault-evolution03-r25-review.yml
printf '{"git":{"deploymentEnabled":false},"ignoreCommand":"exit 0"}\n' > vercel.json
git add -- .vault-evo03-r20/input.zip .vault-evo03-r20/input.sha256 .vault-evo03-r20/prepare.sh .github/workflows/vault-evolution03-r25-review.yml vercel.json
git diff --cached --check
git -c user.name='VAULT Guardian Laboratory' -c user.email='vault-guardian-lab@users.noreply.github.com' commit -m 'test(vault): Macro03 R25 integrated proposal - laboratory only, no activation'
[[ $(remote_main) == "$host" ]] || { echo 'STOP main moved before push';exit 2; }
git push "$origin" "HEAD:refs/heads/$branch"
printf 'LAB BRANCH=%s COMMIT=%s\n' "$branch" "$(git rev-parse HEAD)"
