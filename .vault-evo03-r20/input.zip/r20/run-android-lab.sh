#!/usr/bin/env bash
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r26 && ${GITHUB_REPOSITORY:-} == alefe-redes-computadores/vault-app && $PWD == "$EVO03_LAB/candidate" && ! -e .git ]] || { echo 'STOP compile-only isolated candidate'; exit 2; }
# No access to production Supabase, signing key, or activation flag.
export NEXT_PUBLIC_SUPABASE_URL=https://vault-r20-lab.invalid NEXT_PUBLIC_SUPABASE_ANON_KEY=ci-synthetic-not-a-production-key NEXT_TELEMETRY_DISABLED=1
for k in VAULT_DEBUG_KEYSTORE_BASE64 VAULT_RELEASE_KEYSTORE_BASE64 SUPABASE_SERVICE_ROLE_KEY SUPABASE_DB_URL DATABASE_URL; do [[ -z ${!k:-} ]] || { echo "STOP inherited $k";exit 2; }; done
export NEXT_PUBLIC_VAULT_NATIVE_RUNTIME=android CAPACITOR_BUILD=1
node scripts/ci-build-export-resilient.cjs
test -f out/index.html
cap=node_modules/.bin/cap
if [[ -d android ]]; then "$cap" sync android; else "$cap" add android; fi
test -f assets/icon.png && test -f assets/splash.png
node_modules/.bin/capacitor-assets generate --android
"$cap" sync android
node scripts/validate-android-bridge-v29.mjs
node scripts/patch-android-edge-to-edge-v28.mjs
node scripts/patch-android-health-connect-v113.mjs
node scripts/patch-android-exact-alarms-m99.mjs
node scripts/apply-android-native-updater-m111.mjs
node scripts/check-android-native-updater-m111.mjs
mkdir -p android/app/src/main/res/drawable
cp assets/android/ic_stat_vault.xml android/app/src/main/res/drawable/ic_stat_vault.xml
python3 scripts/prepare-android-nutrition-f2.py --root "$PWD" --isolated-review --health-connect-nutrition-review
python3 "$R20_STAGE/r20/android-lab-identity.py" apply android/app/build.gradle
# Ephemeral runner debug key only. Never use production key; never publish/promote.
(cd android; chmod +x gradlew; ./gradlew clean assembleDebug --no-daemon)
apk=android/app/build/outputs/apk/debug/app-debug.apk;test -s "$apk"
sdk=${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}};test -n "$sdk";aapt=$(find "$sdk/build-tools" -mindepth 2 -maxdepth 2 -type f -name aapt | sort -V | tail -1);test -x "$aapt"
"$aapt" dump badging "$apk" > "$R20_EVIDENCE/android-lab-badging.txt"
python3 "$R20_STAGE/r20/android-lab-identity.py" verify "$R20_EVIDENCE/android-lab-badging.txt" "$apk"
# Artifact for native compilation review only, not a physical or productive homologation.
cp "$apk" "$R20_EVIDENCE/VAULT-R20-COMPILE-ONLY-NOT-FOR-INSTALL.apk"
(cd "$R20_EVIDENCE";sha256sum VAULT-R20-COMPILE-ONLY-NOT-FOR-INSTALL.apk > android-lab-apk.sha256)
