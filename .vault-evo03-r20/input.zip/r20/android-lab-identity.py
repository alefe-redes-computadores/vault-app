#!/usr/bin/env python3
"""Compile-only Android sandbox identity. No production signing or package replacement."""
import re,sys,pathlib,json,zipfile
from reconcile import check
P=pathlib.Path
APP='com.alefejohsefe.vault'; LAB=APP+'.r20lab'
SUFFIX='\n// R20 compile-only isolated package\nandroid {\n    buildTypes {\n        debug { applicationIdSuffix ".r20lab" }\n    }\n}\n'
def apply(s):
 check(len(re.findall(r'(?m)^\s*applicationId\s+["\']'+re.escape(APP)+r'["\']\s*$',s))==1,'unexpected Android base identity')
 check('applicationIdSuffix' not in s,'existing suffix: review required')
 return s+SUFFIX
def verify_badging(s):
 p=re.findall(r"(?m)^package: name='([^']+)'",s);check(p==[LAB],'APK identity not isolated')
 check('android.permission.health.READ_NUTRITION' in s,'nutrition review permission absent')
def verify_dex(apk):
 with zipfile.ZipFile(apk) as z:
  names=[n for n in z.namelist() if re.fullmatch(r'classes(?:\d+)?\.dex',n)];check(names,'no dex')
  native=['VaultNutritionCapturePlugin','VaultNutritionFileProvider','VaultHealthConnectPlugin','VaultApkUpdaterPlugin']
  content=[z.read(n) for n in names]
  for n in native:check(any(('L'+APP.replace('.','/')+'/'+n+';').encode() in x for x in content),'native class absent: '+n)
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='apply':
  p=P(sys.argv[2]);s=p.read_text();p.write_text(apply(s));print('R20_ANDROID_ISOLATED_PACKAGE_CONFIG_PASS',LAB)
 elif mode=='verify':
  verify_badging(P(sys.argv[2]).read_text());verify_dex(P(sys.argv[3]));print('R20_ANDROID_LAB_APK_COMPILED_PASS',LAB)
 else:raise SystemExit('invalid mode')
