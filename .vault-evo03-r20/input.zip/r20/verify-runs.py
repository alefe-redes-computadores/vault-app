#!/usr/bin/env python3
"""Fail-closed run/job identity verification, no release or remote writes."""
import json,os,sys,urllib.request,pathlib
from reconcile import validate_manifest,check,HEX,SHA
P=pathlib.Path
REPO='alefe-redes-computadores/vault-app'
FIXED={
 'stability':(46045908506,'21a54be5fc6f5ae1a4724b7ab85f4275a222700e','VAULT Stability H01-H07 FINAL - SEM RELEASE',('H01-H07 Chromium antes e depois (loopback)','Validar e gerar APK')),
 'macro02':(46043587591,'da1bc6d149dc11884f4c303a2877a5f585ccae64','Macro02 R10 - Premium ativo, boot offline e reconexao integral (isolado)',('active-browser',)),
 'macro03':(46044925237,'bd6e92134920a1b00d4b18139fc68d4742a523ca','VAULT Macro03 R19.1 — functional review only',('functional-review',)),
}
def validate_launch_manifest(m):
 validate_manifest(m)
 check(isinstance(m.get('expected_main_sha'),str) and HEX.fullmatch(m['expected_main_sha']),'expected main SHA missing')
 for k,(rid,sha,_,_) in FIXED.items():check(m.get(k+'_run')==rid and m.get(k+'_sha')==sha,'certified anchor drift '+k)
 check(isinstance(m.get('host_workflow_name'),str) and m['host_workflow_name'].strip(),'approved host workflow identity missing')
 j=m.get('host_required_jobs');check(isinstance(j,list) and j and all(isinstance(x,str) and x.strip() for x in j) and len(j)==len(set(j)),'approved host mandatory jobs missing')
 check(m['host_run'] not in [x[0] for x in FIXED.values()],'isolated prior run cannot certify joint host')
 g=m.get('global_export_review');check(isinstance(g,dict) and g.get('decision')=='GUARDIAN_AND_OWNER_REVIEWED_GLOBAL_EXPORT' and isinstance(g.get('reason'),str) and g['reason'].strip() and not g['reason'].startswith('PENDING'),'global export privacy review missing')
 for k in ('pre_sha256','post_sha256'):check(isinstance(g.get(k),str) and SHA.fullmatch(g[k]),'global export review hash missing '+k)

def verify_one(d,jobs,rid,sha,name,required):
 check(d.get('id')==rid and d.get('head_sha')==sha and d.get('name')==name and d.get('status')=='completed' and d.get('conclusion')=='success' and d.get('repository',{}).get('full_name')==REPO,'STOP run identity/status mismatch '+name)
 alljobs=jobs.get('jobs');check(isinstance(alljobs,list) and jobs.get('total_count')==len(alljobs),'incomplete job pagination '+name)
 checked=[]
 for n in required:
  found=[j for j in alljobs if j.get('name')==n];check(len(found)==1,'required job missing or ambiguous '+n);j=found[0]
  check(j.get('status')=='completed' and j.get('conclusion')=='success' and j.get('head_sha')==sha,'required job not successful at exact SHA '+n)
  checked.append({k:j[k] for k in ('id','name','status','conclusion')})
 return {'id':rid,'name':name,'head_sha':sha,'status':'completed','conclusion':'success','html_url':d.get('html_url'),'required_jobs':checked}

def verify(m,fetch):
 validate_launch_manifest(m);out=[]
 for kind,(rid,sha,name,jobs) in {**FIXED,'host':(m['host_run'],m['host_run_sha'],m['host_workflow_name'],m['host_required_jobs'])}.items():
  endpoint=f'actions/runs/{rid}';out.append(verify_one(fetch(endpoint),fetch(endpoint+'/jobs?per_page=100'),rid,sha,name,jobs))
 return out

if __name__=='__main__':
 m=json.loads(P(sys.argv[1]).read_text());validate_launch_manifest(m)
 check(os.environ.get('GITHUB_ACTIONS')=='true' and os.environ.get('GITHUB_REF')=='refs/heads/vault/lab/evolution03-20261126-r20','STOP exact lab only')
 check(os.environ.get('GITHUB_REPOSITORY')==REPO,'STOP repository');token=os.environ.get('R20_READ_TOKEN');check(token,'STOP read-only token required')
 def fetch(endpoint):
  req=urllib.request.Request(f'https://api.github.com/repos/{REPO}/{endpoint}',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'vault-r20-review'})
  with urllib.request.urlopen(req,timeout=20) as f:return json.load(f)
 out=verify(m,fetch);P(sys.argv[2]).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print('R20_APPROVED_RUNS_AND_REQUIRED_JOBS_VERIFIED',len(out))
