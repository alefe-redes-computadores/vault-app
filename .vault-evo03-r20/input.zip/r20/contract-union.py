#!/usr/bin/env python3
"""Protect registrations by identity and execution, not just a minimum count."""
import collections,json,pathlib,re,subprocess,sys
from reconcile import check
P=pathlib.Path
FIXED_SOURCES=('b5d956ce4a011f43f6ccb3a5ac6be284e41fbaf0','471caebe7965eda437ee0b2ee274d20ba819b0b2')
PATH='scripts/test-v63-release-gate.mjs'
EXTRAS={'scripts/test-vault-static-offline-guard.cjs','scripts/test-vault-guardian-ux360-macro-a.cjs'}
ITEM=re.compile(r'"(scripts/[A-Za-z0-9_./-]+\.(?:cjs|mjs|js))"')

def parse(source):
 blocks=re.findall(r'\bconst\s+contracts\s*=\s*\[([\s\S]*?)\];',source);check(len(blocks)==1,'missing/ambiguous static V63 array')
 block=re.sub(r'//[^\n]*','',blocks[0]);names=ITEM.findall(block)
 residue=ITEM.sub('X',block)
 check(re.fullmatch(r'\s*X(?:\s*,\s*X)*\s*,?\s*',residue) is not None,'unparsed V63 registration; review required')
 check(len(names)==len(set(names)),'duplicate V63 registration')
 for name in names:check('..' not in pathlib.PurePosixPath(name).parts,'unsafe contract path')
 return names

def union(lists,actual):
 expected=set().union(*map(set,lists));missing=sorted(expected-set(actual));check(not missing,'missing V63 contracts: '+', '.join(missing));return expected

def execution(log,actual):
 marker=re.findall(r'^VAULT RELEASE GATE V63: (\d+) CONTRATOS OK\s*$',log,re.M)
 check(len(marker)==1 and int(marker[0])==len(actual),'V63 count differs from registered identities')
 collected=re.findall(r'^V63_COLETA_INTEGRAL_APROVADA \| executadas=(\d+) \| falhas=0\s*$',log,re.M)
 check(len(collected)==1 and int(collected[0])==len(actual),'V63 collection not complete')
 check('V63_FALHA |' not in log and 'V63_BLOQUEADA_COLETA_INTEGRAL' not in log,'V63 failures present')
 executed=set(re.findall(r'^=== (scripts/[A-Za-z0-9_./-]+\.(?:cjs|mjs|js))(?: \([^\n]*\))? ===\s*$',log,re.M))
 missing=sorted((set(actual)|EXTRAS)-executed);check(not missing,'V63 missing execution evidence: '+', '.join(missing))
 for marker in ('V70 SUPER INTEGRITY + UX: OK','VAULT V70 FINAL — COMPLETUDE CONTRACT OK'):check(marker in log,'missing '+marker)
 return len(executed)

def main():
 repo,manifest,candidate,log,out=sys.argv[1:];m=json.loads(P(manifest).read_text());refs=list(dict.fromkeys([*FIXED_SOURCES,m['stability_source_sha'],m['macro02_source_sha']]))
 sources={s:parse(subprocess.check_output(['git','-C',repo,'show',s+':'+PATH],text=True)) for s in refs}
 actual=parse((P(candidate)/PATH).read_text());expected=union(sources.values(),actual);check(len(expected)>=591,'certified union below 591')
 evidence={'required':len(expected),'registered':len(actual),'sources':{s:len(v) for s,v in sources.items()},'required_paths':sorted(expected),'registered_paths':actual}
 if log!='-':evidence['executed_unique_headers']=execution(P(log).read_text(),actual)
 P(out).write_text(json.dumps(evidence,indent=2)+'\n');print('R20_V63_UNION_PASS',len(expected),len(actual),'executed' if log!='-' else 'preflight')
if __name__=='__main__':main()
