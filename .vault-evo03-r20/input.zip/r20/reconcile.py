#!/usr/bin/env python3
"""R20 deterministic, non-installing reconciliation. No git checkout, SQL or push."""
import argparse, hashlib, json, os, pathlib, re, shutil, stat, subprocess, tempfile
P=pathlib.Path
BASE='bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b'
CERT='bd6e92134920a1b00d4b18139fc68d4742a523ca'
R191_RECEIPT='r191-reanchor.json'
HEX=re.compile(r'[0-9a-f]{40}\Z'); SHA=re.compile(r'[0-9a-f]{64}\Z')
class Blocked(ValueError): pass
def check(c,m):
 if not c: raise Blocked(m)
def digest(b): return None if b is None else hashlib.sha256(b).hexdigest()
def blob(b): return None if b is None else hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def safe_path(k):
 q=pathlib.PurePosixPath(k); check(k and str(q)==k and not q.is_absolute() and '..' not in q.parts and '\\' not in k and not any(x.lower()=='.git' for x in q.parts),'unsafe path '+k);return q
def read(root,k):
 q=root/safe_path(k);check(not any(x.is_symlink() for x in [q,*q.parents] if x==root or root in x.parents),'symlink '+k)
 if not q.exists():return None
 check(q.is_file(),'nonregular '+k);return q.read_bytes()
def filemap(root):
 check(root.is_dir() and not root.is_symlink(),'bad root');d={}
 for p in root.rglob('*'):
  k=p.relative_to(root).as_posix();safe_path(k);check(not p.is_symlink(),'symlink '+k)
  if p.is_file():d[k]=(blob(p.read_bytes()),'100755' if p.stat().st_mode&stat.S_IXUSR else '100644')
  else:check(p.is_dir(),'nonregular '+k)
 return d
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def tree(repo,sha):
 check(HEX.fullmatch(sha) and git(repo,'rev-parse',sha+'^{commit}').decode().strip()==sha,'not exact commit '+str(sha)); d={}
 for x in git(repo,'ls-tree','-rz',sha).split(b'\0'):
  if not x:continue
  meta,k=x.split(b'\t',1);mode,typ,obj=meta.decode().split();k=k.decode();safe_path(k);check(typ=='blob' and mode in ('100644','100755'),'unsupported entry '+k);d[k]=(obj,mode)
 return d
def archive(repo,sha,root):
 root.mkdir();expected=tree(repo,sha)
 # cat-file from exact tree, not checkout, no hooks, no archive attributes/export-ignore.
 # Stream git archive, then independently check every path and Git mode/blob.
 import tarfile,io
 data=git(repo,'archive','--format=tar',sha)
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:') as t:
  for m in t:
   k=m.name.rstrip('/');safe_path(k);q=root/k
   if m.isdir():q.mkdir(parents=True,exist_ok=True);continue
   check(m.isfile() and k in expected,'unsupported archive entry '+k);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(t.extractfile(m).read());q.chmod(0o755 if expected[k][1]=='100755' else 0o644)
 check(filemap(root)==expected,'archive path/blob/mode mismatch '+sha)
 return expected

def dexie_proposal(host):
 """Strict additive proposal, never an approval. Existing versions stay byte-for-byte."""
 check(host is not None,'DB host missing');before=b"import { VITAL_STORES } from '@/lib/vital/storage-dexie';";after=b"import { VITAL_STORES, VITAL_RECIPE_STORES } from '@/lib/vital/storage-dexie';"
 check(host.count(before)==1 and b'VITAL_RECIPE_STORES' not in host,'Dexie import collision')
 # Accept only a unique monotonically increasing integer declaration sequence and one enrollment store.
 matches=list(re.finditer(rb'(?m)^(?P<indent>[ \t]*)this\.version\((?P<n>\d+)\)(?:\.stores\(|[ \t]*$)',host));versions=[int(m['n']) for m in matches]
 check(versions and versions==sorted(set(versions)) and 59 in versions and versions[-1]>=60,'Dexie version sequence ambiguous')
 enrollment=re.findall(rb"(?m)^[ \t]*this\.version\((\d+)\)\.stores\(\{macro02_device_enrollment:'account_id'\}\);[ \t]*$",host)
 check(len(enrollment)==1 and int(enrollment[0]) in versions,'Macro02 enrollment anchor missing/ambiguous')
 # Insert only after a complete single-line final registration (no guessing at upgrades).
 last=matches[-1];end=host.find(b'\n',last.start());check(end>=0 and host[last.start():end].rstrip().endswith(b');'),'last schema registration not simple; manual review')
 check(host.count(b'this.version(')==len(matches),'unparsed version declaration')
 addition=b'\n'+last['indent']+b'// Macro03 R20: additive recipe stores; no capability activation.\n'+last['indent']+f'this.version({versions[-1]+1}).stores(VITAL_RECIPE_STORES);'.encode()
 result=(host[:end]+addition+host[end:]).replace(before,after)
 check(result.replace(addition,b'',1).replace(after,before,1)==host,'non-reversible schema proposal');return result

def types_proposal(host):
 anchor=b'    | "vital_meals"';addition=b'    | "vital_recipes"\n    | "vital_recipe_versions"\n'
 check(host is not None and host.count(anchor)==1 and b'"vital_recipes"' not in host and b'"vital_recipe_versions"' not in host,'type union collision')
 out=host.replace(anchor,addition+anchor);check(out.replace(addition,b'',1)==host,'non-reversible type proposal');return out

def decide(old,new,host):
 if host==old:return 'exact-certified-preimage',new
 if host==new:return 'already-identical',host
 return 'collision',None

def validate_manifest(m):
 check(m.get('status')=='GUARDIAN_AND_OWNER_APPROVED_ISOLATED_INTEGRATION','explicit review required')
 check(m.get('scope')=='LAB_ONLY_NO_DEPLOY_NO_MIGRATION_NO_ACTIVATION','scope prohibited')
 check(m.get('macro03_sha')==CERT,'wrong Macro03 checkpoint')
 for k in ('host_sha','host_run_sha','host_source_tree','stability_sha','stability_source_sha','stability_source_tree','macro02_sha','macro02_source_sha','macro02_source_tree'):check(isinstance(m.get(k),str) and HEX.fullmatch(m[k]),'missing exact '+k)
 check(m['host_sha']!=BASE and m['host_sha']!=CERT,'diagnostic host prohibited')
 for k in ('guardian_receipt','owner_receipt','host_reconciliation_receipt'):check(isinstance(m.get(k),str) and m[k].strip() and not m[k].startswith('PENDING'),'missing '+k)
 for k in ('stability_run','macro02_run','host_run'):check(isinstance(m.get(k),int) and not isinstance(m[k],bool) and m[k]>0,'missing run '+k)
 check(isinstance(m.get('resolutions'),dict),'missing resolutions map')
 check(isinstance(m.get('host_resolutions'),dict),'missing host resolutions map')

def audit_host_maps(base,stability,macro02,host,resolutions):
 """Preserve both final trees; every divergence/addition/deletion beyond exact union requires reviewed receipt."""
 rows=[];used=set();unresolved=[]
 for k in sorted(set(base)|set(stability)|set(macro02)|set(host)):
  a,b,c,d=(x.get(k) for x in (base,stability,macro02,host))
  if a==b==c==d:continue
  # A changed path on one side, or identical changes, has one lossless expected result.
  wanted=c if b==a else b if c==a or b==c else None
  conflict=b!=a and c!=a and b!=c
  row={'path':k,'base':a,'stability':b,'macro02':c,'host':d}
  if not conflict and d==wanted:row['decision']='exact-union'
  else:
   v=resolutions.get(k);canonical={q:(None if row[q] is None else list(row[q])) for q in ('base','stability','macro02','host')}
   if v is not None:
    check(v.get('decision')=='GUARDIAN_REVIEWED_HOST_COMPOSITION' and v.get('entries')==canonical and isinstance(v.get('reason'),str) and v['reason'].strip(),'invalid host resolution '+k)
    row['decision']='guardian-reviewed-host';used.add(k)
   else:row['decision']='unresolved';unresolved.append(k)
  rows.append(row)
 check(used==set(resolutions),'unused host resolutions')
 return {'rows':rows,'unresolved':unresolved}

def reconcile(repo,payload,receipt,host,dest,report,manifest=None,resolution_dir=None):
 check(not dest.exists() and not report.exists() and dest.parent==report.parent,'destination/report must be new siblings')
 check(not any(x.is_symlink() for x in (dest.parent,report.parent)),'unsafe destination')
 # All writes confined to a new disposable workspace, never inside a source repo.
 check(repo.resolve()!=dest.resolve() and repo.resolve() not in dest.resolve().parents,'destination inside repository')
 check(receipt['target_sha']==BASE and receipt['changed_paths']==102 and len(receipt['receipts'])==102,'invalid certified receipt')
 check(len({x['path'] for x in receipt['receipts']})==102,'duplicate receipt paths')
 if manifest:
  validate_manifest(manifest);check(manifest['host_sha']==host,'host differs from approved manifest')
  host_audit=audit_host_maps(tree(repo,BASE),tree(repo,manifest['stability_source_sha']),tree(repo,manifest['macro02_source_sha']),tree(repo,host),manifest['host_resolutions'])
 else:host_audit=None
 with tempfile.TemporaryDirectory(prefix='evo03-r20-') as td:
  t=P(td);old=t/'diagnostic';new=t/'certified';h=t/'host';r=t/'receipt.json';archive(repo,BASE,old);archive(repo,host,h)
  subprocess.run(['python3',str(payload/'tools/reanchor-review-tree.py'),str(repo),str(old),str(new),str(r)],check=True)
  check(json.loads(r.read_text())==receipt,'certified R19.1 reanchor mismatch')
  initial=filemap(h);prev=filemap(old);cert=filemap(new);updates={};rows=[];used=set();proposals=report.parent/'proposed-collisions'
  check(not proposals.exists(),'proposals directory already exists')
  for row in receipt['receipts']:
   k=row['path'];a=read(old,k);b=read(new,k);c=read(h,k);check(digest(a)==row['target_pre_sha256'] and digest(b)==row['candidate_post_sha256'],'receipt bytes differ '+k)
   # File mode is part of authority. New files retain certified mode; existing ones preserve host mode.
   am=prev.get(k);bm=cert.get(k);cm=initial.get(k);kind,out=decide(a,b,c)
   if kind=='exact-certified-preimage' and cm!=am:kind='collision';out=None
   if kind=='already-identical' and cm!=bm:kind='collision';out=None
   rec={'path':k,'decision':kind,'diagnostic_sha256':digest(a),'certified_sha256':digest(b),'host_sha256':digest(c),'host_git_entry':cm}
   if kind=='collision':
    try:
     proposed=dexie_proposal(c) if k=='lib/db/index.ts' else types_proposal(c) if k=='lib/types.ts' else None
     if proposed is not None:
      q=proposals/k;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(proposed);rec['proposed_sha256']=digest(proposed)
    except Blocked as e:rec['proposal_blocker']=str(e)
    v=manifest['resolutions'].get(k) if manifest else None
    if v:
     check(resolution_dir is not None and v.get('host_sha256')==digest(c) and v.get('certified_sha256')==digest(b),'resolution preimage mismatch '+k)
     check(v.get('decision')=='GUARDIAN_REVIEWED_COMPOSED' and isinstance(v.get('reason'),str) and v['reason'].strip(),'resolution not reviewed '+k)
     out=read(resolution_dir,k);check(out is not None and digest(out)==v.get('post_sha256') and SHA.fullmatch(v['post_sha256']),'resolution bytes mismatch '+k)
     rec['decision']='guardian-reviewed-composition';used.add(k)
   if rec['decision']!='collision':updates[k]=out;rec['post_sha256']=digest(out)
   rows.append(rec)
  if manifest:check(used==set(manifest['resolutions']),'unused/stale resolutions')
  result={'status':'BLOCKED_COLLISIONS_OR_NO_APPROVAL','host_sha':host,'macro03_sha':CERT,'rows':rows,'unresolved':[x['path'] for x in rows if x['decision']=='collision'],'production_authority':False,'joint_host_audit':host_audit}
  if manifest and not result['unresolved'] and not host_audit['unresolved']:
   # Exact expected file tree: every untouched host entry preserved (including executable bits).
   shutil.copytree(h,dest)
   try:
    expected=dict(initial)
    for k,b in updates.items():
     q=dest/k
     if b is None:q.unlink();expected.pop(k,None);continue
     mode=initial.get(k,cert.get(k,('', '100644')))[1];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);q.chmod(0o755 if mode=='100755' else 0o644);expected[k]=(blob(b),mode)
    check(filemap(dest)==expected,'candidate path/blob/mode mismatch');check(filemap(h)==initial,'host mutated');result['status']='INTEGRATED_REVIEW_ONLY';result['candidate_files']=len(expected);result['expected_tree']={k:list(v) for k,v in sorted(expected.items())}
   except BaseException:shutil.rmtree(dest);raise
  report.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');return result

def main():
 p=argparse.ArgumentParser();p.add_argument('repo',type=P);p.add_argument('payload',type=P);p.add_argument('receipt',type=P);p.add_argument('host');p.add_argument('destination',type=P);p.add_argument('report',type=P);p.add_argument('--manifest',type=P);p.add_argument('--resolutions',type=P);a=p.parse_args();m=json.loads(a.manifest.read_text()) if a.manifest else None
 r=reconcile(a.repo.resolve(),a.payload.resolve(),json.loads(a.receipt.read_text()),a.host,a.destination.resolve(),a.report.resolve(),m,a.resolutions.resolve() if a.resolutions else None);print(r['status'],len(r['unresolved']),'unresolved');return 0 if r['status']=='INTEGRATED_REVIEW_ONLY' else 3
if __name__=='__main__':raise SystemExit(main())
