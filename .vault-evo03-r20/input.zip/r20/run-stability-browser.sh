#!/usr/bin/env bash
# Repeat certified before/after H01-H06 harness against the integrated Next export.
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r26 && ${GITHUB_REPOSITORY:-} == alefe-redes-computadores/vault-app && $PWD == "$EVO03_LAB/candidate" ]] || { echo 'STOP isolated CI only';exit 2; }
base=b40d302ac4594eac60c3929a6c4f0ca855e0a5fa; envelope=21a54be5fc6f5ae1a4724b7ab85f4275a222700e
[[ $(git -C "$R20_REPO" rev-parse "$base^{tree}") == 74ea0ee766067b05744bb3840ef54c51c85d58f2 ]]
[[ $(git -C "$R20_REPO" rev-parse "$envelope^1") == b5d956ce4a011f43f6ccb3a5ac6be284e41fbaf0 ]]
export NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:8765 NEXT_PUBLIC_SUPABASE_ANON_KEY=ci-synthetic-not-a-production-key NEXT_TELEMETRY_DISABLED=1 CAPACITOR_BUILD=0 VAULT_WEB_STATIC_BUILD=1 NEXT_PUBLIC_VAULT_NATIVE_RUNTIME=web TZ=America/Sao_Paulo CI=true
candidate=$PWD; out="$R20_EVIDENCE/stability-browser"; mkdir -p "$out/before" "$out/after"; work=$(mktemp -d "$RUNNER_TEMP/r20-stability.XXXXXX");trap 'rm -rf -- "$work"' EXIT
mkdir "$work/before" "$work/harness"
# Read-only git archive and exact harness from the certified envelope; no merge or checkout.
git -C "$R20_REPO" archive "$base" | tar -xf - -C "$work/before"
for f in qa_browser.py qa_h01_h04.py qa_h05_h06.py;do git -C "$R20_REPO" show "$envelope:.github/h01-h07/$f" > "$work/harness/$f";done
python3 -m venv "$work/venv"; "$work/venv/bin/pip" install --disable-pip-version-check playwright==1.57.0
"$work/venv/bin/python" -m playwright install --with-deps chromium
py="$work/venv/bin/python"; day=$(date +%F); printf '%s\n' "$day" > "$out/day.txt"
# Receipt digest labels the materialized tree, not a fabricated Git commit.
after_sha=$(sha256sum "$EVO03_LAB/r20-receipt.json" | cut -d' ' -f1);printf 'BASELINE_GIT_SHA=%s\nINTEGRATED_RECEIPT_SHA256=%s\n' "$base" "$after_sha" > "$out/origin.txt"
fail=0; before_ok=1; after_ok=1
(cd "$work/before";npm ci --no-audit --no-fund 2>&1 | tee "$out/before/npm.log" && npm run build 2>&1 | tee "$out/before/build.log" && node scripts/verify-static-release-stability.cjs web 2>&1 | tee "$out/before/static.log") || { fail=$((fail+1));before_ok=0; }
(cd "$candidate";npm run build 2>&1 | tee "$out/after/build.log" && node scripts/verify-static-release-stability.cjs web 2>&1 | tee "$out/after/static.log") || { fail=$((fail+1));after_ok=0; }
if ((before_ok));then
 "$py" "$work/harness/qa_h01_h04.py" --phase before --out "$work/before/out" --evidence "$out/before" --sha "$base" --day "$day" 2>&1 | tee "$out/before/chromium.log" || fail=$((fail+1))
 "$py" "$work/harness/qa_h05_h06.py" --phase before --out "$work/before/out" --evidence "$out/before" --sha "$base" --day "$day" 2>&1 | tee "$out/before/chromium-h05-h06.log" || fail=$((fail+1))
fi
if ((after_ok));then
 if [[ -s "$out/before/measurements.json" ]];then
  "$py" "$work/harness/qa_h01_h04.py" --phase after --out "$candidate/out" --evidence "$out/after" --sha "$after_sha" --baseline "$out/before/measurements.json" --day "$day" 2>&1 | tee "$out/after/chromium.log" || fail=$((fail+1))
 else echo 'BLOCKED: missing baseline measurements' | tee "$out/after/chromium.log";fail=$((fail+1));fi
 "$py" "$work/harness/qa_h05_h06.py" --phase after --out "$candidate/out" --evidence "$out/after" --sha "$after_sha" --day "$day" 2>&1 | tee "$out/after/chromium-h05-h06.log" || fail=$((fail+1))
fi
printf 'FAILED_CHECKS=%s\n' "$fail" | tee "$out/collection-status.txt"
[[ $fail == 0 ]]
echo R20_STABILITY_REAL_HOST_BEFORE_AFTER_PASS
