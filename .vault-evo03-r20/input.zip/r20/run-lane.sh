#!/usr/bin/env bash
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r25 && ${EVO03_LAB:-} == "$RUNNER_TEMP/evo03-lab" ]] || { echo 'STOP lab only';exit 2; }
[[ $# == 1 ]]; lane=$1; lab=$EVO03_LAB; out=$R20_EVIDENCE; cd "$lab/candidate"
export PATH="$PWD/node_modules/.bin:$PATH"; export NEXT_TELEMETRY_DISABLED=1
# Explicit test-only origin; no inherited live endpoint, secret, or release action.
export NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:4173 NEXT_PUBLIC_SUPABASE_ANON_KEY=ci-synthetic-not-a-production-key
for k in SUPABASE_SERVICE_ROLE_KEY SUPABASE_DB_URL DATABASE_URL PGHOST PGPORT PGUSER PGPASSWORD PGDATABASE PGHOSTADDR PGSERVICE PGSERVICEFILE PGOPTIONS PGPASSFILE; do [[ -z ${!k:-} ]] || { echo "STOP inherited $k"; exit 2; }; done
run(){ local name=$1;shift; "$@" 2>&1 | tee "$out/$name.log"; }
case "$lane" in
 host)
  failures=0
  collect(){ run "$@" || failures=$((failures+1)); }
  collect typescript ./node_modules/.bin/tsc --noEmit
  manifest="$R20_STAGE/reference/source-manifest.json"
  collect v63-union-preflight python3 "$R20_STAGE/r20/contract-union.py" "$R20_REPO" "$manifest" "$PWD" - "$out/v63-union-preflight.json"
  collect v63 env VAULT_V63_COLLECT_ALL=1 node scripts/test-v63-release-gate.mjs
  collect v63-union-execution python3 "$R20_STAGE/r20/contract-union.py" "$R20_REPO" "$manifest" "$PWD" "$out/v63.log" "$out/v63-union-execution.json"
  collect v70-super node scripts/test-v70-super-integrity-ux-contract.mjs
  collect v70-final node scripts/test-v70-final-completeness-contract.mjs
  for f in test-vault-stability-h01-h04.cjs test-vault-stability-h05-h06.cjs test-vault-stability-h07.cjs test-vault-macro02-dose-premium-p1.cjs test-vault-macro02-dose-premium-p2.cjs test-vault-macro02-dose-premium-p3.cjs test-vault-macro02-compound-r6.cjs test-vault-static-offline-guard.cjs test-vault-offline-session-v62-contract.mjs test-vault-m52-sync-resilience.cjs; do collect "$f" node "scripts/$f"; done
  collect update360 node scripts/test-vault-update360-v34.cjs
  collect export-unchanged bash -c 'cmp "$1" <(git -C "$2" show 109b116e997de0087883c5b0a7deb94143d97ef3:lib/export.ts)' _ "$PWD/lib/export.ts" "$R20_REPO"
  printf 'HOST_FAILED_CHECKS=%s\n' "$failures" | tee "$out/host-status.txt"
  [[ $failures == 0 ]]
  ;;
 fixtures)
  run fixtures bash "$lab/tools/validate-fixture.sh"
  run taco bash "$lab/tools/validate-taco-fixture.sh"
  run usda bash "$lab/tools/validate-usda-fixture.sh"
  run android-prep python3 -B "$lab/tests/test_android_prepare.py"
  run conflict python3 -B "$lab/tests/test_r16_domain_conflicts.py"
  run documentary bash "$R20_STAGE/r20/verify-documentary.sh" "$R20_STAGE/reference/documentary"
  run ledger python3 "$lab/tools/catalog-review-ledger.py" verify "$lab/evidence/rodada-R12/catalog-triage" "$lab/evidence/r15/catalog-review-ledger.jsonl"
  ;;
 server16)
  run pg16 bash "$lab/tools/ci-r16-pg17-docker.sh"
  grep -Fq 'R16_PLAN_VERSION_DB_CARDINALITY_PASS' "$out/pg16.log"; grep -Fq 'R16_PERMANENT_CONFLICT_SINGLE_REJECTION_PASS count=1' "$out/pg16.log"
  ;;
 server24)
  run pg24 bash "$lab/tools/ci-r23-pg17-docker.sh"
  grep -Fxq "R24_FIXED_CHECKS 6752 MISMATCHES 0" "$out/pg24.log"
  grep -Fxq "R24_PG_ALL_COHORTS_PASS 6752; EXACT ORIGINAL REGISTRY PRESERVED; NOT_PRODUCTION" "$out/pg24.log"
  ;;
 server17)
  run pg17 bash "$lab/tools/ci-r17-pg17-docker.sh"
  grep -Fxq 'R17_CATALOG_HTTP_TOTAL 16 REAL_ADAPTER_CALLS 6' "$out/pg17.log"; grep -Fq 'R17_CATALOG_DB_CARDINALITY_PASS' "$out/pg17.log"
  ;;
 browser|dexie-upgrade)
  npm install --prefix "$RUNNER_TEMP/evo03-ui" --no-save --no-audit --no-fund --ignore-scripts playwright@1.55.0 esbuild@0.25.5
  "$RUNNER_TEMP/evo03-ui/node_modules/.bin/playwright" install chromium --with-deps
  if [[ $lane == dexie-upgrade ]]; then
    run dexie-upgrade node "$R20_STAGE/r20/dexie-upgrade.cjs"
    grep -Eq "^R20_REAL_DEXIE_UPGRADE_PASS [0-9]+ [0-9]+$" "$out/dexie-upgrade.log"
  else
  run browser bash "$lab/tools/ci-r19-functional.sh"
  for marker in 'PREMIUM_COMPONENT_VISUAL_PASS 32' 'PREMIUM_FULL_PANEL_PASS 37' 'PREMIUM_F2_JOURNEY_PASS 84' 'PREMIUM_HC_UI_PASS 36' 'PREMIUM_F2_CANONICAL_AND_RECOVERY_PASS 84' 'R13_CONSUMER_VISUAL_PASS 12' 'R17_CATALOG_BROWSER_PASS 3' 'R19_VITAL_SCREEN_ROUTES_PASS 84' 'R19_FUNCTIONAL_LAB_ALL_PASS'; do grep -Fxq "$marker" "$out/browser.log"; done
  fi
  ;;
 stability-browser)
  run stability-browser bash "$R20_STAGE/r20/run-stability-browser.sh"
  grep -Fxq R20_STABILITY_REAL_HOST_BEFORE_AFTER_PASS "$out/stability-browser.log"
  ;;
 android-lab)
  run android-lab bash "$R20_STAGE/r20/run-android-lab.sh"
  grep -Fxq "R20_ANDROID_LAB_APK_COMPILED_PASS com.alefejohsefe.vault.r20lab" "$out/android-lab.log"
  ;;
 macro02-host)
  # Exact full-host harness copied from the approved joint host, not a new clinical writer.
  export UI_GATE_DIR="$RUNNER_TEMP/macro02-ui";mkdir "$UI_GATE_DIR"
  for f in bootstrap.cjs browser.cjs run.sh queue-contract.cjs profile-contract.cjs; do git -C "$R20_REPO" show "$R20_MACRO02_SHA:.github/macro02-ui/$f" > "$UI_GATE_DIR/$f"; done
  cp "$R20_STAGE/r20/host-vital-extension.cjs" "$UI_GATE_DIR/"
  run host-extension python3 "$R20_STAGE/r20/extend-macro02.py" "$UI_GATE_DIR"
  export CAPACITOR_BUILD=0 VAULT_WEB_STATIC_BUILD=1 NEXT_PUBLIC_VAULT_NATIVE_RUNTIME=web TZ=America/Sao_Paulo
  export ESBUILD_MODULE="$UI_GATE_DIR/tools/node_modules/esbuild" PLAYWRIGHT_MODULE="$UI_GATE_DIR/tools/node_modules/playwright" BOOTSTRAP_BUNDLE="$UI_GATE_DIR/bootstrap.js"
  run macro02-queue node "$UI_GATE_DIR/queue-contract.cjs" "$PWD"
  run macro02-profile node "$UI_GATE_DIR/profile-contract.cjs" "$PWD"
  grep -Fxq MACRO02_PREMIUM_ACQUISITION_QUEUE_REGRESSION_PASS "$out/macro02-queue.log"
  grep -Fxq MACRO02_OFFLINE_PROFILE_SCOPE_REGRESSION_PASS "$out/macro02-profile.log"
  run web-export node scripts/ci-build-web-resilient.cjs
  run static-web node scripts/verify-static-release-stability.cjs web
  npm install --prefix "$UI_GATE_DIR/tools" --no-audit --no-fund --save-exact playwright@1.56.1 esbuild@0.25.12
  "$UI_GATE_DIR/tools/node_modules/.bin/playwright" install --with-deps chromium
  run bootstrap node "$UI_GATE_DIR/bootstrap.cjs"
  run macro02-host bash "$UI_GATE_DIR/run.sh"
  for m in UI_OFFLINE_RELOAD_AND_HISTORY_PASS UI_COLD_OFFLINE_PROFILE_AND_OUTBOX_PASS UI_BACKUP_ACTIVE_RECEIPT_READ_PASS UI_RECONNECT_EXACT_RETRY_NO_DUPLICATE_PASS MACRO02_ACTIVE_PREMIUM_BROWSER_PG17_GATE_PASS; do grep -Fxq "$m" "$out/macro02-host.log"; done
  grep -Fxq "R20_VITAL_REAL_NEXT_HOST_PASS 21" "$out/macro02-host.log"
  ;;
 *) echo 'STOP unknown lane'; exit 2;;
esac
printf 'R20_LANE_PASS %s\n' "$lane" | tee "$out/lane-pass.txt"
