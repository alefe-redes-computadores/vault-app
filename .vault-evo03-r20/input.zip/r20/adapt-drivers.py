#!/usr/bin/env python3
"""Only change the exact branch guard in copies of certified drivers."""
import pathlib,sys,json,hashlib
p=pathlib.Path(sys.argv[1]);tools=p/'tools';out={};new=b'refs/heads/vault/lab/evolution03-20261126-r26'
sets={'r24':['ci-r23-pg17-docker.sh','ci-r23-catalog-http.cjs'],'r191':['ci-r19-functional.sh','ci-r191-catalog-prepare.sh','ci-r19-screen.cjs','r19-summary.cjs','r19-f1.cjs','r19-f2.cjs','r19-hc.cjs','r19-recovery.cjs','r19-consumers.cjs','r19-catalog.cjs'],'r16':['ci-r16-pg17-docker.sh','ci-r16-client-http.cjs','test-r16-postgrest-unix.py'],'r172':['ci-r17-pg17-docker.sh','ci-r17-catalog-http.cjs']}
for suffix,files in sets.items():
 old=f'refs/heads/vault/lab/evolution03-20261126-{suffix}'.encode()
 for k in files:
  f=tools/k;a=f.read_bytes();assert a.count(old)==1,k;b=a.replace(old,new);assert b.count(new)==1 and b.replace(new,old)==a,k;f.write_bytes(b);out[k]={'before':hashlib.sha256(a).hexdigest(),'after':hashlib.sha256(b).hexdigest(),'old_guard':old.decode(),'new_guard':new.decode()}
pathlib.Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print('R20_DRIVER_GUARD_ONLY',len(out))
