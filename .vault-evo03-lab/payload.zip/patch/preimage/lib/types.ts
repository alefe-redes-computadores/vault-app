// lib/types.ts
import type { SurgeryRegion, SurgerySide } from './surgery-body';

// ============================================================
// 1. CONFIGURAÇÕES E ENUMS
// ============================================================

export const PERSON_COLORS = [
  "#3B82F6",
  "#8B5CF6",
  "#EC4899",
  "#10B981",
  "#F59E0B",
  "#EF4444",
  "#06B6D4",
  "#6366F1",
] as const;

export type PersonColor = (typeof PERSON_COLORS)[number];

export type CategoryId = "saude" | "pessoal" | "empresa" | "outros";

export type DocumentType =
  | "rg"
  | "cpf"
  | "cnh"
  | "certidao_nascimento"
  | "titulo_eleitor"
  | "certificado"
  | "carteira_trabalho"
  | "passaporte"
  | "dispensa_militar"
  | "receita"
  | "prontuario"
  | "documento_sus"
  | "lme"
  | "laudo"
  | "encaminhamento"
  | "consulta"
  | "cirurgia"
  | "exame_sangue"
  | "exame_imagem"
  | "credencial"
  | "outro";

export type DocumentFieldType = "text" | "date" | "select";

export type TipoReceita = "comum" | "amarela" | "azul" | "branca";

export type ModoLembreteReceita =
  | "automatico"
  | "7_dias"
  | "15_dias"
  | "data_personalizada";

export interface MedicationCatalogSnapshot {
  schema: 1;
  lookup_key: string;
  catalog_signature: string | null;
  resolved_at: string;
  quality: number;
  match_kind: "exact" | "pharmaceutical_equivalence";
  reference: unknown;
}

export type VaultPermission = "view" | "edit" | "admin";

export type VaultMemberStatus =
  | "pending"
  | "accepted"
  | "declined";

export type CardType =
  | "cartao_credito"
  | "cartao_debito"
  | "conta_corrente"
  | "conta_poupanca"
  | "conta_digital";

export type CardBrand =
  | "visa"
  | "mastercard"
  | "elo"
  | "amex"
  | "hipercard"
  | "unknown";

export type CategoriaRegistro =
  | "sintoma"
  | "medicao"
  | "humor"
  | "habito";

// ============================================================
// 2. PESSOAS E CATEGORIAS
// ============================================================

export interface Person {
  id?: string;
  user_id: string;
  name: string;
  email?: string;
  phone?: string;
  avatar_url?: string;
  color: string;
  isDefault?: boolean;
  created_at: string;
  updated_at: string;
  synced: boolean;
}

export interface Category {
  id: CategoryId;
  name: string;
  icon: string;
  color: string;
  description?: string;
}

export const CATEGORIES: Record<CategoryId, Category> = {
  saude: {
    id: "saude",
    name: "Saúde",
    icon: "Heart",
    color: "#EC4899",
    description: "Prontuários, receitas, laudos, medicamentos",
  },
  pessoal: {
    id: "pessoal",
    name: "Pessoal",
    icon: "User",
    color: "#3B82F6",
    description: "C.I.N, CPF, CNH, Certidões",
  },
  empresa: {
    id: "empresa",
    name: "Empresa",
    icon: "Building2",
    color: "#7C9CB5",
    description: "Documentos corporativos",
  },
  outros: {
    id: "outros",
    name: "Outros",
    icon: "FolderOpen",
    color: "#6B7280",
    description: "Documentos diversos",
  },
};

export const AREAS = CATEGORIES;
export const CATEGORY_META = CATEGORIES;

// ============================================================
// 3. DOCUMENTOS E ANEXOS
// ============================================================

export interface Attachment {
  id: string;
  url: string;
  thumbnail_url?: string;
  name: string;
  type: "image" | "pdf";
  uploaded_at: string;
}

export interface Document {
  id?: string;
  user_id: string;
  person_id: string;
  category_id: CategoryId;
  type: DocumentType;
  title: string;
  description?: string;
  metadata: Record<string, unknown>;
  attachments: Attachment[];
  is_favorite: boolean;
  vault_id?: string;

  // Relações diretas já indexadas no schema do Dexie.
  hospital_id?: string;
  medico_id?: string;

  // Relacionamento genérico de documentos introduzido no schema v32.
  entidade_tipo?: string;
  entidade_id?: string;

  created_at: string;
  updated_at: string;
  synced: boolean;
}

export const TYPE_CATEGORY_MAP: Record<DocumentType, CategoryId[]> = {
  rg: ["pessoal"],
  cpf: ["pessoal"],
  cnh: ["pessoal"],
  certidao_nascimento: ["pessoal"],
  titulo_eleitor: ["pessoal"],
  receita: ["saude"],
  prontuario: ["saude"],
  documento_sus: ["saude"],
  lme: ["saude"],
  laudo: ["saude"],
  encaminhamento: ["saude"],
  consulta: ["saude"],
  cirurgia: ["saude"],
  exame_sangue: ["saude"],
  exame_imagem: ["saude"],
  credencial: ["saude"],
  certificado: ["pessoal", "empresa", "outros"],
  carteira_trabalho: ["pessoal", "empresa"],
  passaporte: ["pessoal"],
  dispensa_militar: ["pessoal"],
  outro: ["pessoal", "saude", "empresa", "outros"],
};

export interface DocumentField {
  key: string;
  label: string;
  type: DocumentFieldType;
  options?: string[];
  required?: boolean;
}

export const DOCUMENT_FIELDS: Record<DocumentType, DocumentField[]> = {
  rg: [
    {
      key: "modelo",
      label: "Modelo do Documento",
      type: "select",
      options: ["C.I.N (Nova Identidade)", "RG (Antigo)"],
      required: true,
    },
    {
      key: "cpf",
      label: "Número do CPF",
      type: "text",
      required: true,
    },
    {
      key: "rg_number",
      label: "Número do RG",
      type: "text",
    },
    {
      key: "issue_date",
      label: "Data de emissão",
      type: "date",
      required: true,
    },
    {
      key: "expiry_date",
      label: "Data de validade",
      type: "date",
    },
    {
      key: "issuer",
      label: "Órgão emissor",
      type: "text",
      required: true,
    },
  ],

  cpf: [
    {
      key: "number",
      label: "Número do CPF",
      type: "text",
      required: true,
    },
  ],

  cnh: [
    {
      key: "number",
      label: "Número da CNH",
      type: "text",
      required: true,
    },
    {
      key: "category",
      label: "Categoria",
      type: "select",
      options: ["A", "B", "AB", "C", "D", "E"],
      required: true,
    },
    {
      key: "issue_date",
      label: "Data de emissão",
      type: "date",
      required: true,
    },
    {
      key: "expiry_date",
      label: "Data de validade",
      type: "date",
      required: true,
    },
  ],

  certidao_nascimento: [
    {
      key: "nome_registrado",
      label: "Nome Registrado",
      type: "text",
      required: true,
    },
    {
      key: "matricula",
      label: "Matrícula",
      type: "text",
      required: true,
    },
    {
      key: "livro",
      label: "Livro",
      type: "text",
    },
    {
      key: "folha",
      label: "Folha",
      type: "text",
    },
    {
      key: "termo",
      label: "Termo",
      type: "text",
    },
    {
      key: "cartorio",
      label: "Cartório de Registro",
      type: "text",
    },
    {
      key: "data_nascimento",
      label: "Data de Nascimento",
      type: "date",
      required: true,
    },
  ],

  titulo_eleitor: [
    {
      key: "number",
      label: "Número do Título",
      type: "text",
      required: true,
    },
    {
      key: "zona",
      label: "Zona Eleitoral",
      type: "text",
      required: true,
    },
    {
      key: "secao",
      label: "Seção",
      type: "text",
      required: true,
    },
  ],

  certificado: [
    {
      key: "institution",
      label: "Instituição de ensino",
      type: "text",
      required: true,
    },
    {
      key: "course",
      label: "Curso",
      type: "text",
      required: true,
    },
    {
      key: "duration",
      label: "Duração (ex: 120 horas)",
      type: "text",
      required: true,
    },
    {
      key: "completion_date",
      label: "Data de conclusão",
      type: "date",
    },
  ],

  carteira_trabalho: [
    {
      key: "numero",
      label: "Número da CTPS",
      type: "text",
      required: true,
    },
    {
      key: "serie",
      label: "Série",
      type: "text",
    },
    {
      key: "data_emissao",
      label: "Data de emissão",
      type: "date",
    },
    {
      key: "uf",
      label: "UF",
      type: "text",
    },
  ],

  passaporte: [
    {
      key: "numero",
      label: "Número do Passaporte",
      type: "text",
      required: true,
    },
    {
      key: "pais",
      label: "País de emissão",
      type: "text",
      required: true,
    },
    {
      key: "data_emissao",
      label: "Data de emissão",
      type: "date",
      required: true,
    },
    {
      key: "data_validade",
      label: "Data de validade",
      type: "date",
      required: true,
    },
  ],

  dispensa_militar: [
    {
      key: "numero",
      label: "Número do Certificado",
      type: "text",
      required: true,
    },
    {
      key: "categoria",
      label: "Categoria",
      type: "select",
      options: ["A", "B", "C", "D", "E"],
      required: true,
    },
    {
      key: "data_emissao",
      label: "Data de emissão",
      type: "date",
    },
  ],

  receita: [
    {
      key: "medicamento_id",
      label: "Medicamento",
      type: "select",
      required: true,
    },
    {
      key: "dosage",
      label: "Dosagem",
      type: "text",
      required: true,
    },
    {
      key: "medico_id",
      label: "Médico",
      type: "select",
      required: true,
    },
    {
      key: "farmacia_id",
      label: "Farmácia",
      type: "select",
    },
    {
      key: "prescription_date",
      label: "Data da receita",
      type: "date",
      required: true,
    },
    {
      key: "renewal_date",
      label: "Próxima renovação",
      type: "date",
      required: true,
    },
  ],

  prontuario: [
    {
      key: "hospital_id",
      label: "Hospital",
      type: "select",
      required: true,
    },
    {
      key: "medico_id",
      label: "Médico",
      type: "select",
      required: true,
    },
    {
      key: "specialty",
      label: "Especialidade",
      type: "text",
      required: true,
    },
    {
      key: "date",
      label: "Data",
      type: "date",
      required: true,
    },
  ],

  documento_sus: [
    {key:"date",label:"Data do documento",type:"date",required:true},
    {key:"medico_id",label:"Profissional responsável",type:"select",required:false},
    {key:"hospital_id",label:"Unidade",type:"select",required:false},
    {key:"protocol",label:"Protocolo",type:"text",required:false},
  ],
  lme: [
    {key:"medico_id",label:"Prescritor",type:"select",required:false},
    {key:"hospital_id",label:"Unidade de atendimento",type:"select",required:false},
    {key:"date",label:"Data do preenchimento",type:"date",required:true},
    {key:"protocol",label:"Protocolo",type:"text",required:false},
  ],
  laudo: [
    {
      key: "medico_id",
      label: "Médico",
      type: "select",
      required: true,
    },
    {
      key: "specialty",
      label: "Especialidade",
      type: "text",
      required: true,
    },
    {
      key: "hospital_id",
      label: "Hospital",
      type: "select",
      required: true,
    },
    {
      key: "date",
      label: "Data",
      type: "date",
      required: true,
    },
  ],

  encaminhamento: [
    {
      key: "from_medico_id",
      label: "Quem encaminhou (Médico)",
      type: "select",
      required: true,
    },
    {
      key: "to_medico_id",
      label: "Para quem (Médico - opcional)",
      type: "select",
    },
    {
      key: "reason",
      label: "Motivo",
      type: "text",
      required: true,
    },
    {
      key: "date",
      label: "Data",
      type: "date",
      required: true,
    },
  ],

  consulta: [
    {
      key: "medico_id",
      label: "Médico",
      type: "select",
      required: true,
    },
    {
      key: "specialty",
      label: "Especialidade",
      type: "text",
      required: true,
    },
    {
      key: "hospital_id",
      label: "Clínica / Hospital",
      type: "select",
    },
    {
      key: "date",
      label: "Data da Consulta",
      type: "date",
      required: true,
    },
    {
      key: "reason",
      label: "Motivo da Consulta",
      type: "text",
    },
  ],

  cirurgia: [
    {
      key: "procedure",
      label: "Procedimento",
      type: "text",
      required: true,
    },
    {
      key: "medico_id",
      label: "Médico Cirurgião",
      type: "select",
      required: true,
    },
    {
      key: "hospital_id",
      label: "Hospital",
      type: "select",
      required: true,
    },
    {
      key: "date",
      label: "Data da Cirurgia",
      type: "date",
      required: true,
    },
  ],

  exame_sangue: [
    {
      key: "local_id",
      label: "Local / Laboratório",
      type: "select",
      required: true,
    },
    {
      key: "data_exame",
      label: "Data do Exame",
      type: "date",
      required: true,
    },
  ],

  exame_imagem: [
    {
      key: "hospital_id",
      label: "Local / Hospital",
      type: "select",
      required: true,
    },
    {
      key: "tipo",
      label: "Tipo de Exame (Ex: Raio-X, RM)",
      type: "text",
      required: true,
    },
    {
      key: "data_exame",
      label: "Data do Exame",
      type: "date",
      required: true,
    },
  ],

  credencial: [
    {
      key: "orgao",
      label: "Órgão Emissor / Instituição",
      type: "text",
      required: true,
    },
    {
      key: "validade",
      label: "Validade",
      type: "date",
      required: true,
    },
  ],

  outro: [
    {
      key: "custom_field_1",
      label: "Campo personalizado 1",
      type: "text",
    },
    {
      key: "custom_field_2",
      label: "Campo personalizado 2",
      type: "text",
    },
  ],
};

// ============================================================
// 4. SINCRONIZAÇÃO E FILA
// ============================================================

export interface SyncQueueItem {
  id?: string;
  chave: string;
  table:
    | "persons"
    | "documents"
    | "medicamentos"
    | "renovacoes"
    | "retiradas"
    | "fornecimentos"
    | "fornecimento_ciclos"
    | "fornecimento_itens"
    | "fornecimento_documentos"
    | "vaults"
    | "vaultMembers"
    | "medicos"
    | "farmacias"
    | "hospitais"
    | "locais"
    | "exames"
    | "consultas"
    | "cirurgias"
    | "doseLogs"
    | "credentials"
    | "cards"
    | "instituicoes"
    | "tratamentos"
    | "cids"
    | "anexos_clinicos"
    | "settings"
    | "versiculos"
    | "registros_saude"
    | "careflow_events_m2"
    | "exam_orders"
    | "exam_order_items"
    | "exam_sessions"
    | "exam_session_items"
    | "clinical_assets"
    | "clinical_asset_links"
    | "consultation_exam_order_links"
    | "surgery_consultation_links_m4"
    | "rehab_programs_m5"
    | "rehab_program_team_m5"
    | "rehab_sessions_m5"
    | "rehab_session_team_m5"
    | "rehab_origin_links_m5"
    | "rehab_session_events_m5"
    | "rehab_milestones_m5"
    | "hospitalizations_a5"
    | "hospitalization_stays_a5"
    | "hospitalization_team_a5"
    | "hospitalization_events_a5"
    | "hospitalization_relations_a5"
    | "hospitalization_discharge_a5"
    | "surgery_journey_events_a7"
    | "surgery_team_a7"
    | "vaccination_courses_a8"
    | "vaccination_events_a8"
    | "procedure_events_a9"
    | "sensitivity_events_a9"
    | "surgical_intents_a7m5"
    | "surgery_evidence_links_a7m5"
    | "health_reminders"
    | "notification_policies_p2"
    | "health_profiles"
    | "health_devices"
    | "health_goals"
    | "brain_active_probes"
    | "brain_active_probe_responses"
    | "a1_treatment_phases"
    | "a1_prescription_links"
    | "a1_supply_locations"
    | "vital_exercises"
    | "vital_foods"
    | "vital_nutrition_modalities"
    | "vital_training_plans"
    | "vital_nutrition_plans"
    | "vital_training_plan_versions"
    | "vital_nutrition_plan_versions"
    | "vital_workout_sessions"
    | "vital_meals"
    | "vital_training_checkins"
    | "vital_nutrition_checkins"
    | "vital_exercise_favorites"
    | "vital_audit";
  operation: "add" | "update" | "delete";
  payload: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  retry_count?: number;
  failed?: boolean;
  next_retry_at?: string | null;
  error?: string | null;
}

// ============================================================
// 5. ENTIDADES DE SAÚDE
// ============================================================

export interface Medicamento {
  /** CI360 M1: histórico de via e avaliação, sem substituir doses reais. */
  contexto_clinico_m1?: import("@/lib/clinical/episode-m1").MedicationClinicalContextM1 | null;
  id?: string;
  user_id: string;
  person_id?: string;

  document_id?: string;

  nome: string;
  dosagem: string;

  /** Verdade farmacêutica canônica sincronizada entre instalações. */
  catalog_snapshot?: MedicationCatalogSnapshot | null;

  medico_id?: string;
  farmacia_id?: string;
  hospital_id?: string;
  local_id?: string;

  tratamento_ids?: string[];

  medico: string;
  farmacia?: string;
  /** Etiqueta visual declarada, separada do fabricante por aquisição M126-M129. */
  laboratorio_etiqueta?: string | null;

  data_receita: string;
  proxima_renovacao: string;

  observacoes?: string;
  tipo_receita?: TipoReceita;
  lembrete_receita_modo?: ModoLembreteReceita;
  lembrete_receita_data?: string;
  tipo_uso?: "continuo" | "temporario" | "esporadico" | "sos";

  tipo_aquisicao?: "comprado" | "sus" | "gratuito";
  data_retorno_sus?: string;

  forma_farmaceutica?:
    | "capsula"
    | "comprimido"
    | "gota"
    | "injecao"
    | "adesivo";

  cor_principal?: string;
  cor_secundaria?: string;

  status?: "ativo" | "descontinuado";

  estoque_quantidade?: number;
  estoque_data_referencia?: string;
  estoque_horarios?: string[];

  estoque_unidade_por_dose?: number;
  estoque_unidade_medida?: string;
  estoque_ml_total?: number;
  estoque_gotas_por_ml?: number;

  formato?: string;
  cores?: string[];

  motivo_descontinuacao?: string;
  medico_descontinuacao_id?: string;
  medico_descontinuacao_nome?: string;
  substituido_por_id?: string;
  data_descontinuacao?: string;

  preco?: number;

  historico_dosagens?: {
    dosagem_antiga: string;
    data_mudanca: string;
    medico_responsavel: string;
  }[];

  created_at?: string;
  updated_at?: string;
  synced?: boolean;

  cid_ids?: string[];
  cid_id?: string;
}

/**
 * Contrato de criação.
 *
 * A entidade persistida continua tendo data_receita e
 * proxima_renovacao como strings, mas esses campos podem não
 * existir na entrada inicial. O repository normaliza ausência
 * para string vazia antes de persistir.
 */
export type CreateMedicamentoInput = Omit<
  Medicamento,
  | "id"
  | "user_id"
  | "person_id"
  | "data_receita"
  | "proxima_renovacao"
  | "created_at"
  | "updated_at"
  | "synced"
> & {
  id?: string;
  person_id: string;
  data_receita?: string;
  proxima_renovacao?: string;
};

/**
 * Campos em que null possui significado explícito durante
 * atualização:
 *
 * undefined = não alterar
 * null      = limpar
 *
 * Isso evita espalhar null pela entidade Medicamento inteira.
 */
export type NullableMedicamentoFields = {
  document_id?: string | null;

  medico_id?: string | null;
  farmacia_id?: string | null;
  hospital_id?: string | null;
  local_id?: string | null;

  farmacia?: string | null;
  laboratorio_etiqueta?: string | null;

  data_receita?: string | null;
  proxima_renovacao?: string | null;

  observacoes?: string | null;
  lembrete_receita_data?: string | null;
  data_retorno_sus?: string | null;

  cor_principal?: string | null;
  cor_secundaria?: string | null;

  estoque_quantidade?: number | null;
  estoque_data_referencia?: string | null;
  estoque_unidade_por_dose?: number | null;
  estoque_unidade_medida?: string | null;
  estoque_ml_total?: number | null;
  estoque_gotas_por_ml?: number | null;

  formato?: string | null;

  motivo_descontinuacao?: string | null;
  medico_descontinuacao_id?: string | null;
  medico_descontinuacao_nome?: string | null;
  substituido_por_id?: string | null;
  data_descontinuacao?: string | null;

  preco?: number | null;

  cid_id?: string | null;
};

type UpdateMedicamentoBase = Partial<
  Omit<
    Medicamento,
    | "id"
    | "user_id"
    | "person_id"
    | "created_at"
    | keyof NullableMedicamentoFields
  >
>;

export type UpdateMedicamentoInput =
  UpdateMedicamentoBase &
  NullableMedicamentoFields;

export interface Renovacao {
  /** A3: immutable event-scoped site as recorded, never live directory identity. */
  a3_location_snapshot?: import("@/lib/health-supply/a3-historical-locations").A3LocationSnapshot | null;
  a3_location_changes?: import("@/lib/health-supply/a3-historical-locations").A3LocationChange[] | null;
  id?: string;
  user_id: string;
  person_id?: string;

  /**
   * Relação com o cadastro atual do medicamento.
   *
   * Essa relação pode deixar de resolver no futuro caso o
   * medicamento seja removido. Por isso a renovação também
   * preserva um snapshot histórico de nome e dosagem.
   */
  medicamento_id: string;

  /**
   * Snapshot histórico.
   *
   * Estes campos pertencem ao evento de renovação/aquisição e
   * não devem depender do estado atual do Medicamento.
   *
   * São opcionais para compatibilidade com registros legados.
   */
  medicamento_nome?: string | null;
  medicamento_dosagem?: string | null;

  document_id?: string | null;
  medico_id?: string | null;
  farmacia_id?: string | null;
  hospital_id?: string | null;
  local_id?: string | null;

  /**
   * Quantidade adquirida/retirada.
   *
   * Não representa preço unitário e não deve ser multiplicada
   * automaticamente por preco.
   */
  quantidade?: number | null;

  /**
   * Valor total informado para a aquisição.
   */
  preco?: number | null;

  lote?: string | null;
  validade_produto?: string | null;

  /**
   * Data clínica da receita/prescrição.
   *
   * Mantida com a semântica histórica atual do Vault e usada
   * para validade da receita e regras clínicas relacionadas.
   */
  data: string;

  /**
   * Data real em que a compra ou retirada aconteceu.
   *
   * É a data correta para histórico financeiro.
   *
   * Opcional porque registros antigos possuem somente `data`.
   * Consumidores devem usar `data_aquisicao ?? data` como
   * fallback até os dados legados serem enriquecidos.
   */
  data_aquisicao?: string | null;

  anexo_url?: string | null;
  observacoes?: string | null;

  tipo_aquisicao?:
    | "comprado"
    | "sus"
    | "gratuito";

  data_proxima_retirada?:
    | string
    | null;

  exige_nova_receita?:
    boolean;

  created_at?: string;
  updated_at?: string;
  synced?: boolean;

  data_retorno_sus?:
    | string
    | null;
}

export type RetiradaStatus = "agendada" | "realizada" | "cancelada" | "nao_realizada";
export type RetiradaTipo = "sus" | "farmacia" | "outro";

export interface RetiradaReagendamento {
  data_anterior: string;
  horario_anterior?: string | null;

  nova_data: string;
  novo_horario?: string | null;

  motivo?: string | null;

  reagendada_em: string;
}

export interface Retirada {
  /** A3: event-scoped site snapshot; never derived retroactively for legacy records. */
  a3_location_snapshot?: import("@/lib/health-supply/a3-historical-locations").A3LocationSnapshot | null;
  a3_location_changes?: import("@/lib/health-supply/a3-historical-locations").A3LocationChange[] | null;
  fornecimento_id?: string | null;
  fornecimento_ciclo_id?: string | null;
  id?: string;
  user_id: string;
  person_id: string;
  medicamento_id: string;
  renovacao_origem_id?: string | null;
  renovacao_realizada_id?: string | null;
  medico_id?: string | null;
  farmacia_id?: string | null;
  hospital_id?: string | null;
  local_id?: string | null;
  medicamento_nome?: string | null;
  medicamento_dosagem?: string | null;
  data: string;
  horario?: string | null;
  tipo: RetiradaTipo;
  status: RetiradaStatus;
  quantidade_prevista?: number | null;
  quantidade_retirada?: number | null;
  exige_nova_receita?: boolean;
  observacoes?: string | null;
  realizada_em?: string | null;

  /**
   * Histórico append-only de reagendamentos.
   * Preserva o compromisso original sem criar inferências.
   */
  reagendamentos?: RetiradaReagendamento[];
  created_at?: string;
  updated_at?: string;
  synced?: boolean;
}

export interface DoseLog {
  id?: string;
  user_id: string;
  person_id?: string;
  medicamento_id: string;
  data: string;
  horario: string;
  tomado_em?: string;
  ignorado_em?: string;
  quantidade?: number;
  /** Origem explícita do evento; legado sem valor continua compatível. */
  dose_kind?: "scheduled" | "sos" | "extra" | "planned";
  /** Contexto livre informado pelo usuário, nunca inferido pelo Vault. */
  motivo?: string;
  created_at?: string;
  updated_at?: string;
  synced?: boolean;
}

export interface Exame {
  id?: string;
  user_id?: string;
  person_id?: string;
  document_id?: string;
  nome: string;
  medico_id?: string;
  local_id?: string;
  laboratorio?: string;
  medico?: string;
  data: string;
  horario?: string;
  data_retorno?: string;
  motivo?: string;
  observacoes?: string;
  anexo_url?: string;
  tratamento_ids?: string[];
  cid_ids?: string[];
  synced?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Cirurgia {
  regiao_corporal?: SurgeryRegion | null;
  lateralidade?: SurgerySide | null;
  id?: string;
  user_id: string;
  person_id?: string;
  document_id?: string;
  procedimento: string;
  data: string;
  horario?: string;
  medico_id?: string;
  hospital_id?: string;
  local_id?: string;
  status: "agendada" | "realizada" | "cancelada";
  observacoes?: string;
  tratamento_ids?: string[];
  cid_ids?: string[];
  created_at?: string;
  updated_at?: string;
  synced?: boolean;
}

export interface Consulta {
  /** CI360 M1: desfecho estruturado e fonte declarada, separado da prescrição. */
  desfecho_clinico_m1?: import("@/lib/clinical/episode-m1").ConsultationOutcomeM1 | null;
  id?: string;
  user_id: string;
  person_id?: string;
  document_id?: string;
  especialidade: string;
  medico: string;
  medico_id?: string;
  hospital_id?: string;
  local_id?: string;
  data: string;
  horario?: string;
  motivo?: string;
  observacoes?: string;
  anexo_url?: string;
  status: "agendada" | "realizada" | "cancelada";
  tratamento_ids?: string[];
  cid_ids?: string[];
  /** CI360 P6 — seleção DIRETA, independente de tratamentos; requer migração Supabase. */
  medicamento_ids?: string[];
  /** CI360 P6 P2 R2 — candidatos rejeitados explicitamente, sincronizados na consulta. */
  revisao_vinculos_rejeitados?: string[];
  /** Fonte: percepção pessoal declarada, não diagnóstico. */
  percepcao_paciente?: string;
  /** Orientação relatada pelo usuário, não prescrição alterada. */
  orientacao_profissional?: string;
  /** Plano de acompanhamento declarado, sem criação automática de tarefas. */
  proximos_passos?: string;
  created_at?: string;
  updated_at?: string;
  synced?: boolean;
}

// ============================================================
// 6. REGISTROS DE SAÚDE DIÁRIOS
// ============================================================

export interface RegistroSaude {
  device_id?: string | null;
  source?: "manual" | "samsung_manual" | "health_connect" | null;
  source_record_id?: string | null;
  inicio_em?: string | null;
  fim_em?: string | null;
  id?: string;
  user_id: string;
  person_id?: string;
  categoria: CategoriaRegistro;
  tipo: string;
  nome: string;
  intensidade?: number;
  valor_medicao?: string;

  /** Valor estruturado quando o registro admite número simples. */
  valor_numerico?: number;

  /** Unidade explícita; nunca inferida na apresentação. */
  unidade_medida?: string;

  /** Chave canônica usada para agrupar uma série longitudinal. */
  registro_chave?: string;

  /** Duração observada, quando fizer sentido (sono, dor, atividade). */
  duracao_minutos?: number;

  /** Contexto descritivo opcional, sem inferência causal. */
  contexto?: string;

  data: string;
  horario: string;
  observacoes?: string;
  medicamento_id?: string;
  tratamento_ids?: string[];
  cid_ids?: string[];
  created_at?: string;
  updated_at?: string;
  synced?: boolean;
}

// ============================================================
// 7. VAULTS E COMPARTILHAMENTO
// ============================================================

export interface Vault {
  id?: string;

  /**
   * Conta proprietária/criadora do cofre.
   */
  user_id: string;

  /**
   * Pessoa da conta proprietária à qual este cofre pertence.
   */
  person_id: string;

  name: string;
  description?: string;

  /**
   * Chave visual do ícone.
   */
  icon: string;

  /**
   * Cor canônica em HEX.
   */
  color: string;

  created_at: string;
  updated_at: string;
  synced: boolean;
}

export interface VaultMember {
  id?: string;

  /**
   * Cofre ao qual este convite/membership pertence.
   */
  vault_id: string;

  /**
   * Conta do usuário convidado.
   */
  user_id?: string;

  /**
   * Pessoa da conta convidada vinculada ao compartilhamento.
   */
  person_id?: string;

  email: string;
  name?: string;

  permission: VaultPermission;

  /**
   * ID da conta que enviou o convite.
   */
  invited_by: string;

  status: VaultMemberStatus;

  invited_at: string;

  /**
   * Campo local legado.
   */
  created_at?: string;

  updated_at: string;
  synced: boolean;
}

/**
 * Tipo legado.
 *
 * A arquitetura atual persiste o vínculo com o cofre através de
 * Document.vault_id.
 */
export interface VaultDocument {
  document_id: string;
  vault_id: string;
  shared_by: string;
  shared_at: string;
}

// ============================================================
// 8. PROFISSIONAIS, LOCAIS E INSTITUIÇÕES
// ============================================================

export interface Medico {
  id?: string;
  user_id: string;
  nome: string;
  /** A1 - optional, never infer a board or professional license from an empty field. */
  categoria_profissional?: import("@/components/saude/ProfessionalClassificationA1").A1ProfessionalCategory | null;
  conselho_tipo?: string | null;
  conselho_numero?: string | null;
  conselho_uf?: string | null;
  a1_identity_revision?: number;
  especialidade?: string;
  crm?: string;
  telefone?: string;
  email?: string;
  observacoes?: string;
  created_at: string;
  hospital_ids?: string[];
  tratamento_ids?: string[];
  local_ids?: string[];
  updated_at: string;
  synced: boolean;

  /**
   * Campo legado local.
   *
   * Médico é entidade global da conta.
   */
  person_id?: string;
}

export interface Farmacia {
  id?: string;
  user_id: string;
  nome: string;
  endereco?: string;
  telefone?: string;
  observacoes?: string;

  tipo?: "particular" | "sus" | "posto";
  is_sus?: boolean;

  created_at: string;
  updated_at: string;
  synced: boolean;

  /**
   * Campo legado local.
   *
   * Farmácia é global por conta.
   */
  person_id?: string;
}

export interface Hospital {
  id?: string;
  user_id: string;
  nome: string;
  endereco?: string;
  telefone?: string;
  tipo?: string;
  observacoes?: string;
  medico_ids?: string[];
  tratamento_ids?: string[];
  created_at: string;
  updated_at: string;
  synced: boolean;

  /**
   * Campo legado local.
   *
   * Hospital é global por conta.
   */
  person_id?: string;
}

export type LocalSaudeTipo =
  | "posto_saude"
  | "ubs"
  | "caps"
  | "posto"
  | "laboratorio"
  | "clinica"
  | "outro";



export interface LocalSaude {
  id?: string;
  user_id: string;
  nome: string;
  endereco?: string;
  telefone?: string;
  medico_ids?: string[];
  tratamento_ids?: string[];
  tipo?: string;
  observacoes?: string;
  created_at: string;
  updated_at: string;
  synced: boolean;

  /**
   * Campo legado local.
   *
   * Local é global por conta.
   */
  person_id?: string;
}

export interface InstituicaoEnsino {
  id?: string;
  user_id: string;
  nome: string;
  cnpj?: string;
  created_at: string;
  updated_at: string;
  synced: boolean;
}

// ============================================================
// 9. CIDs E TRATAMENTOS
// ============================================================

export interface Cid {
  id?: string;
  user_id: string;
  person_id?: string;
  codigo: string;
  descricao: string;
  data_diagnostico?: string;
  medico_id?: string;
  hospital_id?: string;
  local_id?: string;
  observacoes?: string;
  anexo_url?: string;
  created_at: string;
  updated_at: string;
  synced: boolean;
}

export interface Tratamento {
  id?: string;
  user_id: string;
  person_id?: string;
  nome: string;
  cid_ids?: string[];
  medicamento_ids?: string[];
  condicao?: string;
  medico_ids?: string[];
  hospital_ids?: string[];
  local_ids?: string[];
  data_inicio?: string;
  status: "ativo" | "concluido" | "suspenso";
  cor?: string;
  observacoes?: string;
  created_at: string;
  updated_at: string;
  synced: boolean;
}

// ============================================================
// 10. CREDENCIAIS E CARTÕES
// ============================================================

export interface Credential {
  id?: string;
  user_id: string;

  /**
   * Toda credencial pertence obrigatoriamente a uma Person.
   */
  person_id: string;

  vault_id?: string;
  title: string;
  username?: string;
  password_encrypted: string;
  url?: string;
  notes?: string;
  category: "banco" | "social" | "trabalho" | "outros";

  password_history?: {
    encrypted: string;
    date: string;
  }[];

  created_at: string;
  updated_at: string;
  synced: boolean;
}

export interface BankCard {
  id?: string;
  user_id: string;

  /**
   * Todo cartão/conta pertence obrigatoriamente a uma Person.
   */
  person_id: string;

  title: string;
  bank_name: string;
  type: CardType;

  card_number_encrypted?: string;
  card_holder?: string;
  brand?: CardBrand;
  expiry_date?: string;
  cvv_encrypted?: string;

  agency?: string;
  account?: string;
  notes?: string;

  created_at: string;
  updated_at: string;
  synced: boolean;
}

// ============================================================
// 11. CONFIGURAÇÕES E VERSÍCULOS
// ============================================================

export type HealthIntelligenceDecisionAction =
  | "accepted"
  | "dismissed";

export interface HealthIntelligenceDecision {
  /**
   * Pessoa a quem pertence a entidade analisada.
   */
  person_id: string;

  /**
   * Tipo lógico da entidade.
   *
   * Mantido como string porque esta infraestrutura é
   * transversal e poderá ser usada fora de Saúde.
   */
  entity_type: string;

  entity_id: string;

  /**
   * Identificador estável do tipo de inconsistência.
   *
   * Ex.:
   * possible_name_typo
   * prescription_type_mismatch
   * presentation_not_found
   */
  issue_key: string;

  /**
   * Valor efetivamente revisado pelo usuário.
   *
   * Se ele mudar depois, a decisão anterior deixa de
   * esconder uma nova inconsistência.
   */
  detected_value: string;

  /**
   * Sugestão apresentada no momento da revisão.
   */
  suggested_value?: string;

  decision:
    HealthIntelligenceDecisionAction;

  reviewed_at: string;
}

export type { ActiveProbe, ActiveProbeResponse } from "@/lib/health-intelligence/active-probing/types";

export interface AppSettings {
  id: string;
  user_id: string;
  default_person_id?: string;

  /**
   * Decisões tomadas pelo usuário sobre alertas de
   * qualidade/inteligência.
   *
   * Campo não indexado: não exige nova versão do Dexie.
   */
  health_intelligence_decisions?:
    HealthIntelligenceDecision[];

  /** Brain V5: JSON não indexado; não exige bump do Dexie. */
  brain_v5_alert_ledger?: import("@/lib/health-intelligence/brain-v5").BrainV5Alert[];

  created_at?: string;
  updated_at?: string;
  synced?: boolean;
}

export interface Versiculo {
  id: string;
  user_id: string;
  texto: string;
  referencia: string;
  created_at: string;
  updated_at?: string;
}
