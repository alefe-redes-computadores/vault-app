"use client";
import {db} from '@/lib/db';
import {getLocalFirstAuthUser} from '@/lib/supabase/local-auth';
import {connectAvailable,healthConnectBridge} from '@/lib/health-connect/bridge';
import {setConnectNutritionConsent} from '@/lib/repositories/healthConnect';
import {own,requireScope} from '@/lib/vital/validation';
import type {Scope} from '@/lib/vital/model';
import type {VitalRepository} from '@/lib/vital/repository';
import {NUTRITION_ORIGIN} from '@/lib/vital/nutrition-f2/health-connect-nutrition';
import {createExternalImportReview} from '@/lib/vital/nutrition-f2/external-import-review';
/** Host adapter. Call only with the activated canonical storage; no background import. */
export function createNutritionConnectRuntime(scope:Scope,repo:VitalRepository,activeScope:()=>Scope|null){
 const s=requireScope(scope);async function binding(){
  const {data,error}=await getLocalFirstAuthUser();if(error||data.user?.id!==s.user_id||!own(activeScope(),s))throw Error('Conta ou pessoa ativa mudou.');
  const row=await db.health_connect_connections.get(s.user_id);if(!row||row.id!==s.user_id||!own(row,s))throw Error('Vincule esta pessoa ao Health Connect.');return row;
 }
 async function current(){const b=await binding();if(!connectAvailable())throw Error('Nutrição externa exige APK compatível.');const permission=await healthConnectBridge.nutritionStatus();const after=await binding();if(after.revision!==b.revision)throw Error('Vínculo mudou.');return {scope:s,revision:b.revision,origin:NUTRITION_ORIGIN,nutritionReadGranted:permission.available===true&&permission.granted===true&&b.nutrition_read===true};}
 const review=createExternalImportReview({scope:s,repo,current,bridge:healthConnectBridge,newId:()=>crypto.randomUUID(),now:()=>new Date(),offsetAt:start=>-new Date(start).getTimezoneOffset()});
 return {current,review,async authorize(){const before=await binding();if(!connectAvailable())throw Error('Atualize o APK.');const p=await healthConnectBridge.requestNutritionPermission();const after=await binding();if(after.revision!==before.revision||!p.available||!p.granted)throw Error('Permissão não concedida ou vínculo mudou.');review.cancel();await setConnectNutritionConsent(s.person_id,before.revision,true);},async revoke(){const b=await binding();review.cancel();await setConnectNutritionConsent(s.person_id,b.revision,false);}};
}
