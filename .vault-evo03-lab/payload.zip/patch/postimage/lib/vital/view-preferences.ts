import type {Scope} from './model';
import {civil,localDay,requireScope} from './validation';
export type VitalPeriod='7'|'30'|'90';
export type VitalPlanFilter='all'|'training'|'nutrition';
export type VitalExerciseMetric='duration'|'distance'|'kg'|'lb';
export type VitalViewPreferences={trainingDay:string;nutritionDay:string;period:VitalPeriod;planFilter:VitalPlanFilter;exerciseMetric:VitalExerciseMetric};
const defaults=(today:string):VitalViewPreferences=>({trainingDay:civil(today),nutritionDay:civil(today),period:'30',planFilter:'all',exerciseMetric:'duration'});
const key=(scope:Scope)=>{const s=requireScope(scope);return s.user_id+':'+s.person_id;};
export function periodStart(today:string,period:VitalPeriod):string{civil(today);if(!['7','30','90'].includes(period))throw Error('Período inválido.');const d=new Date(today+'T12:00:00');d.setDate(d.getDate()-Number(period)+1);return civil(localDay(d));}
/** UI-only, single active identity; no storage, facts, writers or cross-account history. */
export function createVitalViewMemory(){let active:string|null=null;let values:Partial<VitalViewPreferences>={};
 return {activate(scope:Scope|null){const next=scope?key(scope):null;if(next!==active){active=next;values={};}},
 read<K extends keyof VitalViewPreferences>(scope:Scope,name:K,today:string):VitalViewPreferences[K]{const fallback=defaults(today)[name];return active===key(scope)?values[name]??fallback:fallback;},
 write<K extends keyof VitalViewPreferences>(scope:Scope,name:K,value:VitalViewPreferences[K]):boolean{if(active!==key(scope))return false;
 if(name==='trainingDay'||name==='nutritionDay')civil(value);else if(name==='period'&&!['7','30','90'].includes(value))return false;else if(name==='planFilter'&&!['all','training','nutrition'].includes(value))return false;else if(name==='exerciseMetric'&&!['duration','distance','kg','lb'].includes(value))return false;
 values={...values,[name]:value};return true;}};
}
export const vitalViewMemory=createVitalViewMemory();
