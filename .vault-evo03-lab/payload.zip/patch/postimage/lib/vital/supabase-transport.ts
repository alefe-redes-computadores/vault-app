/** Bind to the existing authenticated Supabase client; never create another auth or sync runtime. */
import type { Scope, TableName } from './model';
import { vitalRemoteFields, vitalTable, type VitalRemote } from './cloud-transport';
import { requireId, requireScope, fail } from './validation';
type Result={data:unknown;error:{message:string;code?:string}|null};
interface Query extends PromiseLike<Result>{select(columns:string):Query;eq(column:string,value:string|number):Query;gt(column:string,value:string):Query;order(column:string,options:{ascending:boolean}):Query;limit(count:number):Query;maybeSingle():Query;single():Query;}
interface Table{select(columns:string):Query;insert(payload:Record<string,unknown>):Query;update(payload:Record<string,unknown>):Query;}
export interface SupabaseVitalClient{from(table:string):Table;}
/** Read capability is explicit and pinned to the reviewed cumulative release.
 * Absence means F1 schema; never probe by reading private rows or silently retry a failed F2 read as F1.
 * This is a caller-supplied release guard, not proof of live server capability. */
export type VitalReadSchema = {mode:'f1'} | {mode:'f2';protocol:'vault-vital-f2-meal-v1';baseline:string;approvedBaseline:string;enabled:true;recipes?:true;planTargets?:true};
export function createSupabaseVitalTransport(client:SupabaseVitalClient,authenticatedUser:()=>Promise<string|null>,schema:VitalReadSchema={mode:'f1'}):VitalRemote{
 if(schema.mode!=='f1'&&schema.mode!=='f2')fail('Schema Vital desconhecido.');
 const f2=schema.mode==='f2';
 if(f2&&(schema.enabled!==true||schema.protocol!=='vault-vital-f2-meal-v1'||!(/^[a-f0-9]{40}$/).test(schema.baseline)||schema.baseline!==schema.approvedBaseline))fail('Capacidade de leitura F2 não certificada.');
 // F2 writes must use the dedicated CAS/audit RPC; generic table DML cannot claim a transactional ACK.
 const recipeTable=(t:TableName)=>t==='vital_recipes'||t==='vital_recipe_versions';
 const recipeRead=f2&&schema.recipes===true;
 const guardWrite=(t:TableName,payload:Record<string,unknown>)=>{
  if(recipeTable(t)||(t==='vital_audit'&&payload.target_table==='vital_recipes'))fail('Receitas F2 exigem escritor remoto transacional.');
  if(t==='vital_nutrition_plan_versions'&&Object.hasOwn(payload,'targets_f2'))fail('Metas F2 aguardam escritor remoto certificado.');
  const previous=payload.previous;
  if((t==='vital_meals'&&Object.hasOwn(payload,'nutrition_f2'))||(t==='vital_audit'&&previous!==null&&typeof previous==='object'&&Object.hasOwn(previous,'nutrition_f2')))fail('Operação nutricional F2 exige escritor transacional.');
 };
 const checked=async(table:TableName,scope:Scope)=>{if(!vitalTable(table)||recipeTable(table)&&!recipeRead)fail('Tabela não autorizada para esta capacidade.');const s=requireScope(scope);if(await authenticatedUser()!==s.user_id)fail('Conta de sincronização mudou.');return s;};
 const fields=(t:TableName)=>vitalRemoteFields(t).filter(k=>(k!=='nutrition_f2'||f2)&&(k!=='targets_f2'||f2&&schema.planTargets===true)).join(',');
 const read=async(q:Query,s:Scope)=>{const result=await q;if(await authenticatedUser()!==s.user_id)fail('Conta mudou durante sincronização.');if(result.error)throw Error(`Sincronização Vital indisponível (${result.error.code??'erro remoto'}).`);return result.data;};
 const scoped=(q:Query,s:Scope)=>q.eq('user_id',s.user_id).eq('person_id',s.person_id);
 return {
  ...(recipeRead?{recipeReadEnabled:true as const}:{}),
  ...(f2?{mealReadEnabled:true as const}:{}),
  async get(t,scope,id){const s=await checked(t,scope);return (await read(scoped(client.from(t).select(fields(t)),s).eq('id',requireId(id)).maybeSingle(),s))??null;},
  async insert(t,payload){const s=await checked(t,{user_id:String(payload.user_id??''),person_id:String(payload.person_id??'')});guardWrite(t,payload);return read(client.from(t).insert(payload).select(fields(t)).single(),s);},
  async cas(t,scope,id,expected,payload){const s=await checked(t,scope);if(Object.keys(payload).some(k=>['id','user_id','person_id','created_at'].includes(k)))fail('Identidade não pode ser atualizada.');if(!Number.isSafeInteger(expected)||expected<1)fail('Revisão esperada inválida.');guardWrite(t,payload);return (await read(scoped(client.from(t).update(payload),s).eq('id',requireId(id)).eq('revision',expected).select(fields(t)).maybeSingle(),s))??null;},
  async page(t,scope,afterId,limit){const s=await checked(t,scope);if(!Number.isInteger(limit)||limit<1||limit>1000)fail('Limite inválido.');let q=scoped(client.from(t).select(fields(t)),s).order('id',{ascending:true}).limit(limit);if(afterId!==null)q=q.gt('id',requireId(afterId));const rows=await read(q,s);if(!Array.isArray(rows))fail('Página inválida.');return rows;}
 };
}
