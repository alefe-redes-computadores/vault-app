/** Read-only bridge between sealed USDA exporter and review UI. No activation, persistence or external lookup. */
import { UNITS, normalized, type Composition, type Nutrient, type Value } from './nutrition';
export type FrozenManifest = {provider:'usda';release:string;sourceZipSha256:string;foodsSha256:string;status:'CANDIDATES_ONLY';activation:false;rows:number;license:'CC0-1.0';attribution:string;captured:string;sourceUrl:string;verifiedNutrientIds:number[];dictionaryMismatchIds:number[];counts:Record<string,number>};
export type FrozenCandidate = Readonly<{sourceId:string;version:string;composition:Composition;sourceRecordSha256:string;requiresReview:true}>;
const NUTRIENT_IDS = {'energy_kcal': 1008, 'protein_g': 1003, 'fat_g': 1004, 'carbohydrate_g': 1005, 'fiber_g': 1079, 'sodium_mg': 1093, 'calcium_mg': 1087, 'iron_mg': 1089, 'potassium_mg': 1092, 'magnesium_mg': 1090, 'phosphorus_mg': 1091, 'zinc_mg': 1095, 'selenium_ug': 1103, 'vitamin_c_mg': 1162, 'vitamin_b12_ug': 1178, 'vitamin_a_rae_ug': 1106, 'vitamin_b6_mg': 1175, 'thiamin_mg': 1165, 'riboflavin_mg': 1166, 'niacin_mg': 1167, 'folate_ug': 1177, 'vitamin_e_mg': 1109, 'vitamin_k_ug': 1185, 'trans_fat_g': 1257, 'saturated_fat_g': 1258} as const;
const ATTR='U.S. Department of Agriculture, Agricultural Research Service. FoodData Central. https://fdc.nal.usda.gov/';
const exact=(o:Record<string,unknown>,keys:readonly string[])=>Object.keys(o).length===keys.length&&keys.every(k=>Object.hasOwn(o,k));
function evidenceValue(key:Nutrient,rows:unknown,id:string,verified:Set<number>):Value{
 const n=NUTRIENT_IDS[key as keyof typeof NUTRIENT_IDS];if(!n||!verified.has(n)||!Array.isArray(rows)||!rows.length)fail('Nutriente sem autoridade na release');
 for(const raw of rows){const r=obj(raw);if(Object.values(r).some(v=>typeof v!=='string')||r.fdc_id!==id||typeof r.nutrient_id!=='string'||Number(r.nutrient_id)!==n||typeof r.id!=='string'||typeof r.amount!=='string')fail('Linha original USDA divergente');}
 if(rows.length>1)return {state:'unknown'};
 const r=obj(rows[0]),a=(r.amount as string).trim();if(!a)return {state:'not_reported'};
 // Python float supports some uncommon notations. Fail closed if the source is not a decimal/scientific value.
 if(!/^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$/.test(a))return {state:'unknown'};
 const v=Number(a);if(!Number.isFinite(v)||v<0||v>1e6||v===0||String(r.loq??'').trim()||String(r.footnote??'').trim())return {state:'unknown'};
 return {state:'known',amount:v,unit:UNITS[key]};
}
const hashPattern=/^[a-f0-9]{64}$/;
function fail(message:string):never { throw Error(message); }
function obj(x:unknown):Record<string,unknown>{if(!x||typeof x!=='object'||Array.isArray(x))fail('Objeto inválido');return x as Record<string,unknown>;}
const decode=(b:Uint8Array)=>new TextDecoder('utf-8',{fatal:true}).decode(b);
const stable=(x:unknown):string=>{if(x===null||typeof x!=='object')return JSON.stringify(x);if(Array.isArray(x))return '['+x.map(stable).join(',')+']';const o=obj(x);return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+stable(o[k])).join(',')+'}';};
async function sha(b:Uint8Array){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(b))),x=>x.toString(16).padStart(2,'0')).join('');}
/** expectedManifestSha256 must come from separately verified release registry, not from the same archive. */
export async function readFrozenUSDA(manifestBytes:Uint8Array,foodBytes:Uint8Array,expectedManifestSha256:string):Promise<{manifest:FrozenManifest;candidates:FrozenCandidate[];activation:false}>{
 if(!hashPattern.test(expectedManifestSha256)||manifestBytes.length>256_000||foodBytes.length>150_000_000||await sha(manifestBytes)!==expectedManifestSha256)fail('Manifesto divergente');
 const m=obj(JSON.parse(decode(manifestBytes))) as unknown as FrozenManifest;
 if(m.provider!=='usda'||!/^usda-(foundation|sr)-\d{4}-\d{2}(?:-v(?:[2-9]|[1-9]\d+))?$/.test(m.release)||!hashPattern.test(m.sourceZipSha256)||!hashPattern.test(m.foodsSha256)||m.status!=='CANDIDATES_ONLY'||m.activation!==false||m.license!=='CC0-1.0'||m.sourceUrl!=='https://fdc.nal.usda.gov/download-datasets/'||m.attribution!==ATTR||!/^\d{4}-\d{2}-\d{2}$/.test(m.captured)||!Number.isFinite(Date.parse(m.captured))||new Date(m.captured).toISOString().slice(0,10)!==m.captured||!Number.isSafeInteger(m.rows)||m.rows<1||m.rows>200_000||await sha(foodBytes)!==m.foodsSha256)fail('Release inválida ou adulterada');
 const ids=Object.values(NUTRIENT_IDS);if(!Array.isArray(m.verifiedNutrientIds)||!Array.isArray(m.dictionaryMismatchIds)||[...m.verifiedNutrientIds,...m.dictionaryMismatchIds].length!==ids.length||new Set([...m.verifiedNutrientIds,...m.dictionaryMismatchIds]).size!==ids.length||[...m.verifiedNutrientIds,...m.dictionaryMismatchIds].some(i=>!ids.includes(i as typeof ids[number]))||![1003,1004,1005].every(i=>m.verifiedNutrientIds.includes(i)))fail('Dicionário USDA divergente');const verified=new Set(m.verifiedNutrientIds);
 const text=decode(foodBytes);if(!text.endsWith('\n'))fail('JSONL incompleto');const lines=text.slice(0,-1).split('\n');if(lines.length!==m.rows)fail('Contagem divergente');
 const seen=new Set<string>();const candidates:FrozenCandidate[]=[];
 for(const line of lines){if(line.length>1_000_000)fail('Linha excede limite');const r=obj(JSON.parse(line));const c=obj(r.composition) as unknown as Composition;const s=c.source;
 if(typeof r.sourceId!=='string'||!/^\d+$/.test(r.sourceId)||seen.has(r.sourceId)||r.version!==m.release||r.requiresReview!==true||typeof r.sourceRecordSha256!=='string'||!hashPattern.test(r.sourceRecordSha256)||!s||s.provider!=='usda'||s.recordId!==r.sourceId||s.version!==m.release||s.license!==m.license||s.attribution!==m.attribution||s.retrievedAt!==m.captured+'T00:00:00Z'||typeof c.name!=='string'||!c.name.trim()||c.name.length>1000||c.base?.value!==100||c.base.unit!=='g'||c.preparation!=='unknown'||c.edibleBasis!=='unknown'||c.equivalence!==undefined||c.declaredPortion!==undefined||c.portionDescription!==undefined)fail('Candidato incompatível com a release');
 const evidence=obj(r.rawEvidence);const food=obj(evidence.food);if(food.fdc_id!==r.sourceId||typeof food.description!=='string'||food.description.trim()!==c.name||food.data_type!==(m.release.startsWith('usda-foundation-')?'foundation_food':'sr_legacy_food'))fail('Evidência do alimento divergente');
 // Python exporter uses canonical UTF-8 JSON. Its raw CSV evidence contains strings only.
 if(await sha(new TextEncoder().encode(stable(evidence)))!==r.sourceRecordSha256)fail('Evidência original divergente');
 const values=obj(c.values),nutrientRows=obj(evidence.nutrient_rows);if(!exact(values,Object.keys(nutrientRows)))fail('Cobertura USDA divergente da evidência');for(const [key,raw] of Object.entries(values)){if(!Object.hasOwn(UNITS,key))fail('Nutriente desconhecido');const v=obj(raw) as Value;if(v.state!=='known'&&v.state!=='unknown'&&v.state!=='not_reported')fail('Estado não emitido pelo importador');if(v.state==='known'&&(v.amount<=0||v.unit!==UNITS[key as Nutrient]))fail('Valor ou unidade divergente');normalized(key as Nutrient,v);if(stable(v)!==stable(evidenceValue(key as Nutrient,nutrientRows[key],r.sourceId,verified)))fail('Valor USDA divergente da evidência');}
 seen.add(r.sourceId);candidates.push({sourceId:r.sourceId,version:m.release,composition:structuredClone(c),sourceRecordSha256:r.sourceRecordSha256,requiresReview:true});
 }
 return {manifest:structuredClone(m),candidates,activation:false};
}
