/** Read-only collection from the existing queue, durable ACK and audit table.
 * The network writer revalidates the same byte-exact snapshot before sending. */
import type {Scope,MealRow,VitalAudit} from '../model';
import type {CanonicalDb,CanonicalTable} from '../storage-dexie';
import {vitalAckId,vitalWireRow,vitalFingerprint,VitalSyncConflict} from '../cloud-transport';
import type {VitalQueueItem} from '../queue-finalize';
import {own,requireId,requireScope} from '../validation';
import {recoverAndFinalizeMealF2} from './recover-meal-batch';
const must=(ok:unknown,m:string):void=>{if(!ok)throw new VitalSyncConflict(m);};
const canonical=(x:unknown)=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
type Lookup=Omit<CanonicalTable,'where'>&{where(index:string):{equals(key:string):{toArray():PromiseLike<Record<string,unknown>[]>}}};
export async function collectMealBatch(db:CanonicalDb,scope:Scope,queueItem:VitalQueueItem){
 const s=requireScope(scope),q=structuredClone(queueItem);must(q.table==='vital_meals'&&q.operation!=='delete'&&!!q.id,'Operação F2 inválida.');const id=requireId(q.payload.id);requireId(q.id);must(q.chave===`vital_meals:${id}`,'Chave F2 divergente.');
 const persons=db.table('persons'),meals=db.table('vital_meals'),audits=db.table('vital_audit') as unknown as Lookup,acks=db.table('vital_sync_ack'),queue=db.table('syncQueue') as unknown as Lookup;
 return db.transaction('r',[persons,meals,audits as unknown as CanonicalTable,acks,queue as unknown as CanonicalTable],async()=>{
  must((await persons.get(s.person_id))?.user_id===s.user_id,'Pessoa fora da conta.');const local=vitalWireRow('vital_meals',await meals.get(id),s);must(local.nutrition_f2,'Refeição não é F2.');
  const savedQ=await queue.get(q.id!);must(savedQ&&savedQ.chave===q.chave&&savedQ.table===q.table&&savedQ.operation===q.operation&&savedQ.updated_at===q.updated_at&&canonical(savedQ.payload)===canonical(q.payload),'Fila alterada; replanejar.');must(canonical(vitalWireRow('vital_meals',q.payload,s))===canonical(local),'Fila não corresponde ao registro.');
  const sameKey=await queue.where('chave').equals(q.chave).toArray();must(sameKey.length===1&&sameKey[0].id===q.id,'Chave de fila duplicada.');
  const ackKey=vitalAckId('vital_meals',s,id),ack=await acks.get(ackKey);let baseAck:{revision:number;fingerprint:string}|null=null;
  if(ack){must(ack.id===ackKey&&ack.user_id===s.user_id&&ack.person_id===s.person_id&&ack.table==='vital_meals'&&ack.row_id===id&&ack.pending_revision===null&&ack.pending_fingerprint===null,'ACK incompatível ou pendente.');if(ack.revision!==null){must(Number.isSafeInteger(ack.revision)&&Number(ack.revision)>0&&Number(ack.revision)<=local.revision&&typeof ack.fingerprint==='string'&&/^[a-f0-9]{64}$/.test(ack.fingerprint),'ACK inválido.');baseAck={revision:Number(ack.revision),fingerprint:String(ack.fingerprint)};}else must(ack.fingerprint===null,'ACK vazio divergente.');}
  const history:VitalAudit[]=[];const auditQueues:VitalQueueItem[]=[];const seen=new Set<number>();
  for(const row of await audits.where('target_id').equals(id).toArray()){
   if(row.target_table!=='vital_meals')continue;const a=vitalWireRow('vital_audit',row,s);must(!seen.has(a.previous_revision),'Histórico de revisões duplicado.');seen.add(a.previous_revision);history.push(a);
   const entries=await queue.where('chave').equals(`vital_audit:${a.id}`).toArray();const required=a.previous_revision>=(baseAck?.revision??1)&&a.previous_revision<local.revision;
   if(required){must(entries.length===1,'Fila de auditoria incompleta.');const raw=entries[0] as unknown as VitalQueueItem;must(raw.table==='vital_audit'&&raw.operation!=='delete'&&canonical(vitalWireRow('vital_audit',raw.payload,s))===canonical(a),'Fila de auditoria divergente.');auditQueues.push(raw);}else must(entries.length===0,'Auditoria residual exige reconciliação.');
  }
  return {scope:s,local,baseAck,audits:history,mealQueue:q,auditQueues};
 });
}
export async function processQueuedMealF2(deps:Parameters<typeof recoverAndFinalizeMealF2>[0],scope:Scope,item:VitalQueueItem){
 const input=await collectMealBatch(deps.db,scope,item);return recoverAndFinalizeMealF2(deps,input);
}
/** The existing queue iterates a snapshot; a joint ACK may already have removed this exact
 * entry. Only durable matching ACK + current synced row + no replacement queue prove completion. */
export async function alreadyFinalizedVitalEntry(db:CanonicalDb,scope:Scope,item:VitalQueueItem){
 const s=requireScope(scope);if((item.table!=='vital_meals'&&item.table!=='vital_audit'&&item.table!=='vital_recipes'&&item.table!=='vital_recipe_versions')||!['add','update'].includes(item.operation))return false;
 const table=item.table,wire=vitalWireRow(table,item.payload,s);const digest=await vitalFingerprint(table,wire,s);const queue=db.table('syncQueue') as unknown as Lookup,rows=db.table(table),acks=db.table('vital_sync_ack'),persons=db.table('persons');
 return db.transaction('r',[queue as unknown as CanonicalTable,rows,acks,persons],async()=>{
  if((await persons.get(s.person_id))?.user_id!==s.user_id||item.chave!==`${table}:${wire.id}`||!item.id||await queue.get(item.id)||(await queue.where('chave').equals(item.chave).toArray()).length)return false;
  const row=await rows.get(wire.id),ack=await acks.get(vitalAckId(table,s,wire.id));if(!row||row.synced!==true||!ack||ack.id!==vitalAckId(table,s,wire.id)||!own(ack as unknown as Scope,s)||ack.table!==table||ack.row_id!==wire.id||ack.revision!==wire.revision||ack.fingerprint!==digest||ack.pending_revision!==null||ack.pending_fingerprint!==null)return false;
  return canonical(vitalWireRow(table,row,s))===canonical(wire);
 });
}

/** Historical name retained for callers of the meal reconciler. */
export const alreadyFinalizedMealEntry=alreadyFinalizedVitalEntry;
