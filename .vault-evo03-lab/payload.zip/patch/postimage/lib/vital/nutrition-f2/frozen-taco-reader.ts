/** Read-only candidate release. The workbook and layout must be separately reviewed and pinned. */
import {UNITS,normalized,type Composition,type Nutrient,type Value} from './nutrition';
import type {FrozenCandidate} from './frozen-usda-reader';
const RELEASE='taco-2011-4ed', LICENSE='TACO-2011-attribution';
const URL='https://www.nepa.unicamp.br/arquivo/uploads/taco-4a-edicao/taco-4a-edicao-2/';
const ATTR='NEPA-UNICAMP. Tabela Brasileira de Composição de Alimentos (TACO), 4. ed. rev. e ampl., Campinas, 2011. Reprodução com indicação da fonte.';
const KEYS=['energy_kcal','protein_g','fat_g','carbohydrate_g','fiber_g','calcium_mg','magnesium_mg','phosphorus_mg','iron_mg','sodium_mg','potassium_mg','zinc_mg','vitamin_a_rae_ug','thiamin_mg','riboflavin_mg','vitamin_b6_mg','niacin_mg','vitamin_c_mg'] as const;
const CORE=['energy_kcal','protein_g','fat_g','carbohydrate_g','fiber_g'];
const OFFICIAL_SHA='a66b8ec528daeabc63bc2b015fc9bd8c6d76b941c2fc0ed93a4311d449302d14';
const OFFICIAL_COLS:Record<string,number>=Object.fromEntries(['id','name',...KEYS].map((k,i)=>[k,[1,2,4,6,7,9,10,12,13,16,17,18,19,21,24,25,26,27,28,29][i]]));
const HASH=/^[a-f0-9]{64}$/;
function need(v:unknown,m:string):asserts v{if(!v)throw Error(m);}
function obj(v:unknown):Record<string,unknown>{need(v!==null&&typeof v==='object'&&!Array.isArray(v),'Evidência TACO inválida');return v as Record<string,unknown>;}
function exact(v:Record<string,unknown>,keys:readonly string[]){return Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));}
const stable=(v:unknown):string=>v===null||typeof v!=='object'?JSON.stringify(v):Array.isArray(v)?'['+v.map(stable).join(',')+']':'{'+Object.keys(obj(v)).sort().map(k=>JSON.stringify(k)+':'+stable(obj(v)[k])).join(',')+'}';
async function sha(v:Uint8Array){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new Uint8Array(v))),x=>x.toString(16).padStart(2,'0')).join('');}
const decode=(v:Uint8Array)=>new TextDecoder('utf-8',{fatal:true}).decode(v);
const norm=(v:string)=>v.toLowerCase().replace(/[µμ]/g,'u').normalize('NFKD').replace(/\p{M}/gu,'').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');
const HEADERS:Record<string,string[]>={id:['numero do alimento','numero alimento','n do alimento','n alimento','numero'],name:['descricao dos alimentos','descricao do alimento','descricao'],energy_kcal:['energia'],protein_g:['proteina','proteinas'],fat_g:['lipideos','lipidios'],carbohydrate_g:['carboidrato','carboidratos'],fiber_g:['fibra alimentar','fibras alimentares'],calcium_mg:['calcio'],magnesium_mg:['magnesio'],phosphorus_mg:['fosforo'],iron_mg:['ferro'],sodium_mg:['sodio'],potassium_mg:['potassio'],zinc_mg:['zinco'],vitamin_a_rae_ug:['rae'],thiamin_mg:['tiamina'],riboflavin_mg:['riboflavina'],vitamin_b6_mg:['piridoxina','vitamina b6'],niacin_mg:['niacina'],vitamin_c_mg:['vitamina c']};
function fromRaw(k:Nutrient,v:string):Value{const s=v.trim(),lower=s.toLowerCase();if(lower==='tr')return {state:'trace'};if(lower==='na')return {state:'not_applicable'};if(!s||['-','–','—'].includes(s))return {state:'not_reported'};need(/^\d+(?:[.,]\d+)?$/.test(s),'Notação TACO não revisada');const n=Number(s.replace(',','.'));need(Number.isFinite(n)&&n>=0&&n<=1e6,'Valor TACO inválido');return n===0?{state:'unknown'}:normalized(k,{state:'known',amount:n,unit:UNITS[k]});}
/** Test fixture releases cannot be loaded by the application. No approval or activation is issued here. */
export async function readFrozenTaco(manifestBytes:Uint8Array,foodBytes:Uint8Array,expectedManifestSha256:string):Promise<{manifest:Record<string,unknown>;candidates:FrozenCandidate[];activation:false}>{
 need(HASH.test(expectedManifestSha256)&&manifestBytes.length<=100000&&foodBytes.length<=20_000_000&&await sha(manifestBytes)===expectedManifestSha256,'Manifesto TACO divergente');
 const m=obj(JSON.parse(decode(manifestBytes)));need(exact(m,['provider','release','captured','sourceWorkbookSha256','layoutSha256','sourceUrl','license','attribution','status','activation','rows','fixtureOnly','foodsSha256'])&&m.provider==='taco'&&m.release===RELEASE&&m.license===LICENSE&&m.attribution===ATTR&&m.sourceUrl===URL&&m.status==='CANDIDATES_ONLY'&&m.activation===false&&m.fixtureOnly===false&&m.rows===597&&typeof m.captured==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(m.captured)&&Number.isFinite(Date.parse(m.captured))&&new Date(m.captured).toISOString().slice(0,10)===m.captured&&[m.sourceWorkbookSha256,m.layoutSha256,m.foodsSha256].every(x=>typeof x==='string'&&HASH.test(x))&&await sha(foodBytes)===m.foodsSha256,'Release TACO inválida, incompleta ou sintética');
 const text=decode(foodBytes);need(text.endsWith('\n'),'JSONL TACO incompleto');const lines=text.slice(0,-1).split('\n');need(lines.length===597,'Contagem TACO divergente');
 const candidates:FrozenCandidate[]=[];const seen=new Set<string>();let headerFingerprint:string|null=null;const sourceRows=new Set<string>();const official=m.sourceWorkbookSha256===OFFICIAL_SHA;let prior:{row:string;id:string}|null=null;
 for(const line of lines){need(line.length<=200000,'Linha TACO excede limite');const r=obj(JSON.parse(line)),c=obj(r.composition) as unknown as Composition,e=obj(r.rawEvidence),cells=obj(e.cells),headers=obj(e.headers);
  need(exact(r,['sourceId','version','composition','rawEvidence','sourceRecordSha256','requiresReview'])&&typeof r.sourceId==='string'&&/^[1-9]\d{0,2}$/.test(r.sourceId)&&!seen.has(r.sourceId)&&r.version===RELEASE&&r.requiresReview===true&&typeof r.sourceRecordSha256==='string'&&HASH.test(r.sourceRecordSha256)&&await sha(new TextEncoder().encode(stable(e)))===r.sourceRecordSha256,'Identidade/evidência TACO divergente');
  need(exact(e,official?['sheet','row','cells','headers','headerFragments','identityProof']:['sheet','row','cells','headers'])&&typeof e.sheet==='string'&&!!e.sheet.trim()&&typeof e.row==='string'&&/^\d+$/.test(e.row)&&Number(e.row)>=1&&Number(e.row)<=2000&&!sourceRows.has(e.row)&&typeof cells.id==='string'&&cells.id.trim()===r.sourceId&&typeof cells.name==='string'&&cells.name.trim()===c.name,'Linha original TACO divergente');sourceRows.add(e.row);
  const keyset=Object.keys(cells);need(keyset.includes('id')&&keyset.includes('name')&&CORE.every(k=>keyset.includes(k))&&keyset.every(k=>k==='id'||k==='name'||(KEYS as readonly string[]).includes(k))&&exact(headers,keyset),'Mapa TACO divergente');
  const columns=new Set<string>();for(const k of keyset){const h=obj(headers[k]);need(exact(h,['column','header','unit'])&&typeof h.column==='string'&&/^[1-9]\d{0,2}$/.test(h.column)&&Number(h.column)<=128&&!columns.has(h.column)&&typeof h.header==='string'&&typeof h.unit==='string'&&typeof cells[k]==='string','Cabeçalho TACO inválido');columns.add(h.column);const labels=HEADERS[k];need(labels,'Campo TACO não autorizado');if(k==='id'||k==='name')need(labels.includes(norm(h.header)),'Identificação TACO divergente');else{const unit=UNITS[k as Nutrient];need(labels.includes(norm(h.header))&&norm(h.unit)===unit||h.header===h.unit&&labels.some(x=>norm(h.header as string)===`${x} ${unit}`),'Unidade/cabeçalho TACO divergente');}}
  if(official){
   need(e.sheet==='CMVCol taco3'&&Number(e.row)>=4&&Number(e.row)<=696&&exact(cells,Object.keys(OFFICIAL_COLS)),'Layout oficial TACO divergente');
   const fragments=obj(e.headerFragments),proof=obj(e.identityProof);need(exact(fragments,Object.keys(OFFICIAL_COLS))&&exact(proof,['primary','mirror','previousRow','previousId']),'Prova oficial TACO inválida');
   need(typeof proof.primary==='string'&&typeof proof.mirror==='string'&&proof.previousRow===(prior?.row??null)&&proof.previousId===(prior?.id??null)&&Number(r.sourceId)===(prior?Number(prior.id)+1:1)&&(!prior||Number(e.row)>Number(prior.row)),'Cadeia de identidade TACO inválida');
   need(proof.primary===r.sourceId||(prior!==null&&proof.primary===`=A${prior.row}+1`),'Fórmula de identificação TACO divergente');
   need(proof.mirror===r.sourceId||proof.mirror===`=A${e.row}`,'Espelho de identificação TACO divergente');
   for(const k of Object.keys(OFFICIAL_COLS)){
    const h=obj(headers[k]),f=fragments[k];need(Array.isArray(f)&&f.length===3&&f.every(v=>typeof v==='string'),'Fragmentos TACO inválidos');
    const a=f as string[];let label=a.slice(0,2).map(x=>x.trim()).filter(Boolean).join(' '),unit=a[2];
    if(k==='id'||k==='name'){label=a.map(x=>x.trim()).filter(Boolean).join(' ');unit='';}
    if(k==='carbohydrate_g')label=a.slice(0,2).map(x=>x.trim().replace(/-$/,'')).join('');
    if(k==='vitamin_a_rae_ug'){need(norm(unit)==='mcg','Unidade RAE oficial divergente');unit='ug';}
    need(h.column===String(OFFICIAL_COLS[k])&&h.header===label&&h.unit===unit,'Proveniência de cabeçalho TACO divergente');
   }
   need(await sha(new TextEncoder().encode(stable({sheet:e.sheet,headers,headerFragments:fragments,identityColumns:[1,14]})))===m.layoutSha256,'Layout oficial TACO não corresponde ao manifesto');
   prior={row:e.row as string,id:r.sourceId};
  }
  const fp=stable([e.sheet,headers]);need(headerFingerprint===null||fp===headerFingerprint,'Layout TACO mudou entre linhas');headerFingerprint=fp;
  need(exact(obj(c),['name','source','base','values','preparation','edibleBasis'])&&typeof c.name==='string'&&c.name.trim()===c.name&&c.name.length>0&&c.name.length<=120&&stable(c.source)===stable({provider:'taco',recordId:r.sourceId,version:RELEASE,license:LICENSE,retrievedAt:m.captured+'T00:00:00Z',attribution:ATTR})&&stable(c.base)===stable({value:100,unit:'g'})&&c.edibleBasis==='edible'&&c.preparation==='unknown','Composição TACO divergente');
  const keys=keyset.filter(k=>k!=='id'&&k!=='name');need(exact(obj(c.values),keys),'Nutrientes TACO divergentes');for(const k of keys)need(stable(c.values[k as Nutrient])===stable(fromRaw(k as Nutrient,cells[k] as string)),'Valor TACO divergente da evidência');
  seen.add(r.sourceId);candidates.push({sourceId:r.sourceId,version:RELEASE,composition:structuredClone(c),sourceRecordSha256:r.sourceRecordSha256,requiresReview:true});
 }
 need(Array.from({length:597},(_,i)=>String(i+1)).every(k=>seen.has(k)),'Identidades TACO incompletas');return {manifest:structuredClone(m),candidates,activation:false};
}
