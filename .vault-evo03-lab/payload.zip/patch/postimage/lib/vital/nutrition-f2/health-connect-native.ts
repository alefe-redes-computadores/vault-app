import {readNutritionCandidates,type Connection,type NutritionRecord} from './health-connect-nutrition';
import type {Imported} from './nutrition';
export type NativeNutritionPage={records:readonly Omit<NutritionRecord,'scope'>[];next:string|null;permission:boolean};
export type NativeNutritionReader={readNutritionPage(options:{start:string;end:string;cursor:string|null}):Promise<NativeNutritionPage>};
/** Bind a fixed time range and scope. The bridge never receives account/person identifiers.
 * Read-only staging, not a canonical import or deletion authority. */
export async function stageNativeNutrition(connection:Connection,current:()=>Promise<Connection>,bridge:NativeNutritionReader,range:{start:string;end:string},previous:readonly Imported[],manual:Parameters<typeof readNutritionCandidates>[4],now=Date.now()){
 const start=Date.parse(range.start),end=Date.parse(range.end);
 if(!Number.isFinite(start)||!Number.isFinite(end)||!Number.isFinite(now)||new Date(start).toISOString()!==range.start||new Date(end).toISOString()!==range.end||start>=end||end-start>28*86400000||end>now)throw Error('Período nutricional inválido');
 const fixed={start:range.start,end:range.end};
 return readNutritionCandidates(connection,current,async cursor=>{
  const p=await bridge.readNutritionPage({...fixed,cursor});
  if(!Array.isArray(p.records)||p.records.length>500)throw Error('Página nutricional inválida');
  return {...p,records:p.records.map(r=>{if(Object.hasOwn(r,'scope')||Object.hasOwn(r,'user_id')||Object.hasOwn(r,'person_id')||Date.parse(r.start)<start||Date.parse(r.end)>end)throw Error('Registro externo fora da consulta');return {...r,scope:structuredClone(connection.scope)};})};
 },previous,manual);
}
