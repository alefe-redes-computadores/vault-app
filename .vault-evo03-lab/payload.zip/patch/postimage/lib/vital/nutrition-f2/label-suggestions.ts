/** Conservative straight-table OCR suggestions. Never treats a guess as a reviewed field.
 * Unknown/rotated/multi-table headers use the manual review path. */
import { LABEL_ALIASES, geometryLabel, type OCRToken, type Rect, type Column, type LabelBand } from './ocr-geometry';
import { UNITS, decimalBR, type Nutrient, type Unit } from './nutrition';
import type { CaptureReview } from './native-capture-contract';
export type OcrReview=Extract<CaptureReview,{status:'ocr_review'}>;
export type LabelSuggestion={nutrient:Nutrient;unit:Unit;raw:string;column:'per100'|'portion';printedBase:number|null;box:Rect;confidence:number|null;requiresReview:true};
const norm=(s:string)=>s.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().trim();
const units:Record<string,Unit>={g:'g',mg:'mg',ug:'ug','µg':'ug','μg':'ug',mcg:'ug',kcal:'kcal',kj:'kJ'};
const bounds=(xs:readonly OCRToken[]):Rect=>[Math.min(...xs.map(x=>x.box[0])),Math.min(...xs.map(x=>x.box[1])),Math.max(...xs.map(x=>x.box[2])),Math.max(...xs.map(x=>x.box[3]))];
const center=(b:Rect)=>(b[0]+b[2])/2;
const vcenter=(b:Rect)=>(b[1]+b[3])/2;
const yOverlap=(a:Rect,b:Rect)=>Math.min(a[3],b[3])-Math.max(a[1],b[1]);
function rows(tokens:readonly OCRToken[]){const groups:OCRToken[][]=[];for(const t of [...tokens].sort((a,b)=>vcenter(a.box)-vcenter(b.box)||a.box[0]-b.box[0])){const matches=groups.filter(g=>{const b=bounds(g);return yOverlap(b,t.box)>=Math.min(b[3]-b[1],t.box[3]-t.box[1])*.65;});if(matches.length>1)return null;if(matches.length===1)matches[0].push(t);else groups.push([t]);}return groups.map(g=>g.sort((a,b)=>a.box[0]-b.box[0]));}
function candidateHeader(row:OCRToken[],base:'g'|'mL'){
 const hs:{kind:Column['kind'];header:string;box:Rect}[]=[];
 for(let i=0;i<row.length;i++){
  const t=row[i],s=norm(t.text).replace(/\s+/g,'');const pair=row[i+1]&&s+norm(row[i+1].text).replace(/\s+/g,'');
  if(s==='porcao'||s==='%vd'){hs.push({kind:s==='porcao'?'portion':'dailyValue',header:t.text,box:t.box});continue;}
  if(s==='%'&&pair==='%vd'){hs.push({kind:'dailyValue',header:'%VD',box:bounds(row.slice(i,i+2))});i++;continue;}
  const match=(s.match(/^(\d+(?:[.,]\d+)?)(g|ml)$/)||pair?.match(/^(\d+(?:[.,]\d+)?)(g|ml)$/));
  if(match){const joined=!s.match(/^(\d+(?:[.,]\d+)?)(g|ml)$/);if(match[2]!==base.toLowerCase())return null;const n=decimalBR(match[1]);if(n===null||n<=0)return null;hs.push({kind:n===100?'per100':'portion',header:match[1]+(base==='g'?' g':' mL'),box:joined?bounds(row.slice(i,i+2)):t.box});if(joined)i++;}
 }
 if(hs.length<2||hs.length>3||new Set(hs.map(h=>h.kind)).size!==hs.length||!hs.some(h=>h.kind==='per100')||!hs.some(h=>h.kind==='portion'))return null;
 if(row.some(t=>!hs.some(h=>t.box[0]>=h.box[0]&&t.box[2]<=h.box[2])))return null;
 return hs;
}
export function suggestLabelFields(c:OcrReview,base:'g'|'mL'):{suggestions:LabelSuggestion[];issue:string|null}{
 const none=(issue:string)=>({suggestions:[],issue});
 if(c.status!=='ocr_review'||!['g','mL'].includes(base)||c.tokens.length>4000||c.imageWidth<1||c.imageHeight<1)return none('Captura inválida.');
 const grouped=rows(c.tokens);if(!grouped)return none('Linhas sobrepostas. Confira manualmente.');
 const headers=grouped.map(g=>({g,headers:candidateHeader(g,base)})).filter(x=>x.headers!==null);
 if(headers.length!==1)return none('Não foi possível identificar uma única tabela com cabeçalhos de 100 e porção.');
 const h=headers[0],hs=h.headers!,headerBottom=bounds(h.g)[3];const centers=hs.map(x=>center(x.box));const left=Math.max(0,hs[0].box[0]-(centers[1]-centers[0])/2);const columns:Column[]=hs.map((x,i)=>({kind:x.kind,header:x.header,box:[i===0?left:(centers[i-1]+centers[i])/2,headerBottom,i===hs.length-1?c.imageWidth:(centers[i]+centers[i+1])/2,c.imageHeight]}));
 const bands:LabelBand[]=[];
 for(const g of grouped){const b=bounds(g);if(b[1]<headerBottom)continue;const labels=g.filter(t=>t.box[2]<=left);if(!labels.length)continue;const label=labels.map(t=>t.text).join(' ');const m=label.match(/\(([^()]+)\)\s*$/);if(!m)continue;const unit=units[norm(m[1])];if(!unit)continue;const name=norm(label.slice(0,m.index));const nutrient=(Object.keys(LABEL_ALIASES) as Nutrient[]).find(k=>LABEL_ALIASES[k]?.includes(name));if(!nutrient)continue;bands.push({nutrient,unit,box:[0,b[1],c.imageWidth,b[3]],label});}
 if(!bands.length||new Set(bands.map(x=>x.nutrient)).size!==bands.length)return none('Linhas nutricionais não reconhecidas com segurança.');
 try{const r=geometryLabel({evidence:{text:c.text,recognizer:c.recognizer,recognizerVersion:c.version,geometry:'uncertain',imageRetention:'discard'},imageWidth:c.imageWidth,imageHeight:c.imageHeight,tokens:c.tokens,columns,bands,base,portion:null});const suggestions:LabelSuggestion[]=[];for(const x of r.candidates)for(const cell of x.rawCells){if(cell.column==='dailyValue'||!cell.box||decimalBR(cell.raw)===null)continue;const check=UNITS[x.nutrient];if(!check)continue;suggestions.push({nutrient:x.nutrient,unit:cell.unit,raw:cell.raw,column:cell.column,printedBase:cell.column==='per100'?100:decimalBR(hs.find(h=>h.kind==='portion')!.header.replace(/\s*(g|mL)$/i,'')),box:cell.box,confidence:cell.confidence,requiresReview:true});}return {suggestions,issue:r.issues.length?r.issues.join(' '):null};}catch{return none('Geometria incerta. Confira o texto e preencha manualmente.');}
}
