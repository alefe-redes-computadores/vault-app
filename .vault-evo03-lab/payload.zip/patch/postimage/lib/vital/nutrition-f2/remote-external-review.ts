/** F2 server-review input only. This is not a second importer, writer, or network transport. */
import type {MealRow,Scope} from '../model';
import {vitalWireRow,VitalSyncConflict} from '../cloud-transport';
import {requireScope} from '../validation';
import {externalCanonicalId} from './external-import-review';
import {externalEvidenceOf,externalIdentity} from './external-meal';
const check=(ok:unknown,msg:string):void=>{if(!ok)throw new VitalSyncConflict(msg);};
const stable=(x:unknown)=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
function fact(r:MealRow){const {id,user_id,person_id,created_at,updated_at,deleted_at,revision,synced,...data}=r;return data;}
/** Unlike a legacy local fixture, the remote protocol must prove the device-independent ID.
 * A noncanonical historic import must be reconciled explicitly, never silently rekeyed. */
export async function verifyRemoteExternalRow(scope:Scope,raw:unknown){
 const s=requireScope(scope),r=vitalWireRow('vital_meals',raw,s),e=externalEvidenceOf(r);
 if(!e)throw new VitalSyncConflict('Total externo obrigatório.');
 const mealId=await externalCanonicalId(s,e.record,'meal'),itemId=await externalCanonicalId(s,e.record,'item');
 check(r.id===mealId&&r.items[0]?.id===itemId,'Identidade externa não canônica; reconciliação necessária.');
 check(r.nutrition_f2?.operation_id!==mealId&&r.nutrition_f2?.operation_id!==itemId&&e.reviewedAt<=r.updated_at,'Operação ou revisão externa inválida.');
 return {row:r,evidence:e};
}
export async function verifyRemoteExternalTransition(scope:Scope,oldRaw:unknown|null,newRaw:unknown){
 const s=requireScope(scope),next=await verifyRemoteExternalRow(s,newRaw),r=next.row;
 if(oldRaw===null){check(r.revision===1&&!r.deleted_at&&r.created_at===r.updated_at,'Inserção externa inválida.');return next;}
 const old=await verifyRemoteExternalRow(s,oldRaw);check(old.row.id===r.id&&old.row.created_at===r.created_at&&old.row.deleted_at===null&&r.revision===old.row.revision+1&&r.updated_at>old.row.updated_at&&externalIdentity(old.evidence)===externalIdentity(next.evidence),'Revisão ou identidade externa divergente.');
 if(r.deleted_at)check(r.deleted_at===r.updated_at&&stable(fact(r))===stable(fact(old.row)),'Arquivamento deve preservar total externo.');
 else check(next.evidence.record.lastModified>old.evidence.record.lastModified&&r.nutrition_f2!.operation_id!==old.row.nutrition_f2!.operation_id,'Versão externa não avançou.');
 return next;
}
