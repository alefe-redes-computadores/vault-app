'use client';
import { Capacitor, registerPlugin } from '@capacitor/core';
import type { CaptureTicket } from './capture-session';
import { NutritionCaptureController, type NativeCaptureApi } from './native-capture-contract';
const native=registerPlugin<NativeCaptureApi>('VaultNutritionCapture');
export function createNutritionCapture(active:()=>CaptureTicket|null){
 return new NutritionCaptureController(Capacitor.getPlatform()==='android'&&Capacitor.isPluginAvailable('VaultNutritionCapture')?native:null,active);
}
