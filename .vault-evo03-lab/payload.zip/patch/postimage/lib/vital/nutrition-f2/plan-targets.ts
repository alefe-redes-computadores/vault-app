import {UNITS,convert,type Nutrient,type Unit,type Quantity,type coverageDetailed} from './nutrition';
export const LEGACY_TARGET_KEYS=['energy_kcal','carbohydrate_g','protein_g','fat_g','fiber_g'] as const;
export type ExtraTargetKey=Exclude<Nutrient,typeof LEGACY_TARGET_KEYS[number]>;
export const EXTRA_TARGET_KEYS=Object.keys(UNITS).filter(k=>!(LEGACY_TARGET_KEYS as readonly string[]).includes(k)) as ExtraTargetKey[];
export type TargetKind='at_least'|'at_most'|'exact';
export type ExtraTarget={kind:TargetKind;amount:number;unit:Unit};
export type ExtraTargets=Partial<Record<ExtraTargetKey,ExtraTarget>>;
const assert=(ok:unknown,msg:string)=>{if(!ok)throw Error(msg);};
const obj=(v:unknown):Record<string,unknown>=>{assert(v!==null&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v)),'Metas nutricionais inválidas.');return v as Record<string,unknown>;};
/** No clinical defaults or inferred limits. Canonical stored units are explicit; F1 macros have a single authority. */
export function extraTarget(k:ExtraTargetKey,kind:TargetKind,q:Quantity):ExtraTarget{
 assert(EXTRA_TARGET_KEYS.includes(k),'Meta adicional inválida.');assert(['at_least','at_most','exact'].includes(kind),'Tipo de meta inválido.');
 assert(typeof q.value==='number'&&Number.isFinite(q.value)&&q.value>=0,'Quantidade de meta inválida.');
 const amount=convert(q,UNITS[k]);assert(amount!==null&&amount<=1000000&&(amount===0||amount>=0.000000000001)&&(amount>0||kind==='at_most'),'Quantidade ou unidade de meta inválida.');
 return {kind,amount:amount!,unit:UNITS[k]};
}
export function validateExtraTargets(raw:unknown):ExtraTargets{
 const r=obj(raw),out:ExtraTargets={};for(const [key,v] of Object.entries(r)){const k=key as ExtraTargetKey;assert(EXTRA_TARGET_KEYS.includes(k),'Meta adicional inválida.');const t=obj(v);assert(Object.keys(t).length===3&&['kind','amount','unit'].every(f=>Object.hasOwn(t,f)),'Campos de meta inválidos.');assert(t.unit===UNITS[k],'Unidade de meta não canônica.');out[k]=extraTarget(k,t.kind as TargetKind,{value:t.amount as number,unit:t.unit as Unit});}return out;
}
/** Comparison is a statement about recorded items, not adequacy, compliance or total intake. */
export function extraTargetComparison(target:ExtraTarget,coverage:ReturnType<typeof coverageDetailed>){
 const known=coverage.amount,estimated=coverage.estimatedSubtotal;
 const complete=coverage.complete&&known!==null&&estimated===null;
 const relation=complete?(known===target.amount?'equal':known!<target.amount?'below':'above'):null;
 return {known,estimated,relation,coverage:complete?'recorded_complete' as const:'incomplete' as const};
}
export type ExtraTargetDraft=Partial<Record<ExtraTargetKey,{kind:TargetKind;raw:string}>>;
export function validateTargetDraft(raw:unknown):ExtraTargetDraft{
 const r=obj(raw),out:ExtraTargetDraft={};for(const [key,v] of Object.entries(r)){const k=key as ExtraTargetKey,t=obj(v);assert(EXTRA_TARGET_KEYS.includes(k)&&Object.keys(t).length===2&&['at_least','at_most','exact'].includes(String(t.kind))&&typeof t.raw==='string'&&t.raw.length<=40,'Rascunho de meta inválido.');out[k]={kind:t.kind as TargetKind,raw:t.raw as string};}return out;
}
function plainDecimal(n:number){const s=String(n);if(!s.includes('e'))return s;const [m,exp]=s.split('e'),[a,b='']=m.split('.'),digits=a+b,at=a.length+Number(exp);return at<=0?'0.'+'0'.repeat(-at)+digits:at>=digits.length?digits+'0'.repeat(at-digits.length):digits.slice(0,at)+'.'+digits.slice(at);}
export function targetsToDraft(raw:unknown):ExtraTargetDraft{return Object.fromEntries(Object.entries(validateExtraTargets(raw)).map(([k,t])=>[k,{kind:t.kind,raw:plainDecimal(t.amount).replace('.',',')}])) as ExtraTargetDraft;}
export function confirmTargetDraft(raw:unknown):ExtraTargets{
 const draft=validateTargetDraft(raw),out:ExtraTargets={};for(const [key,d] of Object.entries(draft)){const k=key as ExtraTargetKey;assert(/^\d+(?:[.,]\d+)?$/.test(d.raw.trim()),'Revise a quantidade da meta.');out[k]=extraTarget(k,d.kind,{value:Number(d.raw.trim().replace(',','.')),unit:UNITS[k]});}return out;
}
