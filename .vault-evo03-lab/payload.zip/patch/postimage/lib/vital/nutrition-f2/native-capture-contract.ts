import { gtin } from './nutrition';
import type { CaptureTicket } from './capture-session';
import type { OCRToken, Rect } from './ocr-geometry';
export type NativeCaptureSource = 'camera'|'image';
export interface NativeCaptureApi {
 status():Promise<unknown>;
 capture(input:{mode:'barcode'|'ocr';source:NativeCaptureSource;requestId:string}):Promise<unknown>;
}
export type CaptureReview = {status:'stale'|'busy'|'invalid'|'unavailable'|'cancelled'|'permission_denied'|'error'|'no_match'|'review_limit'} | {status:'barcode_review';codes:readonly string[]} | {status:'ocr_review';text:string;recognizer:string;version:string;imageWidth:number;imageHeight:number;tokens:readonly OCRToken[];geometry:'uncertain';imageRetention:'discard'};
const obj=(x:unknown):x is Record<string,unknown>=>!!x&&typeof x==='object'&&!Array.isArray(x);
const positiveInt=(x:unknown):x is number=>typeof x==='number'&&Number.isInteger(x)&&x>0;
const current=(a:CaptureTicket|null,b:CaptureTicket)=>!!a&&a.scope.user_id===b.scope.user_id&&a.scope.person_id===b.scope.person_id&&a.editorId===b.editorId&&a.requestId===b.requestId&&a.mode===b.mode;
const terminal=['busy','invalid','unavailable','cancelled','permission_denied','error','no_match','review_limit'] as const;
export function parseNativeCapture(active:CaptureTicket|null,started:CaptureTicket,response:unknown):CaptureReview {
 if(!current(active,started))return {status:'stale'};
 if(!obj(response)||response.requestId!==started.requestId||typeof response.status!=='string')return {status:'invalid'};
 if((terminal as readonly string[]).includes(response.status))return {status:response.status as typeof terminal[number]};
 if(response.status==='barcode_candidates'&&started.mode==='barcode'){
  if(!Array.isArray(response.codes)||response.codes.length>64||!response.codes.every(x=>typeof x==='string'))return {status:'invalid'};
  const codes=[...new Set(response.codes.map(x=>gtin(x)).filter((x):x is string=>x!==null))];
  return codes.length?{status:'barcode_review',codes}:{status:'no_match'};
 }
 if(response.status==='ocr'&&started.mode==='ocr'){
  const {text,recognizer,version,imageWidth:w,imageHeight:h,tokens}=response;
  if(typeof text!=='string'||!text.trim()||text.length>20000||recognizer!=='mlkit-latin-bundled'||version!=='16.0.1'||!positiveInt(w)||!positiveInt(h)||w>2560||h>2560||!Array.isArray(tokens)||tokens.length>4000)return {status:'invalid'};
  const verified:OCRToken[]=[];
  for(const t of tokens){
   if(!obj(t)||typeof t.text!=='string'||!t.text.trim()||t.text.length>250||!Array.isArray(t.box)||t.box.length!==4||!t.box.every(v=>typeof v==='number'&&Number.isInteger(v))||t.confidence!==null&&(typeof t.confidence!=='number'||!Number.isFinite(t.confidence)||t.confidence<0||t.confidence>1))return {status:'invalid'};
   const [l,top,r,b]=t.box;if(l<0||top<0||r>w||b>h||r<=l||b<=top)return {status:'invalid'};
   verified.push({text:t.text,box:[l,top,r,b] as Rect,confidence:t.confidence as number|null});
  }
  return {status:'ocr_review',text,recognizer,version,imageWidth:w,imageHeight:h,tokens:verified,geometry:'uncertain',imageRetention:'discard'};
 }
 return {status:'invalid'};
}
/** Serializes native launches; rechecks editor and person before and after awaits. No persistence or account data leaves the bridge. */
export class NutritionCaptureController {
 private flight=false;
 constructor(private readonly api:NativeCaptureApi|null,private readonly active:()=>CaptureTicket|null){}
 async capture(ticket:CaptureTicket,source:NativeCaptureSource):Promise<CaptureReview>{
  const started=structuredClone(ticket);
  if(!current(this.active(),started))return {status:'stale'};
  if(!this.api)return {status:'unavailable'};
  if(started.mode==='photo'||!['camera','image'].includes(source)||!(/^[A-Za-z0-9_-]{8,100}$/.test(started.requestId)))return {status:'invalid'};
  if(this.flight)return {status:'busy'};
  this.flight=true;
  try{
   const s=await this.api.status();
   if(!current(this.active(),started))return {status:'stale'};
   if(!obj(s)||s.available!==true||s.protocol!==1||s.stillImage!==true||s.barcodeModel!=='17.3.0'||s.ocrModel!=='16.0.1')return {status:'unavailable'};
   const response=await this.api.capture({mode:started.mode,source,requestId:started.requestId});
   return parseNativeCapture(this.active(),started,response);
  }catch{return {status:current(this.active(),started)?'error':'stale'};}
  finally{this.flight=false;}
 }
}
