import type {MealRow,Scope} from '../model';
import type {VitalRepository} from '../repository';
import {own,requireId,requireScope} from '../validation';
import {externalEvidenceOf,externalIdentity,makeExternalMealEvidence} from './external-meal';
import {stageNativeNutrition,type NativeNutritionReader} from './health-connect-native';
import type {Connection,NutritionRecord} from './health-connect-nutrition';

const check=(ok:unknown,msg:string):void=>{if(!ok)throw Error(msg);};
const same=(a:Connection,b:Connection)=>own(a.scope,b.scope)&&a.origin===b.origin&&a.revision===b.revision&&a.nutritionReadGranted===true&&b.nutritionReadGranted===true;
const iso=(v:string)=>new Date(v).toISOString();
const key=(r:NutritionRecord)=>JSON.stringify([r.origin,r.recordId]);
const recordMatch=(r:NutritionRecord,old:NutritionRecord)=>JSON.stringify({...r,start:iso(r.start),end:iso(r.end),lastModified:iso(r.lastModified)},(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v)===JSON.stringify(old,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
/** Same device-independent identity for a provider record, scoped by account/person. */
export async function externalCanonicalId(scope:Scope,record:NutritionRecord,part:'meal'|'item'){
 const s=requireScope(scope);check(own(record.scope,s),'Identidade externa fora da pessoa.');
 const bytes=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(['vault-vital-nutrition-v1',s.user_id,s.person_id,record.origin,record.recordId,part]))));
 bytes[6]=(bytes[6]&15)|128;bytes[8]=(bytes[8]&63)|128;const h=Array.from(bytes.slice(0,16),x=>x.toString(16).padStart(2,'0')).join('');return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
}
export type NutritionReviewCard={record:NutritionRecord;state:'new'|'update'|'duplicate'|'archived'|'conflict';existingId:string|null;existingRevision:number|null;needsOverlapConfirmation:boolean};
/** Foreground only, scoped to one connection generation. No independent store, auto-import, cursor or network. */
export function createExternalImportReview(deps:{scope:Scope;repo:Pick<VitalRepository,'nutritionImportHistory'|'importNutritionMeal'>;current:()=>Promise<Connection>;bridge:NativeNutritionReader;newId:()=>string;now:()=>Date;offsetAt:(start:string)=>number}){
 const s=requireScope(deps.scope);let generation=0,busy=false;let batch:{connection:Connection;cards:NutritionReviewCard[]}|null=null;
 const assertConnection=async(c:Connection)=>check(own(c.scope,s)&&same(c,await deps.current()),'Vínculo/permissão mudou. Refaça a leitura.');
 function card(r:NutritionRecord,rows:MealRow[]):NutritionReviewCard {
  const matches=rows.filter(x=>own(x,s)&&externalEvidenceOf(x)&&externalIdentity(externalEvidenceOf(x)!)===key(r));
  check(matches.length<=1,'Identidade externa duplicada.');const old=matches[0],e=old?externalEvidenceOf(old)!:null;
  const state=old?.deleted_at?'archived':!e?'new':iso(r.lastModified)<e.record.lastModified?'conflict':iso(r.lastModified)===e.record.lastModified?(recordMatch(r,e.record)?'duplicate':'conflict'):'update';
  const reviewed=makeExternalMealEvidence(r,'review-preview',deps.now().toISOString(),deps.offsetAt(r.start),false);
  const kind=r.mealType==='unknown'?'custom':r.mealType;
  const overlap=rows.some(x=>{if(!own(x,s)||x.deleted_at||x.id===old?.id)return false;const v=externalEvidenceOf(x);return v?Date.parse(v.record.start)<Date.parse(r.end)&&Date.parse(v.record.end)>Date.parse(r.start):x.day===reviewed.civilDay&&(x.kind===kind||x.time===null||x.kind==='custom'||kind==='custom');});
  return {record:structuredClone(r),state,existingId:old?.id??null,existingRevision:old?.revision??null,needsOverlapConfirmation:overlap};
 }
 return {
  cancel(){generation++;batch=null;},
  async read(range:{start:string;end:string}){check(!busy,'Aguarde a operação atual.');busy=true;const token=++generation;batch=null;try{const connection=await deps.current();await assertConnection(connection);const rows=await deps.repo.nutritionImportHistory(s);const prior=rows.flatMap(x=>{const e=externalEvidenceOf(x);return e?[e.record]:[];});const staged=await stageNativeNutrition(connection,deps.current,deps.bridge,range,prior,[],deps.now().getTime());await assertConnection(connection);check(token===generation,'Leitura cancelada.');const cards=staged.candidates.map(x=>card(x.record,rows));batch={connection:structuredClone(connection),cards};return structuredClone(cards);}finally{busy=false;}},
  async confirm(recordId:string,review:{offsetMinutes:number;overlapConfirmed:boolean;confirmed:true}){
   check(!busy&&batch,'Faça uma leitura antes de confirmar.');busy=true;const token=generation;const selected=batch!;try{
    const original=selected.cards.find(x=>x.record.recordId===recordId);if(!original||review.confirmed!==true)throw Error('Revisão obrigatória.');check(original.state==='new'||original.state==='update','Registro não elegível.');
    await assertConnection(selected.connection);const rows=await deps.repo.nutritionImportHistory(s);const current=card(original.record,rows);
    check(current.state===original.state&&current.existingId===original.existingId&&current.existingRevision===original.existingRevision,'Histórico mudou. Refaça a leitura.');
    check(review.offsetMinutes===deps.offsetAt(original.record.start),'Fuso de revisão mudou. Refaça a leitura.');check(!current.needsOverlapConfirmation||review.overlapConfirmed===true,'Confirme que as refeições são distintas.');
    const old=rows.find(x=>x.id===current.existingId);const req={id:old?.id??await externalCanonicalId(s,original.record,'meal'),itemId:old?.items[0].id??await externalCanonicalId(s,original.record,'item'),operationId:requireId(deps.newId()),expected_revision:old?.revision??null,evidence:makeExternalMealEvidence(original.record,selected.connection.revision,deps.now().toISOString(),review.offsetMinutes,review.overlapConfirmed),reason:old?'Versão externa revisada pelo usuário':undefined};
    check(new Set([req.id,req.itemId,req.operationId]).size===3,'Identidades duplicadas.');await assertConnection(selected.connection);check(token===generation,'Revisão cancelada.');const result=await deps.repo.importNutritionMeal(s,req);if(token===generation)batch=null;return {row:result,status:'saved_locally' as const};
   }finally{busy=false;}
  }
 };
}
