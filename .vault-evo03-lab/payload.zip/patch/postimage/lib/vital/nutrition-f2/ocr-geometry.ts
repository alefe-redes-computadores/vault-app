/** Macro03 N02: engine-neutral geometry adapter for existing label-review. No save or camera side effects. */
import {UNITS, type Nutrient, type Unit, type Quantity} from './nutrition';
import {reviewLabel, type Cell, type Evidence, type Row} from './label-review';
export type Rect=readonly [number,number,number,number];
export type OCRToken={text:string;box:Rect;confidence:number|null};
export type Column={kind:Cell['column'];box:Rect;header:string};
export type LabelBand={nutrient:Nutrient;unit:Unit;box:Rect;label:string;unitReviewed?:boolean};
export type GeometryInput={evidence:Evidence;imageWidth:number;imageHeight:number;tokens:readonly OCRToken[];columns:readonly Column[];bands:readonly LabelBand[];base:'g'|'mL';portion:Quantity|null};
const overlaps=(a:Rect,b:Rect)=>Math.max(a[0],b[0])<Math.min(a[2],b[2])&&Math.max(a[1],b[1])<Math.min(a[3],b[3]);
const contains=(a:Rect,b:Rect)=>a[0]<=b[0]&&a[1]<=b[1]&&a[2]>=b[2]&&a[3]>=b[3];
const tokenUnit=(s:string):Unit|null=>({g:'g',mg:'mg','µg':'ug','μg':'ug',ug:'ug',mcg:'ug',kcal:'kcal',kj:'kJ',ml:'mL'} as Record<string,Unit>)[s.toLowerCase()]??null;
const norm=(s:string)=>s.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().trim();
export const LABEL_ALIASES:Partial<Record<Nutrient,readonly string[]>>={energy_kcal:['valor energetico'],carbohydrate_g:['carboidratos'],protein_g:['proteinas'],fat_g:['gorduras totais'],fiber_g:['fibras alimentares','fibra alimentar'],sugar_g:['acucares totais'],added_sugar_g:['acucares adicionados'],saturated_fat_g:['gorduras saturadas'],trans_fat_g:['gorduras trans'],sodium_mg:['sodio'],calcium_mg:['calcio'],iron_mg:['ferro'],potassium_mg:['potassio'],magnesium_mg:['magnesio'],vitamin_c_mg:['vitamina c'],vitamin_b12_ug:['vitamina b12'],vitamin_d_ug:['vitamina d'],vitamin_k_ug:['vitamina k'],folate_ug:['folato'],selenium_ug:['selenio'],zinc_mg:['zinco'],phosphorus_mg:['fosforo'],vitamin_a_rae_ug:['vitamina a (rae)'],vitamin_e_mg:['vitamina e'],vitamin_b6_mg:['vitamina b6'],thiamin_mg:['tiamina'],riboflavin_mg:['riboflavina'],niacin_mg:['niacina']};
function bounds(xs:readonly OCRToken[]):Rect{return [Math.min(...xs.map(t=>t.box[0])),Math.min(...xs.map(t=>t.box[1])),Math.max(...xs.map(t=>t.box[2])),Math.max(...xs.map(t=>t.box[3]))];}
function checkBox(b:Rect,w:number,h:number){if(b.length!==4||!b.every(Number.isFinite)||b[0]<0||b[1]<0||b[2]>w||b[3]>h||b[2]<=b[0]||b[3]<=b[1])throw Error('Geometria inválida');}
function headerOk(c:Column,base:'g'|'mL'){const s=norm(c.header);if(c.kind==='per100')return s.replace(/\s+/g,'')===`100${base.toLowerCase()}`;if(c.kind==='dailyValue')return /^%\s*vd$/.test(s);return /^porcao(?:\s.*)?$/.test(s)||/^\d+(?:[,.]\d+)?\s*(g|ml)$/.test(s)&&s.replace(/\s+/g,'')!==`100${base.toLowerCase()}`;}
/** Bands and column headers are candidate geometry from a recognizer or user correction. Never infer a column from position alone. */
export function geometryLabel(input:GeometryInput){
 const {imageWidth:w,imageHeight:h,tokens,columns,bands}=input;
 if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w*h>40_000_000||tokens.length>4000||columns.length>3||bands.length>100)throw Error('Limite de imagem ou OCR');
 const issues:string[]=[]; const uncertain=new Set<Nutrient>();
 for(const t of tokens){checkBox(t.box,w,h);if(!t.text.trim()||t.text.length>250||t.confidence!==null&&(!Number.isFinite(t.confidence)||t.confidence<0||t.confidence>1))throw Error('Token OCR inválido');}
 for(const c of columns)checkBox(c.box,w,h);for(const b of bands)checkBox(b.box,w,h);
 const invalidGeometry=columns.length===0||new Set(columns.map(c=>c.kind)).size!==columns.length||columns.some(c=>!headerOk(c,input.base))||columns.some((a,i)=>columns.slice(i+1).some(b=>overlaps(a.box,b.box)))||bands.some((a,i)=>bands.slice(i+1).some(b=>overlaps(a.box,b.box)))||new Set(bands.map(b=>b.nutrient)).size!==bands.length;
 if(invalidGeometry)issues.push('Cabeçalhos ou linhas ambíguos: reposicione as colunas.');
 const rows:Row[]=[];
 for(const b of bands){
  const suffix=b.label.match(/\(([^()]+)\)\s*$/);const labelUnit=suffix?tokenUnit(suffix[1].trim()):null;
  const semanticLabel=norm(labelUnit?b.label.slice(0,suffix!.index):b.label);
  if(!Object.hasOwn(UNITS,b.nutrient)||!LABEL_ALIASES[b.nutrient]?.includes(semanticLabel)){issues.push(`Rótulo de nutriente não confirmado: ${b.label}`);continue;}
  const unitUncertain=labelUnit!==null?labelUnit!==b.unit:b.unitReviewed!==true;
  if(unitUncertain){uncertain.add(b.nutrient);issues.push(`${b.label}: unidade sem confirmação ou divergente.`);}
  const cells:Cell[]=[];
  for(const c of columns){
   const xs=tokens.filter(t=>overlaps(t.box,b.box)&&overlaps(t.box,c.box));if(!xs.length)continue;
   const sorted=[...xs].sort((a,z)=>a.box[0]-z.box[0]);const text=sorted.map(t=>t.text).join(' ').trim();const confidence=sorted.some(t=>t.confidence===null)?null:Math.min(...sorted.map(t=>t.confidence!));
   const crosses=xs.some(t=>!contains(b.box,t.box)||!contains(c.box,t.box));
   // One numeric value, optionally followed by unit. Never concatenate separate digits or remove punctuation.
   const m=text.match(/^(\d+(?:[,.]\d+)?)\s*([a-zA-Zµμ]+)?$/u);const explicit=m?.[2]?tokenUnit(m[2]):null;
   let raw=m?.[1]??text;
   if(c.kind==='dailyValue')raw=text;else if(invalidGeometry||unitUncertain||crosses||!m||m[2]&&explicit!==b.unit){raw='?';uncertain.add(b.nutrient);issues.push(`${b.label}: célula requer revisão (${c.kind}).`);}
   cells.push({raw,unit:b.unit,column:c.kind,confidence,box:bounds(xs)});
  }
  rows.push({nutrient:b.nutrient,cells});
 }
 const geometry=invalidGeometry||input.evidence.geometry==='uncertain'?'uncertain':'aligned';
 const review=reviewLabel({...input.evidence,geometry},input.base,input.portion,rows);
 return {...review,candidates:review.candidates.map(c=>({...c,ambiguous:c.ambiguous||uncertain.has(c.nutrient)})),issues,originalTokens:structuredClone(tokens),columns:structuredClone(columns),bands:structuredClone(bands),autoSave:false as const};
}
