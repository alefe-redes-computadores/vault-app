/** Single capture flow: a late native response cannot affect another person or closed editor. */
import {gtin,type Scope,type Imported,importDecision} from './nutrition';
export type CaptureMode='barcode'|'ocr'|'photo';
export type CaptureTicket={scope:Scope;editorId:string;requestId:string;mode:CaptureMode};
export type CaptureResult={status:'cancelled'|'permission_denied'|'unavailable'|'error'|'offline'}|{status:'barcode';value:string}|{status:'ocr';text:string;recognizer:string;version:string}|{status:'photo_candidate';labels:readonly {name:string;confidence:number|null}[]};
const equal=(a:Scope,b:Scope)=>a.user_id===b.user_id&&a.person_id===b.person_id;
export function acceptCapture(active:CaptureTicket|null,returned:CaptureTicket,result:CaptureResult){
 if(!active||!equal(active.scope,returned.scope)||active.editorId!==returned.editorId||active.requestId!==returned.requestId||active.mode!==returned.mode)return {status:'stale' as const};
 if(!['barcode','ocr','photo_candidate'].includes(result.status))return {status:result.status};
 if(result.status==='barcode'){if(active.mode!=='barcode')return {status:'invalid' as const};const code=gtin(result.value);return code?{status:'review' as const,code}:{status:'invalid' as const};}
 if(result.status==='ocr'){if(active.mode!=='ocr'||!result.recognizer.trim()||!result.version.trim()||!result.text.trim()||result.text.length>20000)return {status:'invalid' as const};return {status:'review' as const,text:result.text,recognizer:result.recognizer,version:result.version};}
 if(result.status==='photo_candidate'){if(active.mode!=='photo'||!result.labels.length||result.labels.length>20||result.labels.some(x=>!x.name.trim()||x.name.length>120||x.confidence!==null&&(!Number.isFinite(x.confidence)||x.confidence<0||x.confidence>1)))return {status:'invalid' as const};return {status:'review' as const,labels:structuredClone(result.labels),quantity:null,nutrients:null};}
 return {status:'invalid' as const};
}
export type HealthImportContext={scope:Scope;permissions:readonly Imported['type'][];enabled:boolean;sessionId:string};
export function reviewHealthImport(active:HealthImportContext,started:HealthImportContext,record:Imported,previous:readonly Imported[],manual:readonly {scope:Scope;type:Imported['type'];start:string;end:string}[]){
 if(!active.enabled||!started.enabled||active.sessionId!==started.sessionId||!equal(active.scope,started.scope)||!started.permissions.includes(record.type))return 'blocked' as const;
 return importDecision(active.scope,active.permissions,record,previous,manual);
}
