/** Replays the exact canonical chain after a lost RPC response, using the original durable
 * ACK + audit preimages. No second outbox or receipt storage. Never bless remote data merely
 * because its revision number is higher. SQL must support immutable historical receipts. */
import type { Scope, MealRow, VitalAudit } from '../model';
import { vitalWireRow, vitalFingerprint, vitalAckId, VitalSyncConflict } from '../cloud-transport';
import { requireScope, requireId, own } from '../validation';
import { planMealSteps, submitMealStep, assertMealStepSupported, type MealStep, type ExistingRpcClient, type F2Capability } from './remote-meal';
import { finalizeMealBatchF2 } from './finalize-meal-batch';
import type { VitalQueueItem } from '../queue-finalize';
import type { CanonicalDb, CanonicalTable } from '../storage-dexie';
type BaseAck = { revision: number; fingerprint: string };
function must(v:unknown,m:string):asserts v {if(!v) throw new VitalSyncConflict(m);}
const same = (a:unknown,b:unknown) => JSON.stringify(a,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x) === JSON.stringify(b,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
/** An already acknowledged revision may be older than the current remote row. Reconstruct
 * it ONLY from the persisted historical audit, and verify against the existing ACK hash.
 * If the original base is unavailable, preserve the queue; no approximation. */
export async function recoverMealPlan(scope:Scope,localRaw:MealRow,remoteRaw:MealRow|null,baseAck:BaseAck|null,audits:readonly VitalAudit[]):Promise<{base:MealRow|null;steps:MealStep[]}> {
 const s=requireScope(scope),local=vitalWireRow('vital_meals',localRaw,s),remote=remoteRaw===null?null:vitalWireRow('vital_meals',remoteRaw,s);
 must(local.nutrition_f2,'Registro não é F2.');
 if(remote)must(remote.id===local.id&&remote.created_at===local.created_at&&remote.revision<=local.revision,'Cabeça remota incompatível.');
 const start=baseAck?.revision??0;
 must(!baseAck||Number.isSafeInteger(start)&&start>=1&&start<=local.revision&&/^[a-f0-9]{64}$/.test(baseAck.fingerprint),'ACK base inválido.');
 must(!baseAck||remote&&remote.revision>=start,'Servidor não possui base confirmada.');
 if(!baseAck&&remote===null)return {base:null,steps:await planMealSteps(s,local,null,null,audits)};
 let base:MealRow|null=null;
 if(baseAck){
  if(remote!.revision===start)base=remote;
  else {
   const relevant=audits.filter(x=>x.target_table==='vital_meals'&&x.target_id===local.id);
   const byRev=new Map<number,VitalAudit>();
   for(const raw of relevant){
    const a=vitalWireRow('vital_audit',raw,s);
    must(a.revision===1&&a.deleted_at===null&&a.created_at===a.updated_at&&!byRev.has(a.previous_revision),'Auditoria de recuperação inválida/duplicada.');
    byRev.set(a.previous_revision,a);
   }
   const following=byRev.get(start),preceding=start===1?undefined:byRev.get(start-1);
   must(following&&following.previous&&typeof following.previous==='object'&&!Array.isArray(following.previous)&&(start===1||preceding),'Pré-imagem da base confirmada indisponível.');
   base=vitalWireRow('vital_meals',{...(following.previous as Record<string,unknown>),...s,id:local.id,created_at:local.created_at,updated_at:start===1?local.created_at:preceding!.created_at,deleted_at:null,revision:start},s);
  }
  must(await vitalFingerprint('vital_meals',base!,s)===baseAck.fingerprint,'Pré-imagem não confirma ACK base.');
 }
 const steps=await planMealSteps(s,local,base,baseAck,audits);
 if(remote){
  const expected=remote.revision===start?base:steps.find(x=>x.meal.revision===remote.revision)?.meal;
  must(expected&&await vitalFingerprint('vital_meals',expected,s)===await vitalFingerprint('vital_meals',remote,s),'Servidor contém revisão divergente da cadeia local.');
 }
 return {base,steps};
}
/** Caller provides the canonical queue snapshot, durable ACK, and authenticated head reader.
 * Always replay from the confirmed base. Previously applied revisions return historical
 * retry receipts; uncommitted revisions use CAS. Finalize only after the full proof.
 * A process crash needs no new journal: persisted meal + audits + existing ACK reconstruct it. */
export async function recoverAndFinalizeMealF2(deps:{db:CanonicalDb;authenticatedUser:()=>Promise<string|null>;activeScope:()=>Scope|null;readHead:(s:Scope,id:string)=>Promise<MealRow|null>;rpc:ExistingRpcClient;capability:F2Capability;approvedBaseline:string},input:{scope:Scope;local:MealRow;baseAck:BaseAck|null;audits:readonly VitalAudit[];mealQueue:VitalQueueItem;auditQueues:readonly VitalQueueItem[]}):Promise<'confirmed'|'preserve_local'|'already_acknowledged_pending_cleanup'> {
 input=structuredClone(input);const s=requireScope(input.scope);
 const active=async()=>await deps.authenticatedUser()===s.user_id&&own(deps.activeScope(),s)?s:null;
 must(await active(),'Conta ou pessoa ativa mudou.');
 must(deps.capability.enabled&&deps.capability.protocol==='vault-vital-f2-meal-v1'&&/^[a-f0-9]{40}$/.test(deps.approvedBaseline)&&deps.capability.baseline===deps.approvedBaseline,'Transporte F2 não habilitado para esta baseline.');
 const db=deps.db,persons=db.table('persons'),meals=db.table('vital_meals'),audits=db.table('vital_audit'),acks=db.table('vital_sync_ack'),queue=db.table('syncQueue');
 // Verify the persisted ACK and exact local inputs before any network request. Subsequent
 // local edits still win in the finalizer; this read never marks records synchronized.
 await db.transaction('r',[persons,meals,audits,acks,queue],async()=>{
  must(own(deps.activeScope(),s)&&(await persons.get(s.person_id))?.user_id===s.user_id,'Pessoa fora da conta.');
  const local=await meals.get(input.local.id);
  must(local&&same(vitalWireRow('vital_meals',local,s),vitalWireRow('vital_meals',input.local,s)),'Registro local mudou; replanejar.');
  const ackId=vitalAckId('vital_meals',s,input.local.id),saved=await acks.get(ackId);
  if(saved)must(saved.id===ackId&&saved.user_id===s.user_id&&saved.person_id===s.person_id&&saved.table==='vital_meals'&&saved.row_id===input.local.id&&saved.revision===(input.baseAck?.revision??null)&&saved.fingerprint===(input.baseAck?.fingerprint??null)&&saved.pending_revision===null&&saved.pending_fingerprint===null,'ACK local mudou ou tem escrita pendente.');
  else must(!input.baseAck,'ACK base não existe no armazenamento.');
  const keys=new Set<string>();
  for(const q of [input.mealQueue,...input.auditQueues]){
   const id=requireId(q.id);must(!keys.has(q.chave)&&['add','update'].includes(q.operation),'Fila duplicada ou inválida.');keys.add(q.chave);
   const current=await queue.get(id);
   must(current&&current.table===q.table&&current.chave===q.chave&&current.operation===q.operation&&current.updated_at===q.updated_at&&same(current.payload,q.payload),'Fila local mudou; replanejar.');
   const matches=await (queue as unknown as Omit<CanonicalTable,'where'>&{where(index:string):{equals(key:string):{toArray():PromiseLike<Record<string,unknown>[]>}}}).where('chave').equals(q.chave).toArray();
   must(matches.length===1&&matches[0].id===id,'Fila local duplicada.');
  }
  for(const a of input.audits){if(a.target_table==='vital_meals'&&a.target_id===input.local.id){const saved=await audits.get(a.id);must(saved&&same(vitalWireRow('vital_audit',saved,s),vitalWireRow('vital_audit',a,s)),'Histórico local mudou; replanejar.');}}
 });
 must(await active(),'Conta ou pessoa ativa mudou.');
 const head=await deps.readHead(s,input.local.id);must(await active(),'Sessão mudou durante leitura.');
 const plan=await recoverMealPlan(s,input.local,head,input.baseAck,input.audits);
 if(!plan.steps.length)return 'already_acknowledged_pending_cleanup'; // Durable ACK exists but queue is NOT finalized; caller must reconcile existing ACK.
 // Check audit queue shape BEFORE I/O. Finalizer checks all exact payloads again in transaction.
 const expectedAuditIds=plan.steps.flatMap(x=>x.audit?[x.audit.id]:[]);
 must(input.auditQueues.length===expectedAuditIds.length&&new Set(input.auditQueues.map(q=>q.payload.id)).size===expectedAuditIds.length&&expectedAuditIds.every(id=>input.auditQueues.some(q=>q.payload.id===id)),'Fila de auditorias incompleta.');
 must(input.mealQueue.table==='vital_meals'&&input.mealQueue.chave===`vital_meals:${input.local.id}`&&same(vitalWireRow('vital_meals',input.mealQueue.payload,s),vitalWireRow('vital_meals',input.local,s)),'Fila de refeição divergente.');
 for(const step of plan.steps){if(step.audit){const q=input.auditQueues.find(x=>x.payload.id===step.audit!.id)!;must(q.table==='vital_audit'&&q.chave===`vital_audit:${step.audit.id}`&&same(vitalWireRow('vital_audit',q.payload,s),vitalWireRow('vital_audit',step.audit,s)),'Fila de auditoria divergente.');}}
 plan.steps.forEach(assertMealStepSupported);
 const receipts=[];for(const step of plan.steps)receipts.push(await submitMealStep(deps.rpc,active,deps.capability,deps.approvedBaseline,step));
 must(await active(),'Sessão mudou antes da verificação.');
 const finalHead=await deps.readHead(s,input.local.id);must(await active(),'Sessão mudou durante verificação.');
 must(finalHead&&await vitalFingerprint('vital_meals',finalHead,s)===await vitalFingerprint('vital_meals',input.local,s),'Servidor avançou durante confirmação; preservar fila.');
 return finalizeMealBatchF2(deps,{scope:s,base:plan.base,baseAck:input.baseAck,steps:plan.steps,receipts,mealQueue:input.mealQueue,auditQueues:input.auditQueues});
}
