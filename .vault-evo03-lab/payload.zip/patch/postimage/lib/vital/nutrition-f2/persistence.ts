/** Proposed F2 extension of the existing meal row. Pure preparation, no writer or network. */
import {reviewedSnapshot, UNITS, type Scope, type Composition, type Quantity, type Nutrient, type Profile} from './nutrition';
import {sourceAllowed,type SourcePolicy} from './catalog';
import {verifyRecipeComposition} from './recipe-consumption';
import {prepareBatch,type MealDraft,type FoodIdentity} from './meal-draft';
import {verifyExternalMeal} from './external-meal';
export type Reviewed = ReturnType<typeof reviewedSnapshot> & {identity:FoodIdentity; food_id:string|null};
export type LegacyItem = {id:string;food_id:string|null;name:string;quantity:number|null;unit:string|null;nutrients:Partial<Record<Nutrient,number>>;nutrient_source:'label'|'declared'|null};
export type F2Envelope = {schema_version:1; operation_id:string; items:Record<string,Reviewed>; legacy_item_ids:string[]};
export const LEGACY_KEYS=['energy_kcal','carbohydrate_g','protein_g','fat_g','fiber_g'] as const;
const uuid=(v:string)=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(v);
const stable=(v:unknown):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
const scopeMatch=(a:Scope,b:Scope)=>a.user_id===b.user_id&&a.person_id===b.person_id;
function fail(message:string):never{throw Error(message)}
function validateScope(scope:Scope){if(!uuid(scope.user_id)||!uuid(scope.person_id))fail('Escopo inválido');}
function checkShape(c:Composition,q:Quantity){if(c.name.trim().length>(c.source.provider==='recipe'?160:120)||q.value>1e6||c.base.value>1e6)fail('Limite do escritor Vital');if(!Number.isFinite(q.value)||q.value<=0)fail('Quantidade inválida');}
function project(r:Reviewed):LegacyItem {
 const s=r.payload;const provider=s.composition.source.provider;const nutrients:LegacyItem['nutrients']={};
 // F1 only knows declared/label; do not misrepresent external composition or estimates as either.
 if(provider==='manual'||provider==='label') for(const k of LEGACY_KEYS){const n=s.totals[k];if(n?.state==='known'&&n.amount<=1e6)nutrients[k]=n.amount;else if(n?.state==='declared_zero')nutrients[k]=0;}
 const full=s.composition.name.trim();const name=provider==='recipe'&&full.length>120?`${full.slice(0,119).replace(/[\uD800-\uDBFF]$/,'').trimEnd()}…`:full;
 return {id:s.itemId,food_id:r.food_id,name,quantity:provider==='health_connect'?null:s.consumed.value,unit:provider==='health_connect'?null:s.consumed.unit,nutrients,nutrient_source:Object.keys(nutrients).length?(provider==='label'?'label':'declared'):null};
}
export type ScopedFoodBinding={scope:Scope;itemId:string;foodId:string;identity:FoodIdentity;name:string};
// In production only the canonical transaction may supply a binding after reading vital_foods.
function validateIdentity(i:FoodIdentity,c:Composition){if(!i.presentationId?.trim()||i.presentationId.length>160||i.provider!==c.source.provider||i.recordId!==c.source.recordId||i.version!==c.source.version||i.preparation!==c.preparation)fail('Identidade de apresentação divergente');}
function validateLegacy(i:LegacyItem){if(!uuid(i.id)||i.food_id!==null&&!uuid(i.food_id)||!i.name?.trim()||i.name.trim().length>120||(i.quantity===null)!==(i.unit===null)||i.quantity!==null&&(!Number.isFinite(i.quantity)||i.quantity<=0||i.quantity>1e6||!i.unit?.trim()||i.unit.length>40))fail('Item legado inválido');if(!i.nutrients||Array.isArray(i.nutrients)||typeof i.nutrients!=='object'||Object.entries(i.nutrients).some(([k,v])=>!LEGACY_KEYS.includes(k as typeof LEGACY_KEYS[number])||typeof v!=='number'||!Number.isFinite(v)||v<0||v>1e6))fail('Nutrientes legados inválidos');if(Object.keys(i.nutrients).length?i.nutrient_source!=='declared'&&i.nutrient_source!=='label':i.nutrient_source!==null)fail('Fonte legada inválida');}
export function prepareMealEnvelope(scope:Scope,draft:MealDraft,reviewedAt:string,policies:readonly SourcePolicy[],legacyOnly:readonly LegacyItem[]=[],bindings:readonly ScopedFoodBinding[]=[]){
 validateScope(scope);const batch=prepareBatch(scope,draft); const items:Record<string,Reviewed>={};const legacy:LegacyItem[]=[];
 for(const s of batch.snapshots){const c=s.composition;checkShape(c,s.consumed);const p=c.source.provider;
 if(p==='health_connect')fail('Use a revisão de importação externa.');
 if(p!=='manual'&&p!=='label'&&p!=='recipe'&&!policies.some(x=>x.provider===p&&x.release===c.source.version&&sourceAllowed(x,'snapshot')))fail('Fonte sem autorização para snapshot');
 const identity=draft.items.find(x=>x.id===s.itemId)!.identity;validateIdentity(identity,c);const bound=bindings.filter(b=>b.itemId===s.itemId);if(bound.length>1||bound.some(b=>!scopeMatch(b.scope,scope)||!uuid(b.foodId)||stable(b.identity)!==stable(identity)||b.name.trim()!==c.name.trim()))fail('Vínculo privado divergente');
 const r:Reviewed={...reviewedSnapshot(scope,s.itemId,c,s.consumed,reviewedAt),identity:structuredClone(identity),food_id:bound[0]?.foodId??null};
 if(r.conversion.status!=='resolved')fail('Conversão requer revisão');
 items[s.itemId]=r;legacy.push(project(r));}
 if(bindings.some(b=>!Object.hasOwn(items,b.itemId)))fail('Vínculo sem item');
 const payload={id:batch.mealId,scope:structuredClone(scope),items:[...legacy,...structuredClone(legacyOnly)],nutrition_f2:{schema_version:1 as const,operation_id:batch.operationId,items,legacy_item_ids:legacyOnly.map(x=>x.id)}};verifyMealEnvelope(scope,payload.items,payload.nutrition_f2);return payload;
}
/** Validate on every local/remote/restore boundary; historical data does not requery the catalog. */
export function verifyMealEnvelope(scope:Scope,legacy:readonly LegacyItem[],env:F2Envelope):void {
 validateScope(scope);if(env.schema_version!==1||!uuid(env.operation_id)||!legacy.length||legacy.length>200||!env.items||Array.isArray(env.items)||!Array.isArray(env.legacy_item_ids)||Object.keys(env.items).length+env.legacy_item_ids.length!==legacy.length||!Object.keys(env.items).length||new Set(env.legacy_item_ids).size!==env.legacy_item_ids.length)fail('Envelope inválido');
 const external=Object.values(env.items).filter(x=>x.payload.composition.source.provider==='health_connect');if(external.length&&(external.length!==1||legacy.length!==1||env.legacy_item_ids.length||!scopeMatch(external[0].payload.composition.externalMeal!.record.scope,scope)||external[0].food_id!==null||external[0].identity.presentationId!=='meal-total'))fail('Total externo não pode ser misturado ou transferido.');
 const seen=new Set<string>();for(const item of legacy){if(!uuid(item.id)||seen.has(item.id.toLowerCase()))fail('Item duplicado');seen.add(item.id.toLowerCase());validateLegacy(item);const r=env.items[item.id];if(env.legacy_item_ids.includes(item.id)){if(r)fail('Item legado duplicado no snapshot');continue;}if(!r||!scopeMatch(scope,r.payload.scope)||r.payload.itemId!==item.id)fail('Snapshot sem vínculo');checkShape(r.payload.composition,r.payload.consumed);verifyRecipeComposition(scope,r.payload.composition);validateIdentity(r.identity,r.payload.composition);if(r.payload.composition.source.provider==='recipe'&&(r.food_id!==null||r.identity.presentationId!==r.payload.composition.recipeVersion?.id))fail('Vínculo de receita inválido');if(r.food_id!==null&&!uuid(r.food_id))fail('Identidade privada inválida');const recomputed:Reviewed={...reviewedSnapshot(scope,item.id,r.payload.composition,r.payload.consumed,r.reviewedAt),identity:r.identity,food_id:r.food_id};if(recomputed.conversion.status!=='resolved'||stable(r)!==stable(recomputed)||stable(item)!==stable(project(r)))fail('Snapshot/projeção divergente');}
}
export type MealVersion={id:string;scope:Scope;revision:number;deleted_at:string|null;items:readonly LegacyItem[];nutrition_f2?:F2Envelope|null};
/** Expected revision is mandatory. Identical operation replay may be ACKed only against exact payload. */
export function classifyWrite(current:MealVersion|null, proposed:MealVersion, expected:number|null):'apply'|'retry'|'conflict' {
 validateScope(proposed.scope);if(proposed.deleted_at!==null||!uuid(proposed.id)||!Number.isSafeInteger(proposed.revision)||proposed.revision<1||!proposed.nutrition_f2)fail('Proposta inválida');verifyMealEnvelope(proposed.scope,proposed.items,proposed.nutrition_f2);
 if(current){if(!scopeMatch(current.scope,proposed.scope)||current.id!==proposed.id||current.deleted_at)return 'conflict';if(current.nutrition_f2?.operation_id===proposed.nutrition_f2.operation_id)return stable(current)===stable(proposed)?'retry':'conflict';}
 if((current?.revision??null)!==expected||proposed.revision!==(current?.revision??0)+1)return 'conflict';return 'apply';
}
/** Old client can read legacy projection; cannot rewrite an F2 fact (including tombstone) until a coordinated correction protocol exists. */
export function legacyMutationAllowed(current:MealVersion|null){return !current?.nutrition_f2;}
export function snapshotProfiles(env:F2Envelope):Profile[]{return Object.values(env.items).map(x=>structuredClone(x.payload.totals));}
/** A mixed F1/F2 meal contributes exactly once per item; historical F1 fields are not invented. */
export function mealProfiles(scope:Scope,legacy:readonly LegacyItem[],env:F2Envelope):Profile[]{verifyMealEnvelope(scope,legacy,env);return legacy.map(i=>env.items[i.id]?structuredClone(env.items[i.id].payload.totals):Object.fromEntries(Object.entries(i.nutrients).map(([k,amount])=>[k,{state:'known',amount,unit:UNITS[k as Nutrient]}])) as Profile);}
export const nutrientKeys=Object.keys(UNITS) as Nutrient[];

/** Build the exact compatible projection for a reviewed external total. The dedicated repository writer
 * must validate the binding and deduplicate within the existing transaction. */
export function prepareExternalMealEnvelope(scope:Scope,mealId:string,operationId:string,itemId:string,c:Composition,reviewedAt:string){
 validateScope(scope);if(!uuid(mealId)||!uuid(operationId)||!uuid(itemId)||new Set([mealId,operationId,itemId]).size!==3||c.source.provider!=='health_connect'||!c.externalMeal||!scopeMatch(c.externalMeal.record.scope,scope)||c.externalMeal.reviewedAt!==reviewedAt)fail('Importação externa inválida');
 const consumed={value:1,unit:'portion' as const};verifyExternalMeal(c,consumed);
 const snapshot:Reviewed={...reviewedSnapshot(scope,itemId,c,consumed,reviewedAt),identity:{provider:'health_connect',recordId:c.source.recordId,version:c.source.version,preparation:'unknown',presentationId:'meal-total'},food_id:null};
 const items=[project(snapshot)],nutrition_f2:F2Envelope={schema_version:1,operation_id:operationId,items:{[itemId]:snapshot},legacy_item_ids:[]};verifyMealEnvelope(scope,items,nutrition_f2);return {items,nutrition_f2};
}
