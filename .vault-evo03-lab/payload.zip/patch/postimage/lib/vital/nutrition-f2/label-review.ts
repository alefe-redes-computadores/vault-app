/** N02: engine-independent candidate review. A recognizer maps bounding boxes to explicitly identified columns; never guesses a column from plain text. */
import {decimalBR,convert,normalized,UNITS,type Nutrient,type Value,type Unit,type Quantity} from './nutrition';
export type Cell={raw:string;confidence:number|null;unit:Unit;column:'per100'|'portion'|'dailyValue';box?:readonly [number,number,number,number]};
export type Row={nutrient:Nutrient;cells:readonly Cell[]};
export type Evidence={text:string;recognizer:string;recognizerVersion:string;geometry:'aligned'|'uncertain';imageRetention:'discard'|'authorized-local';imageRef?:string};
export function interpretCell(key:Nutrient,c:Cell):Value|null{
 if(c.column==='dailyValue')return null;
 if(c.confidence!==null&&(!Number.isFinite(c.confidence)||c.confidence<0||c.confidence>1))throw Error('Confiança inválida');
 const s=c.raw.trim();if(!s||s==='—'||s==='?'||s.includes('%'))return {state:'illegible'};
 const amount=decimalBR(s);if(amount===null)return {state:'illegible'};
 try{return normalized(key,amount===0?{state:'declared_zero',unit:c.unit}:{state:'known',amount,unit:c.unit});}catch{return {state:'illegible'};}
}
/** Display-resolution intervals are a screening heuristic, NOT Anvisa tolerance certification. Zero can mean non-significant and is deliberately inconclusive. */
function interval(c:Cell,key:Nutrient){const n=decimalBR(c.raw);if(n===null||n===0)return null;const digits=c.raw.trim().split(/[,.]/)[1]?.length??0;const delta=.5*10**-digits;try{const lo=convert({value:Math.max(0,n-delta),unit:c.unit},UNITS[key]),hi=convert({value:n+delta,unit:c.unit},UNITS[key]);return lo===null||hi===null?null:[lo,hi] as const;}catch{return null;}}
export function reviewLabel(e:Evidence,base:'g'|'mL',portion:Quantity|null,rows:readonly Row[]){
 if(!e.recognizer.trim()||!e.recognizerVersion.trim()||e.text.length>20000||rows.length>100||!['g','mL'].includes(base))throw Error('Evidência inválida');
 if(e.imageRef&&e.imageRetention!=='authorized-local')throw Error('Imagem sem autorização');
 if(e.imageRef&&(!e.imageRef.startsWith('local:')||e.imageRef.length>256))throw Error('Referência local inválida');
 const p=portion&&portion.value>0?convert(portion,base):null;
 const seen=new Set<Nutrient>();const candidates=rows.map(r=>{
  if(!Object.hasOwn(UNITS,r.nutrient)||seen.has(r.nutrient)||r.cells.length>8)throw Error('Linha duplicada ou inválida');seen.add(r.nutrient);
  const cells=r.cells.filter(c=>c.column!=='dailyValue');const a=cells.filter(c=>c.column==='per100'),b=cells.filter(c=>c.column==='portion');
  const ambiguous=a.length>1||b.length>1||e.geometry==='uncertain';const per100=a.length===1?interpretCell(r.nutrient,a[0]):null;const perPortion=b.length===1?interpretCell(r.nutrient,b[0]):null;
  const ia=a.length===1?interval(a[0],r.nutrient):null,ib=b.length===1?interval(b[0],r.nutrient):null;
  const coherence=ambiguous||!ia||!ib||p===null||p<=0?'inconclusive':ia[0]*p/100>ib[1]||ia[1]*p/100<ib[0]?'review_difference':'display_intervals_overlap';
  return {nutrient:r.nutrient,per100,perPortion,coherence,ambiguous,rawCells:structuredClone(r.cells)};
 });return {evidence:structuredClone(e),base:{value:100,unit:base},portion:structuredClone(portion),candidates,requiresReview:true as const,autoSave:false as const,method:'display-resolution-screen-v1-not-regulatory' as const};
}
