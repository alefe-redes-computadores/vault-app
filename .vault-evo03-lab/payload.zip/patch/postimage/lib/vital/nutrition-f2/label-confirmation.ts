/** Reviewed label evidence. One explicitly chosen column, no automatic OCR acceptance.
 * A local/private product identity is not an OFF or USDA catalog identity. */
import { decimalBR, gtin, normalized, UNITS, type Composition, type Nutrient, type Profile, type Quantity, type Unit } from './nutrition';
import type { DraftItem } from './meal-draft';
import { requireId, instant, text } from '../validation';
export type LabelObservation={raw:string;unit:Unit;column:'per100'|'portion';printedBase:number|null;box:readonly [number,number,number,number];confidence:number|null};
export type LabelField = {nutrient:Nutrient;raw:string;unit:Unit;state:'value'|'unreadable'|'not_reported';confirmed:true;observed:LabelObservation|null};
export type LabelEvidence = {schema:1;recordId:string;versionId:string;reviewedAt:string;name:string;barcode:string|null;basis:'per100'|'portion';base:Quantity;fields:readonly LabelField[];capture:{recognizer:'mlkit-latin-bundled';version:'16.0.1';originalText:string;imageWidth:number;imageHeight:number;retention:'reviewed-text-only'}|null};
const ok=(x:unknown,m:string):void=>{if(!x)throw Error(m);};
const canonical=(x:unknown):string=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const keys=(x:unknown,allowed:readonly string[])=>!!x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===allowed.length&&allowed.every(k=>Object.hasOwn(x,k));
export function reviewedLabelComposition(e:LabelEvidence):Composition {
 ok(keys(e,['schema','recordId','versionId','reviewedAt','name','barcode','basis','base','fields','capture'])&&e.schema===1,'Evidência de rótulo inválida');
 const recordId=requireId(e.recordId),versionId=requireId(e.versionId),at=instant(e.reviewedAt),name=text(e.name,120,true)!;
 ok(recordId===e.recordId&&versionId===e.versionId&&recordId!==versionId&&at===e.reviewedAt&&name===e.name,'Identidade de rótulo inválida');
 ok(e.barcode===null||typeof e.barcode==='string'&&gtin(e.barcode)===e.barcode,'Código GTIN não confirmado');
 ok(keys(e.base,['value','unit'])&&['g','mL'].includes(e.base.unit)&&Number.isFinite(e.base.value)&&e.base.value>0&&e.base.value<=1e6,'Base nutricional inválida');
 ok(e.basis==='per100'&&e.base.value===100||e.basis==='portion','Selecione uma única coluna do rótulo');
 if(e.capture!==null){const c=e.capture;ok(keys(c,['recognizer','version','originalText','imageWidth','imageHeight','retention'])&&c.recognizer==='mlkit-latin-bundled'&&c.version==='16.0.1'&&c.retention==='reviewed-text-only'&&typeof c.originalText==='string'&&!!c.originalText.trim()&&c.originalText.length<=20000&&Number.isInteger(c.imageWidth)&&Number.isInteger(c.imageHeight)&&c.imageWidth>=1&&c.imageWidth<=2560&&c.imageHeight>=1&&c.imageHeight<=2560,'Texto OCR não autorizado ou inválido');}
 ok(Array.isArray(e.fields)&&e.fields.length>0&&e.fields.length<=Object.keys(UNITS).length,'Revise ao menos um campo');
 const seen=new Set<string>(),values:Profile={};
 for(const f of e.fields){
  ok(keys(f,['nutrient','raw','unit','state','confirmed','observed'])&&Object.hasOwn(UNITS,f.nutrient)&&!seen.has(f.nutrient)&&f.confirmed===true&&typeof f.raw==='string'&&f.raw.length<=80,'Campo inválido, duplicado ou não revisado');seen.add(f.nutrient);
  // Printed unit must be explicitly selected. %VD is never a unit or a numeric value.
  ok(['g','mg','ug','kcal','kJ'].includes(f.unit),'Unidade nutricional inválida');
  normalized(f.nutrient,{state:'declared_zero',unit:f.unit});
  if(f.observed!==null){const o=f.observed;ok(e.capture!==null&&keys(o,['raw','unit','column','printedBase','box','confidence'])&&o.column===e.basis&&(o.printedBase===null?e.basis==='portion':o.printedBase===e.base.value)&&typeof o.raw==='string'&&o.raw.length<=80&&decimalBR(o.raw)!==null&&['g','mg','ug','kcal','kJ'].includes(o.unit)&&Array.isArray(o.box)&&o.box.length===4&&o.box.every(Number.isFinite)&&o.box[0]>=0&&o.box[1]>=0&&o.box[2]<=e.capture!.imageWidth&&o.box[3]<=e.capture!.imageHeight&&o.box[2]>o.box[0]&&o.box[3]>o.box[1]&&(o.confidence===null||typeof o.confidence==='number'&&Number.isFinite(o.confidence)&&o.confidence>=0&&o.confidence<=1),'Célula OCR fora da base revisada ou sem evidência');normalized(f.nutrient,{state:'declared_zero',unit:o.unit});}
  if(f.state==='value'){const n=decimalBR(f.raw);ok(n!==null&&n<=1e6,'Valor de rótulo inválido');values[f.nutrient]=normalized(f.nutrient,n===0?{state:'declared_zero',unit:f.unit}:{state:'known',amount:n!,unit:f.unit});}
  else {ok(['unreadable','not_reported'].includes(f.state)&&!f.raw.trim(),'Ausência de valor não pode conter um número');values[f.nutrient]={state:f.state==='unreadable'?'illegible':'not_reported'};}
 }
 return {name,source:{provider:'label',recordId,version:versionId,license:'private-user-label',retrievedAt:at!,attribution:'Rótulo revisado pelo usuário'},base:structuredClone(e.base),values,preparation:'ready',edibleBasis:'unknown',labelEvidence:structuredClone(e)};
}
/** Historical pre-F2 and previously approved manual label snapshots remain readable. */
export function verifyLabelEvidence(c:Composition){if(c.labelEvidence===undefined){ok(c.source.license!=='private-user-label','Evidência de rótulo obrigatória');return;}ok(c.source.provider==='label'&&canonical(reviewedLabelComposition(c.labelEvidence))===canonical(c),'Evidência de rótulo divergente');}
export function labelDraftItem(e:LabelEvidence,itemId:string,quantity:Quantity):DraftItem{const c=reviewedLabelComposition(e);return {id:requireId(itemId),identity:{provider:'label',recordId:c.source.recordId,version:c.source.version,preparation:'ready',presentationId:`${c.base.value}-${c.base.unit}`},composition:c,quantity:structuredClone(quantity),reviewed:false};}
