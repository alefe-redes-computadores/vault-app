import {normalized,UNITS,type Composition,type Nutrient,type Profile,type Quantity,type Scope} from './nutrition';
import {NUTRITION_ORIGIN,type NutritionRecord} from './health-connect-nutrition';
import {civil,own,requireId,requireScope} from '../validation';
import type {MealRow,MealData} from '../model';
export type ExternalMealEvidence={schema:1;granularity:'meal_total';record:NutritionRecord;connectionRevision:string;reviewedAt:string;offsetMinutes:number;civilDay:string;civilTime:string;overlapConfirmed:boolean};
const same=(a:unknown,b:unknown)=>JSON.stringify(a,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v)===JSON.stringify(b,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
function must(ok:unknown,message:string):asserts ok{if(!ok)throw Error(message);}
const iso=(s:string)=>typeof s==='string'&&Number.isFinite(Date.parse(s))&&new Date(s).toISOString()===s;
const exact=(x:unknown,keys:readonly string[])=>!!x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===keys.length&&keys.every(k=>Object.hasOwn(x,k));
/** No inferred portion, food identity, or nutrients. The internal unit is one external meal-total record. */
export function externalMealComposition(raw:ExternalMealEvidence):Composition{
 const e=structuredClone(raw);must(exact(e,['schema','granularity','record','connectionRevision','reviewedAt','offsetMinutes','civilDay','civilTime','overlapConfirmed'])&&e.schema===1&&e.granularity==='meal_total','Evidência externa inválida.');
 const r=e.record;must(exact(r,['scope','type','origin','recordId','start','end','lastModified','mealName','nutrients','mealType'])&&exact(r.scope,['user_id','person_id']),'Registro externo inválido.');requireScope(r.scope);
 must(r.type==='nutrition'&&r.origin===NUTRITION_ORIGIN&&typeof r.recordId==='string'&&r.recordId.trim()===r.recordId&&r.recordId.length>0&&r.recordId.length<=256&&[r.start,r.end,r.lastModified,e.reviewedAt].every(iso)&&r.start<r.end&&r.end<=e.reviewedAt&&r.lastModified<=e.reviewedAt,'Intervalo/versão externa inválidos.');
 must(['breakfast','lunch','dinner','snack','unknown'].includes(r.mealType)&& (r.mealName===null||typeof r.mealName==='string'&&r.mealName.trim()===r.mealName&&r.mealName.length<=200),'Tipo/nome externo inválido.');
 must(typeof e.connectionRevision==='string'&&e.connectionRevision.trim()&&e.connectionRevision.length<=256&&typeof e.overlapConfirmed==='boolean'&&Number.isSafeInteger(e.offsetMinutes)&&e.offsetMinutes>=-840&&e.offsetMinutes<=840,'Revisão de vínculo/fuso inválida.');
 const shifted=new Date(Date.parse(r.start)+e.offsetMinutes*60000).toISOString();must(civil(e.civilDay)===shifted.slice(0,10)&&e.civilTime===shifted.slice(11,16),'Data civil externa divergente.');
 must(r.nutrients&&typeof r.nutrients==='object'&&!Array.isArray(r.nutrients),'Perfil externo inválido.');
 const values:Profile={};for(const [k,v] of Object.entries(r.nutrients)){must(Object.hasOwn(UNITS,k)&&v,'Nutriente externo inválido.');const key=k as Nutrient;
  must(v.state==='known'||v.state==='unknown'||v.state==='not_reported','Estado externo inválido.');const n=normalized(key,v);if(n.state==='known')must(n.amount>0&&n.amount<=1e6&&same(n,v),'Valor externo deve estar normalizado; zero não é comprovado.');else must(same(n,v),'Campo externo inválido.');values[key]=n;
 }
 must(Object.keys(values).length>0,'Registro sem composição disponível.');
 return {name:'Total importado da refeição',source:{provider:'health_connect',recordId:r.recordId,version:r.lastModified,license:'private-health-connect',retrievedAt:e.reviewedAt,attribution:'Health Connect · origem Samsung Health · total da refeição'},base:{value:1,unit:'portion'},values,preparation:'unknown',edibleBasis:'unknown',externalMeal:e};
}
export function verifyExternalMeal(c:Composition,q:Quantity){
 if(c.source.provider!=='health_connect'){must(c.externalMeal===undefined,'Evidência externa em fonte divergente.');return;}
 must(c.externalMeal&&same(c,externalMealComposition(c.externalMeal))&&q.value===1&&q.unit==='portion','Total externo não admite conversão de porção.');
}
export function externalMealMetadata(e:ExternalMealEvidence):Omit<MealData,'items'>{const r=e.record;return {day:e.civilDay,time:e.civilTime,kind:r.mealType==='unknown'?'custom':r.mealType,custom_label:r.mealType==='unknown'?'Refeição importada':null,plan_version_id:null,notes:null};}
export function externalEvidenceOf(row:MealRow):ExternalMealEvidence|null {const all=Object.values(row.nutrition_f2?.items??{}).map(x=>x.payload.composition.externalMeal).filter((x):x is ExternalMealEvidence=>!!x);must(all.length<=1,'Total externo duplicado.');return all[0]??null;}
/** Exact metadata is fixed by reviewed source. It cannot be transformed into manual facts. */
export function verifyExternalRow(scope:Scope,row:Pick<MealRow,'items'|'nutrition_f2'|'day'|'time'|'kind'|'custom_label'|'plan_version_id'|'notes'>){
 const items=Object.values(row.nutrition_f2?.items??{});const external=items.filter(x=>x.payload.composition.source.provider==='health_connect');if(!external.length)return;
 must(items.length===1&&row.items.length===1&&row.nutrition_f2?.legacy_item_ids.length===0,'Total externo não pode ser misturado com alimentos.');
 const e=external[0].payload.composition.externalMeal!;must(own(e.record.scope,scope)&&external[0].food_id===null&&external[0].identity.presentationId==='meal-total','Total externo fora da pessoa.');
 const {items:_i,nutrition_f2:_n,...metadata}=row; // caller passes only the fixed meal data fields
 must(same(externalMealMetadata(e),metadata),'Metadados externos não podem ser alterados pelo editor manual.');
}
export function externalIdentity(e:ExternalMealEvidence){return JSON.stringify([e.record.origin,e.record.recordId]);}
export function makeExternalMealEvidence(record:NutritionRecord,connectionRevision:string,reviewedAt:string,offsetMinutes:number,overlapConfirmed:boolean):ExternalMealEvidence{
 const normalizedRecord=structuredClone(record);for(const k of ['start','end','lastModified'] as const)normalizedRecord[k]=new Date(normalizedRecord[k]).toISOString();
 const shifted=new Date(Date.parse(normalizedRecord.start)+offsetMinutes*60000).toISOString();const e:ExternalMealEvidence={schema:1,granularity:'meal_total',record:normalizedRecord,connectionRevision,reviewedAt,offsetMinutes,civilDay:shifted.slice(0,10),civilTime:shifted.slice(11,16),overlapConfirmed};externalMealComposition(e);return e;
}
