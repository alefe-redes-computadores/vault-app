/** The review tree deliberately has no activation token or environment override.
 * Change only in a certified cumulative release after DB, migration, Android and Guardian gates. */
import type {INTEGRATED_MEAL_REVIEW} from './remote-meal';
export type VitalF2Release={baseline:string;protocol:'vault-vital-f2-meal-v1';enabled:true;integratedMealReview:typeof INTEGRATED_MEAL_REVIEW;recipes?:true;recipeProtocol?:'vault-vital-f2-recipe-v1';nutritionImport?:true;planTargets?:true};
export function certifiedVitalF2Release():VitalF2Release|null{return null;}
