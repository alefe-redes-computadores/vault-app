/** Orchestrates the persisted F2 editor. Uses the existing controller and repository, not a new store. */
import {createMealController,editingMeal,type MealEditor} from './meal-controller';
import {draftAdd,type DraftItem} from './meal-draft';
import {repeatMealDraft} from './meal-history';
import {verifyMealEnvelope,type ScopedFoodBinding} from './persistence';
import {reviewedSnapshot,type Quantity} from './nutrition';
import type {MealData,MealRow,Scope} from '../model';
import type {DraftRecord} from '../drafts';
import {requireScope,requireId,own,text} from '../validation';
type Controller=ReturnType<typeof createMealController>;
export type JourneyState={record:DraftRecord;value:MealEditor};
export type JourneyMetadata=Omit<MealData,'items'>;
type Editing=Extract<MealEditor,{phase:'editing'}>;
function must(v:unknown,message:string):asserts v{if(!v)throw Error(message);}
function sameScope(s:Scope,d:JourneyState){return own(d.record,s)&&own(d.value.draft.scope,s)&&d.record.id===d.value.draft.mealId;}
export function createMealJourney(controller:Controller,rawScope:Scope,now=()=>new Date()){
 const s=requireScope(rawScope);let busy=false;
 async function exclusive<T>(fn:()=>Promise<T>){must(!busy,'Aguarde a gravação do rascunho.');busy=true;try{return await fn();}finally{busy=false;}}
 async function get(id:string):Promise<JourneyState>{const state=await controller.load(s,requireId(id));must(state&&sameScope(s,state),'Rascunho indisponível para esta pessoa.');return state;}
 async function checked(state:JourneyState):Promise<JourneyState>{must(sameScope(s,state),'Rascunho fora da pessoa.');const current=await get(state.record.id);must(current.record.draft_revision===state.record.draft_revision&&current.value.draft.operationId===state.value.draft.operationId,'O rascunho mudou. Reabra antes de continuar.');return current;}
 async function mutate(state:JourneyState,fn:(e:Editing)=>Editing){return exclusive(async()=>{const current=await checked(state);must(current.value.phase==='editing','O rascunho já está selado. Retome a confirmação.');const next=fn(structuredClone(current.value));await controller.saveEditing(s,next,current.record.expected_revision,current.record.draft_revision);return get(current.record.id);});}
 function validateItem(item:DraftItem){const snap=reviewedSnapshot(s,item.id,item.composition,item.quantity,now().toISOString());must(snap.conversion.status==='resolved','Quantidade incompatível com a base.');return item;}
 return {
  async start(id:string,operationId:string,metadata:JourneyMetadata){return exclusive(async()=>{const draft=editingMeal({scope:s,mealId:requireId(id),operationId:requireId(operationId),items:[]},metadata);await controller.saveEditing(s,draft,null,null);return get(id);});},
  /** Retification uses canonical preimage and same meal/item IDs, with a new operation. */
  async correct(id:string,revision:number,operationId:string,reason:string){return exclusive(async()=>{
   const row=await controller.meal(s,id,revision);must(row.nutrition_f2,'Use o editor legado para este registro.');verifyMealEnvelope(s,row.items,row.nutrition_f2);must(!Object.values(row.nutrition_f2.items).some(x=>x.payload.composition.source.provider==='health_connect'),'Total externo exige revisão da importação.');
   must(requireId(operationId)!==row.id&&requireId(operationId)!==row.nutrition_f2.operation_id.toLowerCase(),'A retificação exige nova operação.');
   const metadata:JourneyMetadata={day:row.day,time:row.time,kind:row.kind,custom_label:row.custom_label,plan_version_id:row.plan_version_id,notes:row.notes};
   const items:DraftItem[]=[],bindings:ScopedFoodBinding[]=[];for(const i of row.items){const snap=row.nutrition_f2.items[i.id];if(!snap)continue;
    items.push({id:i.id,identity:structuredClone(snap.identity),composition:structuredClone(snap.payload.composition),quantity:structuredClone(snap.payload.consumed),reviewed:false});
    if(snap.food_id)bindings.push({scope:s,itemId:i.id,foodId:snap.food_id,identity:structuredClone(snap.identity),name:snap.payload.composition.name});
   }
   const editor=editingMeal({scope:s,mealId:row.id,operationId:requireId(operationId),items},metadata,row.items.filter(i=>row.nutrition_f2!.legacy_item_ids.includes(i.id)),text(reason,500,true)!);
   if(bindings.length)editor.bindings=bindings;
   await controller.saveEditing(s,editor,row.revision,null);return get(row.id);
  });},
  /** New meal, not a historical edit. A mixed legacy meal cannot silently lose facts. */
  async repeat(id:string,revision:number,newId:()=>string,metadata:JourneyMetadata){return exclusive(async()=>{
   const row=await controller.meal(s,id,revision);const r=repeatMealDraft(s,row,newId);
   must(r.draft.items.length>0&&!r.legacyForReview.length,'Refeição com itens legados: registre-os explicitamente em um novo prato.');
   const editor=editingMeal(r.draft,metadata);await controller.saveEditing(s,editor,null,null);return get(r.draft.mealId);
  });},
  resume:get,
  list:()=>controller.list(s),
  add:(state:JourneyState,item:DraftItem)=>mutate(state,e=>({...e,draft:draftAdd(e.draft,validateItem({...structuredClone(item),reviewed:false}))})),
  remove:(state:JourneyState,id:string)=>mutate(state,e=>{must(e.draft.items.some(i=>i.id===id),'Alimento indisponível.');return {...e,...(e.bindings?{bindings:e.bindings.filter(b=>b.itemId!==id)}:{}),draft:{...e.draft,items:e.draft.items.filter(i=>i.id!==id)}};}),
  quantity:(state:JourneyState,id:string,quantity:Quantity)=>mutate(state,e=>{must(e.draft.items.some(i=>i.id===id),'Alimento indisponível.');return {...e,draft:{...e.draft,items:e.draft.items.map(i=>i.id===id?validateItem({...i,quantity:structuredClone(quantity),reviewed:false}):i)}};}),
  review:(state:JourneyState,id:string,confirmed:boolean)=>mutate(state,e=>{must(typeof confirmed==='boolean'&&e.draft.items.some(i=>i.id===id),'Revisão inválida.');return {...e,draft:{...e.draft,items:e.draft.items.map(i=>i.id===id?validateItem({...i,reviewed:confirmed}):i)}};}),
  metadata:(state:JourneyState,metadata:JourneyMetadata)=>mutate(state,e=>({...e,metadata:structuredClone(metadata)})),
  async seal(state:JourneyState){return exclusive(async()=>{const current=await checked(state);await controller.seal(s,current.record.id,current.record.draft_revision);return get(current.record.id);});},
  async confirm(state:JourneyState):Promise<{row:MealRow;status:'saved_locally';cleanup:'done'|'pending'}>{return exclusive(async()=>{const current=await checked(state);must(current.value.phase==='sealed','Revise antes de confirmar.');const result=await controller.confirm(s,current.record.id,current.record.draft_revision);try{await controller.cleanup(s,current.record.id,current.record.draft_revision);return {row:result.row,status:'saved_locally',cleanup:'done'};}catch{return {row:result.row,status:'saved_locally',cleanup:'pending'};}});},
  async discard(state:JourneyState){return exclusive(async()=>{const current=await checked(state);await controller.discardEditing(s,current.record.id,current.record.draft_revision);});}
 };
}
