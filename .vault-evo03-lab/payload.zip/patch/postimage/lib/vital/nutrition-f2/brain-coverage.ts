import {coverageDetailed,type Nutrient,type Profile,type Scope} from './nutrition';
export type ObservationDay={scope:Scope;day:string;mealProfiles:readonly Profile[];mealCount:number;trainingObserved:boolean;hydrationObserved:boolean;sleepObserved:boolean;bodyObserved:boolean;energyObserved:boolean};
const equal=(a:Scope,b:Scope)=>a.user_id===b.user_id&&a.person_id===b.person_id;
const civil=(s:string)=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(s))throw Error('Data civil inválida');let d=Date.parse(s+'T00:00:00Z');if(!Number.isFinite(d)||new Date(d).toISOString().slice(0,10)!==s)throw Error('Data civil inválida');return d};
/** Accept one canonical projection per day. Never infer absent meals, hydration or health events. */
export function brainCoverage(scope:Scope,from:string,to:string,rows:readonly ObservationDay[],key:Nutrient){
 const totalDays=(civil(to)-civil(from))/86400000+1;if(totalDays<1||totalDays>366)throw Error('Período inválido');const visible=rows.filter(x=>equal(x.scope,scope)&&x.day>=from&&x.day<=to);const seen=new Set<string>();
 for(const r of visible){civil(r.day);if(seen.has(r.day)||!Number.isSafeInteger(r.mealCount)||r.mealCount<0||r.mealCount===0&&r.mealProfiles.length>0)throw Error('Projeção diária ambígua');seen.add(r.day);}
 const registered=visible.filter(x=>x.mealCount>0),pairs=(k:'trainingObserved'|'hydrationObserved'|'sleepObserved'|'bodyObserved'|'energyObserved')=>registered.filter(x=>x[k]).length;
 return {periodDays:totalDays,daysWithMeals:registered.length,daysWithoutMealRecord:totalDays-registered.length,nutrient:coverageDetailed(key,registered.flatMap(x=>x.mealProfiles)),pairedDays:{training:pairs('trainingObserved'),hydration:pairs('hydrationObserved'),sleep:pairs('sleepObserved'),body:pairs('bodyObserved'),energy:pairs('energyObserved')},interpretation:'observational_only' as const};
}
