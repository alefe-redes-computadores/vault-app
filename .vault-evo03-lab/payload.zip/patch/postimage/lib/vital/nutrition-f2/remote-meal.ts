/** N11: candidate adapter for the existing Vital outbox. No scheduler, no new ACK table on client.
 * Each RPC atomically commits one meal revision + its canonical vital_audit record.
 * Integration must consume the exact existing queue entries only after both ACKs in the same Dexie transaction.
 */
import type { MealRow, Scope, VitalAudit } from '../model';
import {vitalWireRow,vitalPayload,vitalFingerprint,VitalSyncConflict} from '../cloud-transport';
import {requireScope,requireId,own} from '../validation';
import {verifyRemoteExternalRow,verifyRemoteExternalTransition} from './remote-external-review';
import {externalEvidenceOf} from './external-meal';
import type {F2Envelope} from './persistence';
export type MealStep={scope:Scope;operationId:string;expectedRevision:number|null;meal:MealRow;audit:VitalAudit|null};
const fail=(reason:string):never=>{throw new VitalSyncConflict(reason)};
const canon=(v:unknown):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
const same=(a:unknown,b:unknown)=>canon(a)===canon(b);
function dataOf(r:MealRow){const {id,user_id,person_id,created_at,updated_at,revision,deleted_at,synced,...data}=r;return data;}
function validateAudit(a:VitalAudit,s:Scope,id:string){const wire=vitalWireRow('vital_audit',a,s);if(wire.target_table!=='vital_meals'||wire.target_id!==id||wire.revision!==1||wire.deleted_at!==null||wire.created_at!==wire.updated_at||!wire.reason.trim()||wire.reason.length>500)fail('Auditoria da refeição incompatível.');return wire;}
function validateStep(s:Scope,previous:MealRow|null,next:MealRow,audit:VitalAudit|null):MealStep{
 const row=vitalWireRow('vital_meals',next,s);if(!row.nutrition_f2)fail('Revisão sem F2: use o transporte legado reconciliado.');const env=row.nutrition_f2!;
 if(previous===null){if(row.revision!==1||row.deleted_at||audit||row.updated_at!==row.created_at)fail('Inserção F2 precisa da primeira revisão.');return {scope:s,operationId:requireId(env.operation_id),expectedRevision:null,meal:row,audit:null};}
 if(!audit||!own(previous,s)||previous.id!==row.id||previous.created_at!==row.created_at||previous.deleted_at!==null||row.revision!==previous.revision+1||row.updated_at<=previous.updated_at)fail('Cadeia F2 interrompida.');
 const a=validateAudit(audit!,s,row.id);if(a.previous_revision!==previous.revision||a.created_at!==row.updated_at||!same(a.previous,dataOf(previous)))fail('Pré-imagem da auditoria diverge.');
 if(previous.nutrition_f2&&env.legacy_item_ids.some(id=>Object.hasOwn(previous.nutrition_f2!.items,id)))fail('Snapshot não pode voltar a legado.');
 if(row.deleted_at!==null){if(row.deleted_at!==row.updated_at||!same(dataOf(previous),dataOf(row)))fail('Arquivamento precisa preservar o fato.');}
 else if(previous.nutrition_f2&&previous.nutrition_f2.operation_id===env.operation_id)fail('Retificação precisa de nova operação nutricional.');
 return {scope:s,operationId:a.id,expectedRevision:previous.revision,meal:row,audit:a};
}
/** The caller first validates the remote against the durable existing ACK. Missing or ambiguous history blocks upload, never collapses it. */
export async function planMealSteps(scope:Scope,localRaw:MealRow,remoteRaw:MealRow|null,acked:{revision:number;fingerprint:string}|null,audits:readonly VitalAudit[]):Promise<MealStep[]>{
 const s=requireScope(scope),local=vitalWireRow('vital_meals',localRaw,s),remote=remoteRaw===null?null:vitalWireRow('vital_meals',remoteRaw,s);
 if(!local.nutrition_f2)fail('Registro não é F2.');
 if(remote){if(!acked||acked.revision!==remote.revision||acked.fingerprint!==await vitalFingerprint('vital_meals',remote,s)||remote.id!==local.id||remote.created_at!==local.created_at||remote.revision>local.revision)fail('ACK base não confirma a revisão remota.');if(remote.revision===local.revision){if(await vitalFingerprint('vital_meals',remote,s)!==await vitalFingerprint('vital_meals',local,s))fail('Mesma revisão, conteúdo divergente.');return [];}}
 else if(acked)fail('ACK existe, registro remoto indisponível.');
 const start=remote?.revision??0;if(local.revision-start>200)fail('Histórico excede o limite de revisão por lote.');
 const byRev=new Map<number,VitalAudit>(),ids=new Set<string>();for(const raw of audits){if(raw.target_table!=='vital_meals'||raw.target_id!==local.id)continue;if(!own(raw,s))fail('Auditoria de outra pessoa.');const a=validateAudit(raw,s,local.id);if(a.previous_revision<Math.max(1,start)||a.previous_revision>=local.revision)continue;if(byRev.has(a.previous_revision)||ids.has(a.id))fail('Auditoria duplicada.');byRev.set(a.previous_revision,a);ids.add(a.id);}
 const steps:MealStep[]=[];let previous=remote;const operations=new Set<string>(),snapshotOps=new Set<string>();if(remote?.nutrition_f2)snapshotOps.add(remote.nutrition_f2.operation_id);
 for(let revision=start+1;revision<=local.revision;revision++){
  const preceding=revision>1?byRev.get(revision-1):undefined;if(revision>1&&!preceding)fail('Auditoria intermediária ausente.');
  const following=byRev.get(revision);if(revision<local.revision&&!following)fail('Pré-imagem intermediária ausente.');
  const row=revision===local.revision?local:vitalWireRow('vital_meals',{...(following!.previous as Record<string,unknown>),...s,id:local.id,created_at:local.created_at,updated_at:revision===1?local.created_at:preceding!.created_at,revision,deleted_at:null},s);
  const step=validateStep(s,previous,row,preceding??null);if(operations.has(step.operationId))fail('Operação duplicada na cadeia.');operations.add(step.operationId);
  if(!row.deleted_at){const snap=row.nutrition_f2!.operation_id;if(snapshotOps.has(snap))fail('Operação nutricional histórica reutilizada.');snapshotOps.add(snap);}
  steps.push(step);previous=row;
 }
 return steps;
}
export interface ExistingRpcClient{rpc(name:string,args:Record<string,unknown>):PromiseLike<{data:unknown;error:{code?:string}|null}>;}
export const INTEGRATED_MEAL_REVIEW='vault-vital-f2-integrated-meal-review-v1' as const;
export type F2Capability={protocol:'vault-vital-f2-meal-v1';baseline:string;enabled:boolean;integratedMealReview?:typeof INTEGRATED_MEAL_REVIEW};
/** Basic v1 remains restricted. The separately reviewed extension requires the same pinned
 * release capability and the server recomputation from SQL 09, 11 and 12. Catalogs remain OFF.
 * No fall-back or direct DML: a rejected RPC must preserve the original queue. */
export function assertMealStepSupported(step:MealStep,cap?:F2Capability){
 const integrated=cap?.enabled===true&&cap.protocol==='vault-vital-f2-meal-v1'&&cap.integratedMealReview===INTEGRATED_MEAL_REVIEW;
 const compositions=[step.meal.nutrition_f2,(step.audit?.previous as {nutrition_f2?:F2Envelope}|undefined)?.nutrition_f2].flatMap(env=>Object.values(env?.items??{}).map(i=>i.payload.composition));
 for(const c of compositions){
  if(c.source.provider==='recipe'){if(!integrated)fail('Consumo de receita exige revisão remota compatível; fila preservada.');continue;}
  if(c.source.provider==='health_connect'){if(!integrated)fail('Total Health Connect exige revisão remota compatível; fila preservada.');continue;}
  if(!['manual','label'].includes(c.source.provider))fail('Fonte de catálogo não homologada no RPC; fila preservada.');
  if((c.labelEvidence!==undefined||c.source.license==='private-user-label')&&!integrated)fail('Evidência OCR exige revisão remota compatível; fila preservada.');
 }
}
/** Validate each planned step, including device-independent external identity, before any mutation. */
export async function preflightMealStep(step:MealStep,cap:F2Capability){
 assertMealStepSupported(step,cap);
 const current=vitalWireRow('vital_meals',step.meal,step.scope);
 if(step.audit)validateAudit(step.audit,step.scope,current.id);
 const external=(env:F2Envelope|null|undefined)=>Object.values(env?.items??{}).some(i=>i.payload.composition.source.provider==='health_connect');
 const before=external((step.audit?.previous as {nutrition_f2?:F2Envelope}|undefined)?.nutrition_f2),after=external(current.nutrition_f2);
 if(before&&!after||step.expectedRevision!==null&&!before&&after)fail('Transição de total externo incompatível; fila preservada.');
 if(after)await verifyRemoteExternalRow(step.scope,current);
}
/** Full-chain validation with original base; no partial upload of a known invalid suffix. */
export async function preflightMealChain(base:MealRow|null,steps:readonly MealStep[],cap:F2Capability){
 let previous=base;
 for(const step of steps){
  await preflightMealStep(step,cap);
  if(externalEvidenceOf(step.meal))await verifyRemoteExternalTransition(step.scope,previous,step.meal);
  previous=step.meal;
 }
}
/** Proof adapter only. Feature config and authenticated server capability must both be confirmed by cumulative release. */
export async function submitMealStep(client:ExistingRpcClient,activeScope:()=>Promise<Scope|null>,cap:F2Capability,approvedBaseline:string,step:MealStep){
 if(!cap.enabled||cap.protocol!=='vault-vital-f2-meal-v1'||!/^[a-f0-9]{40}$/.test(approvedBaseline)||cap.baseline!==approvedBaseline)fail('Transporte F2 não habilitado para esta baseline.');
 const s=requireScope(step.scope);if(!own(await activeScope(),s))fail('Sessão de sincronização mudou.');
 const meal=vitalWireRow('vital_meals',step.meal,s);if(!meal.nutrition_f2||!Number.isSafeInteger(meal.revision)||meal.revision!==(step.expectedRevision??0)+1)fail('Revisão F2 inválida.');
 const audit=step.audit?validateAudit(step.audit,s,meal.id):null;
 if(step.operationId!==(audit?.id??meal.nutrition_f2!.operation_id)||step.expectedRevision===null&&audit!==null||step.expectedRevision!==null&&(!audit||audit.previous_revision!==step.expectedRevision))fail('Identidade da operação incompatível.');
 await preflightMealStep(step,cap);
 if(!own(await activeScope(),s))fail('Sessão mudou antes do envio; manter fila.');
 const result=await client.rpc('vault_vital_meal_f2_review',{p_person:s.person_id,p_operation:step.operationId,p_expected:step.expectedRevision,p_row:vitalPayload('vital_meals',meal,s),p_audit:audit?vitalPayload('vital_audit',audit,s):null});
 if(!own(await activeScope(),s))fail('Sessão mudou durante o envio; manter fila.');if(result.error)fail(`Envio F2 não confirmado (${result.error!.code??'remote'}).`);
 if(!result.data||typeof result.data!=='object'||Array.isArray(result.data))fail('Recibo remoto inválido.');const ack=result.data as Record<string,unknown>;
 if(!['applied','retry'].includes(String(ack.status))||ack.operation_id!==step.operationId)fail('Operação remota não confirmada.');
 const saved=vitalWireRow('vital_meals',ack.meal,s);const fingerprint=await vitalFingerprint('vital_meals',saved,s);if(fingerprint!==await vitalFingerprint('vital_meals',meal,s))fail('Recibo não confirma refeição enviada.');
 let auditFingerprint:string|null=null;if(audit){const a=vitalWireRow('vital_audit',ack.audit,s);auditFingerprint=await vitalFingerprint('vital_audit',a,s);if(auditFingerprint!==await vitalFingerprint('vital_audit',audit,s))fail('Recibo não confirma auditoria.');}else if(ack.audit!==null)fail('Auditoria inesperada.');
 return {scope:s,operationId:step.operationId,mealId:meal.id,revision:meal.revision,fingerprint,auditId:audit?.id??null,auditFingerprint};
}
