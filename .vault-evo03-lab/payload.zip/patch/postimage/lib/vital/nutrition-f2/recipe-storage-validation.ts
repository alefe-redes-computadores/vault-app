/** Recompute immutable recipe versions on wire/backup/restore. No catalog requery or current
 * license approval can rewrite historical ingredients. New writes remain separately gated. */
import { reviewedSnapshot, type Snapshot } from './nutrition';
import { requireScope, requireId, instant, fail, text } from '../validation';
const stable=(v:unknown):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
export function validateStoredRecipeVersion(r:Record<string,unknown>){
 const s=requireScope({user_id:requireId(r.user_id),person_id:requireId(r.person_id)});requireId(r.recipe_id);if(r.id===r.recipe_id||r.revision!==1||r.deleted_at!==null||r.updated_at!==r.created_at||!Number.isSafeInteger(r.version)||Number(r.version)<1||Number(r.version)>2147483647)fail('Versão de receita inválida ou mutável.');
 if(typeof r.name_snapshot!=='string'||text(r.name_snapshot,160,true)!==r.name_snapshot)fail('Nome histórico inválido.');
 const reviewed=instant(r.reviewed_at);if(typeof r.reviewed_at!=='string'||reviewed!==r.reviewed_at||reviewed===null||reviewed>String(r.created_at))fail('Instante de revisão inválido.');
 for(const k of ['raw_edible_mass_g','finished_mass_g','servings'])if(r[k]!==null&&(typeof r[k]!=='number'||!Number.isFinite(r[k])||Number(r[k])<=0||Number(r[k])>1e6))fail('Rendimento inválido.');
 if(r.yield_evidence!==null&&(typeof r.yield_evidence!=='string'||text(r.yield_evidence,500,true)!==r.yield_evidence))fail('Evidência de rendimento inválida.');
 if((r.finished_mass_g!==null||r.servings!==null)&&!r.yield_evidence)fail('Rendimento sem evidência.');
 if(r.retention_evidence!==null)fail('Retenção de cocção não autorizada.');
 if(!Array.isArray(r.ingredients)||r.ingredients.length<1||r.ingredients.length>200)fail('Ingredientes inválidos.');
 const ids=new Set<string>();for(const raw of r.ingredients as Snapshot[]){if(!raw||typeof raw!=='object'||!raw.scope||raw.scope.user_id!==s.user_id||raw.scope.person_id!==s.person_id)fail('Ingrediente fora do escopo.');if(raw.composition?.source?.provider==='recipe'||raw.composition?.recipeVersion!==undefined)fail('Receita aninhada não habilitada.');const id=requireId(raw.itemId);if(ids.has(id))fail('Ingrediente duplicado.');ids.add(id);const checked=reviewedSnapshot(s,id,raw.composition,raw.consumed,r.reviewed_at);if(checked.conversion.status!=='resolved'||stable(checked.payload)!==stable(raw))fail('Composição de receita divergente.');}
}
