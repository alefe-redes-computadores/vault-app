import type {MealRow,Scope,VitalRecipeRow,VitalRecipeVersionRow} from '../model';
import {own,requireId,requireScope,instant} from '../validation';
import {reviewedSnapshot,decimalBR,coverageDetailed,type Snapshot,type Quantity} from './nutrition';
import {mealProfiles,type LegacyItem} from './persistence';
import {recipeVersionEvidence,recipeVersionComposition} from './recipe-consumption';
export type IngredientRef=({mealId:string;versionId?:never}|{versionId:string;mealId?:never})&{itemId:string};
export function ingredientRefKey(x:IngredientRef){if((x.mealId===undefined)===(x.versionId===undefined))throw Error('Origem do ingrediente inválida.');return `${x.versionId?'version':'meal'}:${requireId(x.versionId??x.mealId)}:${requireId(x.itemId)}`;}
export type IngredientChoice=IngredientRef&{composition:Snapshot['composition'];quantity:Quantity};
/** Reuse only confirmed scoped canonical ingredients. Nested recipes and external licenses remain gated. */
export function recipeIngredientChoices(scope:Scope,rows:readonly MealRow[],source?:VitalRecipeVersionRow):IngredientChoice[]{
 const s=requireScope(scope),visible=rows.filter(m=>own(m,s)&&!m.deleted_at&&m.nutrition_f2),out:IngredientChoice[]=[];
 if(new Set(visible.map(m=>m.id)).size!==visible.length)throw Error('Refeição duplicada');
 for(const m of visible){mealProfiles(s,m.items as LegacyItem[],m.nutrition_f2!);for(const r of Object.values(m.nutrition_f2!.items)){if(['manual','label'].includes(r.payload.composition.source.provider))out.push({mealId:m.id,itemId:r.payload.itemId,composition:structuredClone(r.payload.composition),quantity:structuredClone(r.payload.consumed)});}}
 if(source){const v=recipeVersionEvidence(source);recipeVersionComposition(s,v);for(const i of v.ingredients){if(!['manual','label'].includes(i.composition.source.provider))throw Error('Fonte histórica ainda não autorizada para nova versão.');out.push({versionId:v.id,itemId:i.itemId,composition:structuredClone(i.composition),quantity:structuredClone(i.consumed)});}}
 return out;
}
export type RecipeForm={name:string;kind:'recipe'|'meal_template';favorite:boolean;finishedMass:string;servings:string;rawMass:string;yieldEvidence:string;ingredients:readonly (IngredientRef&{ingredientId:string;quantity:Quantity;reviewed:boolean})[]};
export function prepareRecipeForm(scope:Scope,rows:readonly MealRow[],form:RecipeForm,at:string,source?:VitalRecipeVersionRow){
 const s=requireScope(scope),choices=recipeIngredientChoices(s,rows,source),name=form.name.trim(),seen=new Set<string>();if(!name||name.length>160||!['recipe','meal_template'].includes(form.kind)||typeof form.favorite!=='boolean'||form.ingredients.length<1||form.ingredients.length>200)throw Error('Revise o nome e os ingredientes');
 function optional(raw:string){if(!raw.trim())return null;const v=decimalBR(raw);if(v===null||v<=0||v>1e6)throw Error('Rendimento inválido');return v;}
 const finished_mass_g=optional(form.finishedMass),servings=optional(form.servings),raw_edible_mass_g=optional(form.rawMass),yield_evidence=form.yieldEvidence.trim()||null;
 if(finished_mass_g===null&&servings===null||!yield_evidence||yield_evidence.length>500)throw Error('Informe rendimento final ou porções e sua evidência');
 const ingredients=form.ingredients.map(i=>{const id=requireId(i.ingredientId);if(!i.reviewed||seen.has(id))throw Error('Revise cada ingrediente');seen.add(id);const c=choices.find(x=>ingredientRefKey(x)===ingredientRefKey(i));if(!c)throw Error('Ingrediente histórico indisponível');const snap=reviewedSnapshot(s,id,c.composition,i.quantity,at);if(snap.conversion.status!=='resolved')throw Error('Unidade de ingrediente incompatível');return snap.payload;});
 return {root:{name,kind:form.kind,favorite:form.favorite,active:true} satisfies Omit<VitalRecipeRow,keyof import('../model').Row>,version:{ingredients,raw_edible_mass_g,finished_mass_g,servings,yield_evidence,reviewed_at:at} satisfies Omit<VitalRecipeVersionRow,keyof import('../model').Row|'version'|'name_snapshot'|'recipe_id'|'retention_evidence'>};
}

/** Local-only draft. Do not turn incomplete quantities or historical references into clinical facts. */
export type RecipeDraftPayload={headId:string;versionId:string;previousVersionId:string|null;copySourceVersionId?:string;at:string;form:RecipeForm;raw:Record<string,string>};
export function restoreRecipeDraft(value:unknown):RecipeDraftPayload{
 const object=(v:unknown)=>{if(!v||typeof v!=='object'||Array.isArray(v))throw Error('Rascunho de receita inválido.');return v as Record<string,unknown>;};
 const str=(v:unknown,max:number)=>{if(typeof v!=='string'||v.length>max)throw Error('Campo do rascunho inválido.');return v;};
 const o=object(value),f=object(o.form),raw=object(o.raw),headId=requireId(o.headId),versionId=requireId(o.versionId),previousVersionId=o.previousVersionId===null?null:requireId(o.previousVersionId),at=instant(o.at),copySourceVersionId=o.copySourceVersionId===undefined?undefined:requireId(o.copySourceVersionId);
 if(!at||copySourceVersionId!==undefined&&(previousVersionId!==null||copySourceVersionId===headId||copySourceVersionId===versionId)||headId===versionId||versionId===previousVersionId||headId===previousVersionId||!Array.isArray(f.ingredients)||f.ingredients.length>200||typeof f.favorite!=='boolean'||(f.kind!=='recipe'&&f.kind!=='meal_template'))throw Error('Identidade do rascunho inválida.');
 const seen=new Set<string>(),inputs:Record<string,string>={};
 const ingredients:RecipeForm['ingredients']=f.ingredients.map(v=>{const i=object(v),q=object(i.quantity),ingredientId=requireId(i.ingredientId),unit=q.unit;
  if(seen.has(ingredientId)||typeof i.reviewed!=='boolean'||typeof unit!=='string'||!['g','mg','ug','kg','mL','L','kcal','kJ','portion','unit'].includes(unit)||typeof q.value!=='number'||!Number.isFinite(q.value)||q.value<0)throw Error('Ingrediente do rascunho inválido.');
  const input=str(raw[ingredientId],80);if((decimalBR(input)??0)!==q.value||i.reviewed&&q.value<=0)throw Error('Quantidade do rascunho incompatível.');seen.add(ingredientId);inputs[ingredientId]=input;
  if((i.mealId===undefined)===(i.versionId===undefined))throw Error('Origem do ingrediente inválida.');const ref:IngredientRef=i.versionId===undefined?{mealId:requireId(i.mealId),itemId:requireId(i.itemId)}:{versionId:requireId(i.versionId),itemId:requireId(i.itemId)};if(ref.versionId&&ref.versionId!==(previousVersionId??copySourceVersionId))throw Error('Versão de origem divergente.');return {...ref,ingredientId,quantity:{value:q.value,unit:unit as Quantity['unit']},reviewed:i.reviewed};});
 return {headId,versionId,previousVersionId,...(copySourceVersionId?{copySourceVersionId}:{}),at,raw:inputs,form:{name:str(f.name,160),kind:f.kind,favorite:f.favorite,finishedMass:str(f.finishedMass,80),servings:str(f.servings,80),rawMass:str(f.rawMass,80),yieldEvidence:str(f.yieldEvidence,500),ingredients}};
}
/** Verify recovered draft against the current canonical recipe head before editing. Never rebase a stale draft silently. */
export function recipeDraftRecoveryTarget(scope:Scope,record:{id:string;expected_revision:number|null},draft:RecipeDraftPayload,heads:readonly VitalRecipeRow[],versions:readonly VitalRecipeVersionRow[]){
 const s=requireScope(scope);if(record.id!==draft.versionId)throw Error('Identidade do rascunho incompatível.');
 const scopedHeads=heads.filter(x=>own(x,s)),scopedVersions=versions.filter(x=>own(x,s));
 if(scopedVersions.some(x=>x.id===draft.versionId))throw Error('Esta versão já foi registrada. O rascunho não será reenviado.');
 const matching=scopedHeads.filter(h=>h.id===draft.headId);if(matching.length>1)throw Error('Receita inconsistente.');const head=matching[0];
 if(draft.previousVersionId===null){if(record.expected_revision!==null||head||scopedVersions.some(v=>v.recipe_id===draft.headId))throw Error('Receita mudou. Rascunho preservado.');return null;}
 const vs=scopedVersions.filter(v=>v.recipe_id===draft.headId&&!v.deleted_at).sort((a,b)=>b.version-a.version),latest=vs[0];
 if(!head||head.deleted_at||!head.active||head.revision!==record.expected_revision||!latest||latest.id!==draft.previousVersionId||!vs.every((v,i)=>v.version===vs.length-i)||head.name!==draft.form.name||head.kind!==draft.form.kind||head.favorite!==draft.form.favorite)throw Error('Receita mudou. Rascunho preservado; confira o histórico.');
 return {head,latest};
}

/** Read-only pre-save preview: only reviewed ingredients and canonical totals. No retention or intake claim. */
export function recipeFormPreview(scope:Scope,rows:readonly MealRow[],form:RecipeForm,at:string,source?:VitalRecipeVersionRow){
 const p=prepareRecipeForm(scope,rows,form,at,source),profiles=p.version.ingredients.map(i=>i.totals);
 return (['energy_kcal','protein_g','carbohydrate_g','fat_g','fiber_g'] as const).map(key=>({key,...coverageDetailed(key,profiles)}));
}

/** New IDs and explicit reconfirmation. Never copy historical fact or commit a recipe here. */
export function recipeFormFromVersion(scope:Scope,head:VitalRecipeRow,version:VitalRecipeVersionRow,mode:'version'|'copy',newId:()=>string){
 const s=requireScope(scope);if(!own(head,s)||!head.active||head.deleted_at||version.recipe_id!==head.id)throw Error('Receita de origem indisponível.');
 const choices=recipeIngredientChoices(s,[],version),seen=new Set<string>();
 const raw:Record<string,string>={};const decimal=(n:number|null)=>{if(n===null)return '';const text=n.toLocaleString('en-US',{useGrouping:false,maximumSignificantDigits:21}).replace('.',',');if(text.length>80||decimalBR(text)!==n)throw Error('Quantidade histórica não representável.');return text;};
 const ingredients=choices.map(c=>{const ingredientId=requireId(newId());if(seen.has(ingredientId)||version.ingredients.some(i=>i.itemId===ingredientId))throw Error('Nova identidade de ingrediente inválida.');seen.add(ingredientId);raw[ingredientId]=decimal(c.quantity.value);return {versionId:version.id,itemId:c.itemId,ingredientId,quantity:structuredClone(c.quantity),reviewed:false};});
 const form:RecipeForm={name:mode==='copy'?`${head.name.slice(0,152)} (cópia)`:head.name,kind:head.kind,favorite:mode==='copy'?false:head.favorite,rawMass:decimal(version.raw_edible_mass_g),finishedMass:decimal(version.finished_mass_g),servings:decimal(version.servings),yieldEvidence:'',ingredients};return {form,raw};
}
/** Copy recovery requires the exact immutable source and active scoped recipe; no latest-version substitution. */
export function recipeDraftCopySource(scope:Scope,draft:RecipeDraftPayload,heads:readonly VitalRecipeRow[],versions:readonly VitalRecipeVersionRow[]){
 if(!draft.copySourceVersionId)return undefined;
 const s=requireScope(scope),vs=versions.filter(v=>own(v,s)&&v.id===draft.copySourceVersionId);if(vs.length!==1)throw Error('Versão de origem da cópia indisponível.');const version=vs[0],hs=heads.filter(h=>own(h,s)&&h.id===version.recipe_id&&h.active&&!h.deleted_at);if(hs.length!==1)throw Error('Receita de origem da cópia indisponível.');recipeIngredientChoices(s,[],version);return {head:hs[0],version};
}
