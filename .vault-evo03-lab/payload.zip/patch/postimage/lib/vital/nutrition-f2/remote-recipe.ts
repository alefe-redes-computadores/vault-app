import {assertCatalogComposition,officialCatalog,type CatalogAuthority} from './catalog-authority';
/** Review-only recipe RPC contract. No generic row upsert or queue removal here. */
import type {Scope,VitalRecipeRow,VitalRecipeVersionRow,VitalAudit} from '../model';
import {vitalWireRow,vitalPayload,vitalFingerprint,VitalSyncConflict} from '../cloud-transport';
import {own,requireId,requireScope} from '../validation';
import {reviewedSnapshot} from './nutrition';
import {LEGACY_KEYS} from './persistence';
import {INTEGRATED_MEAL_REVIEW,type ExistingRpcClient} from './remote-meal';
export type RecipeCapability={protocol:'vault-vital-f2-recipe-v1';baseline:string;enabled:boolean;integratedMealReview?:typeof INTEGRATED_MEAL_REVIEW;catalogAuthority?:CatalogAuthority};
const must=(ok:unknown,m:string):void=>{if(!ok)throw new VitalSyncConflict(m)};
const stable=(x:unknown)=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const same=(a:unknown,b:unknown)=>stable(a)===stable(b);
export type RecipeStep={scope:Scope;head:VitalRecipeRow;version:VitalRecipeVersionRow|null;audit:VitalAudit|null;expectedHead:number|null;expectedLatest:string|null;operationId:string};
function metadata(h:VitalRecipeRow){const {id,user_id,person_id,created_at,updated_at,deleted_at,revision,synced,...data}=h;return data;}
/** No independent authority: all rows must come from the canonical repository. */
export function recipeRequest(raw:RecipeStep,cap?:RecipeCapability){
 const integrated=cap?.enabled===true&&cap.protocol==='vault-vital-f2-recipe-v1'&&cap.integratedMealReview===INTEGRATED_MEAL_REVIEW;
 const s=requireScope(raw.scope),h=vitalWireRow('vital_recipes',raw.head,s),v=raw.version?vitalWireRow('vital_recipe_versions',raw.version,s):null,a=raw.audit?vitalWireRow('vital_audit',raw.audit,s):null;
 const op=requireId(raw.operationId),latest=raw.expectedLatest===null?null:requireId(raw.expectedLatest);must(raw.expectedHead===null||Number.isSafeInteger(raw.expectedHead)&&raw.expectedHead>0,'Revisão base inválida.');
 must(!!v!==!!a,'Exatamente uma versão ou auditoria é obrigatória.');
 if(v){must(v.id===op&&v.recipe_id===h.id&&v.name_snapshot===h.name&&h.active&&!h.deleted_at,'Vínculo da versão inválido.');
  if(raw.expectedHead===null)must(h.revision===1&&h.updated_at===h.created_at&&v.version===1&&latest===null,'Criação exige primeira versão.');
  else must(h.revision===raw.expectedHead&&v.version>1&&latest!==null&&latest!==v.id,'Versão exige base explícita.');
 }else{must(raw.expectedHead!==null&&h.revision===(raw.expectedHead??0)+1&&latest!==null&&a!.id===op&&a!.target_table==='vital_recipes'&&a!.target_id===h.id&&a!.previous_revision===raw.expectedHead&&a!.created_at===h.updated_at&&a!.updated_at===h.updated_at&&a!.revision===1&&a!.deleted_at===null,'Auditoria da receita inválida.');
  must((a!.previous as {kind?:unknown}).kind===h.kind&&(!h.deleted_at||h.deleted_at===h.updated_at&&same(a!.previous,metadata(h))),'Arquivamento não pode alterar metadados.');}
 const proofs=v?.ingredients.map(i=>{const c=i.composition,official=officialCatalog(c);if(official){must(integrated&&cap?.catalogAuthority,'Fonte exige revisão remota adicional.');assertCatalogComposition(cap?.catalogAuthority,c,i.consumed);}else must(['manual','label'].includes(c.source.provider)&&(integrated||!c.labelEvidence&&c.source.license!=='private-user-label'),'Fonte exige revisão remota adicional.');const r=reviewedSnapshot(s,i.itemId,c,i.consumed,v.reviewed_at);must(r.conversion.status==='resolved'&&same(r.payload,i),'Ingrediente divergente.');const nutrients:Record<string,number>={};if(!official)for(const k of LEGACY_KEYS){const n=i.totals[k];if(n?.state==='known'&&n.amount<=1e6)nutrients[k]=n.amount;else if(n?.state==='declared_zero')nutrients[k]=0;}
  return {item:{id:i.itemId,food_id:null,name:c.name.trim(),quantity:i.consumed.value,unit:i.consumed.unit,nutrients,nutrient_source:Object.keys(nutrients).length?(c.source.provider==='label'?'label':'declared'):null},snapshot:{...r,identity:{provider:c.source.provider,recordId:c.source.recordId,version:c.source.version,preparation:c.preparation,presentationId:official?'catalog-100g':i.itemId},food_id:null}};
 })??[];
 return {p_person:s.person_id,p_operation:op,p_expected_head:raw.expectedHead,p_expected_latest:latest,p_head:vitalPayload('vital_recipes',h,s),p_version:v?vitalPayload('vital_recipe_versions',v,s):null,p_audit:a?vitalPayload('vital_audit',a,s):null,p_proofs:proofs};
}
export async function submitRecipeStep(client:ExistingRpcClient,activeScope:()=>Promise<Scope|null>,cap:RecipeCapability,approvedBaseline:string,step:RecipeStep){
 must(cap.enabled&&cap.protocol==='vault-vital-f2-recipe-v1'&&/^[a-f0-9]{40}$/.test(approvedBaseline)&&cap.baseline===approvedBaseline,'Transporte de receita não habilitado.');const s=requireScope(step.scope),req=recipeRequest(step,cap);must(own(await activeScope(),s),'Sessão mudou.');const response=await client.rpc('vault_vital_recipe_f2_review',req);must(own(await activeScope(),s),'Sessão mudou durante envio; preservar fila.');must(!response.error&&response.data&&typeof response.data==='object'&&!Array.isArray(response.data),'Receita não confirmada.');const a=response.data as Record<string,unknown>;must(['applied','retry'].includes(String(a.status))&&a.operation_id===step.operationId,'Recibo de receita inválido.');
 const head=vitalWireRow('vital_recipes',a.head,s);const fingerprint=await vitalFingerprint('vital_recipes',head,s);must(fingerprint===await vitalFingerprint('vital_recipes',step.head,s),'Recibo não confirma receita.');
 let versionFingerprint:string|null=null,auditFingerprint:string|null=null;
 if(step.version){const v=vitalWireRow('vital_recipe_versions',a.version,s);versionFingerprint=await vitalFingerprint('vital_recipe_versions',v,s);must(versionFingerprint===await vitalFingerprint('vital_recipe_versions',step.version,s)&&a.audit===null,'Recibo não confirma versão.');}else{const audit=vitalWireRow('vital_audit',a.audit,s);auditFingerprint=await vitalFingerprint('vital_audit',audit,s);must(auditFingerprint===await vitalFingerprint('vital_audit',step.audit!,s)&&a.version===null,'Recibo não confirma auditoria.');}
 return {scope:s,operationId:step.operationId,headId:head.id,headRevision:head.revision,fingerprint,versionId:step.version?.id??null,versionFingerprint,auditId:step.audit?.id??null,auditFingerprint};
}
