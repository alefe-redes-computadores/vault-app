import type {MealRow,NutritionCheckin,NutritionPlan,NutritionPlanVersion,Scope,WorkoutRow} from '../model';
import {civil,own,requireScope} from '../validation';
import {activePlanVersions} from '../projections';
import {nutritionDayF2,nutritionDayProfiles} from './meal-history';
import {coverageDetailed,targetProgress,UNITS,type Nutrient} from './nutrition';
import {EXTRA_TARGET_KEYS,validateExtraTargets,extraTargetComparison} from './plan-targets';

const CORE=['energy_kcal','protein_g','carbohydrate_g','fat_g','fiber_g'] as const;
export const NUTRIENT_LABELS:Readonly<Record<Nutrient,string>>={energy_kcal:'Energia',protein_g:'Proteínas',carbohydrate_g:'Carboidratos',fat_g:'Gorduras',fiber_g:'Fibras',sugar_g:'Açúcares totais',added_sugar_g:'Açúcares adicionados',saturated_fat_g:'Gorduras saturadas',trans_fat_g:'Gorduras trans',sodium_mg:'Sódio',calcium_mg:'Cálcio',iron_mg:'Ferro',potassium_mg:'Potássio',magnesium_mg:'Magnésio',vitamin_c_mg:'Vitamina C',vitamin_b12_ug:'Vitamina B12',vitamin_d_ug:'Vitamina D',vitamin_k_ug:'Vitamina K',folate_ug:'Folato',selenium_ug:'Selênio',zinc_mg:'Zinco',phosphorus_mg:'Fósforo',vitamin_a_rae_ug:'Vitamina A (RAE)',vitamin_e_mg:'Vitamina E',vitamin_b6_mg:'Vitamina B6',thiamin_mg:'Tiamina',riboflavin_mg:'Riboflavina',niacin_mg:'Niacina'};
const KEYS=Object.keys(UNITS) as Nutrient[];
const format=(n:number)=>n.toLocaleString('pt-BR',{maximumFractionDigits:3});
const unit=(k:Nutrient)=>UNITS[k]==='ug'?'µg':UNITS[k];
/** For detailed, explicitly selected clinical evidence only; do not send to analytics. */
export function mealClinicalNutrition(scope:Scope,meal:MealRow){
 const s=requireScope(scope);if(!own(meal,s)||meal.deleted_at||!meal.nutrition_f2)throw Error('Refeição detalhada indisponível.');
 const p=nutritionDayF2(s,meal.day,[meal],[]);const sourceNames={manual:'declarada',label:'rótulo revisado',recipe:'receita calculada',usda:'USDA',taco:'TACO',off:'Open Food Facts',tbca:'TBCA',health_connect:'Health Connect · total externo'};
 const providers=[...new Set(Object.values(meal.nutrition_f2.items).map(x=>sourceNames[x.payload.composition.source.provider]))];
 const known=KEYS.flatMap(k=>{const c=p.coverage[k];if(c.amount===null&&c.estimatedSubtotal===null)return [];const parts=[c.amount===null?null:`${format(c.amount)} ${unit(k)} (${c.complete?'cobertura completa dos itens aplicáveis':'subtotal conhecido'})`,c.estimatedSubtotal===null?null:`${format(c.estimatedSubtotal)} ${unit(k)} estimados`].filter(Boolean);return [`${NUTRIENT_LABELS[k]}: ${parts.join(' + ')}; ${c.known}/${c.total-c.notApplicable} itens conhecidos, ${c.counts.estimated} estimados`];});
 return {source:'vital_meal_reviewed_f2' as const,detail:[`Composição histórica revisada (${providers.join(', ')})`,`${p.recordedItems} itens registrados`,known.length?'Cobertura limitada aos itens registrados; não representa toda a ingestão.':'Sem valores nutricionais quantificados; não significa zero.',...known].join(' | ')};
}
/** Comparison with the single active EXISTING plan. No targets inferred, no automatic prescription. */
export function nutritionPlanComparison(scope:Scope,day:string,meals:readonly MealRow[],checkins:readonly NutritionCheckin[],plans:readonly NutritionPlan[],versions:readonly NutritionPlanVersion[]){
 const s=requireScope(scope);civil(day);const daily=nutritionDayF2(s,day,meals,checkins);
 const candidates=activePlanVersions(s,day,plans,versions);const active=candidates.filter(x=>x.active);const conflict=candidates.some(x=>x.conflict)||active.length>1;
 const version=conflict||active.length!==1?null:active[0].version;
 const targets=CORE.flatMap(key=>{const target=version?.targets[key];if(typeof target!=='number'||!Number.isFinite(target)||target<=0)return [];const c=daily.coverage[key];return [{key,label:NUTRIENT_LABELS[key],unit:unit(key),target,known:c.amount,estimated:c.estimatedSubtotal,knownItems:c.known,applicableItems:c.total-c.notApplicable,percent:targetProgress(c,target),coverage:c.complete?'recorded_complete' as const:'incomplete' as const}];});
 const extra=version?.targets_f2!=null?validateExtraTargets(version.targets_f2):{};
 const extraTargets=EXTRA_TARGET_KEYS.flatMap(key=>{const target=extra[key];if(!target)return [];const c=daily.coverage[key];return [{key,label:NUTRIENT_LABELS[key],unit:unit(key),target:target.amount,kind:target.kind,...extraTargetComparison(target,c),knownItems:c.known,applicableItems:c.total-c.notApplicable}];});
 return {extraTargets,plan:version?{id:version.id,name:version.plan_name,version:version.version}:null,state:conflict?'conflict' as const:version?'active' as const:'none' as const,targets,declared:daily.declared,declarationConflict:daily.declarationConflict,recordedItems:daily.recordedItems,scope:'recorded_items_only' as const};
}
type RecordDay={user_id?:string;person_id?:string;data:string;tipo:string;deleted_at?:string|null};
/** Pair only observed civil days; values are never correlated or used to infer deficiencies. */
export function nutritionObservations(scope:Scope,from:string,to:string,meals:readonly MealRow[],workouts:readonly WorkoutRow[],checkins:readonly NutritionCheckin[],records:readonly RecordDay[]){
 const s=requireScope(scope);civil(from);civil(to);const periodDays=(Date.parse(to+'T00:00:00Z')-Date.parse(from+'T00:00:00Z'))/86400000+1;if(periodDays<1||periodDays>366)throw Error('Período inválido.');
 const visible=meals.filter(x=>own(x,s)&&!x.deleted_at&&x.day>=from&&x.day<=to);if(new Set(visible.map(x=>x.id)).size!==visible.length)throw Error('Refeições duplicadas.');
 const days=[...new Set(visible.map(m=>civil(m.day)))];const profiles=days.flatMap(d=>nutritionDayProfiles(s,d,visible));
 const matching=(k:string)=>new Set(records.filter(x=>x.user_id===s.user_id&&x.person_id===s.person_id&&!x.deleted_at&&x.tipo===k&&x.data>=from&&x.data<=to).map(x=>civil(x.data)));
 const training=new Set(workouts.filter(x=>own(x,s)&&!x.deleted_at&&x.status==='completed'&&x.day>=from&&x.day<=to).map(x=>civil(x.day)));
 const energy=new Set(checkins.filter(x=>own(x,s)&&!x.deleted_at&&typeof x.energy==='string'&&x.energy.trim()&&x.day>=from&&x.day<=to).map(x=>civil(x.day)));
 const pair=(r:Set<string>)=>days.filter(x=>r.has(x)).length;
 return {daysWithMeals:days.length,periodDays,items:profiles.length,coverage:Object.fromEntries(CORE.map(k=>[k,coverageDetailed(k,profiles)])) as Record<typeof CORE[number],ReturnType<typeof coverageDetailed>>,pairedDays:{training:pair(training),hydration:pair(matching('agua')),sleep:pair(matching('sono')),weight:pair(matching('peso')),energy:pair(energy)},interpretation:'observational_only' as const};
}
