/** Incomplete label form stored only inside the existing scoped meal_f2 draft.
 * No clinical fact, queue operation, image or implicit OCR permission. */
import {requireId} from '../validation';
import {UNITS,convert,decimalBR,gtin,type Nutrient,type Unit} from './nutrition';
import {labelDraftItem,type LabelField,type LabelObservation} from './label-confirmation';
import {suggestLabelFields,type OcrReview} from './label-suggestions';
import {parseNativeCapture} from './native-capture-contract';
import type {CaptureTicket} from './capture-session';
export type LabelFieldEdit={raw:string;unit:Unit;state:'omit'|LabelField['state'];confirmed:boolean;observed:LabelObservation|null};
export type LabelFormDraft={schema:1;recordId:string;versionId:string;itemId:string;name:string;code:string;basis:'per100'|'portion';base:'g'|'mL';portion:string;quantity:string;fields:Record<Nutrient,LabelFieldEdit>;capture:OcrReview|null};
const keys=Object.keys(UNITS) as Nutrient[];
const units=['g','mg','ug','kcal','kJ'] as readonly Unit[];
function must(x:unknown,message:string):asserts x{if(!x)throw Error(message);}
const exact=(x:unknown,expected:readonly string[]):boolean=>!!x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===expected.length&&expected.every(k=>Object.hasOwn(x,k));
const canon=(x:unknown):string=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const bounded=(x:unknown,n:number):x is string=>typeof x==='string'&&x.length<=n;
export const blankLabelField=(k:Nutrient):LabelFieldEdit=>({raw:'',unit:UNITS[k],state:'omit',confirmed:false,observed:null});
export const blankLabelFields=()=>Object.fromEntries(keys.map(k=>[k,blankLabelField(k)])) as Record<Nutrient,LabelFieldEdit>;
export function validLabelField(f:LabelFieldEdit){const n=decimalBR(f.raw);return f.state!=='omit'&&(f.state==='value'?n!==null&&n<=1e6:!f.raw.trim());}
export function sameLabelFormIdentity(a:LabelFormDraft,b:LabelFormDraft){return a.recordId===b.recordId&&a.versionId===b.versionId&&a.itemId===b.itemId;}
export function restoreLabelFormDraft(raw:unknown):LabelFormDraft{
 must(exact(raw,['schema','recordId','versionId','itemId','name','code','basis','base','portion','quantity','fields','capture']),'Rascunho de rótulo inválido.');const d=raw as LabelFormDraft;
 const ids=[d.recordId,d.versionId,d.itemId];must(d.schema===1&&ids.every(id=>requireId(id)===id)&&new Set(ids).size===3,'Identidade de rótulo inválida.');
 must(bounded(d.name,120)&&bounded(d.code,14)&&bounded(d.portion,80)&&bounded(d.quantity,80)&&['per100','portion'].includes(d.basis)&&['g','mL'].includes(d.base)&&exact(d.fields,keys),'Campos do rascunho inválidos.');
 // A persisted OCR object is admitted only when the editor explicitly provided consented capture.
 // Reuse the same parser solely to validate its bounded shape, not to attest a new native capture.
 let suggestions:ReturnType<typeof suggestLabelFields>['suggestions']=[];
 if(d.capture!==null){const c=d.capture;must(exact(c,['status','text','recognizer','version','imageWidth','imageHeight','tokens','geometry','imageRetention']),'Captura de rascunho inválida.');const t:CaptureTicket={scope:{user_id:d.recordId,person_id:d.versionId},editorId:d.itemId,requestId:'draft-validation',mode:'ocr'};
  const parsed=parseNativeCapture(t,t,{requestId:t.requestId,status:'ocr',text:c.text,recognizer:c.recognizer,version:c.version,imageWidth:c.imageWidth,imageHeight:c.imageHeight,tokens:c.tokens});must(parsed.status==='ocr_review'&&canon(parsed)===canon(c),'Captura de rascunho inválida.');suggestions=suggestLabelFields(c,d.base).suggestions;
 }
 const p=d.basis==='per100'?100:decimalBR(d.portion);
 for(const k of keys){const f=d.fields[k];must(exact(f,['raw','unit','state','confirmed','observed'])&&bounded(f.raw,80)&&units.includes(f.unit)&&convert({value:0,unit:f.unit},UNITS[k])!==null&&['omit','value','unreadable','not_reported'].includes(f.state)&&typeof f.confirmed==='boolean'&&(!f.confirmed||validLabelField(f))&&(f.state==='value'||!f.raw.trim()),'Campo de rótulo inválido.');
  if(f.observed!==null){const o=f.observed;must(d.capture!==null&&exact(o,['raw','unit','column','printedBase','box','confidence'])&&o.column===d.basis&&(o.printedBase===null||o.printedBase===p)&&suggestions.some(s=>s.nutrient===k&&canon({raw:s.raw,unit:s.unit,column:s.column,printedBase:s.printedBase,box:s.box,confidence:s.confidence})===canon(o)),'Observação OCR sem evidência autorizada ou coluna compatível.');}
 }
 return structuredClone(d);
}
/** Still only a draft item. Final meal confirmation remains a separate explicit operation. */
export function prepareLabelForm(raw:unknown,reviewedAt:string){const d=restoreLabelFormDraft(raw),chosen=keys.filter(k=>d.fields[k].state!=='omit'),p=d.basis==='per100'?100:decimalBR(d.portion),n=decimalBR(d.quantity),barcode=d.code.trim()?gtin(d.code):null;
 must(d.name.trim()&&p!==null&&p>0&&p<=1e6&&n!==null&&n>0&&n<=1e6&&chosen.length>0&&chosen.every(k=>d.fields[k].confirmed&&validLabelField(d.fields[k])),'Revise identificação, porção e campos antes de adicionar.');must(!d.code.trim()||barcode,'Confira o código de barras.');
 return labelDraftItem({schema:1,recordId:d.recordId,versionId:d.versionId,reviewedAt,name:d.name.trim(),barcode,basis:d.basis,base:{value:p,unit:d.base},fields:chosen.map(k=>{const f=d.fields[k];return {nutrient:k,raw:f.state==='value'?f.raw:'',unit:f.unit,state:f.state as LabelField['state'],confirmed:true,observed:f.observed};}),capture:d.capture?{recognizer:'mlkit-latin-bundled',version:'16.0.1',originalText:d.capture.text,imageWidth:d.capture.imageWidth,imageHeight:d.capture.imageHeight,retention:'reviewed-text-only'}:null},d.itemId,{value:n,unit:d.base});}
