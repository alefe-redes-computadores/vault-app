import {reviewedSnapshot,type Scope,type Quantity,type Nutrient,type Snapshot} from './nutrition';
import {recipeEvidence} from './recipe-evidence';
import {sourceAllowed,type SourcePolicy} from './catalog';
const uuid=(v:string)=>typeof v==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(v);
const sameScope=(a:Scope,b:Scope)=>a.user_id===b.user_id&&a.person_id===b.person_id;
const stable=(v:unknown):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
function must(v:unknown,m:string):asserts v{if(!v)throw Error(m);}
export type RecipeHead=Scope&{id:string;revision:number;kind:'recipe'|'meal_template';name:string;active:boolean;deleted_at:string|null};
export type RecipeVersion=Scope&{id:string;recipe_id:string;version:number;name_snapshot:string;ingredients:readonly Snapshot[];raw_edible_mass_g:number|null;finished_mass_g:number|null;servings:number|null;yield_evidence:string|null;retention_evidence:null;reviewed_at:string};
const positive=(n:number|null)=>n===null||Number.isFinite(n)&&n>0&&n<=1e6;
/** Pure transaction preparation. Only the existing Vital writer can commit head/version/queue. No retention inferred. */
export function prepareRecipeVersion(scope:Scope,head:RecipeHead,prior:readonly RecipeVersion[],expectedHeadRevision:number,expectedLatestId:string|null,input:Omit<RecipeVersion,keyof Scope|'recipe_id'|'version'|'retention_evidence'>,policies:readonly SourcePolicy[]){
 must(uuid(scope.user_id)&&uuid(scope.person_id)&&sameScope(head,scope)&&uuid(head.id)&&head.active&&!head.deleted_at,'Receita indisponível');
 must(Number.isSafeInteger(head.revision)&&head.revision>=1&&head.revision===expectedHeadRevision,'Revisão da receita mudou');
 must(uuid(input.id)&&input.id!==head.id&&input.name_snapshot.trim()&&input.name_snapshot.trim().length<=160&&input.ingredients.length>=1&&input.ingredients.length<=200,'Versão inválida');
 must(positive(input.raw_edible_mass_g)&&positive(input.finished_mass_g)&&positive(input.servings),'Rendimento inválido');
 must(input.finished_mass_g===null||!!input.yield_evidence?.trim(),'Rendimento sem evidência');
 must(Number.isFinite(Date.parse(input.reviewed_at))&&/T.*(?:Z|[+-]\d\d:\d\d)$/.test(input.reviewed_at),'Revisão inválida');
 const versions=[...prior].sort((a,b)=>a.version-b.version);const seen=new Set<string>();for(let i=0;i<versions.length;i++){const v=versions[i];must(sameScope(v,scope)&&v.recipe_id===head.id&&v.version===i+1&&uuid(v.id)&&!seen.has(v.id),'Histórico de versões inválido');seen.add(v.id);}
 const last=versions.at(-1);const ids=new Set<string>();for(const ingredient of input.ingredients){must(sameScope(ingredient.scope,scope)&&uuid(ingredient.itemId)&&!ids.has(ingredient.itemId),'Ingrediente duplicado/fora do escopo');ids.add(ingredient.itemId);const checked=reviewedSnapshot(scope,ingredient.itemId,ingredient.composition,ingredient.consumed,input.reviewed_at);must(checked.conversion.status==='resolved'&&stable(checked.payload)===stable(ingredient),'Composição divergente');const p=ingredient.composition.source;must(p.provider==='manual'||p.provider==='label'||policies.some(x=>x.provider===p.provider&&x.release===p.version&&sourceAllowed(x,'snapshot')),'Fonte de receita sem autorização');}
 const next={...structuredClone(input),...scope,recipe_id:head.id,version:(last?.version??0)+1,retention_evidence:null};
 if(last?.id===input.id){const retry={...next,version:last.version};must(stable(retry)===stable(last),'Versão imutável');return {status:'retry' as const,version:structuredClone(last)};}
 must(!seen.has(input.id)&&(last?.id??null)===expectedLatestId,'Receita recebeu nova versão');return {status:'new_version' as const,version:next};
}
/** Only explicit declared yield permits mass/serving normalization. No cooking-retention claim. */
export function recipeVersionPortion(v:RecipeVersion,scope:Scope,consumed:Quantity,keys:readonly Nutrient[]){must(sameScope(v,scope),'Receita fora do escopo');const isMass=consumed.unit==='g'||consumed.unit==='kg';const yieldQty:Quantity|null=isMass&&v.finished_mass_g!==null?{value:v.finished_mass_g,unit:'g'}:consumed.unit==='portion'&&v.servings!==null?{value:v.servings,unit:'portion'}:null;return recipeEvidence({id:v.recipe_id,version:v.version,scope,ingredients:v.ingredients,yield:yieldQty},consumed,keys);}
