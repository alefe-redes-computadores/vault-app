/** Candidate extension of the existing Vital queue/ACK transaction. No second outbox.
 * Only invoke after submitMealStep verified ALL remote responses for the exact batch.
 * A partial network batch remains pending; recovery of lost network ACKs is a separate gate.
 */
import type {CanonicalDb,CanonicalTable} from '../storage-dexie';
import type {Scope,MealRow,VitalAudit} from '../model';
import type {VitalQueueItem} from '../queue-finalize';
import {vitalAckId,vitalFingerprint,vitalPayload,vitalWireRow,type VitalAck,VitalSyncConflict} from '../cloud-transport';
import {own,requireScope,requireId} from '../validation';
import {planMealSteps,type MealStep,submitMealStep} from './remote-meal';
type Receipt=Awaited<ReturnType<typeof submitMealStep>>;
type Queue=Omit<CanonicalTable,'where'>&{delete(id:string):PromiseLike<unknown>;where(index:string):{equals(key:string):{toArray():PromiseLike<Record<string,unknown>[]>}}};
const canon=(v:unknown):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
const same=(a:unknown,b:unknown)=>canon(a)===canon(b);
function must(v:unknown,m:string):asserts v {if(!v)throw new VitalSyncConflict(m);}
type Entry={table:'vital_meals'|'vital_audit';row:MealRow|VitalAudit;queue:VitalQueueItem;fingerprint:string};
/** Explicitly consumes the existing queue entries only if the persisted final revision and
 * every audit match. New local edits, duplicate queue keys, missing ACKs, or changed person
 * cause no deletion. Crypto is intentionally outside IndexedDB's transaction lifetime. */
export async function finalizeMealBatchF2(deps:{db:CanonicalDb;authenticatedUser:()=>Promise<string|null>;activeScope:()=>Scope|null},input:{scope:Scope;base:MealRow|null;baseAck:{revision:number;fingerprint:string}|null;steps:readonly MealStep[];receipts:readonly Receipt[];mealQueue:VitalQueueItem;auditQueues:readonly VitalQueueItem[]}):Promise<'confirmed'|'preserve_local'>{
 input=structuredClone(input); // Seal caller-owned objects before any asynchronous work.
 const s=requireScope(input.scope);const active=()=>own(deps.activeScope(),s);
 must(await deps.authenticatedUser()===s.user_id&&active(),'Conta ou pessoa ativa mudou.');
 must(input.steps.length>=1&&input.steps.length<=200&&input.receipts.length===input.steps.length,'Lote sem confirmação completa.');
 const final=vitalWireRow('vital_meals',input.steps.at(-1)!.meal,s);
 const audits=input.steps.flatMap(x=>x.audit?[x.audit]:[]);
 const planned=await planMealSteps(s,final,input.base,input.baseAck,audits);
 must(same(planned,input.steps),'Plano de revisões divergente.');
 must(input.auditQueues.length===audits.length,'Fila de auditorias incompleta.');
 const finalFingerprint=await vitalFingerprint('vital_meals',final,s);
 const entries:Entry[]=[{table:'vital_meals',row:final,queue:input.mealQueue,fingerprint:finalFingerprint}];
 for(let i=0;i<planned.length;i++){
  const step=planned[i],receipt=input.receipts[i];
  must(own(receipt.scope,s)&&receipt.operationId===step.operationId&&receipt.mealId===final.id&&receipt.revision===step.meal.revision&&receipt.fingerprint===await vitalFingerprint('vital_meals',step.meal,s),'Recibo da refeição divergente.');
  if(step.audit){const audit=vitalWireRow('vital_audit',step.audit,s),fingerprint=await vitalFingerprint('vital_audit',audit,s);
   must(receipt.auditId===audit.id&&receipt.auditFingerprint===fingerprint,'Recibo da auditoria divergente.');
   const matches=input.auditQueues.filter(q=>q.payload.id===audit.id);must(matches.length===1,'Fila da auditoria divergente.');entries.push({table:'vital_audit',row:audit,queue:matches[0],fingerprint});
  }else must(receipt.auditId===null&&receipt.auditFingerprint===null,'Auditoria remota inesperada.');
 }
 const ids=new Set<string>();
 for(const e of entries){const q=e.queue;const id=requireId(q.id);must(!ids.has(id)&&q.table===e.table&&q.chave===`${e.table}:${e.row.id}`&&['add','update'].includes(q.operation),'Identidade de fila inválida.');ids.add(id);
  must(same(vitalPayload(e.table,vitalWireRow(e.table,q.payload,s),s),vitalPayload(e.table,e.row,s)),'Fila enviada não corresponde ao recibo.');}
 must(await deps.authenticatedUser()===s.user_id&&active(),'Conta ou pessoa ativa mudou.');
 const db=deps.db,persons=db.table('persons'),meals=db.table('vital_meals'),auditTable=db.table('vital_audit'),acks=db.table('vital_sync_ack'),queue=db.table('syncQueue') as unknown as Queue;
 return db.transaction('rw',[persons,meals,auditTable,acks,queue as unknown as CanonicalTable],async()=>{
  must(active()&&(await persons.get(s.person_id))?.user_id===s.user_id,'Pessoa fora da conta.');
  // No write until all local rows, exact queue entries and prior ACKs are checked.
  const writes:{row:Record<string,unknown>;table:CanonicalTable;ack:VitalAck;queueId:string}[]=[];
  for(const e of entries){const table=e.table==='vital_meals'?meals:auditTable;const q=e.queue;
   const current=await queue.get(q.id!);if(!current||current.table!==q.table||current.chave!==q.chave||current.operation!==q.operation||current.updated_at!==q.updated_at)return 'preserve_local';
   if(!same(vitalPayload(e.table,vitalWireRow(e.table,current.payload,s),s),vitalPayload(e.table,e.row,s)))return 'preserve_local';
   const matches=await queue.where('chave').equals(q.chave).toArray();if(matches.length!==1||matches[0].id!==q.id)return 'preserve_local';
   const row=await table.get(e.row.id);if(!row||!same(vitalPayload(e.table,vitalWireRow(e.table,row,s),s),vitalPayload(e.table,e.row,s)))return 'preserve_local';
   const ackId=vitalAckId(e.table,s,e.row.id);const old=await acks.get(ackId) as VitalAck|undefined;
   if(old){must(own(old,s)&&old.id===ackId&&old.table===e.table&&old.row_id===e.row.id,'Recibo local fora do escopo.');
    // This first batch finalizer deliberately does not consume independently pending generic writes.
    if(old.pending_revision!==null||old.pending_fingerprint!==null)return 'preserve_local';
    if(e.table==='vital_meals'){if(old.revision!==(input.baseAck?.revision??null)||old.fingerprint!==(input.baseAck?.fingerprint??null))return 'preserve_local';}
    else if(old.revision!==null&&(old.revision!==e.row.revision||old.fingerprint!==e.fingerprint))return 'preserve_local';
    else if(old.revision===null&&old.fingerprint!==null)return 'preserve_local';
   }else if(e.table==='vital_meals'&&input.baseAck)return 'preserve_local';
   writes.push({row,table,queueId:q.id!,ack:{...s,id:ackId,table:e.table,row_id:e.row.id,revision:e.row.revision,fingerprint:e.fingerprint,pending_revision:null,pending_fingerprint:null}});
  }
  must(active(),'Pessoa ativa mudou.');
  for(const w of writes){await w.table.put({...w.row,synced:true});await acks.put(w.ack as unknown as Record<string,unknown>);await queue.delete(w.queueId);}
  must(active(),'Pessoa ativa mudou durante confirmação.');return 'confirmed';
 });
}
