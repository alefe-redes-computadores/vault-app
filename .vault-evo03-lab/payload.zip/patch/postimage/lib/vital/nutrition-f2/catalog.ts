import {gtin, type Source,type Scope} from './nutrition';
export type Candidate={provider:'off'|'usda';sourceId:string;version:string;name:string;barcode:string|null;source:Source};
export function barcodeReview(raw:string,candidates:readonly Candidate[]){const code=gtin(raw);if(!code)return {status:'invalid' as const,candidates:[]};const matches=candidates.filter(c=>c.barcode!==null&&gtin(c.barcode)===code);return {status:matches.length===0?'not_found':matches.length===1?'review':'multiple_review',candidates:structuredClone(matches)};}
/** Only these fields cross a provider boundary. No identity, history, image or credentials. */
export function lookupRequest(input:{barcode:string}):{barcode:string}{const code=gtin(input.barcode);if(!code)throw Error('Código inválido');return {barcode:input.barcode.trim()};}
export function catalogKey(c:Candidate){if(!c.sourceId.trim()||!c.version.trim()||c.source.provider!==c.provider||c.source.recordId!==c.sourceId||c.source.version!==c.version)throw Error('Identidade/fonte divergente');return JSON.stringify([c.provider,c.sourceId,c.version]);}

/** Federation keeps provider records independent; no cross-provider entity merge. Production adapters must supply approved evidence, not user assertions. */
export type Provider='manual'|'label'|'taco'|'usda'|'off'|'tbca';
export type SourcePolicy={provider:Provider;release:string;manifestSha256:string;allowed:readonly ('query'|'cache'|'snapshot'|'distribute'|'images')[];approvalRef:string|null};
export function sourceAllowed(p:SourcePolicy,operation:SourcePolicy['allowed'][number]){
 return p.provider!=='tbca'&&!!p.release.trim()&&/^[a-f0-9]{64}$/.test(p.manifestSha256)&&!!p.approvalRef?.trim()&&p.allowed.includes(operation);
}
export type SearchHit={provider:Provider;sourceId:string;version:string;name:string;preparation:string;barcode?:string;scope?:Scope};
const searchKey=(s:string)=>s.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase('pt-BR').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function federatedSearch(query:string,hits:readonly SearchHit[],policies:readonly SourcePolicy[],limit=30,scope?:Scope){
 if(!Number.isInteger(limit)||limit<1||limit>100)throw Error('Limite inválido');const q=searchKey(query);if(!q)return [];const seen=new Set<string>();return hits.filter(h=>{
 if(!h.sourceId.trim()||!h.version.trim()||!h.name.trim())return false;
 if(h.provider==='manual'||h.provider==='label'){if(!scope||!h.scope||h.scope.user_id!==scope.user_id||h.scope.person_id!==scope.person_id)return false;}else if(h.scope)return false;
 if(!policies.some(p=>p.provider===h.provider&&p.release===h.version&&sourceAllowed(p,'query')))return false;
 if(!q.split(' ').every(t=>searchKey(h.name+' '+h.preparation).includes(t)))return false;const id=JSON.stringify([h.provider,h.sourceId,h.version]);if(seen.has(id))return false;seen.add(id);return true;
 }).slice(0,limit).map(h=>structuredClone(h));
}
