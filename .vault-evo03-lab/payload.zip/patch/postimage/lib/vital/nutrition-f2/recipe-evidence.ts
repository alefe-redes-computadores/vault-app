import {recipePortion, type Recipe,type Quantity,type Nutrient} from './nutrition';
/** Yield distributes calculated ingredients. No implicit nutrient retention factor is applied. */
export function recipeEvidence(r:Recipe,consumed:Quantity,keys:readonly Nutrient[]){
 return {recipeId:r.id,version:r.version,calculated:recipePortion(r,consumed,keys),yield:structuredClone(r.yield),retention:'not_assessed' as const,method:'ingredient_sum_distributed_by_declared_yield' as const,claim:'estimated_recipe_composition_not_measured' as const};
}
