/** Recipe aggregate in the existing canonical outbox. Review-only until certified release.
 * No mutable parallel journal: exact preimages, immutable versions, and existing ACKs.
 * Old ambiguous timestamps are quarantined rather than silently ordering revisions. */
import type {Scope,VitalRecipeRow,VitalRecipeVersionRow,VitalAudit} from '../model';
import type {CanonicalDb,CanonicalTable} from '../storage-dexie';
import type {VitalQueueItem} from '../queue-finalize';
import {vitalWireRow,vitalFingerprint,vitalAckId,VitalSyncConflict,type VitalAck} from '../cloud-transport';
import {own,requireId,requireScope} from '../validation';
import {recipeRequest,submitRecipeStep,type RecipeStep} from './remote-recipe';
import type {ExistingRpcClient} from './remote-meal';
function must(v:unknown,m:string):asserts v{if(!v)throw new VitalSyncConflict(m);}
const canon=(x:unknown)=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const same=(a:unknown,b:unknown)=>canon(a)===canon(b);
function metadata(h:VitalRecipeRow){const {id,user_id,person_id,created_at,updated_at,deleted_at,revision,synced,...d}=h;return d;}
/** Reconstruct exact head preimages and interleave versions using the monotonic writer.
 * An equal timestamp on a metadata boundary or between versions is NOT proof of order. */
export function planRecipeChain(scope:Scope,headRaw:unknown,versionRows:readonly unknown[],auditRows:readonly unknown[]):RecipeStep[]{
 const s=requireScope(scope),head=vitalWireRow('vital_recipes',headRaw,s);
 must(versionRows.length>0&&head.revision===auditRows.length+1,'Histórico de receita incompleto.');
 const versions=versionRows.map(v=>vitalWireRow('vital_recipe_versions',v,s)).sort((a,b)=>a.version-b.version);
 const audits=auditRows.map(a=>vitalWireRow('vital_audit',a,s)).sort((a,b)=>a.previous_revision-b.previous_revision);
 const seen=new Set([head.id]);
 for(let i=0;i<versions.length;i++){const v=versions[i];must(v.recipe_id===head.id&&v.version===i+1&&v.revision===1&&v.deleted_at===null&&v.created_at===v.updated_at&&!seen.has(v.id)&&v.created_at>=head.created_at&&(i===0||v.created_at>versions[i-1].created_at),'Versão de receita incompleta, duplicada ou cronologia ambígua.');seen.add(v.id);}
 for(let i=0;i<audits.length;i++){const a=audits[i];must(a.target_table==='vital_recipes'&&a.target_id===head.id&&a.previous_revision===i+1&&a.revision===1&&a.deleted_at===null&&a.created_at===a.updated_at&&a.created_at>(i===0?head.created_at:audits[i-1].created_at)&&!seen.has(a.id),'Auditoria de receita incompleta ou divergente.');seen.add(a.id);}
 const heads=audits.map((a,i)=>vitalWireRow('vital_recipes',{...(a.previous as Record<string,unknown>),...s,id:head.id,created_at:head.created_at,updated_at:i===0?head.created_at:audits[i-1].created_at,deleted_at:null,revision:i+1},s));heads.push(head);
 must(head.updated_at===(audits.at(-1)?.created_at??head.created_at),'Cabeça de receita sem auditoria correspondente.');
 for(let i=0;i<heads.length;i++){must(heads[i].kind===head.kind,'Tipo histórico divergente.');if(i>0){must(same(audits[i-1].previous,metadata(heads[i-1]))&&(!heads[i].deleted_at||i===heads.length-1&&heads[i].deleted_at===heads[i].updated_at&&same(metadata(heads[i-1]),metadata(heads[i]))),'Pré-imagem histórica divergente.');}}
 must(!audits.some(a=>a.created_at===versions[0].created_at)&&versions[0].created_at<(audits[0]?.created_at??'9999'),'Primeira versão sem ordem comprovada.');
 const steps:RecipeStep[]=[];let ri=0,vi=0,latest:string|null=null;
 while(ri<audits.length||vi<versions.length){const a=audits[ri],v=versions[vi];must(!a||!v||a.created_at!==v.created_at,'Ordem entre versão e metadados ambígua.');
  if(v&&(!a||v.created_at<a.created_at)){const h=heads[ri];must(v.name_snapshot===h.name&&h.active&&!h.deleted_at,'Versão não corresponde à cabeça histórica.');steps.push({scope:s,head:h,version:v,audit:null,expectedHead:vi===0?null:h.revision,expectedLatest:latest,operationId:v.id});latest=v.id;vi++;}
  else{must(a&&latest,'Metadados sem primeira versão.');steps.push({scope:s,head:heads[ri+1],version:null,audit:a,expectedHead:heads[ri].revision,expectedLatest:latest,operationId:a.id});ri++;}
 }
 steps.forEach(recipeRequest);return steps;
}
type Table='vital_recipes'|'vital_recipe_versions'|'vital_audit';
type RecipeRow=VitalRecipeRow|VitalRecipeVersionRow|VitalAudit;
type Lookup=Omit<CanonicalTable,'where'>&{delete(id:string):PromiseLike<unknown>;where(index:string):{equals(key:string):{toArray():PromiseLike<Record<string,unknown>[]>}}};
type Entry={table:Table;row:RecipeRow;queue:VitalQueueItem|null;ack:VitalAck|null;synced:boolean};
export function recipeQueueRoot(item:VitalQueueItem):string|null{if(item.table==='vital_recipes')return requireId(item.payload.id);if(item.table==='vital_recipe_versions')return requireId(item.payload.recipe_id);if(item.table==='vital_audit'&&item.payload.target_table==='vital_recipes')return requireId(item.payload.target_id);return null;}
function port(db:CanonicalDb){return {head:db.table('vital_recipes'),versions:db.table('vital_recipe_versions') as unknown as Lookup,audits:db.table('vital_audit') as unknown as Lookup,queue:db.table('syncQueue') as unknown as Lookup,acks:db.table('vital_sync_ack'),persons:db.table('persons')};}
function tables(p:ReturnType<typeof port>){return Object.values(p) as unknown as CanonicalTable[];}
async function snapshot(p:ReturnType<typeof port>,s:Scope,id:string){
 must((await p.persons.get(s.person_id))?.user_id===s.user_id,'Pessoa fora da conta.');
 const head=vitalWireRow('vital_recipes',await p.head.get(id),s);
 const versions=(await p.versions.where('recipe_id').equals(id).toArray()).map(v=>vitalWireRow('vital_recipe_versions',v,s)).sort((a,b)=>a.version-b.version);
 const audits=(await p.audits.where('target_id').equals(id).toArray()).filter(a=>a.target_table==='vital_recipes').map(a=>vitalWireRow('vital_audit',a,s)).sort((a,b)=>a.previous_revision-b.previous_revision);
 const entries:Entry[]=[];const queuedById=new Map<string,VitalQueueItem>();
 async function entry(table:Table,row:RecipeRow){const key=`${table}:${row.id}`,list=await p.queue.where('chave').equals(key).toArray();must(list.length<=1,'Fila de receita duplicada.');const q=list[0] as unknown as VitalQueueItem|undefined;
  if(q){must(q.table===table&&q.chave===key&&['add','update'].includes(q.operation)&&!!q.updated_at&&same(vitalWireRow(table,q.payload,s),row)&&same(await p.queue.get(requireId(q.id)),q),'Fila de receita divergente.');}
  const ackId=vitalAckId(table,s,row.id),ack=await p.acks.get(ackId) as VitalAck|undefined;
  if(ack)must(ack.id===ackId&&own(ack,s)&&ack.table===table&&ack.row_id===row.id&&ack.pending_revision===null&&ack.pending_fingerprint===null&&(ack.revision===null?ack.fingerprint===null:Number.isSafeInteger(ack.revision)&&ack.revision>0&&ack.revision<=row.revision&&typeof ack.fingerprint==='string'&&/^[a-f0-9]{64}$/.test(ack.fingerprint)),'ACK de receita divergente ou pendente.');
  const t=table==='vital_recipes'?p.head:table==='vital_recipe_versions'?p.versions:p.audits;const stored=await t.get(row.id);must(stored&&typeof stored.synced==='boolean','Estado local de receita inválido.');
  entries.push({table,row,queue:q??null,ack:ack??null,synced:stored.synced});if(q){const qid=requireId(q.id);must(!queuedById.has(qid),'ID de fila repetido.');queuedById.set(qid,q);}}
 await entry('vital_recipes',head);for(const v of versions)await entry('vital_recipe_versions',v);for(const a of audits)await entry('vital_audit',a);
 // A queued child that has no matching canonical row must never be ignored.
 for(const t of ['vital_recipes','vital_recipe_versions','vital_audit'] as const){for(const raw of await p.queue.where('table').equals(t).toArray()){const q=raw as unknown as VitalQueueItem;if(q.payload?.user_id!==s.user_id||q.payload?.person_id!==s.person_id)continue;if(recipeQueueRoot(q)===id)must(q.id&&same(queuedById.get(q.id),q),'Operação órfã de receita; reconciliação necessária.');}}
 return {head,versions,audits,entries};
}
export type RecipeQueueDeps={db:CanonicalDb;authenticatedUser:()=>Promise<string|null>;activeScope:()=>Scope|null;readHead:(s:Scope,id:string)=>Promise<unknown|null>;rpc:ExistingRpcClient;capability:{protocol:'vault-vital-f2-recipe-v1';baseline:string;enabled:boolean};approvedBaseline:string};
/** Replays a pending suffix from immutable history. No ACK or removal before all exact receipts.
 * A local edit during network I/O leaves the entire aggregate pending for reconstruction. */
export async function processQueuedRecipeF2(deps:RecipeQueueDeps,scope:Scope,item:VitalQueueItem):Promise<'confirmed'|'preserve_local'>{
 const s=requireScope(scope),q=structuredClone(item),id=recipeQueueRoot(q);must(id&&deps.capability.enabled&&deps.capability.protocol==='vault-vital-f2-recipe-v1'&&deps.capability.baseline===deps.approvedBaseline&&/^[a-f0-9]{40}$/.test(deps.approvedBaseline),'Receita não habilitada.');
 const active=async()=>await deps.authenticatedUser()===s.user_id&&own(deps.activeScope(),s)?s:null;must(await active(),'Conta ou pessoa ativa mudou.');
 const p=port(deps.db),input=await deps.db.transaction('r',tables(p),()=>snapshot(p,s,id));must(input.entries.some(e=>e.queue&&same(e.queue,q)),'Operação de receita não corresponde à fila atual.');
 const chain=planRecipeChain(s,input.head,input.versions,input.audits),root=input.entries[0];let prefix=0,base:VitalRecipeRow|null=null;
 const entriesByRow=new Map(input.entries.map(e=>[e.row.id,e]));
 for(const [index,step] of chain.entries()){const child=entriesByRow.get(step.operationId);must(child,'Operação sem linha canônica.');if(child.queue){must(!child.synced&&child.ack?.revision==null,'ACK residual de receita exige reconciliação.');continue;}
  must(prefix===index&&child.synced&&child.ack?.revision===child.row.revision&&child.ack.fingerprint===await vitalFingerprint(child.table,child.row,s),'Confirmação histórica incompleta ou fora de ordem.');prefix++;base=step.head;
 }
 must(prefix<chain.length,'Receita já confirmada sem operação pendente.');must((root.ack?.revision??null)===(base?.revision??null)&&(root.ack?.fingerprint??null)===(base?await vitalFingerprint('vital_recipes',base,s):null),'ACK base da cabeça não comprovado.');
 const needsRoot=!base||base.revision!==input.head.revision;must(!!root.queue===needsRoot&&root.synced===!needsRoot,'Fila da cabeça não corresponde à revisão pendente.');
 must(await active(),'Sessão mudou.');const remote=await deps.readHead(s,id);must(await active(),'Sessão mudou durante leitura.');
 if(remote===null)must(!base,'Servidor perdeu a base confirmada.');else{const h=vitalWireRow('vital_recipes',remote,s);must(chain.some(x=>same(x.head,h))&&(!base||h.revision>=base.revision),'Cabeça remota divergente.');}
 for(const step of chain.slice(prefix))await submitRecipeStep(deps.rpc,active,deps.capability,deps.approvedBaseline,step);
 must(await active(),'Sessão mudou.');const final=await deps.readHead(s,id);must(final&&same(vitalWireRow('vital_recipes',final,s),input.head),'Servidor avançou durante confirmação.');
 // Keep hash work bounded without splitting the final IndexedDB transaction.
 const writes:{e:Entry;ack:VitalAck}[]=[];for(const e of input.entries){if(!e.queue)continue;writes.push({e,ack:{...s,id:vitalAckId(e.table,s,e.row.id),table:e.table,row_id:e.row.id,revision:e.row.revision,fingerprint:await vitalFingerprint(e.table,e.row,s),pending_revision:null,pending_fingerprint:null}});}
 must(await active(),'Sessão mudou.');return deps.db.transaction('rw',tables(p),async()=>{must(own(deps.activeScope(),s),'Pessoa ativa mudou.');if(!same(await snapshot(p,s,id),input))return 'preserve_local';
  for(const {e,ack} of writes){const t=e.table==='vital_recipes'?p.head:e.table==='vital_recipe_versions'?p.versions:p.audits;await t.put({...e.row,synced:true});await p.acks.put(ack);await p.queue.delete(requireId(e.queue!.id));}
  must(own(deps.activeScope(),s),'Pessoa ativa mudou durante confirmação.');return 'confirmed';});
}
