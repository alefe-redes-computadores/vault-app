/** Isolated F2 recipe consumption. Never infer cooking retention or promote partial sums. */
import {coverageDetailed,UNITS,type Scope,type Composition,type Quantity,type Profile,type Nutrient} from './nutrition';
import type {RecipeVersion} from './recipe-contract';
import type {VitalRecipeVersionRow} from '../model';
import {validateStoredRecipeVersion} from './recipe-storage-validation';
import {requireId,requireScope} from '../validation';
import type {DraftItem} from './meal-draft';
const stable=(v:unknown):string=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
function must(ok:unknown,msg:string):asserts ok{if(!ok)throw Error(msg);}
const fields=['id','user_id','person_id','recipe_id','version','name_snapshot','ingredients','raw_edible_mass_g','finished_mass_g','servings','yield_evidence','retention_evidence','reviewed_at'] as const;
export function recipeVersionEvidence(row:VitalRecipeVersionRow):RecipeVersion {
 validateStoredRecipeVersion(row as unknown as Record<string,unknown>);
 return structuredClone(Object.fromEntries(fields.map(k=>[k,row[k]]))) as RecipeVersion;
}
/** One composition for the entire declared batch. Only same recipe version can be reused. */
export function recipeVersionComposition(scope:Scope,v:RecipeVersion):Composition {
 const s=requireScope(scope);must(v&&typeof v==='object'&&v.user_id===s.user_id&&v.person_id===s.person_id,'Receita fora do escopo');
 must(Object.keys(v).length===fields.length&&fields.every(k=>Object.hasOwn(v,k)),'Evidência de versão inválida');requireId(v.id);requireId(v.recipe_id);
 validateStoredRecipeVersion({...v,revision:1,created_at:v.reviewed_at,updated_at:v.reviewed_at,deleted_at:null});
 must(v.finished_mass_g!==null||v.servings!==null,'Informe rendimento final ou número de porções');
 // Count all ingredient states. Estimate only when every applicable ingredient has a numeric value.
 const profiles=v.ingredients.map(x=>x.totals),values:Profile={};
 for(const key of Object.keys(UNITS) as Nutrient[]){const c=coverageDetailed(key,profiles);const applicable=c.total-c.notApplicable;
  if(!applicable){values[key]={state:'not_applicable'};continue;}
  if(c.known+c.counts.estimated===applicable){const amount=(c.amount??0)+(c.estimatedSubtotal??0);must(Number.isFinite(amount),'Composição fora do limite');values[key]={state:'estimated',amount,unit:UNITS[key],method:'recipe_ingredient_sum_no_retention_assessed'};continue;}
  const incomplete=['trace','not_analyzed','not_reported','illegible','unknown'] as const;const state=incomplete.find(k=>c.counts[k]===applicable);values[key]={state:state??'unknown'};
 }
 const base:Quantity=v.finished_mass_g!==null?{value:v.finished_mass_g,unit:'g'}:{value:v.servings!,unit:'portion'};
 const equivalence=v.finished_mass_g!==null&&v.servings!==null?{from:{value:v.finished_mass_g,unit:'g' as const},to:{value:v.servings,unit:'portion' as const},evidence:v.yield_evidence!}:undefined;
 return {name:v.name_snapshot,source:{provider:'recipe',recordId:v.recipe_id,version:v.id,license:'private-derived-no-license-override',retrievedAt:v.reviewed_at,attribution:'Receita do usuário; soma de ingredientes; retenção não avaliada'},base,values,preparation:'ready',edibleBasis:'unknown',...(equivalence?{equivalence}:{}),recipeVersion:structuredClone(v)};
}
export function verifyRecipeComposition(scope:Scope,c:Composition):void {
 if(c.source.provider!=='recipe'){must(c.recipeVersion===undefined,'Evidência de receita em fonte divergente');return;}
 must(c.recipeVersion,'Versão histórica da receita ausente');must(stable(recipeVersionComposition(scope,c.recipeVersion))===stable(c),'Composição histórica da receita divergente');
}
export function recipeConsumptionDraft(scope:Scope,row:VitalRecipeVersionRow,itemId:string,quantity:Quantity):DraftItem {
 requireId(itemId);const c=recipeVersionComposition(scope,recipeVersionEvidence(row));return {id:itemId,identity:{provider:'recipe',recordId:c.source.recordId,version:c.source.version,preparation:c.preparation!,presentationId:row.id},composition:c,quantity:structuredClone(quantity),reviewed:false};
}
export function sameRecipeEvidence(row:VitalRecipeVersionRow,c:Composition){return stable(recipeVersionEvidence(row))===stable(c.recipeVersion);}
