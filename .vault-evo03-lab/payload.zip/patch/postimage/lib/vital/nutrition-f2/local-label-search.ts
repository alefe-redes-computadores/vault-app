/** Reuse reviewed private labels from canonical, live meal snapshots only.
 * No duplicate catalog, no name-based identity, no source activation. */
import {gtin,reviewedSnapshot,type Scope,type Composition,type Quantity} from './nutrition';
import {type DraftItem,type FoodIdentity} from './meal-draft';
import {verifyMealEnvelope} from './persistence';
import type {MealRow} from '../model';
import {own,requireId,requireScope} from '../validation';
export type LocalLabelHit={key:string;identity:FoodIdentity;composition:Composition;quantity:Quantity;confirmedAt:string;lastItemId:string;barcode:string|null};
const identityKey=(i:FoodIdentity)=>JSON.stringify([i.provider,i.recordId,i.version,i.preparation,i.presentationId]);
const searchKey=(s:string)=>s.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase('pt-BR').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
const same=(a:unknown,b:unknown)=>JSON.stringify(a,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v)===JSON.stringify(b,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
export function searchLocalLabels(scope:Scope,meals:readonly MealRow[],query:{text:string}|{barcode:string}|{exactKey:string},limit=30){
 const s=requireScope(scope);if(!Number.isSafeInteger(limit)||limit<1||limit>100)throw Error('Limite inválido');
 const code='barcode'in query?gtin(query.barcode):null,words='text'in query?searchKey(query.text).split(' ').filter(Boolean):[];
 if('barcode'in query&&!code)return {status:'invalid_barcode' as const,hits:[],total:0};
 const found=new Map<string,LocalLabelHit>(),all=new Map<string,Composition>();const ids=new Set<string>();
 for(const m of meals){if(!own(m,s)||m.deleted_at||!m.nutrition_f2)continue;if(ids.has(m.id))throw Error('Refeição duplicada na projeção');ids.add(m.id);verifyMealEnvelope(s,m.items,m.nutrition_f2);
  for(const r of Object.values(m.nutrition_f2.items)){const c=r.payload.composition;if(c.source.provider!=='label'||!c.labelEvidence)continue;const key=identityKey(r.identity);const prior=all.get(key);if(prior&&!same(prior,c))throw Error('Composição divergente para a mesma versão de rótulo');all.set(key,c);const barcode=c.labelEvidence.barcode;
   if('exactKey'in query?key!==query.exactKey:code?barcode!==code:!words.every(w=>searchKey(c.name).includes(w)))continue;
   const hit={key,identity:r.identity,composition:c,quantity:r.payload.consumed,confirmedAt:r.reviewedAt,lastItemId:r.payload.itemId,barcode};const old=found.get(key);
   if(!old||Date.parse(hit.confirmedAt)>Date.parse(old.confirmedAt)||hit.confirmedAt===old.confirmedAt&&hit.lastItemId>old.lastItemId)found.set(key,hit);
  }
 }
 const hits=[...found.values()].sort((a,b)=>Date.parse(b.confirmedAt)-Date.parse(a.confirmedAt)||a.key.localeCompare(b.key,'en'));
 return {status:'review' as const,hits:structuredClone(hits.slice(0,limit)),total:hits.length};
}
export function reuseLocalLabel(scope:Scope,meals:readonly MealRow[],key:string,itemId:string,quantity?:Quantity):DraftItem{
 const s=requireScope(scope);const hit=searchLocalLabels(s,meals,{exactKey:key},1).hits[0];
 if(!hit)throw Error('Rótulo histórico indisponível. Refaça a busca.');
 const q=quantity??hit.quantity;const item:DraftItem={id:requireId(itemId),identity:hit.identity,composition:hit.composition,quantity:structuredClone(q),reviewed:false};
 const preview=reviewedSnapshot(s,item.id,item.composition,item.quantity,hit.confirmedAt);if(preview.conversion.status!=='resolved')throw Error('Porção incompatível com este rótulo.');return item;
}
