import type {Connection} from './health-connect-nutrition';

/** Presentation only: unavailable/error is not a denial, nor proof of a grant. */
export type NutritionPermissionView={kind:'checking'|'granted'|'denied'|'error'};
export async function probeNutritionPermission(current:()=>Promise<Pick<Connection,'nutritionReadGranted'>>):Promise<NutritionPermissionView>{
 try{
  const value=await current();
  return {kind:value.nutritionReadGranted===true?'granted':value.nutritionReadGranted===false?'denied':'error'};
 }catch{return {kind:'error'};}
}
