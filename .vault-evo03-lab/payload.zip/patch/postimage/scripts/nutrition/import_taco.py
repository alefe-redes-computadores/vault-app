#!/usr/bin/env python3
"""TACO 4th ed. official XLSX -> sealed candidates. Offline, no DB or network.
Layout must be independently reviewed against the exact workbook; never guesses columns.
No actual food values are bundled with this importer.
"""
import argparse, hashlib, json, math, re, unicodedata, zipfile
from pathlib import Path
from datetime import date
from decimal import Decimal
from openpyxl import load_workbook
from import_usda import canonical, digest, file_digest, export

RELEASE='taco-2011-4ed'
LICENSE='TACO-2011-attribution'
URL='https://www.nepa.unicamp.br/arquivo/uploads/taco-4a-edicao/taco-4a-edicao-2/'
ATTR='NEPA-UNICAMP. Tabela Brasileira de Composição de Alimentos (TACO), 4. ed. rev. e ampl., Campinas, 2011. Reprodução com indicação da fonte.'
# Table 1 only. No inferred sugar/fatty acid totals or vitamin A RE->RAE conversion.
FIELDS={
 'id':({'numero do alimento','numero alimento','n do alimento','n alimento','numero'},None),
 'name':({'descricao dos alimentos','descricao do alimento','descricao'},None),
 'energy_kcal':({'energia'},'kcal'), 'protein_g':({'proteina','proteinas'},'g'),
 'fat_g':({'lipideos','lipidios'},'g'), 'carbohydrate_g':({'carboidrato','carboidratos'},'g'),
 'fiber_g':({'fibra alimentar','fibras alimentares'},'g'), 'calcium_mg':({'calcio'},'mg'),
 'magnesium_mg':({'magnesio'},'mg'), 'phosphorus_mg':({'fosforo'},'mg'),
 'iron_mg':({'ferro'},'mg'), 'sodium_mg':({'sodio'},'mg'), 'potassium_mg':({'potassio'},'mg'),
 'zinc_mg':({'zinco'},'mg'), 'vitamin_a_rae_ug':({'rae'},'ug'),
 'thiamin_mg':({'tiamina'},'mg'), 'riboflavin_mg':({'riboflavina'},'mg'),
 'vitamin_b6_mg':({'piridoxina','vitamina b6'},'mg'), 'niacin_mg':({'niacina'},'mg'),
 'vitamin_c_mg':({'vitamina c'},'mg'),
}
CORE={'id','name','energy_kcal','protein_g','fat_g','carbohydrate_g','fiber_g'}

def norm(x):
 s=unicodedata.normalize('NFKD',str(x or '').lower().replace('µ','u').replace('μ','u'))
 return ' '.join(re.sub(r'[^a-z0-9]+',' ',''.join(c for c in s if not unicodedata.combining(c))).split())
def raw(c):
 v=c.value
 if c.data_type in ('f','e') or isinstance(v,bool) or (v is not None and not isinstance(v,(str,int,float))):raise ValueError('Formula/error/unsupported cell')
 if isinstance(v,float) and not math.isfinite(v):raise ValueError('Non-finite cell')
 return '' if v is None else format(Decimal(str(v)),'f') if isinstance(v,float) else str(v)
def parse_value(text,unit):
 s=text.strip(); low=s.lower()
 if low=='tr':return {'state':'trace'}
 if low=='na':return {'state':'not_applicable'}
 if not s or s in ('-','–','—'):return {'state':'not_reported'}
 if not re.fullmatch(r'\d+(?:[.,]\d+)?',s):raise ValueError('Unreviewed nutrient notation: '+s[:32])
 n=float(s.replace(',','.'))
 if not math.isfinite(n) or not 0<=n<=1e6:raise ValueError('Nutrient out of bounds')
 # Zero in the table is not a declaration of exact absence; never upgrade it to measured zero.
 return {'state':'unknown'} if n==0 else {'state':'known','amount':n,'unit':unit}
def sha_ok(p,expected):
 if not re.fullmatch('[a-f0-9]{64}',expected) or file_digest(p)!=expected:raise ValueError('Source/layout SHA mismatch')
def build(path,expected,layout_path,layout_sha,captured,*,test_count=None):
 path=Path(path);layout_path=Path(layout_path);sha_ok(path,expected);sha_ok(layout_path,layout_sha);date.fromisoformat(captured)
 if path.stat().st_size>20_000_000 or layout_path.stat().st_size>100_000:raise ValueError('Input size')
 with zipfile.ZipFile(path) as z:
  names=z.namelist();
  if len(names)!=len(set(names)) or sum(i.file_size for i in z.infolist())>100_000_000 or any('vbaProject' in n or n.startswith('xl/externalLinks/') for n in names):raise ValueError('Unsupported workbook content')
 layout=json.loads(layout_path.read_text(encoding='utf-8'))
 if not isinstance(layout,dict) or set(layout)!={'sheet','header_row','unit_row','first_data_row','last_data_row','columns'}:raise ValueError('Layout fields')
 h,u,a,b=(layout[k] for k in ('header_row','unit_row','first_data_row','last_data_row'))
 if any(type(i) is not int for i in (h,u,a,b)) or not 1<=h<=u<a<=b<=2000:raise ValueError('Layout rows')
 cols=layout['columns']
 if not isinstance(cols,dict) or not CORE<=set(cols)<=set(FIELDS) or any(type(i) is not int or not 1<=i<=128 for i in cols.values()) or len(set(cols.values()))!=len(cols):raise ValueError('Layout columns')
 wb=load_workbook(path,read_only=True,data_only=False,keep_links=False)
 try:
  if layout['sheet'] not in wb.sheetnames:raise ValueError('Sheet missing')
  ws=wb[layout['sheet']]; width=max(cols.values()); headers={}
  for key,col in cols.items():
   head=raw(ws.cell(h,col));unit=raw(ws.cell(u,col));labels,expected_unit=FIELDS[key]
   # Separate nutrient heading and unit, or same-row compound header if explicitly reviewed.
   if h==u and expected_unit:
    valid=any(norm(head)==f'{label} {expected_unit}' for label in labels)
   else:
    valid=norm(head) in labels and (expected_unit is None or norm(unit)==expected_unit)
   if not valid:raise ValueError('Header/unit drift: '+key)
   headers[key]={'column':str(col),'header':head,'unit':unit}
  rows=[];seen=set()
  for n,cells in enumerate(ws.iter_rows(min_row=a,max_row=b,max_col=width),a):
   selected={k:raw(cells[col-1]) for k,col in cols.items()}
   code=selected['id'].strip();name=selected['name'].strip()
   if not code:
    if any(v.strip() for k,v in selected.items() if k not in ('id','name')):raise ValueError('Nutrient cells without food ID')
    continue # Blank or category row. No nutrients can be silently omitted.
   if not re.fullmatch(r'[1-9]\d{0,2}',code) or code in seen or not name or len(name)>120:raise ValueError('Food identity drift')
   seen.add(code); values={k:parse_value(v,FIELDS[k][1]) for k,v in selected.items() if k not in ('id','name')}
   evidence={'sheet':layout['sheet'],'row':str(n),'cells':selected,'headers':headers}
   c={'name':name,'source':{'provider':'taco','recordId':code,'version':RELEASE,'license':LICENSE,'retrievedAt':captured+'T00:00:00Z','attribution':ATTR},'base':{'value':100,'unit':'g'},'values':values,'preparation':'unknown','edibleBasis':'edible'}
   rows.append({'sourceId':code,'version':RELEASE,'composition':c,'rawEvidence':evidence,'sourceRecordSha256':digest(canonical(evidence)),'requiresReview':True})
  total=597 if test_count is None else test_count
  if seen!={str(n) for n in range(1,total+1)}:raise ValueError('Incomplete TACO Table 1 identity set')
  manifest={'provider':'taco','release':RELEASE,'captured':captured,'sourceWorkbookSha256':expected,'layoutSha256':layout_sha,'sourceUrl':URL,'license':LICENSE,'attribution':ATTR,'status':'CANDIDATES_ONLY','activation':False,'rows':len(rows),'fixtureOnly':test_count is not None}
  return sorted(rows,key=lambda r:int(r['sourceId'])),manifest
 finally:wb.close()
# Exact workbook observed in R03. Never apply this adapter to a different release.
OFFICIAL_SHA='a66b8ec528daeabc63bc2b015fc9bd8c6d76b941c2fc0ed93a4311d449302d14'
OFFICIAL_COLS=dict(zip(FIELDS,[1,2,4,6,7,9,10,12,13,16,17,18,19,21,24,25,26,27,28,29]))
OFFICIAL_SHEET='CMVCol taco3'
def official_identity(primary,mirror,row,previous):
 if re.fullmatch(r'[1-9]\d{0,2}',primary):code=int(primary)
 else:
  match=re.fullmatch(r'=A([1-9]\d*)\+1',primary)
  if not match or previous is None or int(match[1])!=previous[0]:raise ValueError(f'Unreviewed identity formula A{row}')
  code=previous[1]+1
 if mirror not in (str(code),f'=A{row}'):raise ValueError(f'Identity mirror N{row}')
 if code!=(1 if previous is None else previous[1]+1):raise ValueError(f'Identity sequence A{row}')
 return code

def official_headers(ws):
 result={};fragments={}
 for k,col in OFFICIAL_COLS.items():
  f=[raw(ws.cell(i,col)) for i in (1,2,3)]; fragments[k]=f
  label=' '.join(x.strip() for x in f[:2] if x.strip());unit=f[2]
  if k in ('id','name'):label=' '.join(x.strip() for x in f if x.strip());unit=''
  if k=='carbohydrate_g':label=''.join(x.strip().removesuffix('-') for x in f[:2])
  if k=='vitamin_c_mg':label=' '.join(x.strip() for x in f[:2])
  labels,expected=FIELDS[k]
  if norm(label) not in labels or expected and norm(unit)!=('mcg' if k=='vitamin_a_rae_ug' else expected):raise ValueError('Official header drift: '+k+repr(f))
  result[k]={'column':str(col),'header':label,'unit':'ug' if k=='vitamin_a_rae_ug' else unit}
 return result,fragments

# This exact pinned workbook contains 13 arithmetic nutrient formulas. No general spreadsheet evaluation.
def official_nutrient(cell,cached,cells,row):
 if cell.data_type!='f':return raw(cell),None
 formula=str(cell.value); compact=formula.replace(' ',''); references={}
 avg=re.fullmatch(r'=\((\d+(?:\.\d+)?)[+](\d+(?:\.\d+)?)[+](\d+(?:\.\d+)?)\)/3',compact)
 ref=re.fullmatch(r'=(4[+]V|W)([1-9]\d*)(/2)?',compact)
 if avg: result=sum(Decimal(v) for v in avg.groups())/Decimal(3)
 elif ref and int(ref[2])==row and ((ref[1]=='4+V' and ref[3] is None) or (ref[1]=='W' and ref[3]=='/2')):
  col=22 if ref[1]=='4+V' else 23; reference=raw(cells[col-1]);number=Decimal(reference)
  if not number.is_finite() or number<0:raise ValueError(f'Invalid reference row {row}')
  references[('V' if col==22 else 'W')+str(row)]=reference
  result=Decimal(4)+number if col==22 else number/2
 else:raise ValueError(f'Unreviewed nutrient formula row {row}: {formula}')
 value=raw(cached)
 if not re.fullmatch(r'\d+(?:\.\d+)?',value) or not math.isclose(float(result),float(value),rel_tol=1e-12,abs_tol=1e-12):raise ValueError(f'Formula cached value drift row {row}')
 return value,{'formula':formula,'cached':value,'references':references}

def build_official(path,expected,captured):
 path=Path(path);sha_ok(path,expected);date.fromisoformat(captured)
 if expected!=OFFICIAL_SHA or path.stat().st_size>20_000_000:raise ValueError('Official workbook identity/size')
 with zipfile.ZipFile(path) as z:
  names=z.namelist()
  if len(names)!=len(set(names)) or sum(i.file_size for i in z.infolist())>100_000_000 or any('vbaproject' in n.lower() or n.startswith('xl/externalLinks/') for n in names):raise ValueError('Unsupported workbook content')
 wb=load_workbook(path,read_only=True,data_only=False,keep_links=False)
 cached=load_workbook(path,read_only=True,data_only=True,keep_links=False)
 try:
  ws=wb[OFFICIAL_SHEET];cs=cached[OFFICIAL_SHEET]
  if ws.max_row!=696 or ws.max_column!=100:raise ValueError('Official dimension drift')
  headers,fragments=official_headers(ws);layout={'sheet':OFFICIAL_SHEET,'headers':headers,'headerFragments':fragments,'identityColumns':[1,14]}
  rows=[];previous=None;categories=[];width=max(OFFICIAL_COLS.values());header_rows=[tuple(c.value for c in row) for row in ws.iter_rows(min_row=1,max_row=3,max_col=width)]
  for n,(cells,cache) in enumerate(zip(ws.iter_rows(min_row=4,max_col=width),cs.iter_rows(min_row=4,max_col=width)),4):
   a=cells[0];mirror=cells[13];primary=str(a.value or '');mr=str(mirror.value or '')
   # Repeated printed-page headers: exact values in every column except the verified mirror.
   matching=[i for i,h in enumerate(header_rows) if all(c.value==h[j] for j,c in enumerate(cells) if j!=13)]
   if matching:
    if len(matching)!=1 or mr not in ('',f'=A{n}',str(header_rows[matching[0]][0] or '')):raise ValueError(f'Repeated header drift {n}')
    continue
   # Pinned workbook footer, never a food. Reject any numeric/formula payload outside text notes.
   if 690<=n<=696:
    if any(c.value is not None for c in cells[2:]) or not isinstance(cells[1].value,str):raise ValueError(f'Footer drift {n}')
    continue
   if n==548 and mr=='=A548' and all(c.value is None for j,c in enumerate(cells) if j!=13):continue
   name=raw(cells[1]);evaluated={k:official_nutrient(cells[col-1],cache[col-1],cells,n) for k,col in OFFICIAL_COLS.items() if k not in ('id','name')};others=[v[0] for v in evaluated.values()]
   if not name.strip() and not mr and not any(x.strip() for x in others):
    if primary and (a.data_type in ('f','e') or not isinstance(a.value,str) or primary.isdigit()):raise ValueError(f'Unresolved food row {n}')
    if primary:categories.append({'row':n,'text':primary})
    continue
   if not name.strip() or len(name.strip())>120 or a.data_type=='e' or mirror.data_type=='e':raise ValueError(f'Food row {n}')
   code=official_identity(primary,mr,n,previous)
   for c in (cache[0],cache[13]):
    if c.value is not None and (isinstance(c.value,bool) or c.value!=code):raise ValueError(f'Cached identity drift {n}')
   selected={'id':str(code),'name':name,**{k:v[0] for k,v in evaluated.items()}};formulaProof={k:v[1] for k,v in evaluated.items() if v[1] is not None}
   evidence={'sheet':OFFICIAL_SHEET,'row':str(n),'cells':selected,'headers':headers,'headerFragments':fragments,'identityProof':{'primary':primary,'mirror':mr,'previousRow':str(previous[0]) if previous else None,'previousId':str(previous[1]) if previous else None},'nutrientFormulas':formulaProof}
   values={k:({'state':'unknown'} if v.strip()=='*' or (n==424 and k=='vitamin_b6_mg' and v==',0,02') or (n in (328,365,382,451) and k=='carbohydrate_g' and re.fullmatch(r'-0\.\d+',v)) else parse_value(v,FIELDS[k][1])) for k,v in selected.items() if k not in ('id','name')}
   c={'name':name.strip(),'source':{'provider':'taco','recordId':str(code),'version':RELEASE,'license':LICENSE,'retrievedAt':captured+'T00:00:00Z','attribution':ATTR},'base':{'value':100,'unit':'g'},'values':values,'preparation':'unknown','edibleBasis':'edible'}
   rows.append({'sourceId':str(code),'version':RELEASE,'composition':c,'rawEvidence':evidence,'sourceRecordSha256':digest(canonical(evidence)),'requiresReview':True});previous=(n,code)
  if [x['sourceId'] for x in rows]!=[str(i) for i in range(1,598)]:raise ValueError(f'Incomplete official TACO identity set: {len(rows)}')
  manifest={'provider':'taco','release':RELEASE,'captured':captured,'sourceWorkbookSha256':expected,'layoutSha256':digest(canonical(layout)),'sourceUrl':URL,'license':LICENSE,'attribution':ATTR,'status':'CANDIDATES_ONLY','activation':False,'rows':len(rows),'fixtureOnly':False}
  return rows,manifest
 finally:wb.close();cached.close()
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('--sha256',required=True);p.add_argument('--layout',type=Path);p.add_argument('--layout-sha256');p.add_argument('--official-observed-r03',action='store_true');p.add_argument('--captured',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 if a.official_observed_r03:
  if a.layout or a.layout_sha256:p.error('Do not mix layouts')
  result=build_official(a.source,a.sha256,a.captured)
 else:
  if not a.layout or not a.layout_sha256:p.error('Layout and hash required')
  result=build(a.source,a.sha256,a.layout,a.layout_sha256,a.captured)
 print(json.dumps(export(*result,a.out),ensure_ascii=False,indent=2))
