#!/usr/bin/env python3
"""TACO 4th ed. official XLSX -> sealed candidates. Offline, no DB or network.
Layout must be independently reviewed against the exact workbook; never guesses columns.
No actual food values are bundled with this importer.
"""
import argparse, hashlib, json, math, re, unicodedata, zipfile
from pathlib import Path
from datetime import date
from openpyxl import load_workbook
from import_usda import canonical, digest, file_digest, export

RELEASE='taco-2011-4ed'
LICENSE='TACO-2011-attribution'
URL='https://www.nepa.unicamp.br/arquivo/uploads/taco-4a-edicao/taco-4a-edicao-2/'
ATTR='NEPA-UNICAMP. Tabela Brasileira de Composição de Alimentos (TACO), 4. ed. rev. e ampl., Campinas, 2011. Reprodução com indicação da fonte.'
# Table 1 only. No inferred sugar/fatty acid totals or vitamin A RE->RAE conversion.
FIELDS={
 'id':({'numero do alimento','numero alimento','n do alimento','n alimento','numero'},None),
 'name':({'descricao dos alimentos','descricao do alimento','descricao'},None),
 'energy_kcal':({'energia'},'kcal'), 'protein_g':({'proteina','proteinas'},'g'),
 'fat_g':({'lipideos','lipidios'},'g'), 'carbohydrate_g':({'carboidrato','carboidratos'},'g'),
 'fiber_g':({'fibra alimentar','fibras alimentares'},'g'), 'calcium_mg':({'calcio'},'mg'),
 'magnesium_mg':({'magnesio'},'mg'), 'phosphorus_mg':({'fosforo'},'mg'),
 'iron_mg':({'ferro'},'mg'), 'sodium_mg':({'sodio'},'mg'), 'potassium_mg':({'potassio'},'mg'),
 'zinc_mg':({'zinco'},'mg'), 'vitamin_a_rae_ug':({'rae'},'ug'),
 'thiamin_mg':({'tiamina'},'mg'), 'riboflavin_mg':({'riboflavina'},'mg'),
 'vitamin_b6_mg':({'piridoxina','vitamina b6'},'mg'), 'niacin_mg':({'niacina'},'mg'),
 'vitamin_c_mg':({'vitamina c'},'mg'),
}
CORE={'id','name','energy_kcal','protein_g','fat_g','carbohydrate_g','fiber_g'}

def norm(x):
 s=unicodedata.normalize('NFKD',str(x or '').lower().replace('µ','u').replace('μ','u'))
 return ' '.join(re.sub(r'[^a-z0-9]+',' ',''.join(c for c in s if not unicodedata.combining(c))).split())
def raw(c):
 v=c.value
 if c.data_type in ('f','e') or isinstance(v,bool) or (v is not None and not isinstance(v,(str,int,float))):raise ValueError('Formula/error/unsupported cell')
 if isinstance(v,float) and not math.isfinite(v):raise ValueError('Non-finite cell')
 return '' if v is None else str(v)
def parse_value(text,unit):
 s=text.strip(); low=s.lower()
 if low=='tr':return {'state':'trace'}
 if low=='na':return {'state':'not_applicable'}
 if not s or s in ('-','–','—'):return {'state':'not_reported'}
 if not re.fullmatch(r'\d+(?:[.,]\d+)?',s):raise ValueError('Unreviewed nutrient notation: '+s[:32])
 n=float(s.replace(',','.'))
 if not math.isfinite(n) or not 0<=n<=1e6:raise ValueError('Nutrient out of bounds')
 # Zero in the table is not a declaration of exact absence; never upgrade it to measured zero.
 return {'state':'unknown'} if n==0 else {'state':'known','amount':n,'unit':unit}
def sha_ok(p,expected):
 if not re.fullmatch('[a-f0-9]{64}',expected) or file_digest(p)!=expected:raise ValueError('Source/layout SHA mismatch')
def build(path,expected,layout_path,layout_sha,captured,*,test_count=None):
 path=Path(path);layout_path=Path(layout_path);sha_ok(path,expected);sha_ok(layout_path,layout_sha);date.fromisoformat(captured)
 if path.stat().st_size>20_000_000 or layout_path.stat().st_size>100_000:raise ValueError('Input size')
 with zipfile.ZipFile(path) as z:
  names=z.namelist();
  if len(names)!=len(set(names)) or sum(i.file_size for i in z.infolist())>100_000_000 or any('vbaProject' in n or n.startswith('xl/externalLinks/') for n in names):raise ValueError('Unsupported workbook content')
 layout=json.loads(layout_path.read_text(encoding='utf-8'))
 if not isinstance(layout,dict) or set(layout)!={'sheet','header_row','unit_row','first_data_row','last_data_row','columns'}:raise ValueError('Layout fields')
 h,u,a,b=(layout[k] for k in ('header_row','unit_row','first_data_row','last_data_row'))
 if any(type(i) is not int for i in (h,u,a,b)) or not 1<=h<=u<a<=b<=2000:raise ValueError('Layout rows')
 cols=layout['columns']
 if not isinstance(cols,dict) or not CORE<=set(cols)<=set(FIELDS) or any(type(i) is not int or not 1<=i<=128 for i in cols.values()) or len(set(cols.values()))!=len(cols):raise ValueError('Layout columns')
 wb=load_workbook(path,read_only=True,data_only=False,keep_links=False)
 try:
  if layout['sheet'] not in wb.sheetnames:raise ValueError('Sheet missing')
  ws=wb[layout['sheet']]; width=max(cols.values()); headers={}
  for key,col in cols.items():
   head=raw(ws.cell(h,col));unit=raw(ws.cell(u,col));labels,expected_unit=FIELDS[key]
   # Separate nutrient heading and unit, or same-row compound header if explicitly reviewed.
   if h==u and expected_unit:
    valid=any(norm(head)==f'{label} {expected_unit}' for label in labels)
   else:
    valid=norm(head) in labels and (expected_unit is None or norm(unit)==expected_unit)
   if not valid:raise ValueError('Header/unit drift: '+key)
   headers[key]={'column':str(col),'header':head,'unit':unit}
  rows=[];seen=set()
  for n,cells in enumerate(ws.iter_rows(min_row=a,max_row=b,max_col=width),a):
   selected={k:raw(cells[col-1]) for k,col in cols.items()}
   code=selected['id'].strip();name=selected['name'].strip()
   if not code:
    if any(v.strip() for k,v in selected.items() if k not in ('id','name')):raise ValueError('Nutrient cells without food ID')
    continue # Blank or category row. No nutrients can be silently omitted.
   if not re.fullmatch(r'[1-9]\d{0,2}',code) or code in seen or not name or len(name)>120:raise ValueError('Food identity drift')
   seen.add(code); values={k:parse_value(v,FIELDS[k][1]) for k,v in selected.items() if k not in ('id','name')}
   evidence={'sheet':layout['sheet'],'row':str(n),'cells':selected,'headers':headers}
   c={'name':name,'source':{'provider':'taco','recordId':code,'version':RELEASE,'license':LICENSE,'retrievedAt':captured+'T00:00:00Z','attribution':ATTR},'base':{'value':100,'unit':'g'},'values':values,'preparation':'unknown','edibleBasis':'edible'}
   rows.append({'sourceId':code,'version':RELEASE,'composition':c,'rawEvidence':evidence,'sourceRecordSha256':digest(canonical(evidence)),'requiresReview':True})
  total=597 if test_count is None else test_count
  if seen!={str(n) for n in range(1,total+1)}:raise ValueError('Incomplete TACO Table 1 identity set')
  manifest={'provider':'taco','release':RELEASE,'captured':captured,'sourceWorkbookSha256':expected,'layoutSha256':layout_sha,'sourceUrl':URL,'license':LICENSE,'attribution':ATTR,'status':'CANDIDATES_ONLY','activation':False,'rows':len(rows),'fixtureOnly':test_count is not None}
  return sorted(rows,key=lambda r:int(r['sourceId'])),manifest
 finally:wb.close()
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('--sha256',required=True);p.add_argument('--layout',type=Path,required=True);p.add_argument('--layout-sha256',required=True);p.add_argument('--captured',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();print(json.dumps(export(*build(a.source,a.sha256,a.layout,a.layout_sha256,a.captured),a.out),ensure_ascii=False,indent=2))
