#!/usr/bin/env python3
"""Offline FoodData Central Foundation/SR Legacy CSV importer. No database/network access.
Requires the frozen official ZIP SHA-256. Writes a candidate-only release, not an approved corpus.
"""
import argparse,csv,hashlib,io,json,math,os,re,sys,tempfile,zipfile
from collections import defaultdict,Counter
from pathlib import Path
from datetime import date
# Verify exact nutrient id, label and unit against nutrient.csv in each release.
# Do not combine alternate energy or carbohydrate methods. Foundation 2047/2048 are not 1008.
MAP={1008:('energy_kcal','Energy','KCAL'),1003:('protein_g','Protein','G'),1004:('fat_g','Total lipid (fat)','G'),1005:('carbohydrate_g','Carbohydrate, by difference','G'),1079:('fiber_g','Fiber, total dietary','G'),1093:('sodium_mg','Sodium, Na','MG'),1087:('calcium_mg','Calcium, Ca','MG'),1089:('iron_mg','Iron, Fe','MG'),1092:('potassium_mg','Potassium, K','MG'),1090:('magnesium_mg','Magnesium, Mg','MG'),1091:('phosphorus_mg','Phosphorus, P','MG'),1095:('zinc_mg','Zinc, Zn','MG'),1103:('selenium_ug','Selenium, Se','UG'),1162:('vitamin_c_mg','Vitamin C, total ascorbic acid','MG'),1178:('vitamin_b12_ug','Vitamin B-12','UG'),1106:('vitamin_a_rae_ug','Vitamin A, RAE','UG'),1175:('vitamin_b6_mg','Vitamin B-6','MG'),1165:('thiamin_mg','Thiamin','MG'),1166:('riboflavin_mg','Riboflavin','MG'),1167:('niacin_mg','Niacin','MG'),1177:('folate_ug','Folate, total','UG'),1109:('vitamin_e_mg','Vitamin E (alpha-tocopherol)','MG'),1185:('vitamin_k_ug','Vitamin K (phylloquinone)','UG'),1257:('trans_fat_g','Fatty acids, total trans','G'),1258:('saturated_fat_g','Fatty acids, total saturated','G')}
UNIT={'G':'g','MG':'mg','UG':'ug','KCAL':'kcal'}
ATTR='U.S. Department of Agriculture, Agricultural Research Service. FoodData Central. https://fdc.nal.usda.gov/'
def digest(b):return hashlib.sha256(b).hexdigest()
def file_digest(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def archive_member(z,name):
 # No extraction. Accept only a unique case-insensitive basename in a safe relative path.
 # Backslash is an archive path separator, never an OS path; never choose one of duplicates.
 matches=[]
 for x in z.infolist():
  path=x.filename.replace('\\','/')
  if x.is_dir() or path.endswith('/'):continue
  if path.split('/')[-1].casefold()!=name.casefold():continue
  if path.startswith('/') or ':' in path or any(part in ('','.','..') for part in path.split('/')):raise ValueError(f'Unsafe archive member {name}')
  matches.append(x)
 if not matches:raise ValueError(f'Missing {name}')
 if len(matches)!=1:raise ValueError(f'Ambiguous {name}: {len(matches)} members')
 if matches[0].file_size>300_000_000:raise ValueError(f'Oversized {name}: {matches[0].file_size}')
 return matches[0]
def read_csv(z,name,fields):
 member=archive_member(z,name)
 with z.open(member) as f:
  with io.TextIOWrapper(f,encoding='utf-8-sig',errors='strict',newline='') as t:
   r=csv.DictReader(t); headers=r.fieldnames or []
   if len(set(headers))!=len(headers) or not set(fields)<=set(headers):raise ValueError(f'Header drift: {name}')
   for row in r:
    if None in row or any(v is None for v in row.values()):raise ValueError(f'Broken CSV row: {name}:{r.line_num}')
    yield row

def build(path,expected,release,captured,kind):
 if not re.fullmatch('[a-f0-9]{64}',expected) or file_digest(path)!=expected:raise ValueError('Source SHA mismatch')
 if not re.fullmatch(r'usda-(foundation|sr)-\d{4}-\d{2}(?:-v(?:[2-9]|[1-9]\d+))?',release) or not release.startswith('usda-'+('foundation' if kind=='foundation_food' else 'sr')+'-'):raise ValueError('Release identity')
 date.fromisoformat(captured)
 counts=Counter(); food={}; defs={}; profiles=defaultdict(dict); raw=defaultdict(dict); bad=defaultdict(set)
 with zipfile.ZipFile(path) as z:
  for r in read_csv(z,'nutrient.csv',('id','name','unit_name')):
   i=int(r['id']);
   if i in defs:raise ValueError('Duplicate nutrient id')
   defs[i]=r
  # Fail closed on semantic drift rather than choosing a different energy / sugar / folate definition.
  valid={i:v for i,v in MAP.items() if i in defs and defs[i]['name'].strip().casefold()==v[1].casefold() and defs[i]['unit_name'].strip().upper()==v[2]}
  if not {1003,1004,1005}<=valid.keys():raise ValueError('Core nutrient dictionary drift')
  for r in read_csv(z,'food.csv',('fdc_id','data_type','description','publication_date')):
   if r['data_type']!=kind:counts['other_food_type']+=1;continue
   i=r['fdc_id']; name=r['description'].strip()
   if not i.isascii() or not i.isdigit() or not name or len(name)>1000 or i in food:raise ValueError('Food identity drift')
   food[i]=r
  for r in read_csv(z,'food_nutrient.csv',('id','fdc_id','nutrient_id','amount')):
   i=r['fdc_id'];n=int(r['nutrient_id']);
   if i not in food:continue
   if n not in valid:counts['unmapped_nutrient']+=1;continue
   key,_,u=valid[n]
   # Any duplicate is ambiguous even if numerical values agree. Preserve evidence.
   if key in raw[i]:bad[i].add(key);counts['duplicate_nutrient']+=1;raw[i][key].append(r);continue
   raw[i][key]=[r]
   a=r['amount'].strip();loq=r.get('loq','').strip(); foot=r.get('footnote','').strip()
   if not a:profiles[i][key]={'state':'not_reported'};continue
   if not re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',a):bad[i].add(key);counts['malformed_amount']+=1;continue
   try: v=float(a)
   except ValueError:bad[i].add(key);counts['malformed_amount']+=1;continue
   if not math.isfinite(v) or v<0 or v>1e6:bad[i].add(key);counts['invalid_amount']+=1;continue
   # FDC stores some below-LOQ amounts as zero. No ambiguous zero is promoted to known.
   if loq or foot or v==0:
    profiles[i][key]={'state':'unknown'};counts['zero_or_qualified_review']+=1;continue
   profiles[i][key]={'state':'known','amount':v,'unit':UNIT[u]}
  rows=[]
  for i,r in sorted(food.items(),key=lambda p:int(p[0])):
   for key in bad[i]:profiles[i][key]={'state':'unknown'}
   evidence={'food':r,'nutrient_rows':raw[i]}
   # No claim of edible basis, preparation, portion/density, or equivalence by name.
   composition={'name':r['description'].strip(),'source':{'provider':'usda','recordId':i,'version':release,'license':'CC0-1.0','retrievedAt':captured+'T00:00:00Z','attribution':ATTR},'base':{'value':100,'unit':'g'},'values':profiles[i],'preparation':'unknown','edibleBasis':'unknown'}
   rows.append({'sourceId':i,'version':release,'composition':composition,'rawEvidence':evidence,'sourceRecordSha256':digest(canonical(evidence)),'requiresReview':True})
  if not rows:raise ValueError('Empty target data type')
  manifest={'provider':'usda','release':release,'captured':captured,'sourceZipSha256':expected,'sourceUrl':'https://fdc.nal.usda.gov/download-datasets/','license':'CC0-1.0','attribution':ATTR,'status':'CANDIDATES_ONLY','activation':False,'rows':len(rows),'counts':dict(counts),'verifiedNutrientIds':sorted(valid),'dictionaryMismatchIds':sorted(set(MAP)-set(valid))}
  return rows,manifest

def export(rows,manifest,out):
 out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
 if out.exists():raise FileExistsError('Immutable release destination exists')
 # Directory rename is atomic within one filesystem; never overwrite existing release.
 with tempfile.TemporaryDirectory(dir=out.parent,prefix='.fdc-') as t:
  p=Path(t)/'release';p.mkdir();b=b''.join(canonical(r)+b'\n' for r in rows);(p/'foods.jsonl').write_bytes(b);manifest={**manifest,'foodsSha256':digest(b)};(p/'manifest.json').write_bytes(canonical(manifest)+b'\n');os.rename(p,out)
 return manifest
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('--sha256',required=True);p.add_argument('--release',required=True);p.add_argument('--captured',required=True);p.add_argument('--kind',choices=['foundation_food','sr_legacy_food'],required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(); print(json.dumps(export(*build(a.source,a.sha256,a.release,a.captured,a.kind),a.out),ensure_ascii=False,indent=2))
