#!/usr/bin/env python3
"""Only for a generated Android review tree. Not called by existing CI/build."""
import argparse, pathlib, xml.etree.ElementTree as ET, hashlib
p=argparse.ArgumentParser();p.add_argument('manifest',type=pathlib.Path);p.add_argument('--preimage-sha256',required=True);p.add_argument('--write-review-copy',required=True,type=pathlib.Path);a=p.parse_args()
raw=a.manifest.read_bytes()
if hashlib.sha256(raw).hexdigest()!=a.preimage_sha256: raise SystemExit('DRIFT: manifest')
if a.write_review_copy.resolve()==a.manifest.resolve() or a.write_review_copy.exists(): raise SystemExit('Destination must be new and distinct')
ns='http://schemas.android.com/apk/res/android';ET.register_namespace('android',ns);key='{'+ns+'}name';root=ET.fromstring(raw)
if root.tag!='manifest' or root.find('application') is None: raise SystemExit('Invalid manifest')
perm='android.permission.health.READ_NUTRITION';existing=[x for x in root.findall('uses-permission') if x.get(key)==perm]
if len(existing)>1: raise SystemExit('Duplicate nutrition permission')
if not existing: root.insert(list(root).index(root.find('application')),ET.Element('uses-permission',{key:perm}))
with a.write_review_copy.open('xb') as f: ET.ElementTree(root).write(f,encoding='utf-8',xml_declaration=True)
