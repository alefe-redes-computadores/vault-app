#!/usr/bin/env python3
"""Review-only generated-platform preparation. Never called by CI until Guardian approval."""
import argparse,json,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
APP='com.alefejohsefe.vault'; A='{http://schemas.android.com/apk/res/android}'; MARK='// VAULT_NUTRITION_F2_BUNDLED_REVIEW'
BLOCK="\n"+MARK+"\ndependencies {\n    implementation 'com.google.mlkit:barcode-scanning:17.3.0'\n    implementation 'com.google.mlkit:text-recognition:16.0.1'\n}\n"
AUTH='${applicationId}.vaultnutritionprovider'; PROVIDER=APP+'.VaultNutritionFileProvider'
HC_NUTRITION="android.permission.health.READ_NUTRITION"
def plan(root, nutrition_hc=False):
    if json.loads((root/'capacitor.config.json').read_text())['appId']!=APP:raise ValueError('wrong app')
    java=root/'android/app/src/main/java'/Path(*APP.split('.'))
    mains=[p for p in (java/'MainActivity.java',java/'MainActivity.kt') if p.exists()]
    if len(mains)!=1:raise ValueError('MainActivity ambiguity')
    main=mains[0]; s=main.read_text(); isjava=main.suffix=='.java'; anchor='registerPlugin(VaultApkUpdaterPlugin.class);' if isjava else 'registerPlugin(VaultApkUpdaterPlugin::class.java);'
    if not isjava and anchor not in s:anchor=anchor.rstrip(';')
    reg='registerPlugin(VaultNutritionCapturePlugin.class);' if isjava else 'registerPlugin(VaultNutritionCapturePlugin::class.java)'
    if s.count(anchor)!=1 or 'registerPlugin(VaultHealthConnectPlugin' not in s:raise ValueError('prior native patches required')
    if 'VaultNutritionCapturePlugin' in s:
        if s.count(reg)!=1 or s.count('VaultNutritionCapturePlugin')!=1:raise ValueError('bridge drift')
    else:s=s.replace(anchor,anchor+'\n    '+reg)
    gradle=root/'android/app/build.gradle'; g=gradle.read_text()
    if 'VAULT_HEALTH_CONNECT_V113' not in g:raise ValueError('prior Java17 configuration required')
    if MARK in g:
        if g.count(BLOCK)!=1 or g.count('com.google.mlkit:barcode-scanning')!=1 or g.count('com.google.mlkit:text-recognition')!=1:raise ValueError('dependency drift')
    else:
        if re.search(r'(?:com\.google\.mlkit|com\.google\.android\.gms):(?:play-services-mlkit-)?(?:barcode-scanning|text-recognition)',g):raise ValueError('existing recognition dependency')
        g+=BLOCK
    manifest=root/'android/app/src/main/AndroidManifest.xml'; tree=ET.parse(manifest); m=tree.getroot(); apps=m.findall('application')
    if m.tag!='manifest' or len(apps)!=1:raise ValueError('manifest drift')
    permissions=[p for p in m if p.tag.startswith('uses-permission') and p.get(A+'name')==HC_NUTRITION]
    if permissions and (len(permissions)!=1 or permissions[0].tag!='uses-permission' or permissions[0].attrib!={A+'name':HC_NUTRITION} or len(permissions[0])):raise ValueError('nutrition permission drift')
    if nutrition_hc and not permissions: m.insert(list(m).index(apps[0]),ET.Element('uses-permission',{A+'name':HC_NUTRITION}))
    app=apps[0]; providers=[p for p in app.findall('provider') if p.get(A+'name')==PROVIDER or p.get(A+'authorities')==AUTH]
    expected={A+'name':PROVIDER,A+'authorities':AUTH,A+'exported':'false',A+'grantUriPermissions':'true'}
    meta={A+'name':'android.support.FILE_PROVIDER_PATHS',A+'resource':'@xml/vault_nutrition_paths'}
    if providers:
        if len(providers)!=1 or providers[0].attrib!=expected or len(providers[0])!=1 or providers[0][0].tag!='meta-data' or providers[0][0].attrib!=meta:raise ValueError('provider drift')
    else:ET.SubElement(ET.SubElement(app,'provider',expected),'meta-data',meta)
    ET.register_namespace('android','http://schemas.android.com/apk/res/android');ET.register_namespace('tools','http://schemas.android.com/tools')
    outputs={main:s.encode(),gradle:g.encode(),manifest:ET.tostring(m,encoding='utf-8',xml_declaration=True)}
    for name in ('VaultNutritionCapturePlugin.java','VaultNutritionFileProvider.java','vault_nutrition_paths.xml'):
        target=(root/'android/app/src/main/res/xml'/name) if name.endswith('.xml') else java/name
        src=(root/'native/nutrition'/name).read_bytes()
        if target.exists() and target.read_bytes()!=src:raise ValueError('existing native source drift: '+name)
        outputs[target]=src
    return outputs

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',required=True,type=Path);ap.add_argument('--isolated-review',action='store_true');ap.add_argument('--health-connect-nutrition-review',action='store_true');args=ap.parse_args()
    if not args.isolated_review:raise SystemExit('LOCKED: explicit isolated generated-platform review required')
    root=args.root.resolve()
    if (root/'.git').exists():raise SystemExit('LOCKED: do not run on working repository')
    outputs=plan(root,args.health_connect_nutrition_review)
    # Preflight every target before touching any bytes. Never changes CI or package files.
    for p in outputs:
        if not p.resolve().is_relative_to(root):raise ValueError('target outside root')
    for p,content in outputs.items():
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
    print('NUTRITION_GENERATED_PLATFORM_REVIEW_PREPARED',len(outputs),'NOT_BUILT_NOT_HOMOLOGATED')
if __name__=='__main__':main()
