'use strict';
// Historical host tests: explicit, hermetic dependency expansion for the REAL F2 projection.
// No stub, network, filesystem access from evaluated modules, arbitrary require, or gate suppression.
const fs=require('node:fs'), path=require('node:path'), vm=require('node:vm'), ts=require('typescript');
const root=path.resolve(__dirname,'..');
const allowed=new Set(['lib/vital/catalog.ts','lib/vital/projections.ts','lib/vital/validation.ts','lib/vital/facts.ts',...['catalog','consumer-projection','external-meal','health-connect-nutrition','label-confirmation','meal-draft','meal-history','nutrition','persistence','plan-targets','recipe-consumption','recipe-storage-validation'].map(n=>'lib/vital/nutrition-f2/'+n+'.ts')]);
function createLoader(){
 const cache=new Map();
 const realm=vm.createContext({console,structuredClone,encodeURIComponent,decodeURIComponent,TextEncoder,TextDecoder,crypto:globalThis.crypto});
 function load(name){
  if(!allowed.has(name))throw Error('Macro03 pure dependency not allowed: '+name);
  if(cache.has(name))return cache.get(name).exports;
  const source=fs.readFileSync(path.join(root,name),'utf8');
  const code=ts.transpileModule(source,{fileName:name,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true},reportDiagnostics:true});
  if(code.diagnostics?.some(d=>d.category===ts.DiagnosticCategory.Error))throw Error('Macro03 pure dependency has syntax errors: '+name);
  const mod={exports:{}};cache.set(name,mod);
  try{
   const deps=id=>{if(typeof id!=='string'||!id.startsWith('./')&&!id.startsWith('../'))throw Error('Macro03 non-relative pure dependency: '+id);return load(path.posix.normalize(path.posix.join(path.posix.dirname(name),id+'.ts')));};
   // Invoke inside VM timeout; never provide native require or process to application module.
   const key='__vaultInvocation';const previous=realm[key];realm[key]={module:mod,exports:mod.exports,require:deps};
   try{vm.runInContext('(function(module,exports,require){'+code.outputText+'\n})(__vaultInvocation.module,__vaultInvocation.exports,__vaultInvocation.require)',realm,{filename:name,timeout:7000});}finally{if(previous===undefined)delete realm[key];else realm[key]=previous;}
   return mod.exports;
  }catch(e){cache.delete(name);throw e;}
 }
 return {load};
}
const createConsumerProjection=()=>createLoader().load('lib/vital/nutrition-f2/consumer-projection.ts');
module.exports={createConsumerProjection,createLoader};
