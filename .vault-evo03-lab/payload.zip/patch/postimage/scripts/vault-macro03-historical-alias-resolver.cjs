// Macro03 R11: test-only resolution of the reviewed TS aliases.
// No mocks, no runtime changes, no alteration to any historical test assertion.
'use strict';
const fs=require('node:fs'), path=require('node:path'), Module=require('node:module'),crypto=require('node:crypto');
const root=fs.realpathSync(process.cwd());
const entry=fs.realpathSync(path.resolve(process.argv[1]||''));
const tests=new Set(["test-vault-m63-notifications-search.cjs", "test-vault-m2-pure-projections.cjs", "test-v286-planned-purchase-native-agenda.cjs", "test-v218-overdue-access-avatar.cjs", "test-v217-prescription-meaning-access-avatar.cjs", "test-v216-prescription-stages-brain-avatar.cjs", "test-v215-prescription-archive-withdrawal-avatar.cjs", "test-v214-care-network-index-avatar-brain.cjs", "test-v209-overdue-withdrawal-brain-avatar.cjs", "test-v204-access-brain-reminders-avatar.cjs", "test-vault-m150-p5-p4.cjs", "test-vault-m153-p7-build2117.cjs"]);
if(!tests.has(path.basename(entry))||entry!==path.join(root,'scripts',path.basename(entry)))throw Error('STOP historical test entry only');
const ts=require(require.resolve('typescript',{paths:[root]}));
const config=JSON.parse(fs.readFileSync(path.join(root,'tsconfig.json'),'utf8'));
if(JSON.stringify(config.compilerOptions.paths?.['@/*'])!==JSON.stringify(['./*'])||config.compilerOptions.baseUrl!=='.')throw Error('STOP unexpected @ alias contract');
const aliases=new Set(['@/lib/m3/notification-overrides','@/lib/m3/policy-record-p2','@/lib/careflow-m2/reminder-window','@/lib/careflow-m2/withdrawal-coherence']);
const inside=(p,dir=root)=>p.startsWith(dir+path.sep);
const realLib=fs.realpathSync(path.join(root,'lib'));
if(realLib!==path.join(root,'lib'))throw Error('STOP symlink lib');
const sourceModule=p=>typeof p==='string'&&inside(p,realLib)&&!p.includes(path.sep+'node_modules'+path.sep)&&/\.tsx?$/.test(p);
const original=Module._resolveFilename;
Module._resolveFilename=function(request,parent,...args){
 if(typeof request==='string'&&request.startsWith('@/')){
  const origin=parent?.filename||parent?.id;
  if(typeof origin!=='string'||!fs.existsSync(path.resolve(root,origin))||!inside(fs.realpathSync(path.resolve(root,origin))))throw Error('STOP alias caller outside source');
  if(!aliases.has(request))throw Error('STOP unreviewed alias '+request);
  const target=path.resolve(root,request.slice(2))+'.ts';
  if(!sourceModule(target)||!fs.existsSync(target)||fs.realpathSync(target)!==target)throw Error('STOP missing or unsafe alias source '+request);
  const resolved=original.call(this,target,parent,...args);
  if(resolved!==target)throw Error('STOP alias did not resolve exact source');
  console.error('R11_ALIAS '+JSON.stringify({request,source:path.relative(root,resolved),sha256:crypto.createHash('sha256').update(fs.readFileSync(resolved)).digest('hex')}));
  return resolved;
 }
 return original.call(this,request,parent,...args);
};
for(const ext of ['.ts','.tsx']){
 const prior=Module._extensions[ext];
 Module._extensions[ext]=function(mod,file){
  const actual=fs.realpathSync(file);
  if(!sourceModule(actual)){if(prior)return prior(mod,file);throw Error('STOP TS outside reviewed lib: '+file);}
  if(actual!==file)throw Error('STOP symlink TS source');
  const result=ts.transpileModule(fs.readFileSync(file,'utf8'),{fileName:file,reportDiagnostics:true,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}});
  if(result.diagnostics?.some(d=>d.category===ts.DiagnosticCategory.Error))throw Error('STOP TS transpile failed: '+file);
  mod._compile(result.outputText,file);
 };
}
