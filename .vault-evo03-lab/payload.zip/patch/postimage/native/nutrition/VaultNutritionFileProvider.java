package com.alefejohsefe.vault;
/** Dedicated private provider; never shares updater or clinical directories. */
public final class VaultNutritionFileProvider extends androidx.core.content.FileProvider {}
