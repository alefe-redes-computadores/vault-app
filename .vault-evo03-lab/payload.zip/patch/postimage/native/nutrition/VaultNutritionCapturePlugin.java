package com.alefejohsefe.vault;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.util.LinkedHashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Local, still-image capture. No account, nutrition write, network or image upload. */
@CapacitorPlugin(name = "VaultNutritionCapture")
public final class VaultNutritionCapturePlugin extends Plugin {
    private static final int MAX_SIDE = 2560;
    private static final long MAX_SOURCE_PIXELS = 100_000_000L;
    private static final int URI_FLAGS = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService decode = Executors.newSingleThreadExecutor();
    private Session active;
    private boolean destroyed;
    private static final class Session {
        final PluginCall call;
        final String mode, requestId;
        File temp;
        Uri cameraUri;
        boolean processing;
        Session(PluginCall c, String m, String id) { call=c; mode=m; requestId=id; }
    }
    private static JSObject status(String s) { return new JSObject().put("status",s); }
    @PluginMethod public void status(PluginCall call) {
        call.resolve(new JSObject().put("available",Build.VERSION.SDK_INT>=28).put("protocol",1)
            .put("barcodeModel","17.3.0").put("ocrModel","16.0.1").put("stillImage",true));
    }
    private File folder() { return new File(getContext().getCacheDir(),"nutrition-capture"); }
    /** Only our own abandoned temporary images, never another feature's cache. */
    private void sweep() {
        File[] files=folder().listFiles();
        if(files==null)return;
        long limit=System.currentTimeMillis()-24L*60*60*1000;
        for(File f:files) if(f.isFile() && f.getName().startsWith("capture-") && f.getName().endsWith(".jpg") && f.lastModified()<limit) f.delete();
    }
    @PluginMethod public void capture(PluginCall call) { main.post(()->begin(call)); }
    private void begin(PluginCall call) {
        String mode=call.getString("mode", ""), source=call.getString("source", ""), id=call.getString("requestId", "");
        if(!id.matches("[A-Za-z0-9_-]{8,100}") || !(mode.equals("barcode")||mode.equals("ocr")) || !(source.equals("camera")||source.equals("image"))) {call.resolve(status("invalid"));return;}
        if(destroyed || Build.VERSION.SDK_INT<28) {call.resolve(status("unavailable").put("requestId",id));return;}
        if(active!=null) {call.resolve(status("busy").put("requestId",id));return;}
        Session s=new Session(call,mode,id); active=s; sweep();
        try {
            Intent intent;
            if(source.equals("camera")) {
                File dir=folder(); if(!dir.isDirectory()&&!dir.mkdirs()) throw new IllegalStateException();
                s.temp=File.createTempFile("capture-",".jpg",dir);
                s.cameraUri=FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".vaultnutritionprovider",s.temp);
                intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT,s.cameraUri);
                intent.setClipData(ClipData.newRawUri("nutrition-capture",s.cameraUri));
                intent.addFlags(URI_FLAGS);
            } else {
                intent=new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            startActivityForResult(call,intent,"captureResult");
        } catch(SecurityException e) { finish(s,status("permission_denied")); }
        catch(Exception e) { finish(s,status("unavailable")); }
    }
    @ActivityCallback private void captureResult(PluginCall call,ActivityResult result) {
        Session s=active;
        if(s==null||call==null||s.processing||!s.call.getCallbackId().equals(call.getCallbackId())) return;
        s.processing=true;
        if(result.getResultCode()!=Activity.RESULT_OK) {finish(s,status("cancelled"));return;}
        Uri uri=s.cameraUri!=null?s.cameraUri:(result.getData()==null?null:result.getData().getData());
        if(uri==null||!"content".equals(uri.getScheme())) {finish(s,status("invalid"));return;}
        try { decode.execute(()->readImage(s,uri)); }
        catch(Exception e) {finish(s,status("error"));}
    }
    private void readImage(Session s,Uri uri) {
        Bitmap bitmap=null;
        try {
            // API 28+: decoder applies EXIF orientation; bounds checked before allocation.
            bitmap=ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContext().getContentResolver(),uri),(d,info,src)->{
                int w=info.getSize().getWidth(),h=info.getSize().getHeight();
                if(w<=0||h<=0||(long)w*h>MAX_SOURCE_PIXELS) throw new IllegalArgumentException("bounds");
                double scale=Math.min(1.0,(double)MAX_SIDE/Math.max(w,h));
                d.setTargetSize(Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)));
                d.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                d.setOnPartialImageListener(error->false);
            });
            Bitmap ready=bitmap; main.post(()->recognize(s,ready));
        } catch(SecurityException e) {if(bitmap!=null)bitmap.recycle();main.post(()->finish(s,status("permission_denied")));}
        catch(Exception | OutOfMemoryError e) {if(bitmap!=null)bitmap.recycle();main.post(()->finish(s,status("error")));}
    }
    private void recognize(Session s,Bitmap bitmap) {
        if(destroyed||active!=s){bitmap.recycle();return;}
        try {
            InputImage image=InputImage.fromBitmap(bitmap,0);
            if(s.mode.equals("barcode")) {
                BarcodeScannerOptions opts=new BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_EAN_13,Barcode.FORMAT_EAN_8,Barcode.FORMAT_UPC_A,Barcode.FORMAT_ITF).build();
                var scanner=BarcodeScanning.getClient(opts);
                try { scanner.process(image).addOnCompleteListener(task->{
                    try {
                        if(!task.isSuccessful()){finish(s,status("error"));return;}
                        LinkedHashSet<String> codes=new LinkedHashSet<>();
                        for(Barcode code:task.getResult()) {String v=code.getRawValue(); if(v!=null && ((code.getFormat()==Barcode.FORMAT_EAN_8 && v.matches("[0-9]{8}")) || (code.getFormat()==Barcode.FORMAT_UPC_A && v.matches("[0-9]{12}")) || (code.getFormat()==Barcode.FORMAT_EAN_13 && v.matches("[0-9]{13}")) || (code.getFormat()==Barcode.FORMAT_ITF && v.matches("[0-9]{14}")))) codes.add(v);}
                        if(codes.size()>64){finish(s,status("review_limit"));return;}
                        JSArray values=new JSArray(); for(String code:codes) values.put(code);
                        finish(s,status(codes.isEmpty()?"no_match":"barcode_candidates").put("codes",values));
                    } catch(Exception e){finish(s,status("error"));}
                    finally {scanner.close();bitmap.recycle();}
                }); } catch(Exception e){scanner.close();throw e;}
            } else {
                var recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                try { recognizer.process(image).addOnCompleteListener(task->{
                    try {
                        if(!task.isSuccessful()){finish(s,status("error"));return;}
                        Text text=task.getResult(); if(text.getText().trim().isEmpty()){finish(s,status("no_match"));return;}
                        if(text.getText().length()>20000){finish(s,status("review_limit"));return;}
                        JSArray tokens=new JSArray();
                        for(Text.TextBlock block:text.getTextBlocks()) for(Text.Line line:block.getLines()) for(Text.Element el:line.getElements()) {
                            Rect b=el.getBoundingBox();String raw=el.getText();
                            if(b==null||b.left<0||b.top<0||b.right>bitmap.getWidth()||b.bottom>bitmap.getHeight()||b.left>=b.right||b.top>=b.bottom||raw.trim().isEmpty()) continue;
                            if(tokens.length()>=4000||raw.length()>250){finish(s,status("review_limit"));return;}
                            JSArray box=new JSArray();box.put(b.left);box.put(b.top);box.put(b.right);box.put(b.bottom);
                            // Do not invent a confidence value when the engine does not expose a reliable one.
                            JSObject token=new JSObject().put("text",raw).put("box",box);token.put("confidence",org.json.JSONObject.NULL);tokens.put(token);
                        }
                        finish(s,status("ocr").put("text",text.getText()).put("recognizer","mlkit-latin-bundled").put("version","16.0.1")
                            .put("imageWidth",bitmap.getWidth()).put("imageHeight",bitmap.getHeight()).put("tokens",tokens));
                    } catch(Exception e){finish(s,status("error"));}
                    finally {recognizer.close();bitmap.recycle();}
                }); }catch(Exception e){recognizer.close();throw e;}
            }
        }catch(Exception e){bitmap.recycle();finish(s,status("error"));}
    }
    private void cleanup(Session s) {
        if(s.cameraUri!=null) try {getContext().revokeUriPermission(s.cameraUri,URI_FLAGS);} catch(Exception ignored){}
        if(s.temp!=null)s.temp.delete();
    }
    private void finish(Session s,JSObject response) {
        if(active!=s)return;
        active=null;cleanup(s);
        if(!destroyed)s.call.resolve(response.put("requestId",s.requestId));
    }
    @Override protected void handleOnDestroy() {
        destroyed=true; Session s=active;active=null;if(s!=null)cleanup(s);
        decode.shutdown();super.handleOnDestroy();
    }
}
