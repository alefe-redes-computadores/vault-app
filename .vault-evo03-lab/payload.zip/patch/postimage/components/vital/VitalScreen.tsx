"use client";
import {useEffect,useLayoutEffect,useState} from 'react';
import {useRouter,useSearchParams} from 'next/navigation';
import {Database,ChevronRight,RefreshCw,BookOpen,HeartPulse} from 'lucide-react';
import {useVitalRuntime} from '@/hooks/useVitalRuntime';
import {useReturnContext} from '@/hooks/useReturnContext';
import {useRegistrosSaude} from '@/hooks/useRegistrosSaude';
import {avatarWeightContext,healthReadingSource} from '@/lib/health-profile/avatar-readings';
import {withReturnTarget} from '@/lib/navigation/return-context';
import {sanitizeClinicalBackHrefUX360} from '@/lib/ui/clinical-a10-filter-session-ux360';
import {localDay,UUID} from '@/lib/vital/validation';
import {vitalHydrationToday} from '@/lib/vital/measurements';
import {VitalHub,type VitalDestination} from './VitalHub';
import {VitalChrome} from './VitalChrome';
import {VitalProgress} from './VitalProgressPanel';
import {vitalViewMemory} from '@/lib/vital/view-preferences';
import {useHapticFeedback} from '@/lib/haptics';
import {VitalTrainingPanel} from './VitalTrainingPanel';
import {VitalNutritionPanel} from './VitalNutritionPanel';
import {VitalPlansPanel} from './VitalPlansPanel';
import {VitalBackupPanel} from './VitalBackupPanel';
import {VitalReminderPanel} from './VitalReminderPanel';
import {panel,button} from './VitalPrimitives';
const routes:Record<VitalDestination,string>={settings:'/saude/vital?view=settings',newMeal:'/saude/vital/nutricao?action=new',newTraining:'/saude/vital/treinos?action=new',scanner:'/saude/vital/nutricao?action=scan',recipes:'/saude/vital/nutricao?action=recipes',healthConnect:'/saude/vital?view=settings#fontes-vital',hub:'/saude/vital',training:'/saude/vital/treinos',nutrition:'/saude/vital/nutricao',plans:'/saude/vital/planos',progress:'/saude/vital/evolucao',weight:'/saude/fenix',hydration:'/saude/hidratacao',reminders:'/saude/lembretes'};
type Area='hub'|'training'|'nutrition'|'plans'|'progress';
export function VitalScreen({area}:{area:Area}){
 const params=useSearchParams();const rawId=params.get('id');const recordId=rawId&&UUID.test(rawId)?rawId.toLowerCase():undefined;const rawCheckin=params.get('checkin');const checkinId=rawCheckin&&UUID.test(rawCheckin)?rawCheckin.toLowerCase():undefined;const create=params.get('action')==='new'&&!recordId&&!checkinId;
 const {trigger}=useHapticFeedback();const router=useRouter(),runtime=useVitalRuntime(),{registros,isLoading}=useRegistrosSaude();const {backTarget}=useReturnContext(area==='hub'?'/saude/minha-saude':routes.hub);const [today,setToday]=useState(()=>localDay(new Date()));useEffect(()=>{const update=()=>setToday(localDay(new Date()));const id=setInterval(update,30000);window.addEventListener('focus',update);return()=>{clearInterval(id);window.removeEventListener('focus',update);};},[]);
 const scope=runtime.scope;useLayoutEffect(()=>{if(scope)vitalViewMemory.activate(scope);else if(!runtime.loading)vitalViewMemory.activate(null);},[scope?.user_id,scope?.person_id,runtime.loading]);const origin=routes[area],target=sanitizeClinicalBackHrefUX360(backTarget);const back=target.split(/[?#]/)[0]===origin&&params.get('view')!=='settings'?(area==='hub'?'/saude/minha-saude':routes.hub):target;const settings=area==='hub'&&params.get('view')==='settings';
 const navigate=(r:VitalDestination)=>{trigger('light');const href=r==='healthConnect'&&runtime.nutritionConnect?'/saude/vital/nutricao?action=import':routes[r];const parent=r==='hub'?area==='hub'?back:routes.hub:settings?routes.settings:origin;router.push(withReturnTarget(href,parent));};
 const requested=params.get('action');const entry=!recordId&&!checkinId&&(requested==='scan'||requested==='recipes'||requested==='import')?requested:undefined;
 if(runtime.loading)return <main className="p-4 vault-adaptive-tail" role="status">Carregando pessoa ativa…</main>;
 if(!scope)return <main className="p-4 vault-adaptive-tail"><p role="alert">Selecione uma pessoa da conta para acessar o Vital.</p><button type="button" className={button} onClick={()=>router.push('/saude/minha-saude')}>Minha Saúde</button></main>;
 const owned=registros.filter(r=>r.user_id===scope.user_id&&r.person_id===scope.person_id);const context=avatarWeightContext(owned,scope.person_id,scope.user_id,today);const weight=context.latest;const water=vitalHydrationToday(scope,today,owned.map(r=>({...r,user_id:scope.user_id,person_id:scope.person_id})));
 const value=isLoading||!weight?null:{value:`${weight.valor_numerico?.toLocaleString('pt-BR')} kg`,source:healthReadingSource(weight.source)};
 const hydration=isLoading||water.amount===null?null:{value:`${water.amount.toLocaleString('pt-BR')} mL`,source:'Registros de saúde de hoje'};
 return <main key={`${scope.user_id}:${scope.person_id}`} className="mx-auto min-w-0 max-w-3xl space-y-3 px-3 pt-3 vault-adaptive-tail sm:px-5">
  <VitalChrome area={area} settings={settings} editingEntry={!!(create||recordId||checkinId||entry)} onBack={()=>{trigger('light');router.replace(settings&&back.split(/[?#]/)[0]===routes.hub?routes.hub:back);}} onNavigate={navigate}/>
  {settings?<section className="space-y-3" aria-label="Configurações do Vital"><h1 className="text-lg font-semibold">Configurações</h1><article id="fontes-vital" className={`${panel} space-y-2`}><h2 className="flex items-center gap-2 font-semibold"><HeartPulse size={20} className="text-pink-300"/> Fontes e dispositivos</h2><p className="text-sm text-ink-muted">A disponibilidade e as permissões são verificadas pelo sistema de fontes de saúde. Nenhuma conexão é presumida.</p><button type="button" className={`${button} flex w-full items-center gap-2 text-left`} onClick={()=>router.push(withReturnTarget('/saude/fenix#fontes',routes.settings))}><Database size={18}/> Abrir fontes de saúde <ChevronRight size={18} className="ml-auto"/></button>{runtime.nutritionConnect&&<button type="button" className={`${button} w-full`} onClick={()=>navigate('healthConnect')}>Revisar importação nutricional</button>}</article><article className={`${panel} space-y-2`}><h2 className="flex items-center gap-2 font-semibold"><BookOpen size={20} className="text-orange-300"/> Catálogos e preferências</h2><button type="button" className={`${button} w-full`} onClick={()=>navigate('nutrition')}>Alimentos e preferências nutricionais</button><button type="button" className={`${button} w-full`} onClick={()=>navigate('training')}>Exercícios e favoritos</button><button type="button" className={`${button} w-full`} onClick={()=>navigate('plans')}>Planos e metas pessoais</button></article><VitalBackupPanel scope={scope} repo={runtime.repo} restore={runtime.restoreBackup}/><button type="button" className={`${panel} flex w-full items-center gap-2 text-left`} onClick={()=>router.push(withReturnTarget('/mais',routes.settings))}><RefreshCw size={20} className="text-teal-300"/><span className="flex-1">Sincronização e diagnóstico do VAULT</span><ChevronRight size={18}/></button></section>:area==='hub'?<VitalHub repo={runtime.repo} scope={scope} today={today} onNavigate={navigate} weight={value} hydration={hydration} readingsLoading={isLoading} nutritionF2Enabled={runtime.nutritionF2Enabled===true} recipesEnabled={runtime.recipesEnabled===true&&runtime.nutritionF2Enabled===true} nutritionConnectEnabled={!!runtime.nutritionConnect}/>:area==='training'?<VitalTrainingPanel recordId={recordId} checkinId={checkinId} create={create} drafts={runtime.drafts} repo={runtime.repo} scope={scope} today={today}/>:area==='nutrition'?<VitalNutritionPanel nutritionF2Enabled={runtime.nutritionF2Enabled} recipesEnabled={runtime.recipesEnabled} nutritionConnect={runtime.nutritionConnect} recordId={recordId} checkinId={checkinId} create={create} entry={entry} drafts={runtime.drafts} repo={runtime.repo} scope={scope} today={today}/>:area==='plans'?<VitalPlansPanel drafts={runtime.drafts} repo={runtime.repo} scope={scope} today={today}/>:<VitalProgress repo={runtime.repo} scope={scope} today={today} weight={value} hydration={hydration} records={owned} readingsLoading={isLoading} onNavigate={navigate}/>}
  {!settings&&<VitalReminderPanel area={area} origin={origin}/>}
 </main>;
}
