'use client';
import { useEffect,useRef,useState } from 'react';
import { Camera,ImagePlus,ScanBarcode,ScanText,Keyboard,TriangleAlert,ChevronLeft,Check } from 'lucide-react';
import type { Scope } from '@/lib/vital/nutrition-f2/nutrition';
import type { CaptureTicket } from '@/lib/vital/nutrition-f2/capture-session';
import { createNutritionCapture } from '@/lib/vital/nutrition-f2/native-capture-bridge';
import type { CaptureReview, NativeCaptureSource } from '@/lib/vital/nutrition-f2/native-capture-contract';
type OCR=Extract<CaptureReview,{status:'ocr_review'}>;
type Props={scope:Scope;editorId:string;onManual:()=>void;onBack:()=>void}&({mode:'barcode';onBarcode:(code:string)=>void;onOcrReview?:never}|{mode:'ocr';onOcrReview:(result:OCR)=>void;onBarcode?:never});
const labels:Record<string,string>={busy:'Uma captura está em andamento.',cancelled:'Captura cancelada.',unavailable:'A leitura nativa não está disponível neste aparelho. Use o registro manual.',permission_denied:'O acesso à imagem não foi autorizado.',error:'Não foi possível ler a imagem. Tente novamente.',no_match:'Nenhum código ou texto reconhecido. Confira a luz e o enquadramento.',invalid:'O resultado não pôde ser validado.',review_limit:'Imagem muito extensa para revisão segura. Fotografe apenas a tabela.'};
const button='min-h-12 rounded-xl border border-surface-border px-3 py-2 text-left flex items-center gap-3 focus-visible:ring-2 focus-visible:ring-sky-300 disabled:opacity-50';
/** Unmounted review candidate. Parent must own draft, person scope and semantic review. No direct meal save. */
export function NativeCaptureReview({scope,editorId,mode,onBarcode,onOcrReview,onManual,onBack}:Props){
 const identity=`${scope.user_id}:${scope.person_id}:${editorId}:${mode}`;
 const identityRef=useRef(identity);identityRef.current=identity;
 const ticket=useRef<CaptureTicket|null>(null);const alive=useRef(true);
 const controller=useRef<ReturnType<typeof createNutritionCapture>|null>(null);
 const [busy,setBusy]=useState(false);const [result,setResult]=useState<CaptureReview|null>(null);const [selected,setSelected]=useState<string|null>(null);
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;ticket.current=null;}},[]);
 useEffect(()=>{ticket.current=null;setResult(null);setSelected(null);},[identity]);
 async function launch(source:NativeCaptureSource){
  if(busy||ticket.current)return;
  const begun=identity;
  const t:CaptureTicket={scope:{...scope},editorId,mode,requestId:crypto.randomUUID()};ticket.current=t;
  // Each editor identity must use its own controller closure. Existing native flight remains serialized by the plugin.
  controller.current=createNutritionCapture(()=>ticket.current&&identityRef.current===begun?ticket.current:null);
  setBusy(true);setSelected(null);setResult(null);
  const reply=await controller.current.capture(t,source);
  if(!alive.current)return;
  if(ticket.current?.requestId===t.requestId)ticket.current=null;
  setBusy(false);
  if(identityRef.current===begun&&reply.status!=='stale')setResult(reply);
 }
 function leave(fn:()=>void){ticket.current=null;setResult(null);fn();}
 return <section className="space-y-4" aria-label="Captura nutricional">
  <header className="flex items-center gap-3"><button className={button} onClick={()=>leave(onBack)} type="button" aria-label="Voltar"><ChevronLeft size={20}/></button><div className="min-w-0"><h2 className="text-lg font-semibold">{mode==='barcode'?'Identificar produto':'Ler tabela nutricional'}</h2><p className="text-xs text-ink-muted">Leitura local · revisão obrigatória</p></div>{mode==='barcode'?<ScanBarcode className="ml-auto shrink-0 text-cyan-300" size={26}/>:<ScanText className="ml-auto shrink-0 text-violet-300" size={26}/>}</header>
  <p className="text-sm text-ink-muted">{mode==='barcode'?'Enquadre apenas o código de barras, com boa iluminação.':'Fotografe os cabeçalhos, as unidades e todas as linhas da tabela.'} A imagem não é incorporada ao diário.</p>
  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2"><button type="button" className={`${button} text-cyan-200`} disabled={busy} onClick={()=>void launch('camera')}><Camera size={21}/>Fotografar</button><button type="button" className={button} disabled={busy} onClick={()=>void launch('image')}><ImagePlus size={21}/>Escolher imagem</button></div>
  {busy&&<p role="status" className="text-sm text-sky-200">Aguardando leitura… Você pode voltar sem registrar nada.</p>}
  {result&&result.status in labels&&<p role="status" className="flex gap-2 text-sm text-amber-200"><TriangleAlert size={18} className="shrink-0"/>{labels[result.status]}</p>}
  {result?.status==='barcode_review'&&<div className="space-y-2"><h3 className="font-medium">Confirme o código identificado</h3>{result.codes.map(code=><button key={code} type="button" aria-pressed={selected===code} className={`${button} w-full tabular-nums ${selected===code?'border-cyan-300 text-cyan-200':''}`} onClick={()=>setSelected(code)}>{code}{selected===code&&<Check className="ml-auto" size={18}/>}</button>)}<button className={`${button} w-full bg-emerald-900 text-white`} type="button" disabled={!selected} onClick={()=>selected&&onBarcode&&leave(()=>onBarcode(selected))}>Buscar produto pelo código</button></div>}
  {result?.status==='ocr_review'&&<div className="space-y-2"><h3 className="font-medium text-violet-200">Texto capturado</h3><p className="text-xs text-ink-muted">A posição das colunas ainda precisa ser conferida. Nenhum nutriente foi confirmado.</p><pre className="max-h-52 overflow-auto whitespace-pre-wrap break-words rounded-xl border border-surface-border p-3 text-xs">{result.text}</pre><button type="button" className={`${button} w-full bg-violet-900 text-white`} onClick={()=>onOcrReview&&leave(()=>onOcrReview(result))}>Revisar colunas e nutrientes</button></div>}
  <button type="button" className={`${button} w-full`} onClick={()=>leave(onManual)}><Keyboard size={19}/>Registrar manualmente</button>
 </section>;
}
