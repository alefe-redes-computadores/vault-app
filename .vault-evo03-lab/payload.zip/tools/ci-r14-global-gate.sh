#!/usr/bin/env bash
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r14 ]] || { echo 'STOP branch';exit 2; }
[[ "$EVO03_LAB" == "$RUNNER_TEMP/evo03-lab" ]] || { echo 'STOP path';exit 2; }
cd "$EVO03_LAB/candidate"
mkdir -p "$RUNNER_TEMP/evo03-r14-host"
VAULT_V63_COLLECT_ALL=1 node scripts/test-v63-release-gate.mjs 2>&1 | tee "$RUNNER_TEMP/evo03-r14-host/global-gate.log"
