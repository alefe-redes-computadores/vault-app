#!/usr/bin/env python3
"""Generate full collection from the exact R23 cases without editing their data."""
import json,sys,hashlib,re
from pathlib import Path
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
summary=json.loads((root/'summary.json').read_text());assert sum(x['checks'] for x in summary['cohorts'])==6752
scope="'90000000-0000-4000-8000-000000000001'::uuid,'90000000-0000-4000-8000-000000000011'::uuid"
for row in summary['cohorts']:
 i=row['cohort'];p=root/f'cohort-{i}.sql';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];s=b.decode()
 start=s.index('DO $$ DECLARE r record; n int:=0; got boolean;');end=s.index('\nRESET ROLE;',start);old=s[start:end];assert 'R23 cohort' in old and old.count('vault_nutrition_f2_review.recompute(')==1
 loop=f'''DO $$ DECLARE r record; n int:=0; bad int:=0; got boolean; err text; BEGIN
 FOR r IN SELECT * FROM pg_temp.r23_cases ORDER BY label LOOP
  got:=NULL;err:=NULL;
  BEGIN got:=vault_nutrition_f2_review.recompute({scope},r.legacy,r.env); EXCEPTION WHEN OTHERS THEN err:=SQLSTATE; END;
  IF err IS NOT NULL OR got IS DISTINCT FROM r.expected THEN bad:=bad+1; RAISE NOTICE 'R24_MISMATCH %',jsonb_build_object('cohort',{i},'label',r.label,'expected',r.expected,'got',got,'error',err)::text; END IF;
  n:=n+1;
 END LOOP;
 IF n<>{row['checks']} THEN RAISE EXCEPTION 'R24 case cardinality'; END IF;
 RAISE NOTICE 'R24_RESULT {i} % %',n,bad;
END $$;'''
 base=s[:start]+loop+s[end:];(out/f'base-{i}.sql').write_text(base)
 directed=''
 if i==0:
  directed=f'''
DO $$ DECLARE r record; sid text; e jsonb; p text[]; n int:=0; v jsonb; candidate jsonb; BEGIN
 SELECT * INTO STRICT r FROM pg_temp.r23_cases WHERE label='basis:["usda","usda-foundation-2026-10-v2+vault-r22-proposal-basis","1104705"]:g';
 sid:=r.legacy->0->>'id';p:=ARRAY['items',sid,'coverage','selenium_ug'];e:=r.env;
 IF vault_nutrition_f2_review.recompute({scope},r.legacy,e) IS DISTINCT FROM true THEN RAISE EXCEPTION 'R24 historical regression'; END IF;n:=n+1;
 FOR v IN SELECT x FROM jsonb_array_elements('[63,0,-62.746,null,"62.746",true]'::jsonb) t(x) LOOP
  candidate:=jsonb_set(e,p||ARRAY['amount'],v);
  IF vault_nutrition_f2_review.recompute({scope},r.legacy,candidate) IS DISTINCT FROM false THEN RAISE EXCEPTION 'R24 amount tamper %',v;END IF;n:=n+1;
 END LOOP;
 FOR candidate IN SELECT x FROM jsonb_array_elements(jsonb_build_array(
  e#-(p||ARRAY['amount']),e#-(p||ARRAY['estimatedSubtotal']),jsonb_set(e,p||ARRAY['estimatedSubtotal'],'0'::jsonb),jsonb_set(e,p||ARRAY['known'],'0'::jsonb),jsonb_set(e,p||ARRAY['complete'],'false'::jsonb),jsonb_set(e,p||ARRAY['counts','known'],'0'::jsonb),jsonb_set(e,p||ARRAY['scope'],'"all_intake"'::jsonb),jsonb_set(e,p||ARRAY['extra'],'1'::jsonb),
  jsonb_set(e,ARRAY['items',sid,'coverage','fiber_g','amount'],'0'::jsonb),
  jsonb_set(e,ARRAY['items',sid,'payload','totals','selenium_ug','amount'],'63'::jsonb),
  jsonb_set(jsonb_set(e,ARRAY['items',sid,'payload','totals','selenium_ug','amount'],'63'::jsonb),p||ARRAY['amount'],'63'::jsonb)
 )) t(x) LOOP
  IF vault_nutrition_f2_review.recompute({scope},r.legacy,candidate) IS DISTINCT FROM false THEN RAISE EXCEPTION 'R24 directed tamper %',n; END IF;n:=n+1;
 END LOOP;
 IF n<>18 THEN RAISE EXCEPTION 'R24 directed count %',n; END IF; RAISE NOTICE 'R24_RECOMPUTE_DIRECTED_PASS %',n;
END $$;
'''
 fixed=base.replace('\nRESET ROLE;',directed+'\nRESET ROLE;',1);(out/f'fixed-{i}.sql').write_text(fixed)
print('R24_EXACT_R23_CORPUS_PRESERVED 6752')
