#!/usr/bin/env bash
# Optional owner-run launcher. Does not use tokens from chat, deploy, merge or modify a working tree.
set -euo pipefail
[[ $# == 3 ]] || { echo 'Usage: bash launch-guardian-lab.sh EXISTING_REPO CI_PAYLOAD.zip EXPECTED_SHA256';exit 2; }
repo=$(realpath "$1"); payload=$(realpath "$2"); sha=$3
base=bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b
branch=vault/lab/evolution03-20261126-r09
[[ $sha =~ ^[0-9a-f]{64}$ ]] || exit 2
[[ $(sha256sum "$payload" | cut -d' ' -f1) == "$sha" ]] || { echo 'STOP payload SHA';exit 2; }
python3 - "$payload" <<'PYZIP'
import sys,zipfile,pathlib,stat
with zipfile.ZipFile(sys.argv[1]) as z:
 names=z.namelist();assert len(names)==len(set(names)), 'duplicate archive paths'
 assert sum(i.file_size for i in z.infolist())<=100_000_000, 'archive size'
 for i in z.infolist():
  p=pathlib.PurePosixPath(i.filename)
  assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr>>16), 'unsafe archive path'
 assert {'tools/ci-prepare.sh','tools/guardian-remote-lab.yml','CI-SHA256SUMS.txt'}<=set(names), 'missing CI paths'
PYZIP
origin=$(git -C "$repo" remote get-url origin)
case "$origin" in
 https://github.com/alefe-redes-computadores/vault-app|https://github.com/alefe-redes-computadores/vault-app.git|git@github.com:alefe-redes-computadores/vault-app.git|ssh://git@github.com/alefe-redes-computadores/vault-app.git) ;;
 *) echo 'STOP wrong origin';exit 2;;
esac
# Do not depend on the owner's local HEAD or change their checkout.
remote_main=$(git ls-remote --exit-code "$origin" refs/heads/main | cut -f1)
[[ $remote_main == "$base" ]] || { echo 'STOP main advanced or differs; reconcile again';exit 2; }
set +e;git ls-remote --exit-code --heads "$origin" "refs/heads/$branch" >/dev/null; r=$?;set -e
[[ $r == 2 ]] || { echo 'STOP branch exists or remote cannot be verified';exit 2; }
work=$(mktemp -d);trap 'rm -rf -- "$work"' EXIT
git clone --no-local --no-checkout "$repo" "$work/repo"
cd "$work/repo"
git fetch --no-tags "$origin" "$base"
git checkout --detach "$base"
[[ $(git rev-parse HEAD) == "$base" ]] || exit 2
mkdir -p .vault-evo03-lab .github/workflows
cp "$payload" .vault-evo03-lab/payload.zip
printf '%s  .vault-evo03-lab/payload.zip\n' "$sha" > .vault-evo03-lab/payload.sha256
unzip -p "$payload" tools/ci-prepare.sh > .vault-evo03-lab/prepare.sh
unzip -p "$payload" tools/guardian-remote-lab.yml > .github/workflows/vault-evolution03-guardian-lab.yml
# Disable Git integration deploy for this branch, in its FIRST commit.
printf '{"git":{"deploymentEnabled":false}}\n' > vercel.json
# No app changes on the branch itself: Actions materializes the validated candidate in RUNNER_TEMP.
git add -- .vault-evo03-lab/payload.zip .vault-evo03-lab/payload.sha256 .vault-evo03-lab/prepare.sh .github/workflows/vault-evolution03-guardian-lab.yml vercel.json
git diff --cached --check
git -c user.name='VAULT Guardian Laboratory' -c user.email='vault-guardian-lab@users.noreply.github.com' commit -m 'test(vault): isolated Macro03 laboratory, no deployment'
# Non-force push, only the laboratory ref; no merge or main update.
[[ $(git ls-remote --exit-code "$origin" refs/heads/main | cut -f1) == "$base" ]] || { echo 'STOP main moved before laboratory push';exit 2; }
git push "$origin" "HEAD:refs/heads/$branch"
printf 'LAB BRANCH=%s COMMIT=%s\n' "$branch" "$(git rev-parse HEAD)"
