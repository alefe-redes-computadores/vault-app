#!/usr/bin/env bash
# Same immutable authority generator as certified R17.2; no DB or remote service.
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r191 ]] || { echo 'STOP branch'; exit 2; }
[[ -n ${RUNNER_TEMP:-} && ${EVO03_LAB:-} == "$RUNNER_TEMP/evo03-lab" ]] || { echo 'STOP path'; exit 2; }
root=$EVO03_LAB
work=$(mktemp -d "$RUNNER_TEMP/evo03-r191-catalog.XXXXXX")
trap 'rm -rf -- "$work"' EXIT
mkdir -p "$work/current/lib" "$work/cases"
cp -a "$root/tests/fixture-lib/." "$work/current/lib/"
(cd "$work/current"; mapfile -d '' files < <(find lib/vital -name '*.ts' -print0); "$root/candidate/node_modules/.bin/tsc" --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}")
node "$root/tools/r17-catalog-proof.cjs" "$work/current/build" "$root/evidence/rodada-R05" "$root/evidence/r15/catalog-review-ledger.jsonl" "$work/cases"
node "$root/tools/r17-catalog-diary.cjs" "$work/current/build" "$work/cases"
# Pin the actual R17.2 certified artifact, not an independently invented fixture.
printf '%s  %s\n' '9d35a4bfd2f030a84bbfbdc5cc674375050eaab53ec313a45cd7a4d29846eaad' "$work/cases/catalog-lab-authority.json" | sha256sum -c -
# Refuse an existing directory to prevent stale evidence from passing.
mkdir "$RUNNER_TEMP/evo03-r17-catalog-ui"
cp "$work/cases/catalog-lab-authority.json" "$RUNNER_TEMP/evo03-r17-catalog-ui/"
mkdir -p "$RUNNER_TEMP/evo03-r19-catalog-evidence"
cp "$work/cases/catalog-proof-summary.json" "$work/cases/catalog-lab-authority.sha256" "$RUNNER_TEMP/evo03-r19-catalog-evidence/"
echo R191_CATALOG_AUTHORITY_READY
