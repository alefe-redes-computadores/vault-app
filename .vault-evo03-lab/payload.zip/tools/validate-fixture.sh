#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."; root=$PWD
work=$(mktemp -d); trap 'rm -rf -- "$work"' EXIT
mkdir -p "$work/lib" "$work/tests";cp -a tests/fixture-lib/. "$work/lib/";cp tests/*.cjs "$work/tests/"
while IFS= read -r -d '' f;do cmp "$f" "$root/candidate/${f#"$work/"}";done < <(find "$work/lib" -type f -name '*.ts' -print0)
cd "$work";mapfile -d '' files < <(find lib/vital -name '*.ts' -print0)
tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}"
for tz in UTC America/Sao_Paulo America/New_York;do echo "FUSO=$tz"; TZ="$tz" node --test tests/{f2-transport-compat,finalize-meal-batch,f2-integration,r05-controller,remote-meal,recover-meal-batch,recipe-storage,recipe-consumption,native-capture,label-meal-journey,f2-meal-lifecycle,f2-consumers-external,remote-recipe,remote-external-review,queue-recipe-batch,view-preferences,weekly-plan,r13-integrated-transport,r14-plan-target-transport}.cjs;done
node tests/vital-behavior.cjs;node tests/vital-cloud.cjs
