'use strict';
// Real official records, two fixed experimental selections, entirely synthetic people and meals.
// Existing production capability remains null. No remote adapter is bypassed in the app.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {loadCatalogReview,key,stable,sha}=require('./catalog-authority-review.cjs');
const [build,corpus,ledger,out]=process.argv.slice(2);if(!build||!corpus||!ledger||!out)throw Error('Usage: build corpus ledger output');
const req=n=>require(path.resolve(build,'vital',n));
const {prepareMealEnvelope,verifyMealEnvelope}=req('nutrition-f2/persistence');
const {draftAdd}=req('nutrition-f2/meal-draft');
const {prepareRecipeVersion}=req('nutrition-f2/recipe-contract');
const {recipeConsumptionDraft}=req('nutrition-f2/recipe-consumption');
const {reviewedSnapshot}=req('nutrition-f2/nutrition');
const {vitalPayload}=req('cloud-transport');
const {certifiedVitalF2Release}=req('nutrition-f2/release-capability');
const {assertMealStepSupported}=req('nutrition-f2/remote-meal');
const {recipeRequest}=req('nutrition-f2/remote-recipe');
const id=n=>`90000000-0000-4000-8000-${String(n).padStart(12,'0')}`,scope={user_id:id(1),person_id:id(11)},at='2026-11-27T12:00:00.000Z';
const row=(n)=>({...scope,id:id(n),created_at:at,updated_at:at,deleted_at:null,revision:1,synced:false});
let tests=0;function pass(name,fn){fn();tests++;console.log('R17_CATALOG_LOCAL_PASS',name);}
(async()=>{
 assert.equal(certifiedVitalF2Release(),null);const review=await loadCatalogReview(build,corpus,ledger),lab=review.createLabAuthority();
 const records=lab.records(),keys=records.map(r=>key(r.provider,r.release,r.record_id));
 pass('all 1095 source records and zero production approvals',()=>{assert.equal(review.total,1095);assert.equal(review.approved,0);assert.equal(records.length,2);});
 pass('accent insensitive, explicit provider, no cross-provider merge',()=>{assert.equal(review.search('abácate','taco').hits[0].id,'163');assert.equal(review.search('abacate','usda').total,0);assert.equal(lab.search('beans','usda').total,1);assert.equal(review.search('').total,0);});
 pass('invalid query and limits fail closed',()=>{assert.throws(()=>review.search('a','tbca'));assert.throws(()=>review.search('a',undefined,101));});
 const pending=review.search('arroz','taco').hits[0];assert.ok(pending&&!keys.includes(pending.key));
 pass('pending row cannot be selected, even in lab',()=>assert.throws(()=>lab.select(scope,pending.key,id(1101),{value:100,unit:'g'})));
 pass('unknown provider/version/id cannot select',()=>{for(const k of [key('tbca','x','163'),key('taco','wrong','163'),key('taco','taco-2011-4ed','999')])assert.throws(()=>lab.select(scope,k,id(1101),{value:100,unit:'g'}));});
 pass('invalid scope and unsupported mass conversion blocked',()=>{assert.throws(()=>lab.select({user_id:'bad',person_id:scope.person_id},keys[0],id(1101),{value:1,unit:'g'}));for(const quantity of [{value:1,unit:'portion'},{value:1,unit:'mL'},{value:0,unit:'g'},{value:NaN,unit:'g'}])assert.throws(()=>lab.select(scope,keys[0],id(1101),quantity));});
 const a=lab.select(scope,keys[0],id(1101),{value:80,unit:'g'}),b=lab.select(scope,keys[1],id(1102),{value:.12,unit:'kg'});
 pass('fresh snapshots are unreviewed and cannot seal',()=>{assert.equal(a.reviewed,false);assert.equal(b.reviewed,false);assert.throws(()=>lab.validateItem(a));assert.throws(()=>prepareMealEnvelope(scope,{scope,mealId:id(1110),operationId:id(1111),items:[a,b]},at,lab.policies()));});
 pass('frozen original unaffected by mutable preview',()=>{const copy=lab.records();copy[0].composition.name='changed';assert.equal(lab.records()[0].composition.name,records[0].composition.name);assert.throws(()=>lab.check(copy[0].composition));});
 const reviewed=[{...a,reviewed:true},{...b,reviewed:true}];
 let draft={scope,mealId:id(1110),operationId:id(1111),items:[]};for(const i of reviewed){lab.validateItem(i);draft=draftAdd(draft,i);}
 pass('multi-add and duplicate identity rejection',()=>{assert.equal(draft.items.length,2);assert.throws(()=>draftAdd(draft,reviewed[0]));});
 const meal=prepareMealEnvelope(scope,draft,at,lab.policies());
 pass('canonical meal envelope retains source and no fake legacy nutrients',()=>{verifyMealEnvelope(scope,meal.items,meal.nutrition_f2);assert.deepEqual(meal.items.map(i=>i.nutrients),[{},{}]);assert.equal(meal.nutrition_f2.items[a.id].payload.composition.source.provider,'taco');assert.equal(meal.nutrition_f2.items[b.id].conversion.basisAmount,120);assert.throws(()=>verifyMealEnvelope({...scope,person_id:id(12)},meal.items,meal.nutrition_f2));});
 pass('missing nutrient remains missing and no zero invented',()=>{const c=meal.nutrition_f2.items[a.id];assert.equal(c.payload.composition.values.vitamin_b12_ug,undefined);assert.equal(c.payload.totals.vitamin_b12_ug,undefined);assert.equal(c.coverage.vitamin_b12_ug.amount,null);});
 pass('composition drift fails even with recalculated totals',()=>{const bad=structuredClone(a.composition);bad.values.protein_g.amount+=1;assert.throws(()=>lab.check(bad));});
 pass('runtime remains closed (not dormant release certification)',()=>assert.throws(()=>assertMealStepSupported({meal:{nutrition_f2:meal.nutrition_f2}})));
 const mrow={...row(1110),day:'2026-11-27',time:'08:00',kind:'breakfast',custom_label:null,plan_version_id:null,notes:null,items:meal.items,nutrition_f2:meal.nutrition_f2};
 const head={...row(1120),kind:'recipe',name:'LAB catalog recipe',favorite:false,active:true};
 const ingredients=reviewed.map((i,n)=>{const fresh=lab.select(scope,keys[n],id(1122+n),i.quantity);return reviewedSnapshot(scope,fresh.id,fresh.composition,fresh.quantity,at).payload;});
 const v=prepareRecipeVersion(scope,head,[],1,null,{id:id(1121),name_snapshot:head.name,ingredients,raw_edible_mass_g:200,finished_mass_g:180,servings:2,yield_evidence:'Synthetic measured yield',reviewed_at:at},lab.policies());
 const version={...row(1121),...v.version};
 pass('canonical recipe version retains exact catalog ingredients',()=>{assert.equal(v.status,'new_version');assert.deepEqual(version.ingredients.map(i=>i.composition.source.provider),['taco','usda']);assert.equal(version.retention_evidence,null);assert.throws(()=>recipeRequest({scope,head,version,audit:null,expectedHead:null,expectedLatest:null,operationId:version.id}));});
 // R17 isolated proof construction only. Production remote-recipe intentionally rejects catalog sources.
 const proofs=ingredients.map(i=>{const r=reviewedSnapshot(scope,i.itemId,i.composition,i.consumed,at);return {item:{id:i.itemId,food_id:null,name:i.composition.name,quantity:i.consumed.value,unit:i.consumed.unit,nutrients:{},nutrient_source:null},snapshot:{...r,identity:{provider:i.composition.source.provider,recordId:i.composition.source.recordId,version:i.composition.source.version,preparation:i.composition.preparation,presentationId:'catalog-100g'},food_id:null}};});
 const recipe={p_person:scope.person_id,p_operation:version.id,p_expected_head:null,p_expected_latest:null,p_head:vitalPayload('vital_recipes',head,scope),p_version:vitalPayload('vital_recipe_versions',version,scope),p_audit:null,p_proofs:proofs};
 const consumed=recipeConsumptionDraft(scope,version,id(1132),{value:90,unit:'g'});consumed.reviewed=true;
 const cmeal=prepareMealEnvelope(scope,{scope,mealId:id(1130),operationId:id(1131),items:[consumed]},at,[]);
 pass('recipe consumption preserves evidence and no claim of retention',()=>{verifyMealEnvelope(scope,cmeal.items,cmeal.nutrition_f2);assert.equal(cmeal.nutrition_f2.items[consumed.id].payload.composition.recipeVersion.ingredients.length,2);});
 const cRow={...mrow,id:id(1130),items:cmeal.items,nutrition_f2:cmeal.nutrition_f2};
 function mealReq(m){return {p_person:scope.person_id,p_operation:m.nutrition_f2.operation_id,p_expected:null,p_row:vitalPayload('vital_meals',m,scope),p_audit:null};}
 const sqlJson=x=>{const s=JSON.stringify(x);assert.ok(!s.includes('$catalog$'));return `$catalog$${s}$catalog$::jsonb`;};
 const seed=records.map(r=>`INSERT INTO vault_nutrition_f2_review.catalog_authority_lab(provider,release,record_id,record_sha256,manifest_sha256,composition) SELECT provider,release,record_id,record_sha256,manifest_sha256,composition FROM jsonb_to_record(${sqlJson(r)}) AS x(provider text,release text,record_id text,record_sha256 text,manifest_sha256 text,composition jsonb);`).join('\n');
 fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'catalog-seed.sql'),seed+'\n');
 const bundle=Buffer.from(JSON.stringify({mode:'lab',records:records.map(r=>({decision:'lab_only',composition:r.composition,sourceRecordSha256:r.record_sha256,manifestSha256:r.manifest_sha256,approvalRef:'LAB_SYNTHETIC_ONLY_NOT_PRODUCTION',reviewerRef:'LAB_NO_REVIEWER_DECISION',reason:'Synthetic subset to certify software; no clinical or release approval'}))}));
 fs.writeFileSync(path.join(out,'catalog-lab-authority.json'),bundle);fs.writeFileSync(path.join(out,'catalog-lab-authority.sha256'),sha(bundle)+'\n');

 // Recompute forged official composition as if it were valid. Server must reject even internally consistent fake totals.
 const forged=structuredClone(reviewed[0]);forged.composition.values.protein_g.amount+=1;
 const pendingRow=review.reviewRow(pending.key),pendingItem={...reviewed[0],composition:pendingRow.composition,identity:{provider:pendingRow.provider,recordId:pendingRow.id,version:pendingRow.release,preparation:pendingRow.composition.preparation,presentationId:'catalog-100g'}};
 function badMeal(i,mid,op){const e=prepareMealEnvelope(scope,{scope,mealId:id(mid),operationId:id(op),items:[i]},at,lab.policies());return mealReq({...mrow,id:id(mid),items:e.items,nutrition_f2:e.nutrition_f2});}
 const badRecipe=structuredClone(recipe);badRecipe.p_version.ingredients[0]=reviewedSnapshot(scope,ingredients[0].itemId,forged.composition,ingredients[0].consumed,at).payload;const badProof=reviewedSnapshot(scope,ingredients[0].itemId,forged.composition,ingredients[0].consumed,at);badRecipe.p_proofs[0].snapshot={...badRecipe.p_proofs[0].snapshot,...badProof};
 const fixtures={scope,meal:mealReq(mrow),recipe,consumed:mealReq(cRow),forgedMeal:badMeal(forged,1140,1141),pendingMeal:badMeal(pendingItem,1142,1143),forgedRecipe:badRecipe};
 fs.writeFileSync(path.join(out,'catalog-fixtures.json'),JSON.stringify(fixtures));
 fs.writeFileSync(path.join(out,'catalog-proof-summary.json'),JSON.stringify({mode:'LAB_SYNTHETIC_ONLY',productionApproved:0,sourceRecords:1095,experimentRecords:records.map(({composition,...r})=>r),checks:tests,fixturesSha256:sha(fs.readFileSync(path.join(out,'catalog-fixtures.json')))},null,2)+'\n');
 console.log('R17_CATALOG_LOCAL_TOTAL',tests);
})().catch(e=>{console.error(e);process.exitCode=1});
