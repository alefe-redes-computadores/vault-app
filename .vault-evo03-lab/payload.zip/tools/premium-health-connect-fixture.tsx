import React from 'react';
import {createRoot} from 'react-dom/client';
import Dexie from 'dexie';
import {createVitalStorage,VITAL_STORES,type CanonicalDb} from '@/lib/vital/storage-dexie';
import {VitalRepository} from '@/lib/vital/repository';
import {createExternalImportReview} from '@/lib/vital/nutrition-f2/external-import-review';
import {NUTRITION_ORIGIN,type NutritionRecord} from '@/lib/vital/nutrition-f2/health-connect-nutrition';
import {certifiedVitalF2Release} from '@/lib/vital/nutrition-f2/release-capability';
import {HealthConnectNutritionReview} from '@/components/vital/nutrition-f2/HealthConnectNutritionReview';
import {ToastProvider} from '@/components/ToastProvider';
import type {Scope} from '@/lib/vital/model';
const scope:Scope={user_id:'52000000-0000-4000-8000-000000000001',person_id:'52000000-0000-4000-8000-000000000002'};
const db=new Dexie('VAULT_EVO03_SYNTHETIC_HC_ONLY');db.version(1).stores({...VITAL_STORES,persons:'id,user_id',locais:'id,user_id',medicos:'id,user_id',rehab_programs_m5:'id,user_id',syncQueue:'id,table',vital_sync_ack:'id,[user_id+person_id]',health_connect_connections:'id,user_id'});
const repo=new VitalRepository(createVitalStorage({db:db as unknown as CanonicalDb,authenticatedUser:async()=>scope.user_id,activeScope:()=>scope,nutritionImportEnabled:true,enqueue:async(table,operation,row)=>{await db.table('syncQueue').put({id:crypto.randomUUID(),table,operation,payload:row});},dispatch:()=>{/* no network */}}));
let native:'error'|'denied'|'granted'='error',empty=true,authorizationGrants=false;
let revision=0;
async function setConsent(granted:boolean){await db.table('health_connect_connections').put({id:scope.user_id,...scope,revision:`synthetic-${++revision}`,nutrition_read:granted});}
async function current(){if(native==='error')throw Error('Synthetic bridge unavailable');const row=await db.table('health_connect_connections').get(scope.user_id);return {scope,revision:row.revision as string,origin:NUTRITION_ORIGIN,nutritionReadGranted:native==='granted'&&row.nutrition_read===true};}
const instant=Date.now()-2*3600000;
const nativeRecord:Omit<NutritionRecord,'scope'>={type:'nutrition',origin:NUTRITION_ORIGIN,recordId:'synthetic-meal-01',start:new Date(instant).toISOString(),end:new Date(instant+1800000).toISOString(),lastModified:new Date(instant+3600000).toISOString(),mealName:'Refeição externa fictícia',mealType:'lunch',nutrients:{protein_g:{state:'known',amount:20,unit:'g'},fiber_g:{state:'unknown'}}};
const review=createExternalImportReview({scope,repo,current,bridge:{async readNutritionPage(){return {records:empty?[]:[nativeRecord],next:null,permission:native==='granted'};}},newId:()=>crypto.randomUUID(),now:()=>new Date(),offsetAt:start=>-new Date(start).getTimezoneOffset()});
const runtime={current,review,async authorize(){if(authorizationGrants){native='granted';await setConsent(true);}},async revoke(){review.cancel();await setConsent(false);}};
// Test-only control surface: changes synthetic native input, never calls production bridge.
Object.assign(window,{__hcLab:{async configure(mode:'error'|'denied'|'granted',grant:boolean,noRecords:boolean){native=mode;authorizationGrants=grant;empty=noRecords;},async inspect(){return {rows:await repo.list(scope,'vital_meals'),queue:await db.table('syncQueue').count()};}}});
async function init(){if(certifiedVitalF2Release()!==null)throw Error('Unexpected release authority');await db.open();await db.table('persons').put({id:scope.person_id,user_id:scope.user_id});await setConsent(false);createRoot(document.getElementById('root')!).render(<ToastProvider><main className="mx-auto max-w-3xl space-y-3 px-3 py-3"><p className="rounded-lg border border-amber-400/30 p-2 text-xs text-amber-300">LABORATÓRIO HEALTH CONNECT · ORIGEM SINTÉTICA · SEM ATIVAÇÃO OU TRANSPORTE</p><HealthConnectNutritionReview runtime={runtime} onBack={()=>{}} onSaved={()=>{}}/></main></ToastProvider>);}
void init().catch(e=>{document.getElementById('root')!.textContent='LAB INIT ERROR '+String(e);throw e;});
