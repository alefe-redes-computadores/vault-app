#!/usr/bin/env bash
# Isolated CI only. No cloud database, no credentials, no host port.
set -euo pipefail
cd "$(dirname "$0")/.."; root=$PWD
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r13 ]] || { echo 'STOP not the isolated CI branch';exit 2; }
for v in PGHOST PGHOSTADDR PGSERVICE PGSERVICEFILE PGDATABASE PGOPTIONS PGUSER PGPASSWORD PGPASSFILE; do [[ -z ${!v:-} ]] || { echo "STOP inherited $v";exit 2; }; done
(cd r05-lab-inputs; sha256sum -c SHA256SUMS.txt >/dev/null)
work=$(mktemp -d); chmod 755 "$work"; name="vault-evo03-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"; api="${name}-pgrst"; cleanup(){ local rc=$?; trap - EXIT; docker rm -f "$api" >/dev/null 2>&1 || true; docker stop -t 10 "$name" >/dev/null 2>&1 || true; docker rm -f "$name" >/dev/null 2>&1 || true; if ! rm -rf "$work"; then echo "LAB CLEANUP FAILED" >&2; [[ $rc != 0 ]] || rc=1; fi; exit "$rc"; }; trap cleanup EXIT
mkdir -m 777 "$work/pg-socket" "$work/api-socket"
mkdir -p "$work/cases" "$work/r05/lib" "$work/current/lib"; cp -a r05-lab-inputs/integration/baseline/lib/. "$work/r05/lib/";cp -a tests/fixture-lib/. "$work/current/lib/"
for dir in r05 current; do (cd "$work/$dir"; mapfile -d '' files < <(find lib/vital -name '*.ts' -print0); "$root/candidate/node_modules/.bin/tsc" --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}"); done
r=$root/r05-lab-inputs
node sql/generate-fixture-m03.cjs "$work/r05/build" "$work/cases"
node sql/generate-label-fixture.cjs "$work/current/build" "$work/cases/labels.sql"
node sql/generate-recipe-fixture.cjs "$work/current/build" "$work/cases"
node sql/generate-external-fixture.cjs "$work/current/build" "$work/cases/external.sql"
node sql/generate-recipe-consumption-fixture.cjs "$work/current/build" "$work/cases/recipe-consumption.sql"
{ sed '$d' "$r/sql/02-DDL-R04-REVISAO.sql" | sed 's/NOT BETWEEN 170600 AND 170699/<> 170006/';cat "$r/sql/03-LAB-F1-F2-INERT-ASSERTIONS.sql" "$r/sql/r05-lab/04-ENVELOPE-SHAPE-REVIEW.sql" "$r/sql/r05-lab/05-ENVELOPE-ASSERTIONS.sql" sql/06-F2-RECOMPUTE-R03-ORIGINAL.sql;python3 sql/generate-external-meal-review.py;cat sql/08-RECIPE-STRUCTURE-M03.sql;printf '\nCOMMIT;\n'; } > "$work/review.sql"
{ printf 'BEGIN;\n';python3 sql/generate-label-recompute-review.py;printf '\nCOMMIT;\n'; } > "$work/label-review.sql"
{ printf 'BEGIN;\n';python3 sql/generate-integrated-recipe-review.py;printf '\nCOMMIT;\n'; } > "$work/recipe-review.sql"
{ printf 'BEGIN;\n';cat sql/12-RECIPE-CONSUMPTION-REVIEW.sql sql/13-PLAN-TARGETS-REVIEW.sql;printf '\nCOMMIT;\n'; } > "$work/recipe-consumption-review.sql"
cp "$r/sql/r05-lab/00-SYNTHETIC-PREREQUISITES.sql" "$work/prereqs.sql"; cp "$r/sql/r05-lab/F1-EXACT-REFERENCE.sql" "$work/f1.sql"
# Docker image used only as a disposable local lab in the free standard runner. No exposed ports.
docker pull postgres:17.6-bookworm
docker run -d --name "$name" --network none -e POSTGRES_USER=vault_lab_admin -e POSTGRES_DB=vault_macro03_lab_f2 -e POSTGRES_HOST_AUTH_METHOD=trust -v "$work:/lab:ro" -v "$work/pg-socket:/var/run/postgresql" postgres:17.6-bookworm -c listen_addresses='' >/dev/null
for i in $(seq 1 60);do if docker exec "$name" sh -c 'test "$(cat /proc/1/comm)" = postgres' && docker exec "$name" pg_isready -h /var/run/postgresql -U vault_lab_admin -d vault_macro03_lab_f2 >/dev/null 2>&1;then break;fi;sleep 1;done
psql(){ docker exec "$name" psql -X --no-password --set=ON_ERROR_STOP=1 -h /var/run/postgresql -U vault_lab_admin -d vault_macro03_lab_f2 "$@"; }
[[ $(psql -Atc 'show server_version_num') == 170006 ]] || { echo 'STOP version not 17.6'; exit 2; }
psql -c "SET vault.macro03_lab='on'" -f /lab/prereqs.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -f /lab/f1.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/review.sql
race(){ local a b pa pb; set +e;psql -f "/lab/cases/$1" > "$work/a.log" 2>&1 & pa=$!;psql -f "/lab/cases/$2" > "$work/b.log" 2>&1 & pb=$!;wait "$pa";a=$?;wait "$pb";b=$?;set -e;cat "$work/a.log" "$work/b.log";if [[ $a == 0 && $b != 0 ]];then grep -q 40001 "$work/b.log";elif [[ $b == 0 && $a != 0 ]];then grep -q 40001 "$work/a.log";else echo 'FAIL expected one winner';return 1;fi; }
python3 sql/generate-r04-predicate-proof.py "$work/cases/postgrest-meal.json" > "$work/r04-predicate-proof.sql"
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/r04-predicate-proof.sql
psql -f /lab/cases/initial.sql
race race-a.sql race-b.sql
psql -f /lab/cases/verify.sql;psql -f /lab/cases/historical-retry.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/label-review.sql
psql -f /lab/cases/labels.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/recipe-review.sql
psql -f /lab/cases/recipe-initial.sql
race recipe-race-a.sql recipe-race-b.sql
psql -f /lab/cases/recipe-verify.sql;psql -f /lab/cases/external.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/recipe-consumption-review.sql
psql -f /lab/cases/recipe-consumption.sql
echo 'PG17.6_DOCKER_LAB_PASS; NOT_PRODUCTION'
# Independent HTTP proof using PostgREST over Unix sockets. No host ports, no network in either container.
cp sql/14-POSTGREST-SYNTHETIC-AUTH.sql "$work/postgrest-auth.sql"
psql -c "SET vault.macro03_lab='on'" -f /lab/postgrest-auth.sql
# The credential is generated just for this disposable database and is never printed/uploaded.
export VAULT_LAB_JWT_SECRET="$(python3 -c 'import secrets;print(secrets.token_hex(32))')"
docker pull postgrest/postgrest:v13.0.4
docker run -d --name "$api" --network none \
 -v "$work/pg-socket:/pg-socket:ro" -v "$work/api-socket:/api-socket" \
 -e PGRST_DB_URI='postgresql://vault_lab_authenticator@/vault_macro03_lab_f2?host=/pg-socket' \
 -e PGRST_DB_SCHEMAS=public -e PGRST_DB_ANON_ROLE=anon -e PGRST_DB_CONFIG=false \
 -e PGRST_JWT_SECRET="$VAULT_LAB_JWT_SECRET" -e PGRST_SERVER_UNIX_SOCKET=/api-socket/http.sock \
 -e PGRST_SERVER_UNIX_SOCKET_MODE=666 postgrest/postgrest:v13.0.4 >/dev/null
for i in $(seq 1 60); do if test -S "$work/api-socket/http.sock";then break;fi;sleep 1;done
if ! python3 tools/test-r13-postgrest-unix.py "$work/api-socket/http.sock" "$work/cases"; then docker logs "$api" >&2; exit 1; fi
node tools/ci-r13-client-http.cjs "$work/api-socket/http.sock" "$work/current/build" "$work/cases"
mkdir -p "$RUNNER_TEMP/evo03-r13-server"; cp "$work/cases/r13-client-proof.json" "$RUNNER_TEMP/evo03-r13-server/"
unset VAULT_LAB_JWT_SECRET
# Assert physical transaction cardinality independently of the HTTP response.
psql -c "DO \$\$ BEGIN IF (SELECT count(*) FROM public.vital_meals WHERE id='90000000-0000-4000-8000-000000000950' AND revision=1)<>1 OR (SELECT count(*) FROM vault_nutrition_f2_review.meal_receipts WHERE meal_id='90000000-0000-4000-8000-000000000950')<>1 THEN RAISE EXCEPTION 'FAIL HTTP receipt cardinality'; END IF; END \$\$;"
echo 'POSTGREST_DB_CARDINALITY_PASS; SYNTHETIC_ONLY' 
psql -c "DO \$\$ BEGIN IF (SELECT count(*) FROM public.vital_meals WHERE id IN ('90000000-0000-4000-8000-000000000810','90000000-0000-4000-8000-000000000960','90000000-0000-4000-8000-000000000985'))<>3 OR (SELECT count(*) FROM vault_nutrition_f2_review.meal_receipts WHERE meal_id IN ('90000000-0000-4000-8000-000000000810','90000000-0000-4000-8000-000000000960','90000000-0000-4000-8000-000000000985'))<>3 OR (SELECT count(*) FROM public.vital_recipe_versions WHERE id='90000000-0000-4000-8000-000000000982')<>1 OR (SELECT count(*) FROM vault_nutrition_f2_review.recipe_receipts WHERE recipe_id='90000000-0000-4000-8000-000000000981')<>1 THEN RAISE EXCEPTION 'FAIL integrated client cardinality'; END IF; END \$\$;"
external_id=$(node -e 'const p=require(process.argv[1]); const id=p.records[2]; if(!/^[a-f0-9-]{36}$/.test(id))process.exit(1); console.log(id)' "$work/cases/r13-client-proof.json")
psql -c "DO \$\$ BEGIN IF (SELECT count(*) FROM public.vital_meals WHERE id='$external_id' AND revision=3 AND deleted_at IS NOT NULL)<>1 OR (SELECT count(*) FROM vault_nutrition_f2_review.meal_receipts WHERE meal_id='$external_id')<>3 OR (SELECT count(*) FROM public.vital_audit WHERE target_id='$external_id' AND target_table='vital_meals')<>2 THEN RAISE EXCEPTION 'FAIL external client cardinality'; END IF; END \$\$;"
echo 'R13_REAL_CLIENT_DB_CARDINALITY_PASS; SYNTHETIC_ONLY'
