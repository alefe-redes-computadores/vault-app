#!/usr/bin/env python3
"""Review-only overlay on the observed Macro02 Git archive. Never touches a checkout."""
import argparse,hashlib,json,pathlib,shutil,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
BASE='43c39ee489283c772fa52fa07803b2735e94737e'
TARGET='bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b'
DOSSIER='lib/m3/medical-dossier-p3.ts'
DOSSIER_BLOB='2aa96d345080696b6c3f461bc25ee1a3bf975020'
HOST_LOADERS={
 'scripts/test-vault-m98-reports-360.cjs':'315a62a51b39e844a1c2b24d31cf7c2d15c7a598',
 'scripts/test-vault-ci360-m3-p3.cjs':'5458e44636aba255bed70437c98702408d14602d',
 'scripts/test-vault-ci360-p6-p3-d1.cjs':'81026b2f1ac379e44cfd860a0ab237b04101275d',
}


def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):
 if p.is_symlink() or p.exists() and not p.is_file(): raise ValueError('nonregular path '+str(p))
 return p.read_bytes() if p.is_file() else None
def hashes(p):
 if any(x.is_symlink() for x in p.rglob('*')): raise ValueError('symlink in archive')
 return {str(x.relative_to(p)):sha(x.read_bytes()) for x in p.rglob('*') if x.is_file()}

def reviewed_dossier(old,new,remote,expected_blob=DOSSIER_BLOB):
 """Only the previously inspected nutrition provenance substitution is authorized."""
 if blob(remote)!=expected_blob: raise ValueError('STOP dossier remote blob drift')
 prefix=b"source:f.source,sourceId:f.id,registeredAt:null,provenance:"
 before=prefix+b"'declarado',relations:[],href:f.href});"
 after=prefix+b"f.source==='vital_meal_reviewed_f2'?'registrado':'declarado',relations:[],href:f.href});"
 if old.count(before)!=1 or old.replace(before,after)!=new: raise ValueError('STOP unexpected local dossier delta')
 if remote.count(before)!=1: raise ValueError('STOP ambiguous dossier context')
 result=remote.replace(before,after)
 if result.count(after)!=1 or result.replace(after,before)!=remote: raise ValueError('STOP inverse not exact')
 return result

def loader_delta(source):
 lines=[line for line in source.splitlines(keepends=True) if line.startswith(b'const vitalFacts=')]
 if len(lines)!=1 or lines[0].count(b'vitalValidation}')!=1:raise ValueError('STOP loader anchor drift')
 line=lines[0]; after=line.replace(b'vitalValidation}',b"vitalValidation, './nutrition-f2/consumer-projection':require('./vault-macro03-pure-loader.cjs').createConsumerProjection()}")
 if source.count(line)!=1:raise ValueError('STOP loader ambiguous')
 return source.replace(line,after)

def reviewed_loader(name,old,new,remote,expected_blob=None):
 if blob(remote)!=(expected_blob or HOST_LOADERS[name]):raise ValueError('STOP historical loader blob drift '+name)
 if loader_delta(old)!=new:raise ValueError('STOP unexpected historical loader local delta '+name)
 return loader_delta(remote)

def main():
 p=argparse.ArgumentParser();p.add_argument('repo',type=pathlib.Path);p.add_argument('source',type=pathlib.Path);p.add_argument('destination',type=pathlib.Path);p.add_argument('report',type=pathlib.Path);a=p.parse_args()
 s=a.source.resolve();d=a.destination.resolve();repo=a.repo.resolve();report=a.report.resolve()
 if not s.is_dir() or d.exists() or report.exists() or s==d or s in d.parents or d in s.parents or (s/'.git').exists() or d in report.parents: raise ValueError('STOP unsafe paths')
 def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
 if git('rev-parse',TARGET+'^{commit}').decode().strip()!=TARGET: raise ValueError('STOP target SHA')
 subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',BASE,TARGET],check=True)
 # Archive source must equal the exact target Git blobs and path set. No partial export accepted.
 expected={}
 for entry in git('ls-tree','-rz',TARGET).split(b'\0'):
  if not entry:continue
  meta,name=entry.split(b'\t',1);mode,typ,obj=meta.decode().split();name=name.decode('utf-8')
  if typ!='blob' or mode not in ('100644','100755'):raise ValueError('STOP unsupported Git entry '+name)
  expected[name]=obj
 original=hashes(s)
 if original.keys()!=expected.keys():raise ValueError('STOP target archive path set mismatch')
 for name,obj in expected.items():
  if blob((s/name).read_bytes())!=obj:raise ValueError('STOP target archive blob mismatch '+name)
 changes=json.loads((ROOT/'ALLOWLIST.json').read_text())['changes'];updates={};receipts=[]
 for c in changes:
  name=c['path'];path=pathlib.PurePosixPath(name)
  if path.is_absolute() or '..' in path.parts or name in updates:raise ValueError('STOP unsafe allowlist')
  old=read(ROOT/'patch/preimage'/path);new=read(ROOT/'patch/postimage'/path);current=read(s/path)
  digest=lambda v:None if v is None else sha(v)
  if digest(old)!=c['pre_sha256'] or digest(new)!=c['post_sha256']:raise ValueError('STOP payload mismatch '+name)
  if digest(current)==digest(old):result=new;kind='exact-preimage'
  elif name==DOSSIER and old is not None and new is not None and current is not None:result=reviewed_dossier(old,new,current);kind='reviewed-one-line-A10-preserved'
  elif name in HOST_LOADERS and old is not None and new is not None and current is not None:result=reviewed_loader(name,old,new,current);kind='reviewed-one-line-host-loader-asserts-preserved'
  else:raise ValueError('STOP unresolved collision '+name)
  updates[name]=result;receipts.append({'path':name,'decision':kind,'target_pre_sha256':digest(current),'target_pre_git_blob':None if current is None else blob(current),'candidate_post_sha256':digest(result),'candidate_post_git_blob':None if result is None else blob(result)})
 if sum(x['decision']=='reviewed-one-line-A10-preserved' for x in receipts)!=1:raise ValueError('STOP expected reviewed dossier collision not found')
 if sum(x['decision']=='reviewed-one-line-host-loader-asserts-preserved' for x in receipts)!=3:raise ValueError('STOP expected three reviewed host loader collisions')
 shutil.copytree(s,d)
 try:
  for name,v in updates.items():
   p=d/name
   if v is None:p.unlink()
   else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(v)
  final=hashes(d);changed={k for k in original.keys()|final.keys() if original.get(k)!=final.get(k)}
  if changed!=set(updates):raise ValueError('STOP materialized path set mismatch')
  if hashes(s)!=original:raise ValueError('STOP input modified')
  report.write_text(json.dumps({'status':'REVIEW_ONLY_DIAGNOSTIC_BASE_NOT_CERTIFIED','target_sha':TARGET,'historical_base':BASE,'target_files':len(original),'candidate_files':len(final),'changed_paths':len(changed),'unchanged_non_allowlist':len(set(original)-changed),'receipts':receipts},ensure_ascii=False,indent=2)+'\n')
 except BaseException:
  shutil.rmtree(d);raise
 print('REANCHOR_REVIEW_ONLY',TARGET,len(changed),'paths, non-allowlist untouched; no activation or release')
if __name__=='__main__':main()
