#!/usr/bin/env bash
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r19 ]] || { echo 'STOP branch'; exit 2; }
[[ ${EVO03_LAB:-} == "$RUNNER_TEMP/evo03-lab" ]] || { echo 'STOP path'; exit 2; }
mkdir -p "$RUNNER_TEMP/evo03-r19-functional"
export PLAYWRIGHT_MODULE="$RUNNER_TEMP/evo03-ui/node_modules/playwright" ESBUILD_MODULE="$RUNNER_TEMP/evo03-ui/node_modules/esbuild"
failed=0
run() {
 local name=$1 file=$2 marker=$3; local log="$RUNNER_TEMP/evo03-r19-functional/$name.log" rc=0
 node "$EVO03_LAB/tools/$file" 2>&1 | tee "$log" || rc=$?
 if [[ $rc == 0 ]] && grep -Eq "^${marker} [1-9][0-9]*$" "$log"; then printf '%s PASS\n' "$name" | tee -a "$RUNNER_TEMP/evo03-r19-functional/status.txt"; else printf '%s FAIL rc=%s\n' "$name" "$rc" | tee -a "$RUNNER_TEMP/evo03-r19-functional/status.txt"; failed=1; fi
}
run summary r19-summary.cjs PREMIUM_COMPONENT_VISUAL_PASS
run f1 r19-f1.cjs PREMIUM_FULL_PANEL_PASS
run f2 r19-f2.cjs PREMIUM_F2_JOURNEY_PASS
run hc r19-hc.cjs PREMIUM_HC_UI_PASS
run recovery r19-recovery.cjs PREMIUM_F2_CANONICAL_AND_RECOVERY_PASS
run consumers r19-consumers.cjs R13_CONSUMER_VISUAL_PASS
run catalog r19-catalog.cjs R17_CATALOG_BROWSER_PASS
run screen ci-r19-screen.cjs R19_VITAL_SCREEN_ROUTES_PASS
[[ $failed == 0 ]] || exit 1
echo R19_FUNCTIONAL_LAB_ALL_PASS
