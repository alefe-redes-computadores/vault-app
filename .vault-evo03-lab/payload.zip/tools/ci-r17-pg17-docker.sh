#!/usr/bin/env bash
# Isolated CI only. No cloud database, no credentials, no host port.
set -euo pipefail
cd "$(dirname "$0")/.."; root=$PWD
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r171 ]] || { echo 'STOP not the isolated CI branch';exit 2; }
for v in PGHOST PGHOSTADDR PGSERVICE PGSERVICEFILE PGDATABASE PGOPTIONS PGUSER PGPASSWORD PGPASSFILE; do [[ -z ${!v:-} ]] || { echo "STOP inherited $v";exit 2; }; done
(cd r05-lab-inputs; sha256sum -c SHA256SUMS.txt >/dev/null)
work=$(mktemp -d); chmod 755 "$work"; name="vault-evo03-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"; api="${name}-pgrst"; cleanup(){ local rc=$?; trap - EXIT; docker rm -f "$api" >/dev/null 2>&1 || true; docker stop -t 10 "$name" >/dev/null 2>&1 || true; docker rm -f "$name" >/dev/null 2>&1 || true; if ! rm -rf "$work"; then echo "LAB CLEANUP FAILED" >&2; [[ $rc != 0 ]] || rc=1; fi; exit "$rc"; }; trap cleanup EXIT
mkdir -m 777 "$work/pg-socket" "$work/api-socket"
mkdir -p "$work/cases" "$work/current/lib"; cp -a tests/fixture-lib/. "$work/current/lib/"
(cd "$work/current"; mapfile -d '' files < <(find lib/vital -name '*.ts' -print0); "$root/candidate/node_modules/.bin/tsc" --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}")
r=$root/r05-lab-inputs
node tools/r17-catalog-proof.cjs "$work/current/build" "$root/evidence/rodada-R05" "$root/evidence/r15/catalog-review-ledger.jsonl" "$work/cases"
node tools/r17-catalog-diary.cjs "$work/current/build" "$work/cases"
node --test tools/test-r171-readiness.cjs
mkdir -p "$RUNNER_TEMP/evo03-r17-catalog-ui"
cp "$work/cases/catalog-lab-authority.json" "$RUNNER_TEMP/evo03-r17-catalog-ui/"
{ sed '$d' "$r/sql/02-DDL-R04-REVISAO.sql" | sed 's/NOT BETWEEN 170600 AND 170699/<> 170006/';cat "$r/sql/03-LAB-F1-F2-INERT-ASSERTIONS.sql" "$r/sql/r05-lab/04-ENVELOPE-SHAPE-REVIEW.sql" "$r/sql/r05-lab/05-ENVELOPE-ASSERTIONS.sql" sql/06-F2-RECOMPUTE-R03-ORIGINAL.sql;python3 sql/generate-external-meal-review.py;cat sql/08-RECIPE-STRUCTURE-M03.sql;printf '\nCOMMIT;\n'; } > "$work/review.sql"
{ printf 'BEGIN;\n';python3 sql/generate-label-recompute-review.py;printf '\nCOMMIT;\n'; } > "$work/label-review.sql"
{ printf 'BEGIN;\n';python3 sql/generate-catalog-recipe-review.py;printf '\nCOMMIT;\n'; } > "$work/recipe-review.sql"
{ printf 'BEGIN;\n';cat sql/12-RECIPE-CONSUMPTION-REVIEW.sql sql/13-PLAN-TARGETS-REVIEW.sql;printf '\nCOMMIT;\n'; } > "$work/recipe-consumption-review.sql"
cp "$r/sql/r05-lab/00-SYNTHETIC-PREREQUISITES.sql" "$work/prereqs.sql"; cp "$r/sql/r05-lab/F1-EXACT-REFERENCE.sql" "$work/f1.sql"
# Docker image used only as a disposable local lab in the free standard runner. No exposed ports.
docker pull postgres:17.6-bookworm
docker run -d --name "$name" --network none -e POSTGRES_USER=vault_lab_admin -e POSTGRES_DB=vault_macro03_lab_f2 -e POSTGRES_HOST_AUTH_METHOD=trust -v "$work:/lab:ro" -v "$work/pg-socket:/var/run/postgresql" postgres:17.6-bookworm -c listen_addresses='' -c log_lock_waits=on -c deadlock_timeout=1s >/dev/null
for i in $(seq 1 60);do if docker exec "$name" sh -c 'test "$(cat /proc/1/comm)" = postgres' && docker exec "$name" pg_isready -h /var/run/postgresql -U vault_lab_admin -d vault_macro03_lab_f2 >/dev/null 2>&1;then break;fi;sleep 1;done
psql(){ docker exec "$name" psql -X --no-password --set=ON_ERROR_STOP=1 -h /var/run/postgresql -U vault_lab_admin -d vault_macro03_lab_f2 "$@"; }
[[ $(psql -Atc 'show server_version_num') == 170006 ]] || { echo 'STOP version not 17.6'; exit 2; }
psql -c "SET vault.macro03_lab='on'" -f /lab/prereqs.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -f /lab/f1.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/review.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/label-review.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/recipe-review.sql
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f /lab/recipe-consumption-review.sql
cp sql/15-PLAN-TARGETS-WRITER-LAB.sql "$work/plan-target-writer.sql"
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -c 'BEGIN' -f /lab/plan-target-writer.sql -c 'COMMIT'
cp sql/16-CATALOG-AUTHORITY-LAB.sql "$work/catalog-authority.sql"
psql -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -c 'BEGIN' -f /lab/catalog-authority.sql -f /lab/cases/catalog-seed.sql -c 'COMMIT'
cp sql/14-POSTGREST-SYNTHETIC-AUTH.sql "$work/postgrest-auth.sql"
psql -c "SET vault.macro03_lab='on'" -f /lab/postgrest-auth.sql
# The credential is generated just for this disposable database and is never printed/uploaded.
# Bound server work before the client's 30 s absolute deadline; a timeout remains a failure.
psql -c "ALTER ROLE vault_lab_authenticator SET statement_timeout='20s'; ALTER ROLE vault_lab_authenticator SET lock_timeout='8s';"
export VAULT_LAB_JWT_SECRET="$(python3 -c 'import secrets;print(secrets.token_hex(32))')"
docker pull postgrest/postgrest:v13.0.4
docker run -d --name "$api" --network none \
 -v "$work/pg-socket:/pg-socket:ro" -v "$work/api-socket:/api-socket" \
 -e PGRST_DB_URI='postgresql://vault_lab_authenticator@/vault_macro03_lab_f2?host=/pg-socket' \
 -e PGRST_DB_SCHEMAS=public -e PGRST_DB_ANON_ROLE=anon -e PGRST_DB_CONFIG=false \
 -e PGRST_JWT_SECRET="$VAULT_LAB_JWT_SECRET" -e PGRST_SERVER_UNIX_SOCKET=/api-socket/http.sock \
 -e PGRST_SERVER_UNIX_SOCKET_MODE=666 postgrest/postgrest:v13.0.4 >/dev/null
for i in $(seq 1 60); do if test -S "$work/api-socket/http.sock";then break;fi;sleep 1;done
mkdir -p "$RUNNER_TEMP/evo03-r17-server"
cp "$work/cases/catalog-proof-summary.json" "$work/cases/catalog-lab-authority.sha256" "$RUNNER_TEMP/evo03-r17-server/"
if ! node tools/ci-r17-catalog-http.cjs "$work/api-socket/http.sock" "$work/current/build" "$work/cases"; then
 docker logs "$api" > "$RUNNER_TEMP/evo03-r17-server/postgrest.log" 2>&1 || true
 docker logs "$name" > "$RUNNER_TEMP/evo03-r17-server/postgres.log" 2>&1 || true
 exit 1
fi
unset VAULT_LAB_JWT_SECRET
# Independent DB cardinality: positive entries only, replay never doubles records, no pending/forged writes.
psql -c "DO \$\$ BEGIN IF (SELECT count(*) FROM vault_nutrition_f2_review.catalog_authority_lab)<>2 OR (SELECT count(*) FROM public.vital_meals WHERE id IN ('90000000-0000-4000-8000-000000001110','90000000-0000-4000-8000-000000001130'))<>2 OR (SELECT count(*) FROM vault_nutrition_f2_review.meal_receipts WHERE meal_id IN ('90000000-0000-4000-8000-000000001110','90000000-0000-4000-8000-000000001130'))<>2 OR EXISTS(SELECT 1 FROM public.vital_meals WHERE id IN ('90000000-0000-4000-8000-000000001140','90000000-0000-4000-8000-000000001142')) OR (SELECT count(*) FROM public.vital_recipe_versions WHERE id='90000000-0000-4000-8000-000000001121')<>1 OR (SELECT count(*) FROM vault_nutrition_f2_review.recipe_receipts WHERE recipe_id='90000000-0000-4000-8000-000000001120')<>1 THEN RAISE EXCEPTION 'FAIL catalog cardinality'; END IF; END \$\$;"
echo 'R17_CATALOG_DB_CARDINALITY_PASS; LAB_SYNTHETIC_APPROVALS_ONLY; NOT_PRODUCTION'
docker logs "$name" > "$RUNNER_TEMP/evo03-r17-server/postgres.log" 2>&1
docker logs "$api" > "$RUNNER_TEMP/evo03-r17-server/postgrest.log" 2>&1
