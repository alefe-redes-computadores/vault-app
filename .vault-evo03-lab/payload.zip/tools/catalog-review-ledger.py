#!/usr/bin/env python3
"""Offline review decision ledger. Never writes a catalog, release capability or app data."""
import argparse,hashlib,json,pathlib
PINS={"summary.json":"55a8e6d4548912e7915f151251f1dd345333e73de39b0ab7136cb3c71822b485","taco-review.jsonl":"786162e53dd6ca392ed7fcbe6437c27174321a40bde8ee262661c683fb4a8037","usda-review.jsonl":"2dc9a0d55bf8de7b2b77838a6f5b90b8eb0640e224845888a10119f9df75d499"}
def require(condition,message):
 if not condition: raise ValueError(message)
def read_rows(path): return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
def reference(root):
 for f,digest in PINS.items(): require(hashlib.sha256((root/f).read_bytes()).hexdigest()==digest,'Pinned triage altered: '+f)
 summary=json.loads((root/'summary.json').read_text());require(summary['status']=='TECHNICAL_TRIAGE_NOT_APPROVED' and summary['activation'] is False,'Unexpected triage state')
 rows={}
 for provider,count in [('taco',597),('usda',498)]:
  source=read_rows(root/(provider+'-review.jsonl'));require(len(source)==count,'Unexpected source cardinality');info=summary['providers'][provider]
  for raw in source:
   require(raw['approved'] is False and raw['reviewRequired'] is True,'Unexpected preapproved row')
   row={'provider':provider,'release':raw['sourceVersion'],'id':raw['id'],'sourceRecordSha256':raw['sourceRecordSha256'],'manifestSha256':info['manifestSha256'],'name':raw['name'],'base':raw['base'],'coverage':raw['coverage'],'flags':raw['flags'],'license':info['license'],'attribution':info['attribution']}
   key=(provider,row['release'],row['id']);require(key not in rows,'Duplicate source identity');rows[key]=row
 return rows
def write_template(root,out):
 rows=reference(root);ordered=sorted(rows.values(),key=lambda r:(not bool(r['flags']),-len(r['flags']),r['provider'],r['name'],r['id']))
 with out.open('x',encoding='utf-8') as f:
  for row in ordered:f.write(json.dumps({**row,'decision':'pending','reviewerRef':None,'reason':None},ensure_ascii=False,separators=(',',':'))+'\n')
 return len(ordered)
def validate(root,ledger):
 original=reference(root);seen=set();counts={x:0 for x in ['pending','retain_for_approval','exclude']}
 for row in read_rows(ledger):
  key=(row.get('provider'),row.get('release'),row.get('id'));require(key in original and key not in seen,'Unknown or duplicate decision identity');seen.add(key)
  require(set(row)==set(original[key])|{'decision','reviewerRef','reason'},'Unexpected decision fields')
  require({k:row[k] for k in original[key]}==original[key],'Source evidence altered')
  decision=row['decision'];require(decision in counts,'Invalid decision; activation is not supported')
  if decision=='pending':require(row['reviewerRef'] is None and row['reason'] is None,'Pending with review evidence')
  else:require(all(isinstance(row[x],str) and 0<len(row[x].strip())<=2000 for x in ('reviewerRef','reason')),'Review reference and reason required')
  counts[decision]+=1
 require(seen==set(original),'Missing source decision');return {'status':'REVIEW_ONLY_NOT_RELEASE_AUTHORITY','activation':False,'rows':len(seen),'decisions':counts,'approved':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','verify']);p.add_argument('triage',type=pathlib.Path);p.add_argument('ledger',type=pathlib.Path);a=p.parse_args()
 if a.mode=='prepare':write_template(a.triage,a.ledger)
 print(json.dumps(validate(a.triage,a.ledger),ensure_ascii=False))
if __name__=='__main__':main()
