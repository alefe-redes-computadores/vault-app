#!/usr/bin/env bash
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r05 ]] || { echo 'STOP branch';exit 2; }
cd "$(dirname "$0")/.."
[[ $PWD == "$RUNNER_TEMP/evo03-lab" ]] || { echo 'STOP lab path';exit 2; }
out="$RUNNER_TEMP/evo03-catalog-evidence";mkdir "$out"
inputs="$PWD/catalog-inputs"; (cd "$inputs";sha256sum -c source-SHA256.txt)
# R04 bytes, no refetch or silent source substitution. Review-only, never approved release.
python3 candidate/scripts/nutrition/import_usda.py "$inputs/usda.zip" --sha256 c3158a5d1b758f56ef20ec76d93603d2bf872e739d51f5f3079e3ef46181351a --release usda-foundation-2026-10-v2 --kind foundation_food --captured 2026-11-27 --out "$out/usda-candidates"
python3 candidate/scripts/nutrition/import_taco.py "$inputs/taco.xlsx" --sha256 a66b8ec528daeabc63bc2b015fc9bd8c6d76b941c2fc0ed93a4311d449302d14 --official-observed-r03 --captured 2026-11-27 --out "$out/taco-candidates"
cp "$inputs/provenance.txt" "$inputs/source-SHA256.txt" "$out/"
python3 tools/inspect-usda-archive.py "$inputs/usda.zip" > "$out/usda-layout.json"
bash tools/validate-usda-fixture.sh
bash tools/validate-taco-fixture.sh
python3 tests/catalog-usda/test_archive_member.py
python3 tests/catalog-taco/test_official_layout.py
root=$(mktemp -d);trap 'rm -rf -- "$root"' EXIT
mkdir -p "$root/lib";cp -a tests/fixture-lib/. "$root/lib/"
(cd "$root";mapfile -d '' files < <(find lib/vital -name '*.ts' -print0);tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}")
node tools/verify-official-corpus.cjs usda "$root/build" "$out/usda-candidates"
node tools/verify-official-corpus.cjs taco "$root/build" "$out/taco-candidates"
