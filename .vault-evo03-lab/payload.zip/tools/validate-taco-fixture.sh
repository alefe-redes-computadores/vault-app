#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."; self=$PWD
root=$(mktemp -d); trap 'rm -rf -- "$root"' EXIT
PYTHONDONTWRITEBYTECODE=1 python3 tests/catalog-taco/test_import_taco.py
PYTHONDONTWRITEBYTECODE=1 python3 - "$root" <<'PY'
import sys,json
from pathlib import Path
from openpyxl import Workbook
sys.path.insert(0,'candidate/scripts/nutrition');from import_taco import build,export,file_digest
# Synthetic corpus of full size, never persists beyond this test. The release-shaped manifest is a parser fixture, NOT a trust decision.
p=Path(sys.argv[1]);w=Workbook();s=w.active;s.title='Tabela 1';s.append(['Número do alimento','Descrição dos alimentos','Energia','Proteína','Lipídeos','Carboidrato','Fibra alimentar','Ferro','RAE']);s.append(['','','(kcal)','(g)','(g)','(g)','(g)','(mg)','(µg)'])
for i in range(597,0,-1):s.append([i,f'FICTÍCIO TESTE {i}','100,5',2,3,4,'Tr','NA',0])
x=p/'source.xlsx';w.save(x);w.close();l=p/'layout.json';l.write_text(json.dumps({'sheet':'Tabela 1','header_row':1,'unit_row':2,'first_data_row':3,'last_data_row':599,'columns':dict(id=1,name=2,energy_kcal=3,protein_g=4,fat_g=5,carbohydrate_g=6,fiber_g=7,iron_mg=8,vitamin_a_rae_ug=9)}));export(*build(x,file_digest(x),l,file_digest(l),'2026-11-26'),p/'fixture')
PY
mkdir -p "$root/tests" "$root/lib";cp tests/catalog-taco/frozen-taco-reader.cjs "$root/tests/";cp -a tests/fixture-lib/. "$root/lib/"
while IFS= read -r -d '' f;do cmp "$f" "$self/candidate/${f#"$root/"}";done < <(find "$root/lib" -type f -name '*.ts' -print0)
cd "$root";mapfile -d '' files < <(find lib/vital -name '*.ts' -print0)
tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}"
for tz in UTC America/Sao_Paulo America/New_York;do echo "FUSO=$tz"; TZ="$tz" TACO_FIXTURE="$root/fixture" node --test tests/frozen-taco-reader.cjs;done
