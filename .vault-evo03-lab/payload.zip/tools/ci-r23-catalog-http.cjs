'use strict';
// Real candidate adapters for positive writes; direct negative RPC probes independently enforce the server boundary.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
if(process.env.GITHUB_ACTIONS!=='true'||process.env.GITHUB_REF!=='refs/heads/vault/lab/evolution03-20261126-r23')throw Error('STOP isolated branch');
const [socket,build,cases]=process.argv.slice(2),secret=process.env.VAULT_LAB_JWT_SECRET;assert.ok(secret?.length>=32,'STOP disposable JWT');
const {makeUnixRequester}=require('./lab-unix-http.cjs');const unix=makeUnixRequester(socket,{trace:e=>console.log('R17_HTTP_TRACE',JSON.stringify(e))});
const {vitalFingerprint,vitalRemoteFields,vitalWireRow}=require(path.join(build,'vital/cloud-transport'));
const f=JSON.parse(fs.readFileSync(path.join(cases,'catalog-diary-fixtures.json'),'utf8'));const s=f.scope,other='90000000-0000-4000-8000-000000000002';
const jwt=user=>{const msg=Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url')+'.'+Buffer.from(JSON.stringify({sub:user,role:'authenticated',exp:Math.floor(Date.now()/1000)+600})).toString('base64url');return msg+'.'+crypto.createHmac('sha256',secret).update(msg).digest('base64url');};
const call=(method,url,user,body)=>unix(method,url,{Accept:'application/json',...(user?{Authorization:'Bearer '+jwt(user)}:{})},body);
const rpc=(name,body,user=s.user_id)=>call('POST','/rpc/vault_vital_'+name+'_f2_review',user,body);
const {waitForCatalogReadiness}=require('./r171-readiness.cjs');
const readinessUnix=makeUnixRequester(socket,{timeout:2000});
let checks=0;const ok=n=>{checks++;console.log('R17_CATALOG_HTTP_PASS',n);};
async function denied(name,body,label,code='23514',user=s.user_id){const r=await rpc(name,body,user);assert.notEqual(r.status,200,label);assert.equal(r.data?.code,code,label);ok(label);}
async function saved(name,body,status){const r=await rpc(name,body);assert.equal(r.status,200,JSON.stringify(r.data));assert.equal(r.data?.status,status);assert.equal(r.data.operation_id,body.p_operation);return r.data;}
async function read(table,expected,user=s.user_id){const r=await call('GET',`/${table}?id=eq.${expected.id}&select=${vitalRemoteFields(table).join(',')}`,user);assert.equal(r.status,200);if(user!==s.user_id){assert.deepEqual(r.data,[]);return;}assert.equal(r.data.length,1);assert.equal(await vitalFingerprint(table,r.data[0],s),await vitalFingerprint(table,expected,s));}
(async()=>{
 const {loadCatalogAuthority}=require(path.join(build,'vital/nutrition-f2/catalog-authority'));
 const {submitMealStep,INTEGRATED_MEAL_REVIEW}=require(path.join(build,'vital/nutrition-f2/remote-meal'));
 const {submitRecipeStep}=require(path.join(build,'vital/nutrition-f2/remote-recipe'));
 const authority=await loadCatalogAuthority(fs.readFileSync(path.join(cases,'catalog-lab-authority.json')),fs.readFileSync(path.join(cases,'catalog-lab-authority.sha256'),'utf8').trim(),'lab');
 const baseline='43c39ee489283c772fa52fa07803b2735e94737e',cap={enabled:true,baseline,protocol:'vault-vital-f2-meal-v1',integratedMealReview:INTEGRATED_MEAL_REVIEW,catalogAuthority:authority},rcap={...cap,protocol:'vault-vital-f2-recipe-v1'};
 let calls=0,last;const client={async rpc(name,args){calls++;const r=await call('POST','/rpc/'+name,s.user_id,args);last=r.data;return r.status===200?{data:r.data,error:null}:{data:null,error:{code:r.data?.code??'remote'}};}};
 const step=b=>({scope:s,operationId:b.p_operation,expectedRevision:b.p_expected,meal:vitalWireRow('vital_meals',b.p_row,s),audit:b.p_audit?vitalWireRow('vital_audit',b.p_audit,s):null});
 const rstep=b=>({scope:s,head:vitalWireRow('vital_recipes',b.p_head,s),version:vitalWireRow('vital_recipe_versions',b.p_version,s),audit:null,expectedHead:b.p_expected_head,expectedLatest:b.p_expected_latest,operationId:b.p_operation});
 async function meal(b,status){const a=await submitMealStep(client,async()=>s,cap,baseline,step(b));assert.equal(last.status,status);assert.equal(a.fingerprint,await vitalFingerprint('vital_meals',b.p_row,s));return last;}
 async function recipe(b,status){const a=await submitRecipeStep(client,async()=>s,rcap,baseline,rstep(b));assert.equal(last.status,status);assert.equal(a.versionFingerprint,await vitalFingerprint('vital_recipe_versions',b.p_version,s));return last;}
 await assert.rejects(submitMealStep(client,async()=>s,{...cap,catalogAuthority:undefined},baseline,step(f.meal)));assert.equal(calls,0);ok('catalog capability absent blocks before HTTP');
 await waitForCatalogReadiness((route)=>readinessUnix('GET',route,{Accept:'application/json',Authorization:'Bearer '+jwt(s.user_id)}));
 console.log('R171_POSTGREST_AUTHENTICATED_READINESS_PASS');
 await denied('meal',f.forgedMeal,'consistent forged composition rejected');
 await denied('meal',f.pendingMeal,'pending official row rejected');
 await denied('recipe',f.forgedRecipe,'consistent forged recipe ingredient rejected');
 const wrong=structuredClone(f.meal);Object.values(wrong.p_row.nutrition_f2.items)[0].identity.presentationId='invented-household';await denied('meal',wrong,'unapproved presentation rejected');
 await denied('meal',f.meal,'other account cannot write', '42501',other);
 const r1=await meal(f.meal,'applied');assert.equal(await vitalFingerprint('vital_meals',r1.meal,s),await vitalFingerprint('vital_meals',f.meal.p_row,s));ok('canonical two-provider meal saved unchanged');
 const r2=await meal(f.meal,'retry');assert.deepEqual(r2.meal,r1.meal);ok('exact meal replay returns identical receipt');
 await read('vital_meals',f.meal.p_row);await read('vital_meals',f.meal.p_row,other);ok('meal persisted exact and foreign read empty');
 const r3=await recipe(f.recipe,'applied');assert.equal(await vitalFingerprint('vital_recipe_versions',r3.version,s),await vitalFingerprint('vital_recipe_versions',f.recipe.p_version,s));ok('catalog recipe saved with immutable ingredients');
 const r4=await recipe(f.recipe,'retry');assert.deepEqual(r4.version,r3.version);ok('exact recipe replay');
 await read('vital_recipe_versions',f.recipe.p_version);await read('vital_recipe_versions',f.recipe.p_version,other);ok('recipe persisted exact and foreign read empty');
 const r5=await meal(f.consumed,'applied');assert.equal(await vitalFingerprint('vital_meals',r5.meal,s),await vitalFingerprint('vital_meals',f.consumed.p_row,s));ok('recipe consumption server recomputation');
 const r6=await meal(f.consumed,'retry');assert.deepEqual(r6.meal,r5.meal);await read('vital_meals',f.consumed.p_row);ok('consumption exact replay and persisted fingerprint');
 const direct=await call('POST','/catalog_authority_lab',s.user_id,{provider:'taco'});assert.notEqual(direct.status,201);assert.notEqual(direct.status,200);ok('private registry not exposed through API');
 const anon=await rpc('meal',f.meal,null);assert.notEqual(anon.status,200);ok('anonymous writer denied');
 console.log('R17_CATALOG_HTTP_TOTAL',checks,'REAL_ADAPTER_CALLS',calls);
})().catch(e=>{console.error(e);process.exitCode=1});
