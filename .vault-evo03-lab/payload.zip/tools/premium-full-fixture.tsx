import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {db} from '@/lib/db';
import {createVitalStorage,type CanonicalDb} from '@/lib/vital/storage-dexie';
import {createVitalDraftStorage} from '@/lib/vital/drafts';
import {restoreWorkoutDraft} from '@/lib/vital/draft-payload';
import {VitalRepository} from '@/lib/vital/repository';
import {TABLES,type Scope,type WorkoutRow,type MealRow,type TrainingPlan,type NutritionPlan} from '@/lib/vital/model';
import {vitalViewMemory} from '@/lib/vital/view-preferences';
import {VitalHub,type VitalDestination} from '@/components/vital/VitalHub';
import {VitalChrome,type VitalArea} from '@/components/vital/VitalChrome';
import {VitalProgress} from '@/components/vital/VitalProgressPanel';
import {VitalTrainingPanel} from '@/components/vital/VitalTrainingPanel';
import {VitalNutritionPanel} from '@/components/vital/VitalNutritionPanel';
import {VitalPlansPanel} from '@/components/vital/VitalPlansPanel';
import {ToastProvider} from '@/components/ToastProvider';
const scope:Scope={user_id:'10000000-0000-4000-8000-000000000001',person_id:'10000000-0000-4000-8000-000000000002'};
const other:Scope={...scope,person_id:'10000000-0000-4000-8000-000000000099'};
const today='2026-11-27',mode=new URLSearchParams(location.search).get('mode')??'empty',filled=mode==='filled';
const id=(n:number)=>`10000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
const base={...scope,created_at:today+'T12:00:00Z',updated_at:today+'T12:00:00Z',deleted_at:null,revision:1,synced:true};
const canonicalDb=db as unknown as CanonicalDb;
const auth=async()=>scope.user_id,active=()=>scope;
const repo=new VitalRepository(createVitalStorage({db:canonicalDb,authenticatedUser:auth,activeScope:active,enqueue:async()=>{throw Error('LAB: clinical writes disabled');},dispatch:()=>{throw Error('LAB: no transport');}}));
const drafts=createVitalDraftStorage({db:canonicalDb,authenticatedUser:auth,activeScope:active});
const workout:WorkoutRow={...base,id:id(3),day:today,title:'Treino fictício',modality:'strength',custom_modality:null,status:'completed',started_at:null,ended_at:null,duration_seconds:1800,active_seconds:1200,pause_seconds:600,duration_source:'declared',location_id:null,location_label:null,plan_version_id:null,rehab_program_id:null,notes:null,items:[],clock:null};
const meal:MealRow={...base,id:id(4),day:today,time:'12:00',kind:'lunch',custom_label:null,plan_version_id:null,items:[{id:id(5),food_id:null,name:'Alimento fictício',quantity:100,unit:'g',nutrients:{energy_kcal:210},nutrient_source:'declared'}],notes:null};
const training:TrainingPlan={...base,id:id(6),name:'Ficha fictícia',starts_on:today,ends_on:null};
const nutrition:NutritionPlan={...base,id:id(7),name:'Plano alimentar fictício',starts_on:today,ends_on:null,professional_id:null};
async function initialize(){
 await db.open();const names=db.tables.map(t=>t.name);for(const n of [...TABLES,'vital_drafts','vital_sync_ack','syncQueue','persons'])if(!names.includes(n))throw Error('Missing canonical store '+n);
 if(!(await db.table('persons').get(scope.person_id)))await db.table('persons').put({id:scope.person_id,user_id:scope.user_id,name:'Pessoa fictícia'});
 if(!(await db.table('persons').get(other.person_id)))await db.table('persons').put({id:other.person_id,user_id:other.user_id,name:'Outra pessoa fictícia'});
 if(filled){await db.table('vital_workout_sessions').put(workout);await db.table('vital_workout_sessions').put({...workout,...other,id:id(93),title:'TREINO ESTRANGEIRO'});await db.table('vital_meals').put(meal);await db.table('vital_meals').put({...meal,...other,id:id(94),items:[{...meal.items[0],name:'ALIMENTO ESTRANGEIRO'}]});await db.table('vital_training_plans').put(training);await db.table('vital_nutrition_plans').put(nutrition);}
 const snapshot=await repo.snapshot(scope);if(snapshot.workouts.length!==(filled?1:0)||snapshot.meals.length!==(filled?1:0))throw Error('Scope or cardinality mismatch');
 if(await db.table('syncQueue').count()!==0)throw Error('Unexpected queue mutation');
 vitalViewMemory.activate(scope);
 if(mode==='error')repo.snapshot=async()=>{throw Error('synthetic read failure');};
 const node=document.getElementById('root')!;createRoot(node).render(<ToastProvider><App schema={db.verno} /></ToastProvider>);
}
function App({schema}:{schema:number}){const [area,setArea]=useState<VitalArea>('hub'),[last,setLast]=useState('none');function nav(x:VitalDestination){setLast(x);if(['hub','training','nutrition','progress','plans'].includes(x))setArea(x as VitalArea);}
 const reading=filled?{value:'72 kg',source:'Registro manual fictício'}:null;
 return <main className="mx-auto max-w-3xl space-y-3 px-3 py-3"><p className="rounded-lg border border-amber-400/30 p-2 text-xs text-amber-300">LABORATÓRIO VISUAL · DADOS SINTÉTICOS · DEXIE LOCAL DESCARTÁVEL</p><VitalChrome area={area} settings={false} editingEntry={false} onBack={()=>nav('hub')} onNavigate={nav}/>{area==='training'?<VitalTrainingPanel scope={scope} repo={repo} drafts={drafts} today={today}/>:area==='nutrition'?<VitalNutritionPanel scope={scope} repo={repo} drafts={drafts} today={today}/>:area==='plans'?<VitalPlansPanel scope={scope} repo={repo} drafts={drafts} today={today}/>:area==='progress'?<VitalProgress scope={scope} repo={repo} today={today} weight={reading} hydration={null} records={[]} readingsLoading={false} onNavigate={nav}/>:<VitalHub scope={scope} repo={repo} today={today} weight={reading} hydration={null} readingsLoading={false} nutritionF2Enabled={false} recipesEnabled={false} nutritionConnectEnabled={false} onNavigate={nav}/>}<output data-testid="destination" className="sr-only">{last}</output><output data-testid="schema" className="sr-only">{schema}</output><button type="button" className="sr-only" data-testid="inspect-local" onClick={async()=>{const queue=await db.table('syncQueue').count();const facts=await db.table('vital_workout_sessions').where('[user_id+person_id]').equals([scope.user_id,scope.person_id]).count();const saved=await drafts.list(scope,'workout');const loaded=await Promise.all(saved.map(r=>drafts.load(scope,r.id,'workout',restoreWorkoutDraft)));setLast(JSON.stringify({queue,facts,drafts:saved.length,titles:loaded.map(r=>r?.value.data.title??null)}));}}>Conferir contagens do laboratório</button></main>;
}
void initialize().catch(e=>{document.getElementById('root')!.textContent='LAB INIT ERROR: '+String(e);throw e;});
