import os,sys,json,pathlib,subprocess,hashlib,re
if os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('GITHUB_REF')!='refs/heads/vault/lab/evolution03-20261126-r12' or not __debug__:sys.exit('STOP isolated branch')
lab=pathlib.Path(os.environ['EVO03_LAB']);tmp=pathlib.Path(os.environ['RUNNER_TEMP']);assert lab==tmp/'evo03-lab';candidate=lab/'candidate';out=tmp/'evo03-r12-host';out.mkdir(exist_ok=True)
prior=json.loads((lab/'docs/R11-result.json').read_text());assert len(prior)==15 and all(r['compatibility_pass'] for r in prior)
receipt=json.loads((tmp/'evo03-reanchor-receipt.json').read_text());old=json.loads((lab/'docs/R10-evo03-reanchor-receipt.json').read_text());assert receipt['changed_paths']==101
changed=set(json.loads((lab/'docs/R12-delta.json').read_text())['changed']);new={x['path']:x for x in receipt['receipts']}
for row in old['receipts']:
 if row['path'] not in changed:assert new[row['path']]==row,'STOP previously certified path drift '+row['path']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for old in prior:
 name=old['script'];p=candidate/'scripts'/name;before=sha(p);assert before==old['raw_candidate']['script_sha256'],'STOP historical script drift '+name
 result=subprocess.run(['node','--require','./scripts/vault-m2-test-alias-preload.cjs','scripts/'+name],cwd=candidate,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
 (out/(name+'.log')).write_text(result.stdout);assert sha(p)==before
 aliases=[json.loads(l[len('R11_ALIAS '):]) for l in result.stdout.splitlines() if l.startswith('R11_ALIAS ')]
 if old.get('adapted_candidate'):
  requested=old['raw_candidate']['signature'].split("'")[1];assert any(a['request']==requested for a in aliases)
  for a in aliases:assert sha(candidate/a['source'])==a['sha256'] and a['source']==a['request'][2:]+'.ts'
 rows.append({'name':name,'exit':result.returncode,'sha256':before,'aliases':aliases});print(name,result.returncode,flush=True)
(out/'global-preload-results.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['exit']==0 for r in rows),'Historical regression';print('R12_GLOBAL_PRELOAD_PASS',len(rows))
