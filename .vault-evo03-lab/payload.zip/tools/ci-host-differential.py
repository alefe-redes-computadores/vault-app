#!/usr/bin/env python3
"""R11: raw historical runs plus independent alias-compatible runs; no runtime changes."""
import os,sys,subprocess,pathlib,json,hashlib,re
if os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('GITHUB_REF')!='refs/heads/vault/lab/evolution03-20261126-r11' or not __debug__:
 sys.exit('STOP isolated CI ref required')
tmp=pathlib.Path(os.environ['RUNNER_TEMP']).resolve(); base=tmp/'evo03-observed-macro02'; cand=tmp/'evo03-lab/candidate'; evidence=tmp/'evo03-host-differential'; evidence.mkdir(exist_ok=False)
assert pathlib.Path(os.environ['EVO03_LAB']).resolve()==cand.parent
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()=='bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b'
for f in ('package.json','package-lock.json'):
 assert (base/f).read_bytes()==(cand/f).read_bytes(), 'STOP dependencies differ; require separate installation'
assert (cand/'node_modules/typescript').is_dir() and not (base/'node_modules').exists()
(base/'node_modules').symlink_to(cand/'node_modules',target_is_directory=True)
NAMES=['test-vault-m98-reports-360.cjs', 'test-vault-m63-notifications-search.cjs', 'test-vault-m2-pure-projections.cjs', 'test-v286-planned-purchase-native-agenda.cjs', 'test-v218-overdue-access-avatar.cjs', 'test-v217-prescription-meaning-access-avatar.cjs', 'test-v216-prescription-stages-brain-avatar.cjs', 'test-v215-prescription-archive-withdrawal-avatar.cjs', 'test-v214-care-network-index-avatar-brain.cjs', 'test-v209-overdue-withdrawal-brain-avatar.cjs', 'test-v204-access-brain-reminders-avatar.cjs', 'test-vault-m150-p5-p4.cjs', 'test-vault-m153-p7-build2117.cjs', 'test-vault-ci360-m3-p3.cjs', 'test-vault-ci360-p6-p3-d1.cjs']
previous=json.loads((cand.parent/'docs/R10-result.json').read_text())
assert [r['script'] for r in previous]==NAMES
expected={r['script']:r for r in previous}
assert sum(r['classification']=='same_failure_signature_not_certified' for r in previous)==12
assert sum(r['classification']=='both_pass' for r in previous)==3
resolver=cand.parent/'tools/historical-alias-resolver.cjs'
# Exact previously certified materialization: identical 97 pre/post receipts, no UI/runtime delta.
receipt=json.loads((tmp/'evo03-reanchor-receipt.json').read_text())
assert receipt==json.loads((cand.parent/'docs/R10-evo03-reanchor-receipt.json').read_text()), 'STOP R10 runtime receipt drift'
assert receipt['changed_paths']==len(receipt['receipts'])==97
# Tests may read source but must not mutate it. Ignore only the installed dependencies symlink/tree.
def tree(root):
 result={}
 for directory, dirs, files in os.walk(root):
  if pathlib.Path(directory)==root and 'node_modules' in dirs: dirs.remove('node_modules')
  for file in files:
   p=pathlib.Path(directory)/file
   assert p.is_file() and not p.is_symlink(), 'STOP unsafe source tree'
   result[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
initial={tag:tree(root) for root,tag in [(base,'base'),(cand,'candidate')]}
expected_tree=dict(initial['base'])
for record in receipt['receipts']:
 name=record['path'];assert expected_tree.get(name)==record['target_pre_sha256'],'STOP base preimage drift '+name
 if record['candidate_post_sha256'] is None:expected_tree.pop(name)
 else:expected_tree[name]=record['candidate_post_sha256']
assert expected_tree==initial['candidate'],'STOP R10 tree changed after materialization or npm ci'
(evidence/'tree-identity.json').write_text(json.dumps({'base_files':len(initial['base']),'candidate_files':len(initial['candidate']),'receipt_count':97,'same_as_r10':True},indent=2)+'\n')
def alias_proof(actual,prior,tag):
 requested=prior['signature'].split("'")[1]
 return any(a['request']==requested for a in actual['aliases']) and all(a['source']==a['request'][2:]+'.ts' and initial[tag].get(a['source'])==a['sha256'] for a in actual['aliases'])
rows=[]
def run(root,tag,name,adapted=False):
 p=root/'scripts'/name; assert p.is_file() and not p.is_symlink()
 try:
  cmd=['node']+(['--require',str(resolver)] if adapted else [])+['scripts/'+name]
  proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace',timeout=90)
  rc=proc.returncode; log=proc.stdout
 except subprocess.TimeoutExpired as e:
  rc=124; log=(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout,bytes) else (e.stdout or '')
 (evidence/((('adapted-' if adapted else 'raw-')+tag)+'-'+name+'.log')).write_text(log)
 sig=next((x.strip() for x in log.splitlines() if re.match(r'^(?:[A-Za-z]*Error(?: \[.*?\])?:|AssertionError)',x.strip())),None)
 return {'exit':rc,'signature':sig,'script_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'aliases':[json.loads(line.removeprefix('R11_ALIAS ')) for line in log.splitlines() if line.startswith('R11_ALIAS ')]}
for name in NAMES:
 prior=expected[name]
 b=run(base,'base',name); c=run(cand,'candidate',name)
 # No historical script changes; reproduce raw results or report a discrepancy.
 for actual,old in [(b,prior['base']),(c,prior['candidate'])]:
  assert actual['script_sha256']==old['script_sha256'], 'STOP historical test byte drift '+name
 raw_matches=all(actual[k]==old[k] for actual,old in [(b,prior['base']),(c,prior['candidate'])] for k in ('exit','signature'))
 row={'script':name,'raw_base':b,'raw_candidate':c,'raw_matches_r10':raw_matches,'r10_classification':prior['classification']}
 if prior['classification']=='same_failure_signature_not_certified':
  ab=run(base,'base',name,True); ac=run(cand,'candidate',name,True)
  for actual,old in [(ab,prior['base']),(ac,prior['candidate'])]:assert actual['script_sha256']==old['script_sha256'], 'STOP historical test byte drift '+name
  row.update(adapted_base=ab,adapted_candidate=ac,compatibility_pass=raw_matches and ab['exit']==ac['exit']==0 and alias_proof(ab,prior['base'],'base') and alias_proof(ac,prior['candidate'],'candidate'))
 else:row['compatibility_pass']=raw_matches and b['exit']==c['exit']==0
 rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(evidence/'result.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
for root,tag in [(base,'base'),(cand,'candidate')]:
 assert initial[tag]==tree(root), 'STOP source tree changed by test '+tag
passed=sum(r['compatibility_pass'] for r in rows)
print('R11_COMPATIBILITY_PASS',passed,'/',len(rows),'RAW_FAILURES_RETAINED',sum(r['raw_candidate']['exit']!=0 for r in rows),'NO_SOURCE_DELTA')
# The compatibility gate is separate from the original direct Node invocation.
sys.exit(0 if passed==len(rows) else 1)
