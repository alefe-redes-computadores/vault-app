#!/usr/bin/env python3
"""Review only: run original failing contracts on exact parent and candidate. No runtime changes."""
import os,sys,subprocess,pathlib,json,hashlib,re
if os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('GITHUB_REF')!='refs/heads/vault/lab/evolution03-20261126-r06' or not __debug__:
 sys.exit('STOP isolated CI ref required')
tmp=pathlib.Path(os.environ['RUNNER_TEMP']).resolve(); base=tmp/'evo03-observed-macro02'; cand=tmp/'evo03-lab/candidate'; evidence=tmp/'evo03-host-differential'; evidence.mkdir(exist_ok=False)
assert pathlib.Path(os.environ['EVO03_LAB']).resolve()==cand.parent
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()=='bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b'
for f in ('package.json','package-lock.json'):
 assert (base/f).read_bytes()==(cand/f).read_bytes(), 'STOP dependencies differ; require separate installation'
assert (cand/'node_modules/typescript').is_dir() and not (base/'node_modules').exists()
(base/'node_modules').symlink_to(cand/'node_modules',target_is_directory=True)
NAMES=['test-vault-m98-reports-360.cjs', 'test-vault-m63-notifications-search.cjs', 'test-vault-m2-pure-projections.cjs', 'test-v286-planned-purchase-native-agenda.cjs', 'test-v218-overdue-access-avatar.cjs', 'test-v217-prescription-meaning-access-avatar.cjs', 'test-v216-prescription-stages-brain-avatar.cjs', 'test-v215-prescription-archive-withdrawal-avatar.cjs', 'test-v214-care-network-index-avatar-brain.cjs', 'test-v209-overdue-withdrawal-brain-avatar.cjs', 'test-v204-access-brain-reminders-avatar.cjs', 'test-vault-m150-p5-p4.cjs', 'test-vault-m153-p7-build2117.cjs', 'test-vault-ci360-m3-p3.cjs', 'test-vault-ci360-p6-p3-d1.cjs']
rows=[]
def run(root,tag,name):
 p=root/'scripts'/name; assert p.is_file() and not p.is_symlink()
 try:
  proc=subprocess.run(['node','scripts/'+name],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace',timeout=90)
  rc=proc.returncode; log=proc.stdout
 except subprocess.TimeoutExpired as e:
  rc=124; log=(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout,bytes) else (e.stdout or '')
 (evidence/(tag+'-'+name+'.log')).write_text(log)
 sig=next((x.strip() for x in log.splitlines() if re.match(r'^(?:[A-Za-z]*Error(?: \[.*?\])?:|AssertionError)',x.strip())),None)
 return {'exit':rc,'signature':sig,'script_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for name in NAMES:
 b=run(base,'base',name); c=run(cand,'candidate',name)
 if b['exit']==0 and c['exit']==0: state='both_pass'
 elif b['exit']==0 and c['exit']!=0: state='candidate_regression'
 elif b['exit']!=0 and c['exit']==0: state='candidate_pass_base_fail'
 elif b['signature'] and b['signature']==c['signature'] and b['exit']!=124 and c['exit']!=124: state='same_failure_signature_not_certified'
 else: state='unresolved_difference'
 row={'script':name,'base':b,'candidate':c,'classification':state};rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(evidence/'result.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
# Never convert an observed candidate failure into a green gate.
sys.exit(1 if any(row['candidate']['exit']!=0 for row in rows) else 0)
