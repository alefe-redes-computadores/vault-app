#!/usr/bin/env bash
# Isolated acquisition of public, official sources. No release authorization, DB or credentials.
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r03 ]] || { echo 'STOP branch'; exit 2; }
cd "$(dirname "$0")/.."; lab=$PWD
evidence="${RUNNER_TEMP:?}/evo03-catalog-evidence"; test ! -e "$evidence"; mkdir -m 700 "$evidence"
root=$(mktemp -d); trap 'rm -rf -- "$root"' EXIT
capture(){ curl --fail --silent --show-error --location --max-redirs 4 --proto '=https' --proto-redir '=https' --connect-timeout 20 --max-time 240 --max-filesize 250000000 --output "$2" "$1" || return $?; test -s "$2" || return $?; sha256sum "$2"; }
# Capture hashes attest the bytes downloaded, NOT an independent source signature/Guardian approval.
export PYTHONDONTWRITEBYTECODE=1
usda='https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_foundation_food_csv_2026-10-29.zip'
taco='https://www.nepa.unicamp.br/arquivo/uploads/taco-4a-edicao/taco-4a-edicao-2/'
# Official index labels the same URL as October 2026 v2, corrected 2026-11-19.
# Keep distinct identity; hash documents acquired bytes, not release approval.
set +e;capture "$usda" "$root/usda.zip";u=$?;capture "$taco" "$root/taco.xlsx";t=$?;set -e
printf 'USDA_CAPTURE_EXIT=%s TACO_CAPTURE_EXIT=%s\n' "$u" "$t" | tee "$evidence/acquisition-status.txt"
printf 'USDA URL=%s\nUSDA identity=usda-foundation-2026-10-v2\nTACO URL=%s\nCaptured UTC=%s\nStatus=REVIEW_ONLY; NO ACTIVATION\n' "$usda" "$taco" "$(date -u +%FT%TZ)" > "$evidence/provenance.txt"
if [[ $u == 0 ]];then (cd "$root"; sha256sum usda.zip) >> "$evidence/source-SHA256.txt";fi
if [[ $t == 0 ]];then (cd "$root"; sha256sum taco.xlsx) >> "$evidence/source-SHA256.txt";fi
if [[ $u == 0 ]];then
 python3 "$lab/candidate/scripts/nutrition/import_usda.py" "$root/usda.zip" --sha256 "$(sha256sum "$root/usda.zip"|cut -d' ' -f1)" --release usda-foundation-2026-10-v2 --kind foundation_food --captured "$(date -u +%F)" --out "$root/usda-candidates" || u=$?
fi
if [[ -f "$root/usda-candidates/manifest.json" ]];then cp "$root/usda-candidates/manifest.json" "$evidence/usda-manifest.json";fi
if [[ $t == 0 ]];then
 python3 - "$root/taco.xlsx" > "$evidence/taco-layout.txt" <<'PY' || t=$?
import sys,zipfile
from openpyxl import load_workbook
p=sys.argv[1]
with zipfile.ZipFile(p) as z:
 assert sum(i.file_size for i in z.infolist())<=100_000_000
w=load_workbook(p,read_only=True,data_only=False,keep_links=False)
try:
 for s in w:
  print('TACO_SHEET',repr(s.title),s.max_row,s.max_column)
  for i,row in enumerate(s.iter_rows(min_row=1,max_row=12,max_col=32,values_only=True),1):
   print('REVIEW_LAYOUT',i,repr([str(x)[:150] if x is not None else '' for x in row]))
finally:w.close()
PY
fi
printf 'CAPTURE_REVIEW_ONLY USDA_EXIT=%s TACO_EXIT=%s; NO APPROVED RELEASE\n' "$u" "$t" | tee -a "$evidence/acquisition-status.txt"
[[ $u == 0 && $t == 0 ]]
