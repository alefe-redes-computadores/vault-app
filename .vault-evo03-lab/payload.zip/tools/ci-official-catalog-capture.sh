#!/usr/bin/env bash
# Isolated acquisition of public, official sources. No release authorization, DB or credentials.
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r04 ]] || { echo 'STOP branch'; exit 2; }
cd "$(dirname "$0")/.."; lab=$PWD
evidence="${RUNNER_TEMP:?}/evo03-catalog-evidence"; test ! -e "$evidence"; mkdir -m 700 "$evidence"
root=$(mktemp -d); trap 'rm -rf -- "$root"' EXIT
capture(){ curl --fail --silent --show-error --location --max-redirs 4 --proto '=https' --proto-redir '=https' --connect-timeout 20 --max-time 240 --max-filesize 250000000 --output "$2" "$1" || return $?; test -s "$2" || return $?; sha256sum "$2"; }
# Capture hashes attest the bytes downloaded, NOT an independent source signature/Guardian approval.
export PYTHONDONTWRITEBYTECODE=1
usda='https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_foundation_food_csv_2026-10-29.zip'
taco='https://www.nepa.unicamp.br/arquivo/uploads/taco-4a-edicao/taco-4a-edicao-2/'
# The public index currently labels October 2026 CSV, same URL. The R03 local review identity is retained; the hash is the exact anchor.
usda_expected=e396b1ffc3ea05d1bdccbcddbfd2a4fcb42f64d37fabdacdd9c35158c4ced817
taco_expected=a66b8ec528daeabc63bc2b015fc9bd8c6d76b941c2fc0ed93a4311d449302d14
set +e;capture "$usda" "$root/usda.zip";u=$?;capture "$taco" "$root/taco.xlsx";t=$?;set -e
printf 'USDA_CAPTURE_EXIT=%s TACO_CAPTURE_EXIT=%s\n' "$u" "$t" | tee "$evidence/acquisition-status.txt"
printf 'USDA URL=%s\nUSDA review identity=usda-foundation-2026-10-v2\nTACO URL=%s\nCaptured UTC=%s\nStatus=REVIEW_ONLY; NO ACTIVATION\n' "$usda" "$taco" "$(date -u +%FT%TZ)" > "$evidence/provenance.txt"
# Retain bytes even if they drift or validation fails. Never silently substitute a changed source.
if [[ $u == 0 ]];then
 cp "$root/usda.zip" "$evidence/usda.zip"
 (cd "$evidence";sha256sum usda.zip) >> "$evidence/source-SHA256.txt"
 python3 tools/inspect-usda-archive.py "$root/usda.zip" > "$evidence/usda-layout.json" || u=$?
 [[ $(sha256sum "$root/usda.zip"|cut -d' ' -f1) == "$usda_expected" ]] || { echo 'STOP USDA SOURCE DRIFT';u=2; }
fi
if [[ $t == 0 ]];then
 cp "$root/taco.xlsx" "$evidence/taco.xlsx"
 (cd "$evidence";sha256sum taco.xlsx) >> "$evidence/source-SHA256.txt"
 [[ $(sha256sum "$root/taco.xlsx"|cut -d' ' -f1) == "$taco_expected" ]] || { echo 'STOP TACO SOURCE DRIFT';t=2; }
fi
if [[ $u == 0 ]];then
 python3 "$lab/candidate/scripts/nutrition/import_usda.py" "$root/usda.zip" --sha256 "$usda_expected" --release usda-foundation-2026-10-v2 --kind foundation_food --captured 2026-11-27 --out "$evidence/usda-candidates" || u=$?
fi
if [[ $t == 0 ]];then
 python3 "$lab/candidate/scripts/nutrition/import_taco.py" "$root/taco.xlsx" --sha256 "$taco_expected" --official-observed-r03 --captured 2026-11-27 --out "$evidence/taco-candidates" || t=$?
fi
# Independent readers and all historical parser fixtures: no release approval.
set +e
bash tools/validate-usda-fixture.sh;uf=$?
bash tools/validate-taco-fixture.sh;tf=$?
python3 tests/catalog-usda/test_archive_member.py;ua=$?
python3 tests/catalog-taco/test_official_layout.py;ta=$?
set -e
mkdir -p "$root/reader/lib";cp -a tests/fixture-lib/. "$root/reader/lib/"
(cd "$root/reader";mapfile -d '' files < <(find lib/vital -name '*.ts' -print0);tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}")
if [[ $u == 0 ]];then node tools/verify-official-corpus.cjs usda "$root/reader/build" "$evidence/usda-candidates" || u=$?;fi
if [[ $t == 0 ]];then node tools/verify-official-corpus.cjs taco "$root/reader/build" "$evidence/taco-candidates" || t=$?;fi
printf 'CAPTURE_REVIEW_ONLY USDA_EXIT=%s TACO_EXIT=%s FIXTURES=%s,%s,%s,%s; NO APPROVED RELEASE\n' "$u" "$t" "$uf" "$tf" "$ua" "$ta" | tee -a "$evidence/acquisition-status.txt"
[[ $u == 0 && $t == 0 && $uf == 0 && $tf == 0 && $ua == 0 && $ta == 0 ]]
