#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."; self=$PWD
root=$(mktemp -d); trap 'rm -rf -- "$root"' EXIT
mkdir -p "$root/tools" "$root/tests" "$root/lib"
cp candidate/scripts/nutrition/import_usda.py "$root/tools/"
cp tests/catalog-usda/test_import_usda.py "$root/tests/"
sed "s|../build/frozen-usda-reader|../build/vital/nutrition-f2/frozen-usda-reader|" tests/catalog-usda/frozen-usda-reader.cjs > "$root/tests/frozen-usda-reader.cjs"
cp -a tests/fixture-lib/. "$root/lib/"
while IFS= read -r -d '' f;do cmp "$f" "$self/candidate/${f#"$root/"}";done < <(find "$root/lib" -type f -name '*.ts' -print0)
cd "$root"
PYTHONDONTWRITEBYTECODE=1 python3 tests/test_import_usda.py
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0,'tests');from test_import_usda import USDA,export
x=USDA();x.setUp()
try:
 x.fixture();export(*x.parse(),Path('fixture'));export(*x.parse(release='usda-foundation-2026-10-v2'),Path('fixture-v2'))
finally:x.tearDown()
PY
mapfile -d '' files < <(find lib/vital -name '*.ts' -print0)
tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}"
for tz in UTC America/Sao_Paulo America/New_York;do echo "FUSO=$tz"; TZ="$tz" USDA_FIXTURE="$root/fixture" USDA_FIXTURE_V2="$root/fixture-v2" node --test tests/frozen-usda-reader.cjs;done
