'use strict';
// Read-only, deterministic observation of each explicit user action in the synthetic CI fixture.
const assert=require('node:assert/strict');
const pendingLabel='Conferi alimento e porção', confirmedLabel='Conferido · revisar novamente';
function onlyDraft(snapshot){
 assert.equal(snapshot.rows.length,0,'review must not persist a clinical fact');
 assert.equal(snapshot.queue,0,'review must not enqueue a clinical fact');
 assert.equal(snapshot.acks,0,'review must not fabricate an ACK');
 assert.equal(snapshot.drafts.length,1);assert.equal(snapshot.draftDetails.length,1);
 const d=snapshot.draftDetails[0];assert.equal(d.id,snapshot.drafts[0].id);assert.equal(d.draft_revision,snapshot.drafts[0].draft_revision);return d;
}
async function reviewEachCatalogItem(page,inspect,{timeout=10000,onStage=async()=>{}}={}){
 const plate=page.getByRole('region',{name:'Prato nutricional',exact:true});await plate.waitFor({timeout});
 const first=onlyDraft(await inspect());assert.equal(first.payload.phase,'editing');
 const items=first.payload.draft.items;assert.equal(items.length,2);assert.equal(new Set(items.map(i=>i.id)).size,2);assert.ok(items.every(i=>i.reviewed===false));
 assert.deepEqual(items.map(i=>[i.composition.source.recordId,i.quantity.value,i.quantity.unit]).sort(),[['163',80,'g'],['321611',0.1,'kg']]);
 const seal=(remaining)=>plate.getByRole('button',{name:'Revisar e preparar confirmação'+(remaining?` · ${remaining} pendentes`:''),exact:true});
 await seal(2).waitFor({timeout});assert.ok(await seal(2).isDisabled());
 let previous=first;
 for(let index=0;index<items.length;index++){
  const item=items[index];await onStage(`review-${index+1}-before`);
  // Locate the specific item's card by its unique heading, not a changing list index.
  const heading=plate.getByRole('heading',{name:item.composition.name,level:3,exact:true});assert.equal(await heading.count(),1);
  const card=heading.locator('xpath=ancestor::div[.//button[@aria-pressed]][1]');
  const pending=card.getByRole('button',{name:pendingLabel,exact:true}).and(card.locator('button[aria-pressed="false"]'));
  const confirmed=card.getByRole('button',{name:confirmedLabel,exact:true}).and(card.locator('button[aria-pressed="true"]'));
  await pending.waitFor({timeout});await pending.click({timeout}); // exactly one click per item
  await confirmed.waitFor({timeout});
  const now=onlyDraft(await inspect());assert.equal(now.id,first.id);assert.equal(now.draft_revision,previous.draft_revision+1,'one persisted CAS revision per explicit review');assert.equal(now.payload.phase,'editing');
  assert.equal(now.payload.draft.operationId,first.payload.draft.operationId);
  assert.deepEqual(now.payload.draft.items,items.map((i,n)=>({...i,reviewed:n<=index})),'same item identities, amounts, sources and compositions; only review state changes');
  previous=now;const remaining=items.length-index-1;await seal(remaining).waitFor({timeout});
  if(remaining)assert.ok(await seal(remaining).isDisabled());
  await onStage(`review-${index+1}-persisted`);
 }
 await seal(0).and(plate.locator('button:enabled')).waitFor({timeout});
 return previous;
}
module.exports={onlyDraft,reviewEachCatalogItem};
