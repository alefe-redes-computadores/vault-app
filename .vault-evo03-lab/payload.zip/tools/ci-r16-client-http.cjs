'use strict';
// Real TypeScript RPC adapters -> disposable PostgREST via Unix socket. No TCP, production or saved credentials.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto'),assert=require('node:assert/strict');
if(process.env.GITHUB_ACTIONS!=='true'||process.env.GITHUB_REF!=='refs/heads/vault/lab/evolution03-20261126-r16')throw Error('STOP isolated branch');
const [socket,build,cases]=process.argv.slice(2);assert.ok(path.isAbsolute(socket)&&fs.statSync(socket).isSocket());assert.ok(path.isAbsolute(build)&&path.isAbsolute(cases));
const secret=process.env.VAULT_LAB_JWT_SECRET;assert.ok(secret?.length>=32,'STOP disposable JWT missing');
const load=n=>JSON.parse(fs.readFileSync(path.join(cases,'postgrest-'+n+'.json'),'utf8'));
const {submitMealStep,planMealSteps,preflightMealChain,INTEGRATED_MEAL_REVIEW}=require(path.join(build,'vital/nutrition-f2/remote-meal'));
const {submitRecipeStep,recipeRequest}=require(path.join(build,'vital/nutrition-f2/remote-recipe'));
const {vitalWireRow,vitalFingerprint,vitalRemoteFields,vitalPayload,vitalAckId,pushVital,vitalTable}=require(path.join(build,'vital/cloud-transport'));
const {verifyVitalBackupRemote,encryptVitalBackup,decryptVitalBackup}=require(path.join(build,'vital/backup'));
const {createSupabaseVitalTransport,PLAN_TARGET_REVIEW}=require(path.join(build,'vital/supabase-transport'));
const {makeSnapshot}=require(path.join(build,'vital/nutrition-f2/nutrition'));
const {recipeConsumptionDraft}=require(path.join(build,'vital/nutrition-f2/recipe-consumption'));
const {prepareMealEnvelope}=require(path.join(build,'vital/nutrition-f2/persistence'));
const {certifiedVitalF2Release}=require(path.join(build,'vital/nutrition-f2/release-capability'));
const id=n=>`90000000-0000-4000-8000-${String(n).padStart(12,'0')}`,scope={user_id:id(1),person_id:id(11)},baseline='43c39ee489283c772fa52fa07803b2735e94737e';
assert.equal(certifiedVitalF2Release(),null);const cap={protocol:'vault-vital-f2-meal-v1',enabled:true,baseline,integratedMealReview:INTEGRATED_MEAL_REVIEW},recipeCap={...cap,protocol:'vault-vital-f2-recipe-v1'};
const jwt=user=>{const msg=Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url')+'.'+Buffer.from(JSON.stringify({sub:user,role:'authenticated',exp:Math.floor(Date.now()/1000)+600})).toString('base64url');return msg+'.'+crypto.createHmac('sha256',secret).update(msg).digest('base64url');};
const {makeUnixRequester}=require('./lab-unix-http.cjs');
const unix=makeUnixRequester(socket,{trace:event=>console.log('R16_HTTP_TRACE',JSON.stringify(event))});
function request(method,url,user,body){return unix(method,url,{Accept:'application/json',Authorization:'Bearer '+jwt(user)},body);}

let count=0;const statuses=[];const rpcFor=user=>({async rpc(name,args){assert.ok(['vault_vital_meal_f2_review','vault_vital_recipe_f2_review','vault_vital_plan_targets_f2_review'].includes(name));const r=await request('POST','/rpc/'+name,user,args);count++;if(r.status!==200)return {data:null,error:{code:r.data?.code??'remote'}};statuses.push(r.data.status);return {data:r.data,error:null};}});const rpc=rpcFor(scope.user_id),active=async()=>scope;
const step=p=>({scope,operationId:p.p_operation,expectedRevision:p.p_expected,meal:vitalWireRow('vital_meals',p.p_row,scope),audit:p.p_audit?vitalWireRow('vital_audit',p.p_audit,scope):null});
const ok=(n)=>console.log('R16_CLIENT_HTTP_PASS',n);
async function head(table,record){const r=await request('GET',`/${table}?id=eq.${record.id}&select=${vitalRemoteFields(table).join(",")}`,scope.user_id);assert.equal(r.status,200);assert.equal(r.data.length,1);assert.equal(await vitalFingerprint(table,r.data[0],scope),await vitalFingerprint(table,record,scope));}
async function meal(s,expected){const i=statuses.length,a=await submitMealStep(rpc,active,cap,baseline,s);assert.equal(statuses[i],expected);assert.equal(a.fingerprint,await vitalFingerprint('vital_meals',s.meal,scope));if(s.audit)assert.equal(a.auditFingerprint,await vitalFingerprint('vital_audit',s.audit,scope));return a;}
(async()=>{
 const label=step(load('label')),portion=step(load('recipe-portion')),chain=load('external-chain').map(step);for(const s of [label,portion,chain[0]])assert.equal(s.scope.user_id,scope.user_id);
 // Historical raw HTTP suite ran before this driver. These are distinct fresh fixtures.
 const start=count;await assert.rejects(submitMealStep(rpc,active,{...cap,integratedMealReview:undefined},baseline,label),/revisão remota compatível/);assert.equal(count,start);ok('legacy capability blocks before HTTP');
 // Real server commit with a discarded response: no fake ACK; exact retry must succeed.
 await assert.rejects(submitMealStep({async rpc(n,args){const r=await rpc.rpc(n,args);assert.equal(r.data.status,'applied');throw Error('synthetic lost response after commit');}},active,cap,baseline,label),/lost response/);await meal(label,'retry');await head('vital_meals',label.meal);ok('OCR receipt lost and replayed, persisted fingerprint verified');
 await meal(portion,'applied');await meal(portion,'retry');await head('vital_meals',portion.meal);ok('recipe portion persisted and replayed');
 // Prove the original collision against the server BEFORE repairing synthetic IDs.
 const original=load('recipe-consumption');assert.equal(chain.at(-1).operationId,original.p_operation);assert.equal(chain.at(-1).operationId,id(952));
 await preflightMealChain(null,chain,cap);await meal(chain[0],'applied');await meal(chain[1],'applied');
 await assert.rejects(submitMealStep(rpc,active,cap,baseline,chain[2]),/23505/);await head('vital_meals',chain[1].meal);
 const collisionAudit=await request('GET',`/vital_audit?id=eq.${chain[2].audit.id}&select=id`,scope.user_id);assert.equal(collisionAudit.status,200);assert.deepEqual(collisionAudit.data,[]);ok('original 952 collision denied, previous head and audit cardinality preserved');
 // Only the archive audit/operation ID changes. The frozen HC envelope and original history are untouched.
 chain[2]={...chain[2],operationId:id(972),audit:{...chain[2].audit,id:id(972)}};
 assert.ok(![original.p_operation,chain[0].operationId,chain[1].operationId,portion.operationId,label.operationId].includes(chain[2].operationId));
 await preflightMealChain(null,chain,cap);await meal(chain[2],'applied');for(const s of chain)await meal(s,'retry');await head('vital_meals',chain.at(-1).meal);for(const s of chain.filter(s=>s.audit))await head('vital_audit',s.audit);ok('Health Connect insert, revision, tombstone, historical receipts and audits');
 // New recipe uses exact reviewed OCR composition and the same canonical ingredient recomputation.
 const common=n=>({...scope,id:id(n),created_at:label.meal.created_at,updated_at:label.meal.created_at,deleted_at:null,revision:1,synced:false});
 const composition=Object.values(label.meal.nutrition_f2.items)[0].payload.composition, h={...common(981),kind:'recipe',name:'Receita OCR sintética',active:true,favorite:false};
 const v={...common(982),recipe_id:h.id,version:1,name_snapshot:h.name,ingredients:[makeSnapshot(scope,id(983),composition,{value:200,unit:'g'})],raw_edible_mass_g:200,finished_mass_g:150,servings:3,yield_evidence:'Peso declarado',retention_evidence:null,reviewed_at:h.created_at};
 const r={scope,head:h,version:v,audit:null,expectedHead:null,expectedLatest:null,operationId:v.id};
 const req=recipeRequest(r,recipeCap),forged=structuredClone(req);forged.p_proofs[0].snapshot.payload.composition.labelEvidence.fields[0].raw='999';const rejected=await rpc.rpc('vault_vital_recipe_f2_review',forged);assert.equal(rejected.error?.code,'23514');ok('server refuses tampered label ingredient proof');
 const rc=statuses.length;await submitRecipeStep(rpc,active,recipeCap,baseline,r);await submitRecipeStep(rpc,active,recipeCap,baseline,r);assert.deepEqual(statuses.slice(rc),['applied','retry']);await head('vital_recipes',h);await head('vital_recipe_versions',v);ok('reviewed OCR ingredient recipe write + retry');
 const item=recipeConsumptionDraft(scope,v,id(984),{value:50,unit:'g'}),env=prepareMealEnvelope(scope,{scope,mealId:id(985),operationId:id(986),items:[{...item,reviewed:true}]},h.created_at,[]);const derived={...common(985),day:'2026-11-25',time:'12:30',kind:'lunch',custom_label:null,plan_version_id:null,notes:null,items:env.items,nutrition_f2:env.nutrition_f2};const [s]=await planMealSteps(scope,derived,null,null,[]);await meal(s,'applied');await meal(s,'retry');await head('vital_meals',s.meal);ok('consumption of OCR recipe version with server recomputation');
 await assert.rejects(submitMealStep(rpcFor(id(2)),active,cap,baseline,label),/42501/);const denied=await request('GET',`/vital_meals?id=eq.${label.meal.id}&select=id`,id(2));assert.equal(denied.status,200);assert.deepEqual(denied.data,[]);ok('cross-account write/read denied');
 // F2 targets: same canonical plan/version tables and existing pushVital ACK. Real remote socket,
 // local ACK Map is deliberately synthetic; it does not certify physical Dexie or host queue.
 const planTable='vital_nutrition_plan_versions',targetCap={mode:'f2',...cap,approvedBaseline:baseline,planTargets:true,planTargetProtocol:PLAN_TARGET_REVIEW,recipes:true};
 const planRoot={...common(1000),name:'Plano sintético R16',starts_on:'2026-11-25',ends_on:null,professional_id:null};
 const planRow=(n,version,day)=>({...common(n),plan_id:planRoot.id,version,effective_on:day,status:'active',plan_name:planRoot.name,professional_id:null,modality_ids:['balanced'],modalities:[{id:'balanced',name:'Equilibrada',identity_id:'balanced',category:'pattern'}],custom_modality:null,rules:[],targets:{protein_g:100},targets_f2:{iron_mg:{kind:'at_least',amount:18,unit:'mg'},sodium_mg:{kind:'at_most',amount:0,unit:'mg'}},origin:'user',notes:null});
 const v1=planRow(1001,1,'2026-11-25'),v2=planRow(1002,2,'2026-11-26'),v3=planRow(1003,3,'2026-11-27');
 const missing=await rpc.rpc('vault_vital_plan_targets_f2_review',{p_person:scope.person_id,p_row:vitalPayload(planTable,v1,scope)});assert.equal(missing.error?.code,'42501');ok('missing canonical root denied');
 const rootResponse=await request('POST','/vital_nutrition_plans',scope.user_id,vitalPayload('vital_nutrition_plans',planRoot,scope));assert.equal(rootResponse.status,201);await head('vital_nutrition_plans',planRoot);
 let planCalls=0,lost=true;const client={from(t){assert.ok(vitalTable(t));const params=new URLSearchParams();const q={select(k){params.set('select',k);return q;},eq(k,v){params.set(k,'eq.'+v);return q;},gt(k,v){params.set(k,'gt.'+v);return q;},order(k,o){params.set('order',k+(o.ascending?'.asc':'.desc'));return q;},limit(n){params.set('limit',String(n));return q;},maybeSingle(){q.one=true;return q;},then(resolve,reject){return request('GET','/'+t+'?'+params.toString(),scope.user_id).then(r=>{if(r.status!==200)return {data:null,error:{message:'read denied',code:r.data?.code}};assert.ok(Array.isArray(r.data));if(q.one)assert.ok(r.data.length<=1);return {data:q.one?r.data[0]??null:r.data,error:null};}).then(resolve,reject);}};return {...q,insert(){throw Error('unexpected direct DML');},update(){throw Error('unexpected direct DML');}};},async rpc(n,args){planCalls++;const out=await rpc.rpc(n,args);if(lost){assert.equal(out.data?.status,'applied');lost=false;throw Error('lost plan response');}return out;}};
 const transport=createSupabaseVitalTransport(client,async()=>scope.user_id,targetCap),journal=new Map(),deps={remote:transport,acks:{async read(k){return journal.get(k)},async write(row){journal.set(row.id,structuredClone(row));}}};
 // Before sending, legacy direct mutation and noncanonical targets remain blocked.
 const payload1=vitalPayload(planTable,v1,scope),bad=structuredClone(payload1);bad.targets_f2.iron_mg.unit='g';
 const generic=await request('POST','/'+planTable,scope.user_id,payload1);assert.equal(generic.status,403);assert.equal(generic.data.code,'42501');
 const invalid=await rpc.rpc('vault_vital_plan_targets_f2_review',{p_person:scope.person_id,p_row:bad});assert.equal(invalid.error?.code,'23514');ok('direct F2 DML and invalid targets denied');
 await assert.rejects(pushVital(deps,planTable,scope,v1),/lost plan response/);const key=vitalAckId(planTable,scope,v1.id);assert.equal(journal.get(key).pending_revision,1);assert.equal(journal.get(key).revision,null);
 const ack=await pushVital(deps,planTable,scope,v1);assert.equal(ack.pending_revision,null);assert.equal(ack.fingerprint,await vitalFingerprint(planTable,v1,scope));assert.equal(planCalls,1);await head(planTable,v1);ok('plan version persisted, lost response recovered by canonical fingerprint without second RPC');
 console.log('R16_PLAN_PHASE second version');const ack2=await pushVital(deps,planTable,scope,v2);assert.equal(ack2.revision,1);await head(planTable,v2);await head(planTable,v1);
 console.log('R16_PLAN_PHASE historical retry');const retry=await rpc.rpc('vault_vital_plan_targets_f2_review',{p_person:scope.person_id,p_row:payload1});assert.equal(retry.data?.status,'retry');assert.equal(await vitalFingerprint(planTable,retry.data.version,scope),ack.fingerprint);
 const changed=structuredClone(payload1);changed.targets_f2.iron_mg.amount=19;const started=Date.now();const changedRetry=await request('POST','/rpc/vault_vital_plan_targets_f2_review',scope.user_id,{p_person:scope.person_id,p_row:changed});assert.equal(changedRetry.status,409);assert.equal(changedRetry.data?.code,'PT409');assert.ok(Date.now()-started<8000,'permanent conflict must finish promptly');await head(planTable,v1);await head(planTable,v2);await assert.rejects(pushVital(deps,planTable,scope,{...v1,targets_f2:{}}));ok('version history immutable, historical retry exact, changed replay refused with finite HTTP 409');
 console.log('R16_PLAN_PHASE concurrent versions');const loser={...v3,id:id(1004)},race=await Promise.all([v3,loser].map(v=>rpc.rpc('vault_vital_plan_targets_f2_review',{p_person:scope.person_id,p_row:vitalPayload(planTable,v,scope)})));
 assert.equal(race.filter(x=>x.data?.status==='applied').length,1);assert.equal(race.filter(x=>['23514','23505','PT409'].includes(x.error?.code)).length,1);
 const persisted=await request('GET','/'+planTable+'?plan_id=eq.'+planRoot.id+'&select=id,version&order=version.asc',scope.user_id);assert.equal(persisted.status,200);assert.deepEqual(persisted.data.map(x=>x.version),[1,2,3]);ok('concurrent versions serialize at canonical root, only one winner');
 const foreign=await rpcFor(id(2)).rpc('vault_vital_plan_targets_f2_review',{p_person:scope.person_id,p_row:payload1});assert.equal(foreign.error?.code,'42501');const wrongPerson=await rpc.rpc('vault_vital_plan_targets_f2_review',{p_person:id(12),p_row:payload1});assert.equal(wrongPerson.error?.code,'42501');
 const deniedPlan=await request('GET','/'+planTable+'?id=eq.'+v1.id+'&select=id',id(2));assert.deepEqual(deniedPlan.data,[]);const directChange=await request('PATCH','/'+planTable+'?id=eq.'+v1.id,scope.user_id,{targets_f2:{}});assert.equal(directChange.status,403);await head(planTable,v1);ok('plan account/person isolation and direct version mutation denied');
 // Independent empty person in the same synthetic account. Check legacy F1 write and exact encrypted
 // backup against real PostgREST, not a fixture that simply returns the incoming backup.
 const s2={...scope,person_id:id(12)},root2={...planRoot,...s2,id:id(1010),name:'Plano recuperação R16'},vA={...v1,...s2,id:id(1011),plan_id:root2.id,plan_name:root2.name},vB={...v2,...s2,id:id(1012),plan_id:root2.id,plan_name:root2.name};delete vB.targets_f2;
 const init2=await request('POST','/vital_nutrition_plans',scope.user_id,vitalPayload('vital_nutrition_plans',root2,s2));assert.equal(init2.status,201);await pushVital(deps,planTable,s2,vA);
 const legacy2=await request('POST','/'+planTable,scope.user_id,vitalPayload(planTable,vB,s2));assert.equal(legacy2.status,201);ok('F1 version insert remains compatible after F2');
 const copy={schema:2,scope:s2,created_at:root2.created_at,entries:[{table:'vital_nutrition_plans',row:{...root2,synced:true}},{table:planTable,row:{...vA,synced:true}},{table:planTable,row:{...vB,synced:true}}]};
 const encrypted=await encryptVitalBackup(copy,s2,'synthetic lab passphrase only'),opened=await decryptVitalBackup(encrypted,s2,'synthetic lab passphrase only');
 const preRestore=planCalls,verified=await verifyVitalBackupRemote(opened,s2,transport);assert.equal(verified.length,3);assert.ok(verified.every(x=>x.ack?.revision===1));assert.equal(verified.find(x=>x.row.id===vA.id).ack.fingerprint,await vitalFingerprint(planTable,vA,s2));assert.equal(planCalls,preRestore);
 const badCopy=structuredClone(opened);badCopy.entries.find(x=>x.row.id===vA.id).row.targets_f2={};await assert.rejects(verifyVitalBackupRemote(badCopy,s2,transport),/diverge/);assert.equal(planCalls,preRestore);ok('encrypted plan backup confirmed against actual remote history; tampering refused without writes');
 // Persist only synthetic identifiers and pass counters, not JWTs, requests or user data.
 const proof={status:'DISPOSABLE_REAL_POSTGREST_ADAPTER_ONLY',rpcCalls:count,receipts:statuses,records:[label.meal.id,portion.meal.id,chain.at(-1).meal.id,derived.id],externalRevision:3,recipeVersion:v.id,planRoot:planRoot.id,planVersions:persisted.data.map(x=>x.id),planAck:ack.fingerprint,originalCollision:original.p_operation,correctedArchive:chain[2].operationId,backupRemoteVerified:verified.length};fs.writeFileSync(path.join(cases,'r16-client-proof.json'),JSON.stringify(proof,null,2)+'\n');console.log('R16_REAL_CLIENT_HTTP_PASS',count);
})().catch(e=>{console.error(e);process.exitCode=1});
