import React,{useSyncExternalStore} from 'react';
import {createRoot} from 'react-dom/client';
import {db} from '@/lib/db';
import {createVitalStorage,type CanonicalDb} from '@/lib/vital/storage-dexie';
import {createVitalDraftStorage} from '@/lib/vital/drafts';
import {VitalRepository} from '@/lib/vital/repository';
import {certifiedVitalF2Release} from '@/lib/vital/nutrition-f2/release-capability';
import {VitalScreen} from '@/components/vital/VitalScreen';
import {ToastProvider} from '@/components/ToastProvider';
const scope={user_id:'53000000-0000-4000-8000-000000000001',person_id:'53000000-0000-4000-8000-000000000002'};
const enabled=localStorage.getItem('r19-synthetic-f2')==='yes';
const auth=async()=>scope.user_id,active=()=>scope;
const repo=new VitalRepository(createVitalStorage({db:db as unknown as CanonicalDb,authenticatedUser:auth,activeScope:active,recipesEnabled:enabled,enqueue:async()=>{throw Error('LAB: route-only writes denied');},dispatch:()=>{throw Error('LAB: no transport');}}));
const drafts=createVitalDraftStorage({db:db as unknown as CanonicalDb,authenticatedUser:auth,activeScope:active});
Object.assign(window,{__r19runtime:{scope,repo,drafts,loading:false,nutritionF2Enabled:enabled?true:undefined,recipesEnabled:enabled?true:undefined,nutritionConnect:null,restoreBackup:async()=>{throw Error('LAB route-only restore denied');}},__r19inspect:async()=>({queue:await db.table('syncQueue').count(),facts:await db.table('vital_meals').count()})});
const subscribe=(cb:()=>void)=>{window.addEventListener('popstate',cb);return()=>window.removeEventListener('popstate',cb);};
function App(){useSyncExternalStore(subscribe,()=>location.href);const route=location.pathname;const areas:Record<string,'hub'|'training'|'nutrition'|'plans'|'progress'>={'/saude/vital':'hub','/saude/vital/treinos':'training','/saude/vital/nutricao':'nutrition','/saude/vital/planos':'plans','/saude/vital/evolucao':'progress'};const area=areas[route];return area?<VitalScreen area={area} key={route}/>:<main><h1>Destino externo ao fixture de Vital</h1><p>{route}</p></main>;}
async function init(){if(certifiedVitalF2Release()!==null)throw Error('Unexpected release authority');await db.open();await db.table('persons').put({id:scope.person_id,user_id:scope.user_id,name:'Pessoa fictícia R19'});createRoot(document.getElementById('root')!).render(<ToastProvider><App/></ToastProvider>);}
void init().catch(e=>{document.getElementById('root')!.textContent='LAB INIT ERROR '+String(e);throw e;});
