#!/usr/bin/env python3
"""Independent decimal model of the R16 coverage predicate (not PostgreSQL)."""
from decimal import Decimal as D
from pathlib import Path
import collections,json,sys
EPS=D('1e-12')
FIELDS=('amount','estimatedSubtotal')
def isnum(v):return type(v) in (D,int)
def near(a,b):return isnum(a) and isnum(b) and abs(D(a)-D(b))<=abs(D(b))*EPS
def equal_amount(a,b):return (a is None and b is None) or near(a,b)
def exact(a,b):
 if isnum(a) and isnum(b):return D(a)==D(b)
 if type(a) is not type(b):return False
 if isinstance(a,dict):return set(a)==set(b) and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def coverage_ok(actual,expected):
 return isinstance(actual,dict) and set(actual)==set(expected) and all(equal_amount(actual[k],expected[k]) if k in FIELDS else exact(actual[k],expected[k]) for k in expected)
def expected_cov(t):
 state=t['state'];known=int(state in ('known','declared_zero'));na=int(state=='not_applicable')
 return {'counts':{k:int(k==state) for k in ('known','declared_zero','estimated','trace','not_analyzed','not_reported','illegible','not_applicable','unknown')},'amount':t['amount'] if state=='known' else 0 if state=='declared_zero' else None,'estimatedSubtotal':t['amount'] if state=='estimated' else None,'known':known,'unknown':1-known-na,'notApplicable':na,'total':1,'complete':known==1 and na==0,'scope':'recorded_items_only'}
def run(directory):
 total=0;oldbad=[];newbad=[];fields=collections.Counter();cohorts=[];negative=0
 for i in range(3):
  pos=bad=neg=0
  with (Path(directory)/f'cohort-{i}.sql').open() as f:
   for line in f:
    if not line.startswith('INSERT INTO r23_cases SELECT'):continue
    cases=json.loads(line.split('$r23json$')[1],parse_float=D)
    for r in cases:
     total+=1
     if not r['expected']:negative+=1;neg+=1;continue
     pos+=1;s=next(iter(r['env']['items'].values()));t=s['payload']['totals'];diff=[];nd=[]
     for k,c in s['coverage'].items():
      exp=expected_cov(t.get(k,{'state':'not_reported'}))
      if c!=exp:diff.append(k);fields[k]+=1
      if not coverage_ok(c,exp):nd.append(k)
     if diff:oldbad.append({'cohort':i,'label':r['label'],'fields':diff});bad+=1
     if nd:newbad.append({'cohort':i,'label':r['label'],'fields':nd})
  cohorts.append({'cohort':i,'positive':pos,'negative':neg,'exact_coverage_mismatches':bad})
 assert total==6752 and negative==2976
 assert len(newbad)==0,newbad[:5]
 assert any('1104705' in x['label'] and x['label'].endswith(':g') and 'selenium_ug' in x['fields'] for x in oldbad)
 return {'mode':'LOCAL_DECIMAL_MODEL_NOT_POSTGRESQL','total_cases':total,'positive':total-negative,'negative_not_evaluated_by_this_model':negative,'original_exact_coverage_mismatches':len(oldbad),'proposed_coverage_mismatches':len(newbad),'cohorts':cohorts,'nutrient_differences':dict(fields),'mismatches':oldbad}
if __name__=='__main__':
 out=run(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='mismatches'},indent=2))
