'use strict';
// Disposable review only. No catalog release, personal storage, network, or application activation.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const pins={taco:'bf5f03c123ae90053682e595430f5adb00680ed1f689b65c676ef68c5504ff49',usda:'4bd2f7e41502ce6adc2123ca7d80c6e342fde9655d290d7e5b4c275292456f28'};
const ledgerPin='25c041da4be855876acc84a45d99236e152e11903a8e1e0ca1543650fdcc0e22';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const stable=x=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const key=(provider,version,id)=>JSON.stringify([provider,version,id]);
const compositionKey=c=>key(c.source.provider,c.source.version,c.source.recordId);
const fold=s=>s.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase('pt-BR').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
// Explicit, fixed experimental subset. This is NOT a reviewer decision or a production authority.
const LAB_ROWS=[['taco','taco-2011-4ed','163','c54def344f9222952b12fcf435818e1370b2920751c12a9196bc5a85c60c39d9'],['usda','usda-foundation-2026-10-v2','321611','b2b156f6517f32d7a7e8f4caa9a9b1a1478335ed218dd70a454a664ce385b015']];
async function loadCatalogReview(build,corpus,ledgerPath){
 const bytes=fs.readFileSync(ledgerPath);assert.equal(sha(bytes),ledgerPin,'Pinned review ledger mismatch');
 const ledger=new Map();for(const l of bytes.toString('utf8').trimEnd().split('\n')){const r=JSON.parse(l),k=key(r.provider,r.release,r.id);assert.ok(!ledger.has(k));assert.equal(r.decision,'pending');assert.equal(r.reviewerRef,null);assert.equal(r.reason,null);ledger.set(k,r);}
 assert.equal(ledger.size,1095);const rows=new Map();
 const {UNITS}=require(path.resolve(build,'vital/nutrition-f2/nutrition.js'));
 for(const [provider,pin] of Object.entries(pins)){
  const dir=path.join(corpus,provider+'-candidates'),m=fs.readFileSync(path.join(dir,'manifest.json')),f=fs.readFileSync(path.join(dir,'foods.jsonl'));
  const readers=require(path.resolve(build,'vital/nutrition-f2/frozen-'+provider+'-reader.js'));
  const result=await (provider==='taco'?readers.readFrozenTaco:readers.readFrozenUSDA)(m,f,pin);assert.equal(result.activation,false);
  for(const c of result.candidates){const k=compositionKey(c.composition),r=ledger.get(k);assert.ok(r&&!rows.has(k),'Missing/duplicate reviewed identity');assert.equal(c.requiresReview,true);assert.equal(c.sourceRecordSha256,r.sourceRecordSha256);assert.equal(r.manifestSha256,pin);assert.equal(c.composition.name,r.name);assert.deepEqual(c.composition.base,r.base);assert.equal(c.composition.source.license,r.license);assert.equal(c.composition.source.attribution,r.attribution);assert.equal(Object.keys(UNITS).filter(n=>['known','declared_zero'].includes(c.composition.values[n]?.state)).length,r.coverage);rows.set(k,{...r,key:k,composition:c.composition});}
 }
 assert.equal(rows.size,ledger.size);assert.equal(rows.size,1095);
 const search=(query,provider,limit=30)=>{assert.ok(typeof query==='string'&&query.length<=160&&[undefined,'taco','usda'].includes(provider)&&Number.isInteger(limit)&&limit>=1&&limit<=100);const words=fold(query).split(' ').filter(Boolean);if(!words.length)return {hits:[],total:0};const hits=[...rows.values()].filter(r=>(!provider||r.provider===provider)&&words.every(w=>fold(r.name).includes(w))).sort((a,b)=>a.name.localeCompare(b.name,'pt-BR')||a.key.localeCompare(b.key));return {hits:structuredClone(hits.slice(0,limit).map(({composition,...r})=>r)),total:hits.length};};
 return {status:'REVIEW_ONLY',approved:0,total:rows.size,search,reviewRow:k=>structuredClone(rows.get(k)??null),createLabAuthority(){
  const allowed=new Map();for(const [provider,version,id,recordHash] of LAB_ROWS){const k=key(provider,version,id),r=rows.get(k);assert.ok(r&&r.sourceRecordSha256===recordHash&&r.flags.length===0);allowed.set(k,r);}
  const policies=[...allowed.values()].map(r=>({provider:r.provider,release:r.release,manifestSha256:r.manifestSha256,allowed:['query','snapshot'],approvalRef:'LAB_SYNTHETIC_ONLY_NOT_PRODUCTION'}));
  const {reviewedSnapshot}=require(path.resolve(build,'vital/nutrition-f2/nutrition.js'));
  const {requireId,requireScope}=require(path.resolve(build,'vital/validation.js'));
  function check(c){const r=allowed.get(compositionKey(c));assert.ok(r&&stable(r.composition)===stable(c),'Catalog composition is pending or differs from the frozen record');return r;}
  function select(scope,k,itemId,quantity){const s=requireScope(scope),r=allowed.get(k);assert.ok(r,'Not in isolated approval subset');const q=structuredClone(quantity);assert.ok(['g','kg'].includes(q.unit)&&Number.isFinite(q.value)&&q.value>0&&q.value<=1e6,'Catalog portion requires measured mass');const c=structuredClone(r.composition);const id=requireId(itemId);const proof=reviewedSnapshot(s,id,c,q,'2026-11-27T12:00:00.000Z');assert.equal(proof.conversion.status,'resolved');return {id,composition:c,quantity:q,identity:{provider:r.provider,recordId:r.id,version:r.release,preparation:c.preparation,presentationId:'catalog-100g'},reviewed:false};}
  function validateItem(i){check(i.composition);assert.equal(i.identity.presentationId,'catalog-100g');assert.ok(['g','kg'].includes(i.quantity.unit));assert.equal(i.reviewed,true,'Explicit review required');}
  return {mode:'LAB_SYNTHETIC_ONLY',search:(q,p,l)=>{const all=search(q,p,100);const hits=all.hits.filter(x=>allowed.has(x.key)); // search subset independently below, no silent truncation
   const words=fold(q).split(' ').filter(Boolean);const exact=words.length?[...allowed.values()].filter(r=>(!p||r.provider===p)&&words.every(w=>fold(r.name).includes(w))):[];assert.ok(hits.length<=exact.length);const n=l??30;assert.ok(Number.isInteger(n)&&n>=1&&n<=100);return {hits:structuredClone(exact.slice(0,n).map(({composition,...r})=>r)),total:exact.length};},select,check,validateItem,policies:()=>structuredClone(policies),records:()=>structuredClone([...allowed.values()].map(r=>({provider:r.provider,release:r.release,record_id:r.id,record_sha256:r.sourceRecordSha256,manifest_sha256:r.manifestSha256,composition:r.composition}))) };
 }};
}
module.exports={loadCatalogReview,key,sha,stable};
