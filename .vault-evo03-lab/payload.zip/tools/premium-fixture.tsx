import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {VitalHub,type VitalDestination} from '@/components/vital/VitalHub';
import {VitalChrome,type VitalArea} from '@/components/vital/VitalChrome';
import type {VitalRepository} from '@/lib/vital/repository';
import type {Scope} from '@/lib/vital/model';
const scope:Scope={user_id:'10000000-0000-4000-8000-000000000001',person_id:'10000000-0000-4000-8000-000000000002'};
const today='2026-11-27', mode=new URLSearchParams(location.search).get('mode')??'empty';
const base={...scope,id:'10000000-0000-4000-8000-000000000003',created_at:today+'T12:00:00Z',updated_at:today+'T12:00:00Z',deleted_at:null,revision:1};
const filled=mode==='filled';
const repo={snapshot:async(s:Scope)=>{if(s.user_id!==scope.user_id||s.person_id!==scope.person_id)throw Error('SCOPE');if(mode==='error')throw Error('synthetic query failure');return {exercises:[],foods:[],favorites:[],workouts:filled?[{...base,day:today,status:'completed',items:[]}]:[],trainingCheckins:[],trainingPlans:[],trainingVersions:[],meals:filled?[{...base,day:today,time:'12:00',items:[{id:'10000000-0000-4000-8000-000000000004',name:'Alimento fictício',nutrients:{energy_kcal:210}}]}]:[],nutritionCheckins:[],nutritionModalities:[],nutritionPlans:[],nutritionVersions:[]};}} as unknown as VitalRepository;
function App(){const [area,setArea]=useState<VitalArea>('hub'),[settings,setSettings]=useState(false),[last,setLast]=useState('none');function nav(x:VitalDestination){setLast(x);if(x==='settings')setSettings(true);else if(['hub','training','nutrition','progress','plans'].includes(x)){setSettings(false);setArea(x as VitalArea);}}
return <main className="mx-auto max-w-3xl space-y-3 px-3 py-3"><p className="rounded-lg border border-amber-400/30 p-2 text-xs text-amber-300">LABORATÓRIO VISUAL · DADOS SINTÉTICOS · SEM CONTA REAL</p><VitalChrome area={area} settings={settings} editingEntry={false} onBack={()=>{setLast('back');setSettings(false);setArea('hub');}} onNavigate={nav}/><VitalHub repo={repo} scope={scope} today={today} onNavigate={nav} weight={filled?{value:'72 kg',source:'Registro manual fictício'}:null} hydration={filled?{value:'0 mL',source:'Registro fictício explícito'}:null} readingsLoading={false} nutritionF2Enabled={mode!=='locked'} recipesEnabled={mode!=='locked'} nutritionConnectEnabled={false}/><output data-testid="destination" className="sr-only">{last}</output></main>;}
createRoot(document.getElementById('root')!).render(<App/>);
