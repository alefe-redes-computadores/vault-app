import React from 'react';
import {createRoot} from 'react-dom/client';
import {db} from '@/lib/db';
import {createVitalStorage,type CanonicalDb} from '@/lib/vital/storage-dexie';
import {VitalRepository} from '@/lib/vital/repository';
import {prepareMealEnvelope} from '@/lib/vital/nutrition-f2/persistence';
import {localDay} from '@/lib/vital/validation';
import {VitalContextCard} from '@/components/vital/VitalContextCard';
import {VitalEvidencePanel} from '@/components/vital/VitalEvidencePanel';
import type {Scope} from '@/lib/vital/model';
const id=(n:number)=>`53000000-0000-4000-8000-${String(n).padStart(12,'0')}`,scope:Scope={user_id:id(1),person_id:id(2)},foreign={...scope,person_id:id(3)};
const mode=new URLSearchParams(location.search).get('mode')??'empty',day=localDay(new Date()),at=new Date().toISOString();
const repo=new VitalRepository(createVitalStorage({db:db as unknown as CanonicalDb,authenticatedUser:async()=>scope.user_id,activeScope:()=>scope,recipesEnabled:true,enqueue:async()=>{throw Error('Read-only lab');},dispatch:()=>{throw Error('No dispatch');}}));
const records=[{...scope,data:day,tipo:'peso',deleted_at:at},{...scope,data:day,tipo:'sono',deleted_at:null},{...foreign,data:day,tipo:'agua',deleted_at:null}];
async function main(){await db.open();if(db.verno!==60)throw Error('V60 expected');for(const s of [scope,foreign])await db.table('persons').put({id:s.person_id,user_id:s.user_id});
 if(mode==='filled'){const c={name:'Alimento sintético',source:{provider:'manual' as const,recordId:'fixture',version:'1',license:'private',retrievedAt:at,attribution:'fixture'},base:{value:100,unit:'g' as const},values:{protein_g:{state:'known' as const,amount:3,unit:'g' as const}},preparation:'cooked' as const,edibleBasis:'edible' as const};const env=prepareMealEnvelope(scope,{scope,mealId:id(4),operationId:id(5),items:[{id:id(6),identity:{provider:'manual',recordId:'fixture',version:'1',preparation:'cooked',presentationId:'g'},composition:c,quantity:{value:100,unit:'g'},reviewed:true}]},at,[]);const base={...scope,id:id(4),day,time:'12:00',kind:'lunch',custom_label:null,plan_version_id:null,notes:null,items:env.items,nutrition_f2:env.nutrition_f2,created_at:at,updated_at:at,deleted_at:null,revision:1,synced:true};await db.table('vital_meals').put(base);await db.table('vital_meals').put({...base,id:id(7),deleted_at:at,custom_label:'REMOVIDO SINTÉTICO'});await db.table('vital_meals').put({...base,...foreign,id:id(8),custom_label:'ESTRANGEIRO SINTÉTICO'});}
 if(mode==='error')repo.snapshot=async()=>{throw Error('synthetic read error');};Object.assign(window,{__r12Consumer:{runtime:{scope,repo,loading:false},health:{registros:records,isLoading:false}}});createRoot(document.getElementById('root')!).render(<main className="mx-auto max-w-3xl space-y-3 px-3 py-3"><p className="text-xs text-amber-300">LABORATÓRIO · DADOS SINTÉTICOS · SOMENTE LEITURA</p><section aria-label="Home"><VitalContextCard origin="/" day={day}/></section><section aria-label="Hoje"><VitalContextCard origin="/hoje" day={day} returnTo={'/hoje?date='+day}/></section><section aria-label="Fênix"><VitalContextCard origin="/saude/fenix" day={day}/></section><section aria-label="Brain"><VitalEvidencePanel origin="/saude/brain-v7" from={day} to={day} brain/></section><section aria-label="Linha Clínica"><VitalEvidencePanel origin="/saude/linha-clinica" from={day} to={day}/></section></main>);}
void main().catch(e=>{document.getElementById('root')!.textContent='LAB ERROR '+String(e);throw e;});
