#!/usr/bin/env python3
"""Strict local materializer. Never installs, commits, pushes, migrates or touches the input tree."""
import argparse, hashlib, json, pathlib, shutil, sys
r=pathlib.Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('source',type=pathlib.Path);p.add_argument('destination',type=pathlib.Path);p.add_argument('--reverse',action='store_true');a=p.parse_args()
s=a.source.resolve();d=a.destination.resolve()
if not s.is_dir() or d.exists() or s==d or s in d.parents or d in s.parents:sys.exit('STOP: use new sibling destination')
if (s/'.git').exists():sys.exit('STOP: use a clean source export, not a live git worktree')
if any(x.is_symlink() for x in s.rglob('*')):sys.exit('STOP: source contains symlinks')
changes=json.loads((r/'ALLOWLIST.json').read_text())['changes'];h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest() if x.is_file() else None
for c in changes:
 path=pathlib.PurePosixPath(c['path']);assert not path.is_absolute() and '..' not in path.parts
 expected=c['post_sha256' if a.reverse else 'pre_sha256'];target=c['pre_sha256' if a.reverse else 'post_sha256'];payload=r/'patch'/('preimage' if a.reverse else 'postimage')/path
 if (s/path).exists() and not (s/path).is_file():sys.exit(f'STOP path collision: {path}')
 if h(s/path)!=expected or h(payload)!=target:sys.exit(f'STOP preimage or patch drift: {path}')
shutil.copytree(s,d)
try:
 for c in changes:
  path=pathlib.PurePosixPath(c['path']);target=c['pre_sha256' if a.reverse else 'post_sha256'];payload=r/'patch'/('preimage' if a.reverse else 'postimage')/path
  if target is None:(d/path).unlink()
  else:
   (d/path).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(payload,d/path)
  if h(d/path)!=target:raise RuntimeError(f'Hash mismatch: {path}')
except BaseException:
 shutil.rmtree(d);raise
print('REVIEW_ONLY_NOT_INSTALLABLE',len(changes),'paths; input unchanged; no production writes')
