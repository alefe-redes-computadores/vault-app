import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {db} from '@/lib/db';
import {createVitalStorage,type CanonicalDb} from '@/lib/vital/storage-dexie';
import {createVitalDraftStorage} from '@/lib/vital/drafts';
import {VitalRepository} from '@/lib/vital/repository';
import {loadCatalogAuthority} from '@/lib/vital/nutrition-f2/catalog-authority';
import {certifiedVitalF2Release} from '@/lib/vital/nutrition-f2/release-capability';
import {NutritionMealJourney} from '@/components/vital/nutrition-f2/NutritionMealJourney';
import {ToastProvider} from '@/components/ToastProvider';
const id=(n:number)=>`51000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
const scope={user_id:id(1),person_id:id(2)},port=db as unknown as CanonicalDb;
async function initialize(){
 if(certifiedVitalF2Release()!==null)throw Error('Unexpected production release');
 const raw=await fetch('/catalog-lab-authority.json');if(!raw.ok)throw Error('Laboratory authority unavailable');
 const authority=await loadCatalogAuthority(new Uint8Array(await raw.arrayBuffer()),'9d35a4bfd2f030a84bbfbdc5cc674375050eaab53ec313a45cd7a4d29846eaad','lab');
 await db.open();if(db.verno!==60)throw Error('Unexpected canonical version');await db.table('persons').put({id:scope.person_id,user_id:scope.user_id});
 const repo=new VitalRepository(createVitalStorage({db:port,authenticatedUser:async()=>scope.user_id,activeScope:()=>scope,recipesEnabled:true,enqueue:async(table,operation,row)=>{await db.table('syncQueue').put({id:crypto.randomUUID(),chave:`${table}:${row.id}`,table,operation,payload:row,created_at:new Date().toISOString(),updated_at:new Date().toISOString(),retry_count:0,failed:false});},dispatch:()=>{/* no network */}}),()=>new Date(),()=>crypto.randomUUID(),authority);
 const drafts=createVitalDraftStorage({db:port,authenticatedUser:async()=>scope.user_id,activeScope:()=>scope});
 Object.assign(window,{__r17Inspect:async()=>{const index=await drafts.list(scope,'meal_f2');const draftDetails=await Promise.all(index.map(async d=>{const loaded=await drafts.load(scope,d.id,'meal_f2',p=>p);if(!loaded)throw Error('Laboratory draft disappeared');return loaded.record;}));return {rows:await repo.list(scope,'vital_meals'),queue:await db.table('syncQueue').count(),acks:await db.table('vital_sync_ack').count(),drafts:index,draftDetails};}});
 function App(){const [key,setKey]=useState(0);return <main className="mx-auto max-w-3xl space-y-3 px-3 py-3"><p className="text-xs text-amber-300">LABORATÓRIO · AUTORIDADE SINTÉTICA · SEM ATIVAÇÃO</p><NutritionMealJourney key={key} scope={scope} repo={repo} drafts={drafts} today="2026-11-27" day="2026-11-25" planId={null} meals={[]} initialKind="lunch" recipesEnabled={true} onClose={()=>setKey(k=>k+1)} onSaved={()=>setKey(k=>k+1)}/></main>}
 createRoot(document.getElementById('root')!).render(<ToastProvider><App/></ToastProvider>);
}
void initialize().catch(e=>{document.body.textContent='LAB STOP: '+String(e);throw e;});
