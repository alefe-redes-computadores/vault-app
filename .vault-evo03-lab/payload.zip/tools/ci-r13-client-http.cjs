'use strict';
// Real TypeScript RPC adapters -> disposable PostgREST via Unix socket. No TCP, production or saved credentials.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto'),assert=require('node:assert/strict');
if(process.env.GITHUB_ACTIONS!=='true'||process.env.GITHUB_REF!=='refs/heads/vault/lab/evolution03-20261126-r13')throw Error('STOP isolated branch');
const [socket,build,cases]=process.argv.slice(2);assert.ok(path.isAbsolute(socket)&&fs.statSync(socket).isSocket());assert.ok(path.isAbsolute(build)&&path.isAbsolute(cases));
const secret=process.env.VAULT_LAB_JWT_SECRET;assert.ok(secret?.length>=32,'STOP disposable JWT missing');
const load=n=>JSON.parse(fs.readFileSync(path.join(cases,'postgrest-'+n+'.json'),'utf8'));
const {submitMealStep,planMealSteps,preflightMealChain,INTEGRATED_MEAL_REVIEW}=require(path.join(build,'vital/nutrition-f2/remote-meal'));
const {submitRecipeStep,recipeRequest}=require(path.join(build,'vital/nutrition-f2/remote-recipe'));
const {vitalWireRow,vitalFingerprint,vitalRemoteFields}=require(path.join(build,'vital/cloud-transport'));
const {makeSnapshot}=require(path.join(build,'vital/nutrition-f2/nutrition'));
const {recipeConsumptionDraft}=require(path.join(build,'vital/nutrition-f2/recipe-consumption'));
const {prepareMealEnvelope}=require(path.join(build,'vital/nutrition-f2/persistence'));
const {certifiedVitalF2Release}=require(path.join(build,'vital/nutrition-f2/release-capability'));
const id=n=>`90000000-0000-4000-8000-${String(n).padStart(12,'0')}`,scope={user_id:id(1),person_id:id(11)},baseline='43c39ee489283c772fa52fa07803b2735e94737e';
assert.equal(certifiedVitalF2Release(),null);const cap={protocol:'vault-vital-f2-meal-v1',enabled:true,baseline,integratedMealReview:INTEGRATED_MEAL_REVIEW},recipeCap={...cap,protocol:'vault-vital-f2-recipe-v1'};
const jwt=user=>{const msg=Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url')+'.'+Buffer.from(JSON.stringify({sub:user,role:'authenticated',exp:Math.floor(Date.now()/1000)+600})).toString('base64url');return msg+'.'+crypto.createHmac('sha256',secret).update(msg).digest('base64url');};
function request(method,url,user,body){assert.ok(url.startsWith('/')&&!url.startsWith('//'));return new Promise((resolve,reject)=>{const payload=body===undefined?undefined:JSON.stringify(body),headers={Accept:'application/json',Authorization:'Bearer '+jwt(user),...(payload===undefined?{}:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload)})};const q=http.request({socketPath:socket,path:url,method,headers,timeout:10000},r=>{let s='';r.setEncoding('utf8');r.on('data',d=>s+=d);r.on('end',()=>{try{resolve({status:r.statusCode,data:s?JSON.parse(s):null});}catch(e){reject(e)}});});q.on('error',reject);q.on('timeout',()=>q.destroy(Error('Unix request timeout')));q.end(payload);});}
let count=0;const statuses=[];const rpcFor=user=>({async rpc(name,args){assert.ok(['vault_vital_meal_f2_review','vault_vital_recipe_f2_review'].includes(name));const r=await request('POST','/rpc/'+name,user,args);count++;if(r.status!==200)return {data:null,error:{code:r.data?.code??'remote'}};statuses.push(r.data.status);return {data:r.data,error:null};}});const rpc=rpcFor(scope.user_id),active=async()=>scope;
const step=p=>({scope,operationId:p.p_operation,expectedRevision:p.p_expected,meal:vitalWireRow('vital_meals',p.p_row,scope),audit:p.p_audit?vitalWireRow('vital_audit',p.p_audit,scope):null});
const ok=(n)=>console.log('R13_CLIENT_HTTP_PASS',n);
async function head(table,record){const r=await request('GET',`/${table}?id=eq.${record.id}&select=${vitalRemoteFields(table).join(",")}`,scope.user_id);assert.equal(r.status,200);assert.equal(r.data.length,1);assert.equal(await vitalFingerprint(table,r.data[0],scope),await vitalFingerprint(table,record,scope));}
async function meal(s,expected){const i=statuses.length,a=await submitMealStep(rpc,active,cap,baseline,s);assert.equal(statuses[i],expected);assert.equal(a.fingerprint,await vitalFingerprint('vital_meals',s.meal,scope));if(s.audit)assert.equal(a.auditFingerprint,await vitalFingerprint('vital_audit',s.audit,scope));return a;}
(async()=>{
 const label=step(load('label')),portion=step(load('recipe-portion')),chain=load('external-chain').map(step);for(const s of [label,portion,chain[0]])assert.equal(s.scope.user_id,scope.user_id);
 // Historical raw HTTP suite ran before this driver. These are distinct fresh fixtures.
 const start=count;await assert.rejects(submitMealStep(rpc,active,{...cap,integratedMealReview:undefined},baseline,label),/revisão remota compatível/);assert.equal(count,start);ok('legacy capability blocks before HTTP');
 // Real server commit with a discarded response: no fake ACK; exact retry must succeed.
 await assert.rejects(submitMealStep({async rpc(n,args){const r=await rpc.rpc(n,args);assert.equal(r.data.status,'applied');throw Error('synthetic lost response after commit');}},active,cap,baseline,label),/lost response/);await meal(label,'retry');await head('vital_meals',label.meal);ok('OCR receipt lost and replayed, persisted fingerprint verified');
 await meal(portion,'applied');await meal(portion,'retry');await head('vital_meals',portion.meal);ok('recipe portion persisted and replayed');
 await preflightMealChain(null,chain,cap);for(const s of chain)await meal(s,'applied');for(const s of chain)await meal(s,'retry');await head('vital_meals',chain.at(-1).meal);for(const s of chain.filter(s=>s.audit))await head('vital_audit',s.audit);ok('Health Connect insert, revision, tombstone, historical receipts and audits');
 // New recipe uses exact reviewed OCR composition and the same canonical ingredient recomputation.
 const common=n=>({...scope,id:id(n),created_at:label.meal.created_at,updated_at:label.meal.created_at,deleted_at:null,revision:1,synced:false});
 const composition=Object.values(label.meal.nutrition_f2.items)[0].payload.composition, h={...common(981),kind:'recipe',name:'Receita OCR sintética',active:true,favorite:false};
 const v={...common(982),recipe_id:h.id,version:1,name_snapshot:h.name,ingredients:[makeSnapshot(scope,id(983),composition,{value:200,unit:'g'})],raw_edible_mass_g:200,finished_mass_g:150,servings:3,yield_evidence:'Peso declarado',retention_evidence:null,reviewed_at:h.created_at};
 const r={scope,head:h,version:v,audit:null,expectedHead:null,expectedLatest:null,operationId:v.id};
 const req=recipeRequest(r,recipeCap),forged=structuredClone(req);forged.p_proofs[0].snapshot.payload.composition.labelEvidence.fields[0].raw='999';const rejected=await rpc.rpc('vault_vital_recipe_f2_review',forged);assert.equal(rejected.error?.code,'23514');ok('server refuses tampered label ingredient proof');
 const rc=statuses.length;await submitRecipeStep(rpc,active,recipeCap,baseline,r);await submitRecipeStep(rpc,active,recipeCap,baseline,r);assert.deepEqual(statuses.slice(rc),['applied','retry']);await head('vital_recipes',h);await head('vital_recipe_versions',v);ok('reviewed OCR ingredient recipe write + retry');
 const item=recipeConsumptionDraft(scope,v,id(984),{value:50,unit:'g'}),env=prepareMealEnvelope(scope,{scope,mealId:id(985),operationId:id(986),items:[{...item,reviewed:true}]},h.created_at,[]);const derived={...common(985),day:'2026-11-25',time:'12:30',kind:'lunch',custom_label:null,plan_version_id:null,notes:null,items:env.items,nutrition_f2:env.nutrition_f2};const [s]=await planMealSteps(scope,derived,null,null,[]);await meal(s,'applied');await meal(s,'retry');await head('vital_meals',s.meal);ok('consumption of OCR recipe version with server recomputation');
 await assert.rejects(submitMealStep(rpcFor(id(2)),active,cap,baseline,label),/42501/);const denied=await request('GET',`/vital_meals?id=eq.${label.meal.id}&select=id`,id(2));assert.equal(denied.status,200);assert.deepEqual(denied.data,[]);ok('cross-account write/read denied');
 // Persist only synthetic identifiers and pass counters, not JWTs, requests or user data.
 const proof={status:'DISPOSABLE_REAL_POSTGREST_ADAPTER_ONLY',rpcCalls:count,receipts:statuses,records:[label.meal.id,portion.meal.id,chain.at(-1).meal.id,derived.id],externalRevision:3,recipeVersion:v.id};fs.writeFileSync(path.join(cases,'r13-client-proof.json'),JSON.stringify(proof,null,2)+'\n');console.log('R13_REAL_CLIENT_HTTP_PASS',count);
})().catch(e=>{console.error(e);process.exitCode=1});
