'use strict';
// Disposable CI readiness: an authenticated read, never a write retry.
const {performance}=require('node:perf_hooks');
const route='/vital_meals?select=id&limit=1';
const transient=new Set(['ECONNREFUSED','ENOENT','ECONNRESET','EPIPE','DEADLINE','ABORTED']);
async function waitForCatalogReadiness(probe,{timeoutMs=30000,intervalMs=500,now=()=>performance.now(),sleep=ms=>new Promise(r=>setTimeout(r,ms))}={}){
 const start=now();let last='not attempted';
 for(let attempt=1;attempt<=60 && now()-start<timeoutMs;attempt++){
  let r;
  try{r=await probe(route);}catch(e){if(!transient.has(e?.code))throw e;last=e.code;}
  if(r){
   if(r.status===200 && Array.isArray(r.data))return;
   if(r.status!==503 || r.data?.code!=='PGRST002')throw Error(`STOP authenticated readiness unexpected HTTP ${r.status} ${r.data?.code??'invalid response'}`);
   last='PGRST002';
  }
  const remaining=timeoutMs-(now()-start);if(remaining<=0)break;
  await sleep(Math.min(intervalMs,remaining));
 }
 throw Error(`STOP PostgREST authenticated readiness deadline: ${last}`);
}
module.exports={waitForCatalogReadiness};
