'use strict';
// Isolated synthetic lab helper. Never retries a write or logs credentials / payloads.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
function makeUnixRequester(socket,{timeout=30000,trace=()=>{}}={}){
 if(!path.isAbsolute(socket)||!fs.statSync(socket).isSocket())throw Error('Not a local Unix socket');
 if(!Number.isSafeInteger(timeout)||timeout<10||timeout>60000)throw Error('Invalid request deadline');
 let serial=0;
 return function request(method,url,headers,body){
  if(!['GET','POST','PATCH'].includes(method)||!url.startsWith('/')||url.startsWith('//')||/[\r\n]/.test(url))throw Error('Invalid local request');
  const seq=++serial,route=url.split('?')[0],started=Date.now(),payload=body===undefined?undefined:JSON.stringify(body);
  return new Promise((resolve,reject)=>{
   let settled=false,timer,q;
   const finish=(err,result)=>{if(settled)return;settled=true;clearTimeout(timer);trace({seq,method,route,elapsedMs:Date.now()-started,status:result?.status??null,result:err?'error':'response',error:err?.code??null});if(err)reject(err);else resolve(result);};
   const error=(code)=>Object.assign(new Error(`Unix ${code}: #${seq} ${method} ${route}`),{code});
   trace({seq,method,route,result:'start'});
   q=http.request({socketPath:socket,path:url,method,agent:false,headers:{...headers,Connection:'close',...(payload===undefined?{}:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload)})}},r=>{
    let bytes=0;const parts=[];r.on('data',d=>{bytes+=d.length;if(bytes>8_000_000){q.destroy(error('RESPONSE_LIMIT'));return;}parts.push(d);});
    r.on('aborted',()=>finish(error('ABORTED')));r.on('error',()=>finish(error('RESPONSE_ERROR')));
    r.on('end',()=>{try{const text=Buffer.concat(parts).toString('utf8');finish(null,{status:r.statusCode,data:text?JSON.parse(text):null});}catch{finish(error('INVALID_JSON'));}});
   });
   q.on('error',e=>finish(error(e.code??'REQUEST_ERROR')));
   timer=setTimeout(()=>q.destroy(error('DEADLINE')),timeout);q.end(payload);
  });
 };
}
module.exports={makeUnixRequester};
