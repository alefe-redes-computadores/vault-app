import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import Dexie from 'dexie';
import {createVitalStorage,VITAL_STORES,VITAL_RECIPE_STORES,type CanonicalDb} from '@/lib/vital/storage-dexie';
import {createVitalDraftStorage,DRAFT_STORE} from '@/lib/vital/drafts';
import {VitalRepository} from '@/lib/vital/repository';
import {makeSnapshot,type Composition} from '@/lib/vital/nutrition-f2/nutrition';
import {restoreRecipeDraft} from '@/lib/vital/nutrition-f2/recipe-authoring';
import {certifiedVitalF2Release} from '@/lib/vital/nutrition-f2/release-capability';
import {RecipePicker} from '@/components/vital/nutrition-f2/RecipePicker';
import {NutritionHistory} from '@/components/vital/nutrition-f2/NutritionHistory';
import {ToastProvider} from '@/components/ToastProvider';
import type {Scope} from '@/lib/vital/model';
const id=(n:number)=>`51000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
const scope:Scope={user_id:id(1),person_id:id(2)};const foreign:Scope={user_id:id(3),person_id:id(4)};
const at='2026-11-25T18:00:00.000Z';
const db=new Dexie('VAULT_EVO03_SYNTHETIC_F2_ONLY');db.version(1).stores({...VITAL_STORES,...VITAL_RECIPE_STORES,persons:'id,user_id',locais:'id,user_id',medicos:'id,user_id',rehab_programs_m5:'id,user_id',syncQueue:'id,table',vital_sync_ack:'id,[user_id+person_id]',vital_drafts:DRAFT_STORE});
const port=db as unknown as CanonicalDb;
const repo=new VitalRepository(createVitalStorage({db:port,authenticatedUser:async()=>scope.user_id,activeScope:()=>scope,recipesEnabled:true,enqueue:async(table,operation,row)=>{await db.table('syncQueue').put({id:crypto.randomUUID(),table,operation,payload:row});},dispatch:()=>{/* intentionally no network */}}));
const drafts=createVitalDraftStorage({db:port,authenticatedUser:async()=>scope.user_id,activeScope:()=>scope});
const c:Composition={name:'Ingrediente fictício',source:{provider:'manual',recordId:'fixture',version:'1',license:'private',retrievedAt:at,attribution:'fixture'},base:{value:100,unit:'g'},values:{protein_g:{state:'known',amount:10,unit:'g'},vitamin_c_mg:{state:'known',amount:2,unit:'mg'}},preparation:'raw',edibleBasis:'edible'};
async function initialize(){if(certifiedVitalF2Release()!==null)throw Error('Unexpected release authority');await db.open();await db.table('persons').put({id:scope.person_id,user_id:scope.user_id});await db.table('persons').put({id:foreign.person_id,user_id:foreign.user_id});if(!(await db.table('vital_recipes').get(id(10)))){await repo.createRecipe(scope,{id:id(10),expected_revision:null,data:{kind:'recipe',name:'Receita fictícia',favorite:false,active:true}},{id:id(11),expected_revision:null,data:{ingredients:[makeSnapshot(scope,id(20),c,{value:200,unit:'g'})],raw_edible_mass_g:200,finished_mass_g:150,servings:3,yield_evidence:'Peso final declarado',reviewed_at:at}});await db.table('vital_recipes').put({...foreign,id:id(99),name:'RECEITA ESTRANGEIRA',active:true});}
createRoot(document.getElementById('root')!).render(<ToastProvider><App/></ToastProvider>);}
function App(){const [area,setArea]=useState<'recipe'|'history'>('recipe'),[result,setResult]=useState(''),[serial,setSerial]=useState(0);return <main className="mx-auto max-w-3xl space-y-3 px-3 py-3"><p className="rounded-lg border border-amber-400/30 p-2 text-xs text-amber-300">LABORATÓRIO F2 · DADOS SINTÉTICOS · STORE DESCARTÁVEL · SEM ATIVAÇÃO</p><nav className="flex gap-2"><button type="button" onClick={()=>setArea('recipe')}>Receitas</button><button type="button" onClick={()=>setArea('history')}>Histórico</button></nav>{area==='recipe'?<RecipePicker scope={scope} repo={repo} drafts={drafts} meals={[]} onBack={()=>setArea('history')}/>:<NutritionHistory scope={scope} day="2026-11-27" meals={[]}/>}<button type="button" data-testid="inspect" className="sr-only" onClick={async()=>{const rows=await repo.list(scope,'vital_recipe_versions'),heads=await repo.list(scope,'vital_recipes'),local=await drafts.list(scope,'recipe_f2');const loaded=await Promise.all(local.map(x=>drafts.load(scope,x.id,'recipe_f2',restoreRecipeDraft)));setSerial(n=>n+1);setResult(JSON.stringify({versions:rows,heads,queue:await db.table('syncQueue').count(),meals:await db.table('vital_meals').count(),drafts:loaded.map(x=>x?.value??null)}));}}>Conferir evidência local</button><output className="sr-only" data-testid="result" data-serial={serial}>{result}</output></main>}
void initialize().catch(e=>{document.getElementById('root')!.textContent='LAB INIT ERROR '+String(e);throw e;});
