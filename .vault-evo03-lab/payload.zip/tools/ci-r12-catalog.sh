#!/usr/bin/env bash
set -euo pipefail
[[ ${GITHUB_ACTIONS:-} == true && ${GITHUB_REF:-} == refs/heads/vault/lab/evolution03-20261126-r12 ]] || { echo 'STOP branch';exit 2; }
[[ "$EVO03_LAB" == "$RUNNER_TEMP/evo03-lab" ]] || { echo 'STOP path';exit 2; }
cd "$EVO03_LAB"
work=$(mktemp -d);trap 'rm -rf -- "$work"' EXIT
mapfile -d '' files < <(find tests/fixture-lib/vital -name '*.ts' -print0)
candidate/node_modules/.bin/tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir "$work/build" --rootDir tests/fixture-lib "${files[@]}"
node tools/curate-official-review.cjs "$work/build" catalog-review-inputs "$RUNNER_TEMP/evo03-r12-catalog"
