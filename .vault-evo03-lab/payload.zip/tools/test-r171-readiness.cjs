'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {waitForCatalogReadiness}=require('./r171-readiness.cjs');
const ready={status:200,data:[]},loading={status:503,data:{code:'PGRST002'}};
function harness(values){let clock=0,calls=0;return {run:()=>waitForCatalogReadiness(async route=>{assert.equal(route,'/vital_meals?select=id&limit=1');const v=values[Math.min(calls++,values.length-1)];if(v instanceof Error)throw v;return v;},{timeoutMs:5,intervalMs:1,now:()=>clock,sleep:async ms=>{clock+=ms}}),count:()=>calls};}
test('schema loading then authenticated ready',async()=>{const h=harness([loading,ready]);await h.run();assert.equal(h.count(),2)});
test('already ready performs one GET',async()=>{const h=harness([ready]);await h.run();assert.equal(h.count(),1)});
test('transport unavailable then ready',async()=>{const h=harness([Object.assign(Error('socket'),{code:'ECONNREFUSED'}),ready]);await h.run();assert.equal(h.count(),2)});
test('permanent authorization error stops immediately',async()=>{const h=harness([{status:403,data:{code:'42501'}},ready]);await assert.rejects(h.run(),/unexpected HTTP 403/);assert.equal(h.count(),1)});
test('unrelated 503 fails closed',async()=>{const h=harness([{status:503,data:{code:'OTHER'}},ready]);await assert.rejects(h.run(),/unexpected HTTP 503/);assert.equal(h.count(),1)});
test('invalid 200 payload fails closed',async()=>{const h=harness([{status:200,data:{}},ready]);await assert.rejects(h.run(),/unexpected HTTP 200/);assert.equal(h.count(),1)});
test('permanently loading cache bounded by deadline',async()=>{const h=harness([loading]);await assert.rejects(h.run(),/deadline: PGRST002/);assert.equal(h.count(),5)});
test('unexpected transport error is not retried',async()=>{const h=harness([Object.assign(Error('invalid JSON'),{code:'INVALID_JSON'}),ready]);await assert.rejects(h.run(),/invalid JSON/);assert.equal(h.count(),1)});
