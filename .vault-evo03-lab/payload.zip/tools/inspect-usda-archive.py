#!/usr/bin/env python3
"""Review-only ZIP central directory; no extraction, modification, or activation."""
import json,sys,zipfile
from pathlib import Path
p=Path(sys.argv[1])
with zipfile.ZipFile(p) as z:
 rows=[dict(name=i.filename,compressed=i.compress_size,uncompressed=i.file_size,is_dir=i.is_dir()) for i in z.infolist()]
 if len(rows)>10000: raise ValueError('Archive member limit')
 expected={}
 for k in ['food.csv','nutrient.csv','food_nutrient.csv']:
  old=[i for i in rows if Path(i['name']).name==k and not i['is_dir']]
  normalized=[i for i in rows if i['name'].replace('\\','/').split('/')[-1].casefold()==k.casefold() and not i['is_dir']]
  reason='missing' if not old else 'ambiguous' if len(old)!=1 else 'oversized' if old[0]['uncompressed']>300_000_000 else 'old_member_check_pass'
  expected[k]={'r03_exact_matches':old,'r03_exact_reason':reason,'r04_normalized_matches':normalized,'limit':300_000_000}
 print(json.dumps(dict(members=rows,expected=expected),indent=2))
