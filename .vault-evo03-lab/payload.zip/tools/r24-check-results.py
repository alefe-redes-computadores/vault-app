#!/usr/bin/env python3
"""Fail on missing/extra cases, SQL exceptions, or any unexpected mismatch."""
import json,re,sys
from pathlib import Path
mode=sys.argv[1];folder=Path(sys.argv[2]);audit=json.loads(Path(sys.argv[3]).read_text());summary=json.loads(Path(sys.argv[4]).read_text())
expected={(x['cohort'],x['label']) for x in audit['mismatches']} if mode=='base' else set()
seen=set();issues=[];n=0
for c in summary['cohorts']:
 i=c['cohort'];f=folder/f'{mode}-{i}.log'
 if not f.exists():issues.append(f'missing {f.name}');continue
 s=f.read_text();marks=re.findall(r'R24_RESULT (\d+) (\d+) (\d+)',s)
 if len(marks)!=1:issues.append(f'invalid completion {i}');continue
 a,b,d=map(int,marks[0]);n+=b
 if (a,b)!=(i,c['checks']):issues.append(f'cardinality {i}')
 rows=[json.loads(x) for x in re.findall(r'R24_MISMATCH (\{[^\n]*\})',s)]
 if len(rows)!=d:issues.append(f'mismatch count {i}')
 for r in rows:
  key=(r['cohort'],r['label'])
  if key in seen or r['cohort']!=i or r['expected'] is not True or r['got'] is not False or r['error'] is not None:issues.append(f'unexpected result {r}')
  seen.add(key)
 if 'ERROR:' in s or 'FATAL:' in s:issues.append(f'SQL failure {i}')
 if mode=='fixed' and i==0 and not re.search(r'R24_RECOMPUTE_DIRECTED_PASS 18\b',s):issues.append('directed missing')
missing=expected-seen;extra=seen-expected
if missing or extra:issues.append(f'mismatch delta missing={len(missing)} extra={len(extra)}');print('MISSING',sorted(missing)[:30]);print('EXTRA',sorted(extra)[:30])
if n!=6752:issues.append(f'total {n}')
print(f'R24_{mode.upper()}_CHECKS {n} MISMATCHES {len(seen)}')
if issues:print('\n'.join(issues));sys.exit(1)
print(f'R24_{mode.upper()}_PASS {n}')
