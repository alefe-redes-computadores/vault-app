#!/usr/bin/env python3
"""Disposable Unix-socket PostgREST contract checks. Synthetic identities only. No TCP or cloud endpoints."""
import argparse, base64, copy, hashlib, hmac, http.client, json, os, socket, stat, time
from pathlib import Path

class UnixHTTP(http.client.HTTPConnection):
 def __init__(self, path):
  super().__init__('localhost',timeout=8); self.path=str(path)
 def connect(self):
  self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.settimeout(self.timeout);self.sock.connect(self.path)

def b64(data):return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')
def token(secret,subject,role='authenticated'):
 header=b64(b'{"alg":"HS256","typ":"JWT"}');body=b64(json.dumps({'sub':subject,'role':role,'exp':int(time.time())+900},separators=(',',':')).encode());msg=f'{header}.{body}'
 return msg+'.'+b64(hmac.new(secret,msg.encode(),hashlib.sha256).digest())
def rpc(route):return '/rpc/'+route
MEAL='vault_vital_meal_f2_review';RECIPE='vault_vital_recipe_f2_review'

def run(sock,case_dir,secret):
 assert sock.is_socket(), 'STOP not Unix socket'
 assert len(secret)>=32, 'STOP missing disposable JWT secret'
 def request(method,path,auth=None,body=None):
  headers={'Accept':'application/json'}
  if auth:headers['Authorization']='Bearer '+auth
  if body is not None:headers['Content-Type']='application/json'
  c=UnixHTTP(sock)
  try:
   c.request(method,path,body=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers);r=c.getresponse();raw=r.read();return r.status,json.loads(raw) if raw else None
  finally:c.close()
 def load(name):return json.loads((case_dir/f'postgrest-{name}.json').read_text())
 first=load('meal');recipe=load('recipe');consumption=load('recipe-consumption');owner=first['p_row']['user_id'];person=first['p_person'];other='90000000-0000-4000-8000-000000000002';other_person='90000000-0000-4000-8000-000000000012'
 assert owner!=other and person!=other_person and owner.startswith('90000000-0000-4000-8000-'), 'STOP nonfixture identity'
 a=token(secret,owner);b=token(secret,other);checks=[]
 def ok(name,condition):
  if not condition:raise AssertionError(name)
  checks.append(name);print('PASS',name,flush=True)
 def receipt(name,route,auth,payload,expected):
  status,data=request('POST',rpc(route),auth,payload)
  ok(name,status==200 and isinstance(data,dict) and data.get('status')==expected and data.get('operation_id')==payload['p_operation']);return data
 def denied(name,route,auth,payload,statuses,codes):
  s,d=request('POST',rpc(route),auth,payload);ok(name,s in statuses and isinstance(d,dict) and d.get('code') in codes)
 # Schema cache readiness requires a real accessible endpoint and valid authenticated JWT.
 for _ in range(30):
  try:
   status,_=request('GET','/vital_meals?select=id&limit=1',a)
   if status==200:break
  except (OSError,http.client.HTTPException,ValueError):pass
  time.sleep(1)
 else:raise AssertionError('PostgREST authenticated readiness failed')
 r=receipt('historical meal retry over HTTP',MEAL,a,first,'retry');ok('historical revision not replaced by latest',r['meal']['id']==first['p_row']['id'] and r['meal']['revision']==1)
 r=receipt('historical recipe retry over HTTP',RECIPE,a,recipe,'retry')
 denied('foreign account cannot replay meal',MEAL,b,first,{403},{'42501'})
 denied('foreign account cannot replay recipe',RECIPE,b,recipe,{403},{'42501'})
 wrong=copy.deepcopy(first);wrong['p_person']=other_person
 denied('foreign person cannot replay meal',MEAL,a,wrong,{403},{'42501'})
 wrong=copy.deepcopy(recipe);wrong['p_person']=other_person
 denied('foreign person cannot replay recipe',RECIPE,a,wrong,{403},{'42501'})
 denied('anonymous RPC blocked',MEAL,None,first,{401,403,404},{'42501','PGRST202'})
 wrong_token=token(b'x'*32,owner)
 denied('invalid JWT blocked',MEAL,wrong_token,first,{401},{'PGRST301','PGRST303'})
 changed=copy.deepcopy(first);changed['p_row']['notes']='altered synthetic replay'
 denied('altered historical receipt rejected',MEAL,a,changed,{409},{'23505'})
 # Actual creation through HTTP using SQL-recompute consumption fixture. Direct SQL case rolled back.
 r=receipt('recipe-derived meal creation over HTTP',MEAL,a,consumption,'applied');ok('server receipt exact meal and revision',r['meal']['id']==consumption['p_row']['id'] and r['meal']['revision']==1)
 again=receipt('lost-response-equivalent exact retry',MEAL,a,consumption,'retry');ok('retry returned identical persisted meal',again['meal']==r['meal'])
 route='/vital_meals?select=id,revision&id=eq.'+consumption['p_row']['id'];status,rows=request('GET',route,a);ok('one scoped persisted meal',status==200 and rows==[{'id':consumption['p_row']['id'],'revision':1}]);status,rows=request('GET',route,b);ok('foreign account cannot read persisted meal',status==200 and rows==[])
 status,rows=request('GET','/vital_recipes?select=id&id=eq.'+recipe['p_head']['id'],b);ok('foreign account cannot read recipe',status==200 and rows==[])
 status,data=request('PATCH',route,a,{'notes':'direct unauthorized change','revision':2,'updated_at':'2026-11-25T10:00:01Z'});ok('direct legacy overwrite of F2 blocked',status==403 and isinstance(data,dict) and data.get('code')=='42501')
 status,rows=request('GET',route,a);ok('no revision advance after denied direct change',status==200 and rows==[{'id':consumption['p_row']['id'],'revision':1}]);print('POSTGREST_UNIX_LAB_PASS',len(checks),'SYNTHETIC_ONLY',flush=True)

if __name__=='__main__':
 if not __debug__ or os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('GITHUB_REF')!='refs/heads/vault/lab/evolution03-20261126-r15':raise SystemExit('STOP isolated CI ref only (assertions required)')
 p=argparse.ArgumentParser();p.add_argument('socket',type=Path);p.add_argument('cases',type=Path);a=p.parse_args();run(a.socket,a.cases,os.environ['VAULT_LAB_JWT_SECRET'].encode())
