import unittest,importlib.util,json,tempfile,subprocess,sys,hashlib,re,copy
from decimal import Decimal as D
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('r24_numeric',ROOT/'tools/r24-numeric-audit.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
class Coverage(unittest.TestCase):
 def test_numeric_round_trip(self):
  e=m.expected_cov({'state':'known','amount':D('62.745999999999995')});a=copy.deepcopy(e);a['amount']=D('62.746');self.assertTrue(m.coverage_ok(a,e));self.assertNotEqual(a,e)
  for v in (D('63'),D('0'),D('-62.746'),None,'62.746',True, D('62.7459999')):
   with self.subTest(value=v):self.assertFalse(m.coverage_ok({**e,'amount':v},e))
 def test_strict_metadata(self):
  e=m.expected_cov({'state':'known','amount':D('62.746')})
  for x in ({**e,'known':0},{**e,'known':True},{**e,'complete':1},{**e,'scope':'all_intake'},{**e,'estimatedSubtotal':0},{**e,'extra':1},{k:v for k,v in e.items() if k!='amount'},{k:v for k,v in e.items() if k!='estimatedSubtotal'},None,[],{**e,'counts':{**e['counts'],'known':False}}):
   with self.subTest(x=x):self.assertFalse(m.coverage_ok(x,e))
 def test_zero_unknown_estimate(self):
  z=m.expected_cov({'state':'declared_zero'});self.assertTrue(m.coverage_ok(z,z));self.assertFalse(m.coverage_ok({**z,'amount':D('1e-30')},z));self.assertFalse(m.coverage_ok({**z,'amount':None},z))
  u=m.expected_cov({'state':'not_reported'});self.assertTrue(m.coverage_ok(u,u));self.assertFalse(m.coverage_ok({**u,'amount':0},u))
  e=m.expected_cov({'state':'estimated','amount':D('62.745999999999995')});self.assertTrue(m.coverage_ok({**e,'estimatedSubtotal':D('62.746')},e));self.assertFalse(m.coverage_ok({**e,'estimatedSubtotal':D('63')},e));self.assertFalse(m.coverage_ok({**e,'amount':0},e))
 def test_pinned_preimage(self):
  generated=subprocess.check_output([sys.executable,str(ROOT/'sql/generate-label-recompute-review.py')],text=True)
  body=re.search(r'CREATE OR REPLACE FUNCTION vault_nutrition_f2_review\.recompute\([^\n]+ AS \$\$(.*?)\$\$;',generated,re.S).group(1)
  self.assertEqual(hashlib.md5(body.encode()).hexdigest(),'bcc0e4b48df7de58c02d43cc2468b429');self.assertEqual(body.count('IF cov IS DISTINCT FROM expected THEN RETURN false; END IF;'),1)
  p=(ROOT/'sql/17-R24-COVERAGE-NUMERIC-LAB.sql').read_text();self.assertIn('bcc0e4b48df7de58c02d43cc2468b429',p);self.assertIn('prosrc=replace(before_source,old,new)',p);self.assertIn('inet_server_addr() IS NOT NULL',p)
class Report(unittest.TestCase):
 def test_checker_fails_closed(self):
  audit=ROOT/'r23-inputs/r24-numeric-audit.json';summary=ROOT/'r23-inputs/expected-summary.json';a=json.loads(audit.read_text());s=json.loads(summary.read_text())
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)
   def write(mode):
    for c in s['cohorts']:
     i=c['cohort'];rows=[x for x in a['mismatches'] if x['cohort']==i] if mode=='base' else []
     log=''.join('NOTICE: R24_MISMATCH '+json.dumps({'cohort':i,'label':x['label'],'expected':True,'got':False,'error':None})+'\n' for x in rows)+f'NOTICE: R24_RESULT {i} {c["checks"]} {len(rows)}\n'
     if mode=='fixed' and i==0:log+='NOTICE: R24_RECOMPUTE_DIRECTED_PASS 18\n'
     (p/f'{mode}-{i}.log').write_text(log)
   def run(mode):return subprocess.run([sys.executable,str(ROOT/'tools/r24-check-results.py'),mode,d,str(audit),str(summary)],capture_output=True,text=True)
   write('base');write('fixed');self.assertEqual(run('base').returncode,0);self.assertEqual(run('fixed').returncode,0)
   for mode,i,transform in [('base',0,lambda x:x.replace('"got": false','"got": true',1)),('base',1,lambda x:x.replace('"error": null','"error": "23514"',1)),('fixed',0,lambda x:x.replace('R24_RECOMPUTE_DIRECTED_PASS 18','R24_RECOMPUTE_DIRECTED_PASS 17')),('fixed',1,lambda x:x.replace('2264','2263')),('fixed',2,lambda x:x+'\nERROR: fake test exception\n'),('base',2,lambda x:x.split('\n',1)[1])]:
    with self.subTest(mode=mode,i=i):
     f=p/f'{mode}-{i}.log';old=f.read_text();f.write_text(transform(old));self.assertNotEqual(run(mode).returncode,0);f.write_text(old)
   (p/'fixed-2.log').unlink();self.assertNotEqual(run('fixed').returncode,0)
if __name__=='__main__':unittest.main(verbosity=2)
