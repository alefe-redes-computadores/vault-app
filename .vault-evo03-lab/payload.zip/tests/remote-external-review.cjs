const test=require('node:test'),assert=require('node:assert/strict');
const {externalCanonicalId}=require('../build/vital/nutrition-f2/external-import-review');
const {externalMealComposition,externalMealMetadata,makeExternalMealEvidence}=require('../build/vital/nutrition-f2/external-meal');
const {prepareExternalMealEnvelope}=require('../build/vital/nutrition-f2/persistence');
const {verifyRemoteExternalRow,verifyRemoteExternalTransition}=require('../build/vital/nutrition-f2/remote-external-review');
const id=n=>`90000000-0000-4000-8000-${String(n).padStart(12,'0')}`,scope={user_id:id(1),person_id:id(11)},at='2026-11-25T10:00:00.000Z',t2='2026-11-25T10:00:01.000Z',t3='2026-11-25T10:00:02.000Z';
const record={scope,type:'nutrition',origin:'com.sec.android.app.shealth',recordId:'test-"ação"-🥗',start:'2026-11-23T00:30:00.000Z',end:'2026-11-23T01:00:00.000Z',lastModified:'2026-11-23T02:00:00.000Z',mealName:null,mealType:'unknown',nutrients:{protein_g:{state:'known',amount:12,unit:'g'},sodium_mg:{state:'unknown'}}};
async function row(r=record,rev=1,stamp=at,op=id(940)){
 const e=makeExternalMealEvidence(r,'binding',stamp,-180,false),mealId=await externalCanonicalId(scope,r,'meal'),itemId=await externalCanonicalId(scope,r,'item'),x=prepareExternalMealEnvelope(scope,mealId,op,itemId,externalMealComposition(e),stamp);
 return {...scope,id:mealId,created_at:at,updated_at:stamp,deleted_at:null,revision:rev,synced:false,...externalMealMetadata(e),...x};
}
const verify=r=>verifyRemoteExternalRow(scope,r);
test('remote external proof requires canonical ID and preserved civil day',async()=>{const r=await row();assert.equal((await verify(r)).row.id,r.id);assert.equal(r.day,'2026-11-22');assert.equal(r.time,'21:30');});
test('independent UUIDs cannot duplicate a canonical provider record',async()=>{const r=await row();await assert.rejects(verify({...r,id:id(941)}),/não canônica/);});
test('remote external proof binds item ID as well as meal ID',async()=>{const r=await row(),next=id(942),e=makeExternalMealEvidence(record,'binding',at,-180,false);const env=prepareExternalMealEnvelope(scope,r.id,r.nutrition_f2.operation_id,next,externalMealComposition(e),at);await assert.rejects(verify({...r,...env}),/não canônica/);});
test('operation may not reuse canonical meal ID',async()=>{const r=await row();r.nutrition_f2.operation_id=r.id;await assert.rejects(verify(r),/Operação/);});
test('new imported meal must start at revision one',async()=>{await assert.rejects(verifyRemoteExternalTransition(scope,null,await row(record,2)),/Inserção/);});
test('newer provider version advances same meal without changing identity',async()=>{const a=await row(),b=await row({...record,lastModified:'2026-11-23T03:00:00.000Z'},2,t2,id(943));assert.equal((await verifyRemoteExternalTransition(scope,a,b)).row.revision,2);});
test('same provider version with new content is not a correction',async()=>{const a=await row(),b=await row({...record,nutrients:{protein_g:{state:'known',amount:20,unit:'g'}}},2,t2,id(943));await assert.rejects(verifyRemoteExternalTransition(scope,a,b),/não avançou/);});
test('changed provider record cannot retarget old meal',async()=>{const a=await row(),b=await row({...record,recordId:'another'},2,t2,id(943));await assert.rejects(verifyRemoteExternalTransition(scope,a,b),/identidade/);});
test('future review cannot be newer than the persisted row timestamp',async()=>{const a=await row(record,1,t2);a.updated_at=at;await assert.rejects(verify(a),/revisão externa/);});
test('archive preserves exact external fact and rejects resurrection',async()=>{const a=await row(),b={...a,revision:2,updated_at:t2,deleted_at:t2};assert.equal((await verifyRemoteExternalTransition(scope,a,b)).row.deleted_at,t2);await assert.rejects(verifyRemoteExternalTransition(scope,b,await row({...record,lastModified:'2026-11-23T03:00:00.000Z'},3,t3,id(943))),/identidade/);});
test('old client cannot replace external total with manual projection',async()=>{const a=await row(),b={...a,revision:2,updated_at:t2};delete b.nutrition_f2;await assert.rejects(verifyRemoteExternalTransition(scope,a,b),/Total externo obrigatório/);});
