import sys,unittest,ast,zipfile
from pathlib import Path
from openpyxl import Workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'candidate/scripts/nutrition'))
from import_taco import official_headers,official_identity,raw,parse_value
class Official(unittest.TestCase):
 def test_observed_fragments(self):
  w=Workbook();s=w.active
  # Exact public header fragments captured by R03 (not food values).
  s.append(['','','','','','','','','Carbo-','Fibra','','','','','','','','','','','','','','','','','','','Vitamina'])
  s.append(['Número do','','Umidade','Energia','','Proteína','Lipídeos','Colesterol','idrato','Alimentar','Cinzas','Cálcio','Magnésio','Número do','Manganês','Fósforo','Ferro','Sódio','Potássio','Cobre','Zinco','Retinol','RE','RAE ','Tiamina','Riboflavina','Piridoxina','Niacina','C'])
  s.append(['Alimento','Descrição dos alimentos','(%)','(kcal)','(kJ)','(g)','(g)','(mg)','(g)','(g)','(g)','(mg)','(mg)','Alimento','(mg)','(mg)','(mg)','(mg)','(mg)','(mg)','(mg)','(mcg)','(mcg)','(mcg)','(mg)','(mg)','(mg)','(mg)','(mg)'])
  h,f=official_headers(s);self.assertEqual(h['vitamin_a_rae_ug']['unit'],'ug');self.assertEqual(f['vitamin_a_rae_ug'][2],'(mcg)');self.assertEqual(h['carbohydrate_g']['header'],'Carboidrato');self.assertEqual(h['vitamin_c_mg']['header'],'Vitamina C');s.cell(2,24,'RE');self.assertRaises(ValueError,official_headers,s)
 def test_identity(self):
  self.assertEqual(official_identity('1','=A5',5,None),1);self.assertEqual(official_identity('=A5+1','=A6',6,(5,1)),2);self.assertEqual(official_identity('=A6+1','=A8',8,(6,2)),3)
  for a,b,r,p in [('=A4+1','=A6',6,(5,1)),('=A5+2','=A6',6,(5,1)),('=A5+1','=A5',6,(5,1)),('3','=A6',6,(5,1)),('=SUM(A5,1)','=A6',6,(5,1))]:self.assertRaises(ValueError,official_identity,a,b,r,p)
 def test_small_number(self):
  w=Workbook();s=w.active;s['A1']=1e-8;self.assertEqual(parse_value(raw(s['A1']),'mg')['amount'],1e-8);s['A1']='=A2';self.assertRaises(ValueError,raw,s['A1'])
if __name__=='__main__':unittest.main(verbosity=2)
