import hashlib,json,sys,tempfile,unittest
from pathlib import Path
from openpyxl import Workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'candidate/scripts/nutrition'))
from import_taco import build,parse_value,export
from import_usda import file_digest
class Taco(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.p=Path(self.tmp.name);self.src=self.p/'source.xlsx';self.lay=self.p/'layout.json'
  self.layout={'sheet':'Tabela 1','header_row':1,'unit_row':2,'first_data_row':3,'last_data_row':5,'columns':dict(id=1,name=2,energy_kcal=3,protein_g=4,fat_g=5,carbohydrate_g=6,fiber_g=7,iron_mg=8,vitamin_a_rae_ug=9)}
  self.wb=Workbook();self.wb.active.title='Tabela 1';self.ws=self.wb.active;self.ws.append(['Número do alimento','Descrição dos alimentos','Energia','Proteína','Lipídeos','Carboidrato','Fibra alimentar','Ferro','RAE']);self.ws.append(['','','(kcal)','(g)','(g)','(g)','(g)','(mg)','(µg)']);self.ws.append([1,'Alimento fictício A','100,5',2,3,4,'Tr','NA',0]);self.ws.append([None,'Categoria fictícia']);self.ws.append([2,'Alimento fictício B',30,1,2,3,None,'0,1',None])
 def tearDown(self):self.wb.close();self.tmp.cleanup()
 def run_parse(self,fixture=True):
  self.wb.save(self.src);self.lay.write_text(json.dumps(self.layout));return build(self.src,file_digest(self.src),self.lay,file_digest(self.lay),'2026-11-26',**({'test_count':2} if fixture else {}))
 def test_candidates(self):
  rows,m=self.run_parse();self.assertEqual(len(rows),2);self.assertTrue(m['fixtureOnly']);self.assertFalse(m['activation']);c=rows[0]['composition'];self.assertEqual(c['base'],{'value':100,'unit':'g'});self.assertEqual(c['edibleBasis'],'edible');self.assertEqual(c['preparation'],'unknown');self.assertEqual(c['values']['energy_kcal']['amount'],100.5);self.assertEqual(c['values']['fiber_g']['state'],'trace');self.assertEqual(c['values']['iron_mg']['state'],'not_applicable');self.assertEqual(c['values']['vitamin_a_rae_ug']['state'],'unknown');self.assertEqual(rows[1]['composition']['values']['fiber_g']['state'],'not_reported');self.assertNotIn('sugar_g',c['values']);self.assertIn('NEPA-UNICAMP',c['source']['attribution'])
 def test_incomplete_real_rejected(self):
  with self.assertRaisesRegex(ValueError,'Incomplete'):self.run_parse(False)
 def test_header_drift(self):
  self.ws.cell(1,9,'RE');
  with self.assertRaisesRegex(ValueError,'Header/unit drift'):self.run_parse()
 def test_unit_drift(self):
  self.ws.cell(2,3,'kJ');
  with self.assertRaisesRegex(ValueError,'Header/unit drift'):self.run_parse()
 def test_duplicate(self):
  self.ws.cell(5,1,1)
  with self.assertRaisesRegex(ValueError,'identity'):self.run_parse()
 def test_missing_id(self):
  self.ws.cell(5,1).value=None
  with self.assertRaisesRegex(ValueError,'without food ID'):self.run_parse()
 def test_formula(self):
  self.ws.cell(3,4,'=1+2')
  with self.assertRaisesRegex(ValueError,'Formula'):self.run_parse()
 def test_qualified_value(self):
  self.ws.cell(3,4,'1,2a')
  with self.assertRaisesRegex(ValueError,'Unreviewed'):self.run_parse()
 def test_layout_duplicate(self):
  self.layout['columns']['iron_mg']=4
  with self.assertRaisesRegex(ValueError,'Layout columns'):self.run_parse()
 def test_sha(self):
  self.run_parse()
  with self.assertRaisesRegex(ValueError,'SHA mismatch'):build(self.src,'0'*64,self.lay,file_digest(self.lay),'2026-11-26',test_count=2)
 def test_layout_sha(self):
  self.run_parse()
  with self.assertRaisesRegex(ValueError,'SHA mismatch'):build(self.src,file_digest(self.src),self.lay,'0'*64,'2026-11-26',test_count=2)
 def test_export_no_overwrite(self):
  rows,m=self.run_parse();out=self.p/'release';export(rows,m,out);self.assertTrue((out/'foods.jsonl').exists());
  with self.assertRaises(FileExistsError):export(rows,m,out)
if __name__=='__main__':unittest.main(verbosity=2)
