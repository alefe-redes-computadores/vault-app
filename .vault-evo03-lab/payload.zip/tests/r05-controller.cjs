const assert=require('node:assert/strict');
const {VitalRepository}=require('../build/vital/repository');
const {TABLES}=require('../build/vital/model');
const {createVitalStorage,VITAL_STORES}=require('../build/vital/storage-dexie');
const {createVitalDraftStorage}=require('../build/vital/drafts');
const {trainingDay,trainingPeriod,nutritionDay,activePlanVersions,exerciseCatalog,reuseWorkout}=require('../build/vital/projections');
const {startClock,pauseClock,resumeClock,stopClock,clockTimes}=require('../build/vital/clock');
const {ScopedEditor}=require('../build/vital/editor');
const {decideVitalSync}=require('../build/vital/sync-contract');
const {findModalities,NUTRITION_MODALITIES,EXERCISES}=require('../build/vital/catalog');
const {VITAL_REMINDER_TARGETS,REUSED_REMINDER_TARGETS}=require('../build/vital/reminder-targets');
const {civil}=require('../build/vital/validation');
let idn=0;const id=()=>`11111111-1111-4111-8111-${String(++idn).padStart(12,'0')}`;
const A={user_id:id(),person_id:id()},A2={user_id:A.user_id,person_id:id()},B={user_id:id(),person_id:id()},B2={user_id:B.user_id,person_id:id()};
const clone=structuredClone;const DAY='2026-11-25';let stamp=new Date(2026,10,25,18,0,0).getTime();
// Test-only transactional implementation, no fake IndexedDB or remote success claims.
class FakeDb{
 constructor(){this.tables=new Map([...TABLES,'persons','locais','medicos','rehab_programs_m5','syncQueue','vital_drafts','vital_sync_ack'].map(n=>[n,new Map()]));this.tail=Promise.resolve();this.failure=false;this.dispatched=0;}
 table(name){const self=this;if(!this.tables.has(name))throw Error('Tabela ausente');return {name,async get(k){return clone(self.tables.get(name).get(k));},async put(r){self.tables.get(name).set(r.id,clone(r));},async delete(k){self.tables.get(name).delete(k);},where(index){assert.ok(['[user_id+person_id]','table'].includes(index));return {equals(key){return {async toArray(){return [...self.tables.get(name).values()].filter(r=>index==='table'?r.table===key:r.user_id===key[0]&&r.person_id===key[1]).map(r=>clone(r));}};}};}};}
 transaction(mode,tables,fn){const run=async()=>{const backup=clone(this.tables);try{return await fn();}catch(e){this.tables=backup;throw e;}};const next=this.tail.then(run);this.tail=next.catch(()=>{});return next;}
}
function fixture(){const db=new FakeDb();for(const s of [A,A2,B,B2])db.tables.get('persons').set(s.person_id,{id:s.person_id,user_id:s.user_id});let active=A;let queueFail=false,dispatchFail=false;const auth=async()=>active.user_id;
 const storage=createVitalStorage({db,authenticatedUser:auth,activeScope:()=>active,enqueue:async(table,operation,row,opts)=>{assert.equal(opts.dispatchSync,false);if(queueFail)throw Error('Fila indisponível');const q={id:id(),table,operation,payload:clone(row)};await db.table('syncQueue').put(q);},dispatch:()=>{db.dispatched++;if(dispatchFail)throw Error('sem rede');}});
 return {db,repo:new VitalRepository(storage,()=>new Date(stamp),id),storage,drafts:createVitalDraftStorage({db,authenticatedUser:auth,activeScope:()=>active,now:()=>stamp}),switch(s){active=s;},failQueue(b){queueFail=b;},failDispatch(b){dispatchFail=b;},countQ(){return db.tables.get('syncQueue').size;}};
}
const request=(data,key=id(),rev=null)=>({id:key,expected_revision:rev,data});
const exercise=(ref='treadmill')=>({id:id(),exercise:{source:'catalog',id:ref},duration_seconds:720,distance_m:null,intensity:null,laterality:'not_reported',adaptation:null,sets:[]});
const workout=(over={})=>({day:DAY,title:'Sessão de teste',modality:'cardio',custom_modality:null,status:'completed',started_at:null,ended_at:null,duration_seconds:1800,active_seconds:null,pause_seconds:null,duration_source:'declared',location_id:null,location_label:null,plan_version_id:null,rehab_program_id:null,notes:null,items:[exercise()],clock:null,...over});
const item=(over={})=>({id:id(),food_id:null,name:'Alimento de teste',quantity:null,unit:null,nutrients:{},nutrient_source:null,...over});
const meal=(over={})=>({day:DAY,time:'12:30',kind:'lunch',custom_label:null,plan_version_id:null,items:[item()],notes:null,...over});
const check=(day=DAY,status='trained')=>({day,status,reason:null});
const food=(name='Favorito')=>({name,favorite:true,active:true,notes:null});
const plan=(over={})=>({name:'Plano',starts_on:'2026-11-01',ends_on:null,...over});
const nversion=(plan_id,over={})=>({plan_id,effective_on:'2026-11-01',status:'active',modality_ids:['ketogenic'],custom_modality:null,rules:[],targets:{},origin:'user',notes:null,...over});
const tversion=(plan_id,over={})=>({plan_id,effective_on:'2026-11-01',status:'active',items:[{id:id(),weekday:1,label:'A',exercise:{source:'catalog',id:'leg-press'},target_seconds:600,target_sets:null,target_reps:null,target_load:null,target_load_unit:null}],goal:null,...over});

const {test}=require('node:test');const P=require('../build/vital/nutrition-f2/persistence');const {vitalWireRow,vitalFingerprint,vitalPayload}=require('../build/vital/cloud-transport');const {validateVitalBackup}=require('../build/vital/backup');
const NOW='2026-11-25T14:00:00Z';
const f2item=(provider='manual',itemId=id(),quantity=150)=>({id:itemId,identity:{provider,recordId:'demo',version:'1',preparation:'cooked',presentationId:'g'},composition:{name:'Alimento teste',source:{provider,recordId:'demo',version:'1',license:provider==='taco'?'TACO-2011-attribution':'private',retrievedAt:NOW,attribution:'fixture'},base:{value:100,unit:'g'},values:{protein_g:{state:'known',amount:3,unit:'g'},vitamin_c_mg:{state:'known',amount:2,unit:'mg'}},preparation:'cooked',edibleBasis:'edible'},quantity:{value:quantity,unit:'g'},reviewed:true});
function data(items=[f2item()],mealId=id(),op=id(),legacy=[],scope=A,policies=[]){let e=P.prepareMealEnvelope(scope,{scope,mealId,operationId:op,items},NOW,policies,legacy);return {id:mealId,expected_revision:null,data:meal({items:e.items}),envelope:e.nutrition_f2};}
async function save(f,x,rev=null,reason){return f.repo.saveMealF2(A,{id:x.id,expected_revision:rev,data:x.data},x.envelope,reason);}

const {createMealController,editingMeal}=require('../build/vital/nutrition-f2/meal-controller');
const {decideVitalPull,pushVital}=require('../build/vital/cloud-transport');
const {nutritionDayF2,rememberedPortion}=require('../build/vital/nutrition-f2/meal-history');
function ctrl(f){return createMealController({drafts:f.drafts,repo:f.repo,now:()=>new Date(NOW)});}
const meta={day:'2026-11-24',time:'12:30',kind:'lunch',custom_label:null,plan_version_id:null,notes:null};
function editing(items=[f2item(),f2item()],mealId=id(),op=id(),reason=null){return editingMeal({scope:A,mealId,operationId:op,items},meta,[],reason);}
async function sealed(f,e=editing(),base=null){const c=ctrl(f);await c.saveEditing(A,e,base,null);const r=await c.seal(A,e.draft.mealId,1);return {c,e,r,key:e.draft.mealId};}
test('persisted editor reopens with identical draft after controller recreation',async()=>{const f=fixture(),e=editing();await ctrl(f).saveEditing(A,e,null,null);assert.deepEqual((await ctrl(f).load(A,e.draft.mealId)).value,e);});
test('stale draft revision refuses edits',async()=>{const f=fixture(),e=editing(),c=ctrl(f);await c.saveEditing(A,e,null,null);await assert.rejects(c.saveEditing(A,e,null,null));});
test('unsealed draft cannot confirm',async()=>{const f=fixture(),e=editing(),c=ctrl(f);await c.saveEditing(A,e,null,null);await assert.rejects(c.confirm(A,e.draft.mealId,1));});
test('review required for every item',async()=>{const f=fixture(),e=editing([{...f2item(),reviewed:false}]),c=ctrl(f);await c.saveEditing(A,e,null,null);await assert.rejects(c.seal(A,e.draft.mealId,1));assert.equal(f.countQ(),0);});
test('sealing is stable and does not enqueue',async()=>{const f=fixture(),{c,key,r}=await sealed(f);assert.equal(r.draft_revision,2);assert.deepEqual(await c.seal(A,key,2),r);assert.equal(f.countQ(),0);});
test('sealed draft cannot be edited or ordinarily discarded',async()=>{const f=fixture(),{c,key,e}=await sealed(f);await assert.rejects(c.saveEditing(A,e,null,2));await assert.rejects(c.discardEditing(A,key,2));});
test('queue failure rolls back fact and preserves sealed draft',async()=>{const f=fixture(),{c,key}=await sealed(f);f.failQueue(true);await assert.rejects(c.confirm(A,key,2));assert.equal(f.countQ(),0);assert.equal((await f.repo.list(A,'vital_meals')).length,0);assert.equal((await c.load(A,key)).value.phase,'sealed');});
test('offline dispatch still reports only local save',async()=>{const f=fixture(),{c,key}=await sealed(f);f.failDispatch(true);const result=await c.confirm(A,key,2);assert.equal(result.status,'saved_locally');assert.equal(result.row.synced,false);assert.equal(f.countQ(),1);});
test('recreated controller confirms exact sealed retry only once',async()=>{const f=fixture(),{c,key}=await sealed(f);const a=await c.confirm(A,key,2);const b=await ctrl(f).confirm(A,key,2);assert.deepEqual(a,b);assert.equal(f.countQ(),1);});
test('cleanup refuses uncommitted draft; committed seal can be cleared',async()=>{const f=fixture(),{c,key}=await sealed(f);await assert.rejects(c.cleanup(A,key,2));await c.confirm(A,key,2);await c.cleanup(A,key,2);assert.equal(await c.load(A,key),null);assert.equal(f.countQ(),1);});
test('switching account/person blocks draft recovery',async()=>{const f=fixture(),{c,key}=await sealed(f);f.switch(A2);await assert.rejects(c.load(A2,key));f.switch(B);await assert.rejects(c.load(B,key));assert.equal(f.countQ(),0);});
test('new operation identity cannot be shared by another meal',async()=>{const f=fixture(),{c,key,e}=await sealed(f);await c.confirm(A,key,2);const x=await sealed(f,editing([f2item()],id(),e.draft.operationId));await assert.rejects(x.c.confirm(A,x.key,2),/outra refeição/);assert.equal(f.countQ(),1);});
test('superseded operation cannot replay as new correction',async()=>{const f=fixture(),x=data();await save(f,x);const y=data([f2item()],x.id,id());await save(f,y,1,'retificação');const z=data([f2item()],x.id,x.envelope.operation_id);await assert.rejects(save(f,z,2,'replay'),/histórica/);});
test('pull cannot downgrade F2 even with greater revision',async()=>{const f=fixture(),r=await save(f,data());const remote={...r,revision:2,updated_at:'2026-11-25T23:00:01Z'};delete remote.nutrition_f2;assert.equal(decideVitalPull('vital_meals',A,{...r,synced:true},remote,false),'conflict');});
test('push cannot downgrade F2 even with greater revision',async()=>{const f=fixture(),r=await save(f,data());const local={...r,revision:2,updated_at:'2026-11-25T23:00:01Z'};delete local.nutrition_f2;let writes=0;await assert.rejects(pushVital({remote:{get:async()=>r,insert:async()=>writes++,cas:async()=>writes++},acks:{read:async()=>undefined,write:async()=>writes++}},'vital_meals',A,local),/rebaixado/);assert.equal(writes,0);});
test('projection of confirmed meal uses historical values and last portion',async()=>{const f=fixture(),{c,key,e}=await sealed(f);await c.confirm(A,key,2);const rows=await f.repo.list(A,'vital_meals');const r=nutritionDayF2(A,meta.day,rows,[]);assert.equal(r.recordedItems,2);assert.equal(r.coverage.protein_g.amount,9);assert.equal(r.coverage.vitamin_c_mg.amount,6);assert.deepEqual(rememberedPortion(A,e.draft.items[0].identity,rows),{value:150,unit:'g'});});
test('ordinary cancellation clears draft without creating facts',async()=>{const f=fixture(),c=ctrl(f),e=editing();await c.saveEditing(A,e,null,null);await c.discardEditing(A,e.draft.mealId,1);assert.equal(await c.load(A,e.draft.mealId),null);assert.equal(f.countQ(),0);});
test('correction must contain reason before seal',async()=>{const f=fixture(),x=data();await save(f,x);const c=ctrl(f),e=editing([f2item()],x.id);await c.saveEditing(A,e,1,null);await assert.rejects(c.seal(A,x.id,1),/motivo/);});
test('future date is rejected before sealing, editable draft survives',async()=>{const f=fixture(),c=ctrl(f),e=editing();e.metadata.day='2026-12-01';await c.saveEditing(A,e,null,null);await assert.rejects(c.seal(A,e.draft.mealId,1),/futura/);assert.equal((await c.load(A,e.draft.mealId)).value.phase,'editing');assert.equal(f.countQ(),0);});
test('invalid plan reference and invalid base revision cannot become a sealed draft',async()=>{const f=fixture(),c=ctrl(f),e=editing();await assert.rejects(c.saveEditing(A,e,0,null),/Revisão-base/);e.metadata.plan_version_id='invalid';await assert.rejects(c.saveEditing(A,e,null,null));assert.equal(await c.load(A,e.draft.mealId),null);});
