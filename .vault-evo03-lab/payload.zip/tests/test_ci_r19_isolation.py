import pathlib,os,subprocess,sys,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
REF="refs/heads/vault/lab/evolution03-20261126-r191"
class Isolation(unittest.TestCase):
 def test_wrong_branch_fails_closed(self):
  commands=[['bash','ci-prepare.sh'],['bash','ci-r19-functional.sh'],['bash','ci-r191-catalog-prepare.sh'],['node','ci-r19-screen.cjs'],['node','r19-summary.cjs'],['node','r19-f1.cjs'],['node','r19-f2.cjs'],['node','r19-hc.cjs'],['node','r19-recovery.cjs'],['node','r19-consumers.cjs'],['node','r19-catalog.cjs']]
  for cmd,file in commands:
   for action,ref in [('true','refs/heads/main'),('true','refs/heads/vault/lab/evolution03-20261126-r172'),('true',REF+'-other'),('',REF),('true','')]:
    with self.subTest(file=file,ref=ref,action=action):
     p=subprocess.run([cmd,str(ROOT/'tools'/file)],cwd=ROOT,env={**os.environ,'GITHUB_ACTIONS':action,'GITHUB_REF':ref},capture_output=True,text=True,timeout=5)
     self.assertNotEqual(p.returncode,0);self.assertIn('STOP',p.stdout+p.stderr)
 def test_review_only_workflow(self):
  y=(ROOT/'tools/guardian-remote-lab.yml').read_text();self.assertIn(REF,y);self.assertIn('contents: read',y);self.assertNotIn('workflow_dispatch:',y);self.assertNotIn('continue-on-error:',y)
  launcher=(ROOT/'tools/launch-guardian-lab.sh').read_text();self.assertIn('7f143eb619ba5d9a53572a07c0adcbbd48977c3c',launcher);self.assertIn('git push "$origin" "HEAD:refs/heads/$branch"',launcher)
if __name__=='__main__':unittest.main(verbosity=2)
