#!/usr/bin/env python3
"""Negative isolation tests; no command enters an authorized laboratory."""
from pathlib import Path
import os, subprocess, unittest, re, sys
ROOT=Path(__file__).resolve().parent.parent
REF='refs/heads/vault/lab/evolution03-20261126-r172'
class Isolation(unittest.TestCase):
 def test_exact_ref_agreement(self):
  files=['ci-prepare.sh','guardian-remote-lab.yml','launch-guardian-lab.sh','ci-r17-pg17-docker.sh','ci-r17-catalog-http.cjs','ci-r17-catalog-ui.cjs']
  for f in files:
   with self.subTest(file=f):
    refs=re.findall(r'vault/lab/evolution03-20261126(?:-[a-z0-9]+)?',(ROOT/'tools'/f).read_text())
    expected={REF.removeprefix('refs/heads/')}
    if f=='launch-guardian-lab.sh':
     expected.update({'vault/lab/evolution03-20261126-r17','vault/lab/evolution03-20261126-r171'})
     old_lines=[line for line in (ROOT/'tools'/f).read_text().splitlines() if re.search(r'vault/lab/evolution03-20261126-r17(?![a-z0-9])',line)]
     self.assertEqual(len(old_lines),1);self.assertIn('git ls-remote --exit-code',old_lines[0]);self.assertIn('9c3f626af5cf43b1be23788811d24979fdebdff3',old_lines[0])
     prior=[line for line in (ROOT/'tools'/f).read_text().splitlines() if re.search(r'vault/lab/evolution03-20261126-r171(?![a-z0-9])',line)]
     self.assertEqual(len(prior),1);self.assertIn('git ls-remote --exit-code',prior[0]);self.assertIn('490ffb3d4565a3436e91529e9ff024292462dd31',prior[0])
    self.assertTrue(refs);self.assertEqual(set(refs),expected)
  workflow=(ROOT/'tools/guardian-remote-lab.yml').read_text()
  self.assertEqual(workflow.count("if: github.ref == '"+REF+"'"),1)
  self.assertNotIn('workflow_dispatch:',workflow)
  self.assertIn('contents: read',workflow)
 def test_fail_closed_wrong_branch_and_missing_ci(self):
  cmds=[['bash',str(ROOT/'tools'/f)] for f in ['ci-prepare.sh','ci-r17-pg17-docker.sh']]+[['node',str(ROOT/'tools'/f)] for f in ['ci-r17-catalog-http.cjs','ci-r17-catalog-ui.cjs']]
  for cmd in cmds:
   for action,ref in [('true','refs/heads/main'),('true','refs/heads/vault/lab/evolution03-20261126-r17'),('true','refs/heads/vault/lab/evolution03-20261126-r16'),('true','refs/heads/vault/lab/evolution03-20261126-r171'),('true',REF+'-other'),('true','refs/tags/vault/lab/evolution03-20261126-r172'),('',REF),('true','')]:
    with self.subTest(command=cmd[-1],action=action,ref=ref):
     env={**os.environ,'GITHUB_ACTIONS':action,'GITHUB_REF':ref,'PYTHONOPTIMIZE':'0'}
     r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=5)
     self.assertNotEqual(r.returncode,0);self.assertIn('STOP',r.stdout+r.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
