'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {makeUnixRequester}=require('../tools/lab-unix-http.cjs');
test('isolated HTTP diagnostics and fail-closed deadline, no automatic write replay',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'vault-r15-')),socket=path.join(dir,'http.sock');let writes=0,connections=0;
 const server=http.createServer((req,res)=>{if(req.url==='/slow'){writes++;return;}if(req.url==='/bad'){res.end('no json');return;}req.resume();req.on('end',()=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:true}));});});server.on('connection',()=>connections++);
 await new Promise(r=>server.listen(socket,r));const trace=[];const req=makeUnixRequester(socket,{timeout:100,trace:e=>trace.push(e)});
 try{assert.deepEqual(await req('GET','/first?private=synthetic',{},undefined),{status:200,data:{ok:true}});await assert.rejects(req('POST','/slow',{Authorization:'fake secret'},{sensitive:'test'}),/DEADLINE/);assert.equal(writes,1);assert.deepEqual(await req('GET','/next',{},undefined),{status:200,data:{ok:true}});await assert.rejects(req('GET','/bad',{},undefined),/INVALID_JSON/);assert.equal(connections,4);assert.equal(trace.filter(e=>e.result==='start').length,4);assert.equal(trace.filter(e=>e.result==='error').length,2);assert.doesNotMatch(JSON.stringify(trace),/fake secret|sensitive|private=/);assert.throws(()=>req('GET','//example.com',{}));}finally{server.closeAllConnections?.();await new Promise(r=>server.close(r));fs.rmSync(dir,{recursive:true,force:true});}
});
