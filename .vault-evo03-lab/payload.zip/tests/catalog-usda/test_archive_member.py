import io,sys,unittest,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'candidate/scripts/nutrition'))
from import_usda import archive_member
class Archive(unittest.TestCase):
 def archive(self,names):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   for n in names:z.writestr(n,'fixture')
  return zipfile.ZipFile(b)
 def test_normal(self):
  for n in ['food.csv','dir/FOOD.CSV','dir\\food.csv']:
   with self.archive([n]) as z:self.assertEqual(archive_member(z,'food.csv').filename,n)
 def test_diagnostics(self):
  for ns,msg in [(['nutrient.csv'],'Missing'),(['a/food.csv','b/FOOD.CSV'],'Ambiguous'),(['../food.csv'],'Unsafe'),(['C:\\food.csv'],'Unsafe')]:
   with self.archive(ns) as z:self.assertRaisesRegex(ValueError,msg,archive_member,z,'food.csv')
 def test_size_unchanged(self):
  with self.archive(['food.csv']) as z:
   z.infolist()[0].file_size=300_000_001;self.assertRaisesRegex(ValueError,'Oversized',archive_member,z,'food.csv')
if __name__=='__main__':unittest.main(verbosity=2)
