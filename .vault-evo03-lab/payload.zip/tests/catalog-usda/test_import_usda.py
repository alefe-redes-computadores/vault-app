import csv,io,json,sys,tempfile,unittest,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from import_usda import build,export,file_digest
class USDA(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.p=Path(self.t.name);self.src=self.p/'source.zip'
 def tearDown(self):self.t.cleanup()
 def fixture(self,extra=(),name='Protein',unit='G',duplicate=False):
  with zipfile.ZipFile(self.src,'w') as z:
   z.writestr('data/nutrient.csv',f'id,name,unit_name\n1003,{name},{unit}\n1004,Total lipid (fat),G\n1005,"Carbohydrate, by difference",G\n1093,"Sodium, Na",MG\n1008,Energy,KCAL\n2047,Metabolizable Energy (Atwater General Factor),KCAL\n')
   z.writestr('data/food.csv','fdc_id,data_type,description,publication_date\n100,foundation_food,Test food,2026-10-29\n101,sr_legacy_food,Other,2018-04-01\n'+('100,foundation_food,Duplicate,2026-10-29\n' if duplicate else ''))
   z.writestr('data/food_nutrient.csv','id,fdc_id,nutrient_id,amount,loq,footnote\n1,100,1003,8,,\n2,100,1004,0,0.03,\n3,100,1005,,,\n4,100,1093,12,,\n5,100,2047,110,,\n6,101,1003,9,,\n'+''.join(extra))
 def parse(self,sha=None,release='usda-foundation-2026-10'):return build(self.src,sha or file_digest(self.src),release,'2026-11-26','foundation_food')
 def test_known(self):self.fixture();r,m=self.parse();self.assertEqual(r[0]['composition']['values']['protein_g'],{'state':'known','amount':8,'unit':'g'})
 def test_zero_loq(self):self.fixture();r,_=self.parse();self.assertEqual(r[0]['composition']['values']['fat_g'],{'state':'unknown'})
 def test_missing(self):self.fixture();r,_=self.parse();self.assertEqual(r[0]['composition']['values']['carbohydrate_g']['state'],'not_reported');self.assertNotIn('vitamin_d_ug',r[0]['composition']['values'])
 def test_energy_method(self):self.fixture();r,_=self.parse();self.assertNotIn('energy_kcal',r[0]['composition']['values'])
 def test_scope_kind(self):self.fixture();r,_=self.parse();self.assertEqual(len(r),1);self.assertEqual(r[0]['sourceId'],'100')
 def test_drift(self):self.fixture(name='Unrelated');self.assertRaises(ValueError,self.parse)
 def test_unit_drift(self):self.fixture(unit='MG');self.assertRaises(ValueError,self.parse)
 def test_sha(self):self.fixture();self.assertRaises(ValueError,self.parse,'0'*64)
 def test_duplicate_food(self):self.fixture(duplicate=True);self.assertRaises(ValueError,self.parse)
 def test_duplicate_nutrient(self):self.fixture(extra=['7,100,1003,9,,\n']);r,_=self.parse();self.assertEqual(r[0]['composition']['values']['protein_g']['state'],'unknown');self.assertEqual(len(r[0]['rawEvidence']['nutrient_rows']['protein_g']),2)
 def test_footnote(self):self.fixture(extra=['7,100,1008,100,,Estimated\n']);r,_=self.parse();self.assertEqual(r[0]['composition']['values']['energy_kcal']['state'],'unknown')
 def test_output_deterministic(self):self.fixture();a,m=self.parse();b,n=self.parse();self.assertEqual(a,b);self.assertEqual(m,n)
 def test_immutable_output(self):self.fixture();a,m=self.parse();out=self.p/'release';export(a,m,out);self.assertRaises(FileExistsError,export,a,m,out);self.assertFalse(json.loads((out/'manifest.json').read_text())['activation'])
 def test_no_guessed_preparation(self):self.fixture();a,m=self.parse();self.assertEqual(a[0]['composition']['preparation'],'unknown');self.assertNotIn('equivalence',a[0]['composition'])
 def test_corrected_release_distinct(self):
  self.fixture();old,_=self.parse();new,m=self.parse(release='usda-foundation-2026-10-v2');self.assertEqual(m['release'],'usda-foundation-2026-10-v2');self.assertEqual(new[0]['composition']['source']['version'],m['release']);self.assertNotEqual(old[0]['version'],new[0]['version']);self.assertEqual(old[0]['sourceRecordSha256'],new[0]['sourceRecordSha256']);self.assertFalse(m['activation'])
 def test_invalid_revision_identity(self):
  self.fixture()
  for release in ('usda-foundation-2026-10-v0','usda-foundation-2026-10-v1','usda-foundation-2026-10-v02','usda-foundation-2026-10-v2-extra','usda-sr-2026-10-v2'):
   with self.subTest(release=release):self.assertRaises(ValueError,self.parse,release=release)
 def test_non_decimal_amount_unknown(self):
  self.fixture(extra=['7,100,1008,1_00,,\n']);r,m=self.parse();self.assertEqual(r[0]['composition']['values']['energy_kcal'],{'state':'unknown'});self.assertEqual(m['counts']['malformed_amount'],1)
if __name__=='__main__':unittest.main(verbosity=2)
