#!/usr/bin/env python3
"""Synthetic negative controls for test-only loader. Not clinical certification."""
import pathlib,tempfile,subprocess,unittest,json,os
ROOT=pathlib.Path(__file__).resolve().parent.parent
LOADER=ROOT/'tools/historical-alias-resolver.cjs'
class Resolver(unittest.TestCase):
 def setUp(self):
  self.work=tempfile.TemporaryDirectory(); self.addCleanup(self.work.cleanup)
  self.root=pathlib.Path(self.work.name).resolve();(self.root/'scripts').mkdir();(self.root/'lib/m3').mkdir(parents=True)
  self.entry=self.root/'scripts/test-vault-m63-notifications-search.cjs'
  (self.root/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'baseUrl':'.','paths':{'@/*':['./*']}}}))
  self.module=self.root/'lib/m3/notification-overrides.ts'
  self.module.write_text("import { value } from './nested'; export const result: number=value+1;\n")
  (self.root/'lib/m3/nested.ts').write_text('export const value:number=6;\n')
 def run_entry(self,code,entry=None):
  p=entry or self.entry;p.write_text(code)
  return subprocess.run(['node','--require',str(LOADER),str(p)],cwd=self.root,capture_output=True,text=True,timeout=10)
 def test_real_source_and_transitive(self):
  r=self.run_entry("require('node:assert/strict').equal(require('@/lib/m3/notification-overrides').result,7)")
  self.assertEqual(r.returncode,0,r.stderr);self.assertIn('R11_ALIAS',r.stderr)
 def test_failed_assertion_never_masked(self):
  r=self.run_entry("require('node:assert/strict').equal(require('@/lib/m3/notification-overrides').result,99)")
  self.assertNotEqual(r.returncode,0);self.assertIn('AssertionError',r.stderr)
 def test_unknown_alias(self):
  r=self.run_entry("require('@/lib/m3/nested')");self.assertNotEqual(r.returncode,0);self.assertIn('STOP unreviewed alias',r.stderr)
 def test_missing(self):
  self.module.unlink();r=self.run_entry("require('@/lib/m3/notification-overrides')");self.assertNotEqual(r.returncode,0);self.assertIn('STOP missing or unsafe alias',r.stderr)
 def test_symlink(self):
  self.module.unlink();self.module.symlink_to(self.root/'lib/m3/nested.ts');r=self.run_entry("require('@/lib/m3/notification-overrides')");self.assertNotEqual(r.returncode,0);self.assertIn('STOP missing or unsafe alias',r.stderr)
 def test_other_entry(self):
  r=self.run_entry("console.log('not authorized')",self.root/'scripts/unapproved.cjs');self.assertNotEqual(r.returncode,0);self.assertIn('STOP historical test entry only',r.stderr)
 def test_changed_alias_config(self):
  (self.root/'tsconfig.json').write_text('{"compilerOptions":{"baseUrl":".","paths":{"@/*":["./elsewhere/*"]}}}')
  r=self.run_entry("require('@/lib/m3/notification-overrides')");self.assertNotEqual(r.returncode,0);self.assertIn('STOP unexpected @ alias contract',r.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
