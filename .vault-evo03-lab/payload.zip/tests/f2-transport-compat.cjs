const test=require('node:test');const assert=require('node:assert/strict');
const {createSupabaseVitalTransport}=require('../build/vital/supabase-transport');
const {vitalRemoteFields}=require('../build/vital/cloud-transport');
const id=n=>`11111111-1111-4111-8111-${String(n).padStart(12,'0')}`;const s={user_id:id(1),person_id:id(2)};const baseline='43c39ee489283c772fa52fa07803b2735e94737e';const capability={mode:'f2',enabled:true,protocol:'vault-vital-f2-meal-v1',baseline,approvedBaseline:baseline};
function fixture({data=null,error=null,auth=async()=>s.user_id,mode}={}){const calls=[];const q={};for(const k of ['select','eq','gt','order','limit','maybeSingle','single'])q[k]=(...args)=>{calls.push([k,...args]);return q};q.then=(ok,bad)=>Promise.resolve({data,error}).then(ok,bad);const client={from(t){calls.push(['from',t]);return {...q,insert(v){calls.push(['insert',v]);return q},update(v){calls.push(['update',v]);return q}}}};return {calls,t:createSupabaseVitalTransport(client,auth,mode)};}
const columns=f=>f.calls.filter(c=>c[0]==='select').map(c=>c[1].split(','));
test('legacy get does not ask for an absent F2 column',async()=>{const f=fixture();await f.t.get('vital_meals',s,id(3));assert.deepEqual(columns(f)[0],vitalRemoteFields('vital_meals').filter(k=>k!=='nutrition_f2'));assert.ok(f.calls.some(c=>c[0]==='eq'&&c[1]==='person_id'&&c[2]===s.person_id));});
test('legacy pagination preserves scope and keyset',async()=>{const f=fixture({data:[]});await f.t.page('vital_meals',s,id(3),30);assert.ok(!columns(f)[0].includes('nutrition_f2'));assert.ok(f.calls.some(c=>c[0]==='gt'&&c[2]===id(3)));});
test('F1 insertion omits absent column in returned selection',async()=>{const f=fixture();await f.t.insert('vital_meals',{...s,items:[]});assert.ok(!columns(f)[0].includes('nutrition_f2'));assert.equal(f.calls.filter(c=>c[0]==='insert').length,1)});
test('F1 CAS keeps revision predicate and omits absent column',async()=>{const f=fixture();await f.t.cas('vital_meals',s,id(3),1,{revision:2});assert.ok(!columns(f)[0].includes('nutrition_f2'));assert.ok(f.calls.some(c=>c[0]==='eq'&&c[1]==='revision'&&c[2]===1))});
test('explicit certified reader selects F2 extension',async()=>{const f=fixture({mode:capability});await f.t.get('vital_meals',s,id(3));assert.ok(columns(f)[0].includes('nutrition_f2'))});
test('explicit certified reader selects F2 on paginated read',async()=>{const f=fixture({mode:capability,data:[]});await f.t.page('vital_meals',s,null,30);assert.ok(columns(f)[0].includes('nutrition_f2'))});
test('F2 schema failure is not retried as a legacy read',async()=>{const f=fixture({mode:capability,error:{code:'42703',message:'missing'}});await assert.rejects(f.t.get('vital_meals',s,id(3)),/42703/);assert.equal(columns(f).length,1);assert.ok(columns(f)[0].includes('nutrition_f2'))});
for(const [label,mode] of [['different baseline',{...capability,approvedBaseline:'a'.repeat(40)}],['wrong protocol',{...capability,protocol:'unknown'}],['disabled',{...capability,enabled:false}],['malformed baseline',{...capability,baseline:'x',approvedBaseline:'x'}]])test('reject '+label,()=>assert.throws(()=>fixture({mode}),/não certificada/));
for(const [label,mode] of [['F1',undefined],['F2',capability]]){
 test(label+' generic insert cannot write F2 or explicit null',async()=>{const f=fixture({mode});for(const nutrition_f2 of [{},null])await assert.rejects(f.t.insert('vital_meals',{...s,nutrition_f2}),/transacional/);assert.equal(f.calls.length,0)});
 test(label+' generic CAS cannot write F2 or explicit null',async()=>{const f=fixture({mode});for(const nutrition_f2 of [{},null])await assert.rejects(f.t.cas('vital_meals',s,id(3),1,{revision:2,nutrition_f2}),/transacional/);assert.equal(f.calls.length,0)});
 test(label+' generic audit with F2 previous refused',async()=>{const f=fixture({mode});await assert.rejects(f.t.insert('vital_audit',{...s,target_table:'vital_meals',previous:{nutrition_f2:{}}}),/transacional/);assert.equal(f.calls.length,0)});
}
test('other Vital tables do not request F2 column',async()=>{const f=fixture({mode:capability});await f.t.get('vital_foods',s,id(3));assert.deepEqual(columns(f)[0],vitalRemoteFields('vital_foods'));});
test('account switches during read invalidate result',async()=>{let n=0;const f=fixture({mode:capability,auth:async()=>++n===1?s.user_id:id(4)});await assert.rejects(f.t.get('vital_meals',s,id(3)),/Conta mudou/)});
test('legacy audit remains writable',async()=>{const f=fixture();await f.t.insert('vital_audit',{...s,target_table:'vital_meals',previous:{notes:null}});assert.equal(f.calls.filter(c=>c[0]==='insert').length,1)});

test('unknown runtime schema mode rejected',()=>assert.throws(()=>fixture({mode:{mode:'future'}}),/Schema Vital desconhecido/));
