import importlib.util,pathlib,unittest
root=pathlib.Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('reanchor',root/'tools/reanchor-review-tree.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=(root/'patch/preimage'/m.DOSSIER).read_bytes();new=(root/'patch/postimage'/m.DOSSIER).read_bytes()
class TestDossier(unittest.TestCase):
 def test_nonoverlap_preserved(self):
  current=b'// A10 synthetic remote change\n'+old
  self.assertEqual(m.reviewed_dossier(old,new,current,m.blob(current)),b'// A10 synthetic remote change\n'+new)
 def test_stale_blob_rejected(self):
  with self.assertRaisesRegex(ValueError,'blob drift'):m.reviewed_dossier(old,new,old,'0'*40)
 def test_other_candidate_changes_rejected(self):
  with self.assertRaisesRegex(ValueError,'local dossier delta'):m.reviewed_dossier(old,new+b'\n',old,m.blob(old))
 def test_ambiguous_context_rejected(self):
  current=old+old
  with self.assertRaisesRegex(ValueError,'ambiguous'):m.reviewed_dossier(old,new,current,m.blob(current))
class TestHistoricalLoader(unittest.TestCase):
 def test_exact_delta(self):
  for name in m.HOST_LOADERS:
   old=(root/'patch/preimage'/name).read_bytes();new=(root/'patch/postimage'/name).read_bytes();remote=b'// synthetic independent edit\n'+old
   self.assertEqual(m.reviewed_loader(name,old,new,remote,m.blob(remote)),b'// synthetic independent edit\n'+new)
   with self.assertRaisesRegex(ValueError,'blob drift'):m.reviewed_loader(name,old,new,remote,'0'*40)
   with self.assertRaisesRegex(ValueError,'local delta'):m.reviewed_loader(name,old,new+b'\n',remote,m.blob(remote))
   with self.assertRaisesRegex(ValueError,'anchor drift'):m.loader_delta(old+old)
class TestHostAdditive(unittest.TestCase):
 def test_reversible_shared_deltas(self):
  for name in m.HOST_ADDITIVE:
   before=(root/'patch/preimage'/name).read_bytes();after=(root/'patch/postimage'/name).read_bytes();remote=b'// synthetic unrelated delta\n'+before
   self.assertEqual(m.reviewed_additive(name,before,after,remote,m.blob(remote)),b'// synthetic unrelated delta\n'+after)
   with self.assertRaisesRegex(ValueError,'blob drift'):m.reviewed_additive(name,before,after,remote,'0'*40)
   with self.assertRaisesRegex(ValueError,'local additive'):m.reviewed_additive(name,before,after+b'\n',remote,m.blob(remote))
 def test_schema_collision(self):
  before=(root/'patch/preimage/lib/db/index.ts').read_bytes()
  with self.assertRaisesRegex(ValueError,'schema version collision'):m.additive_delta('lib/db/index.ts',before+b'\nthis.version(60).stores({})')
if __name__=='__main__':unittest.main()
