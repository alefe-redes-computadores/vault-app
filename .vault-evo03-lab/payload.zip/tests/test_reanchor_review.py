import importlib.util,pathlib,unittest
root=pathlib.Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('reanchor',root/'tools/reanchor-review-tree.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=(root/'patch/preimage'/m.DOSSIER).read_bytes();new=(root/'patch/postimage'/m.DOSSIER).read_bytes()
class TestDossier(unittest.TestCase):
 def test_nonoverlap_preserved(self):
  current=b'// A10 synthetic remote change\n'+old
  self.assertEqual(m.reviewed_dossier(old,new,current,m.blob(current)),b'// A10 synthetic remote change\n'+new)
 def test_stale_blob_rejected(self):
  with self.assertRaisesRegex(ValueError,'blob drift'):m.reviewed_dossier(old,new,old,'0'*40)
 def test_other_candidate_changes_rejected(self):
  with self.assertRaisesRegex(ValueError,'local dossier delta'):m.reviewed_dossier(old,new+b'\n',old,m.blob(old))
 def test_ambiguous_context_rejected(self):
  current=old+old
  with self.assertRaisesRegex(ValueError,'ambiguous'):m.reviewed_dossier(old,new,current,m.blob(current))
if __name__=='__main__':unittest.main()
