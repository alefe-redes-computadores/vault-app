const assert=require('node:assert/strict');
const {VitalRepository}=require('../build/vital/repository');
const {TABLES}=require('../build/vital/model');
const {createVitalStorage,VITAL_STORES}=require('../build/vital/storage-dexie');
const {createVitalDraftStorage}=require('../build/vital/drafts');
const {trainingDay,trainingPeriod,nutritionDay,activePlanVersions,exerciseCatalog,reuseWorkout}=require('../build/vital/projections');
const {startClock,pauseClock,resumeClock,stopClock,clockTimes}=require('../build/vital/clock');
const {ScopedEditor}=require('../build/vital/editor');
const {decideVitalSync}=require('../build/vital/sync-contract');
const {findModalities,NUTRITION_MODALITIES,EXERCISES}=require('../build/vital/catalog');
const {VITAL_REMINDER_TARGETS,REUSED_REMINDER_TARGETS}=require('../build/vital/reminder-targets');
const {civil}=require('../build/vital/validation');
let idn=0;const id=()=>`11111111-1111-4111-8111-${String(++idn).padStart(12,'0')}`;
const A={user_id:id(),person_id:id()},A2={user_id:A.user_id,person_id:id()},B={user_id:id(),person_id:id()},B2={user_id:B.user_id,person_id:id()};
const clone=structuredClone;const DAY='2026-11-25';let stamp=new Date(2026,10,25,18,0,0).getTime();
// Test-only transactional implementation, no fake IndexedDB or remote success claims.
class FakeDb{
 constructor(){this.tables=new Map([...TABLES,'persons','locais','medicos','rehab_programs_m5','syncQueue','vital_drafts','vital_sync_ack'].map(n=>[n,new Map()]));this.tail=Promise.resolve();this.failure=false;this.dispatched=0;}
 table(name){const self=this;if(!this.tables.has(name))throw Error('Tabela ausente');return {name,async get(k){return clone(self.tables.get(name).get(k));},async put(r){self.tables.get(name).set(r.id,clone(r));},async delete(k){self.tables.get(name).delete(k);},where(index){assert.ok(['[user_id+person_id]','table'].includes(index));return {equals(key){return {async toArray(){return [...self.tables.get(name).values()].filter(r=>index==='table'?r.table===key:r.user_id===key[0]&&r.person_id===key[1]).map(r=>clone(r));}};}};}};}
 transaction(mode,tables,fn){const run=async()=>{const backup=clone(this.tables);try{return await fn();}catch(e){this.tables=backup;throw e;}};const next=this.tail.then(run);this.tail=next.catch(()=>{});return next;}
}
function fixture(){const db=new FakeDb();for(const s of [A,A2,B,B2])db.tables.get('persons').set(s.person_id,{id:s.person_id,user_id:s.user_id});let active=A;let queueFail=false,dispatchFail=false;const auth=async()=>active.user_id;
 const storage=createVitalStorage({db,authenticatedUser:auth,activeScope:()=>active,enqueue:async(table,operation,row,opts)=>{assert.equal(opts.dispatchSync,false);if(queueFail)throw Error('Fila indisponível');const q={id:id(),table,operation,payload:clone(row)};await db.table('syncQueue').put(q);},dispatch:()=>{db.dispatched++;if(dispatchFail)throw Error('sem rede');}});
 return {db,repo:new VitalRepository(storage,()=>new Date(stamp),id),storage,drafts:createVitalDraftStorage({db,authenticatedUser:auth,activeScope:()=>active,now:()=>stamp}),switch(s){active=s;},failQueue(b){queueFail=b;},failDispatch(b){dispatchFail=b;},countQ(){return db.tables.get('syncQueue').size;}};
}
const request=(data,key=id(),rev=null)=>({id:key,expected_revision:rev,data});
const exercise=(ref='treadmill')=>({id:id(),exercise:{source:'catalog',id:ref},duration_seconds:720,distance_m:null,intensity:null,laterality:'not_reported',adaptation:null,sets:[]});
const workout=(over={})=>({day:DAY,title:'Sessão de teste',modality:'cardio',custom_modality:null,status:'completed',started_at:null,ended_at:null,duration_seconds:1800,active_seconds:null,pause_seconds:null,duration_source:'declared',location_id:null,location_label:null,plan_version_id:null,rehab_program_id:null,notes:null,items:[exercise()],clock:null,...over});
const item=(over={})=>({id:id(),food_id:null,name:'Alimento de teste',quantity:null,unit:null,nutrients:{},nutrient_source:null,...over});
const meal=(over={})=>({day:DAY,time:'12:30',kind:'lunch',custom_label:null,plan_version_id:null,items:[item()],notes:null,...over});
const check=(day=DAY,status='trained')=>({day,status,reason:null});
const food=(name='Favorito')=>({name,favorite:true,active:true,notes:null});
const plan=(over={})=>({name:'Plano',starts_on:'2026-11-01',ends_on:null,...over});
const nversion=(plan_id,over={})=>({plan_id,effective_on:'2026-11-01',status:'active',modality_ids:['ketogenic'],custom_modality:null,rules:[],targets:{},origin:'user',notes:null,...over});
const tversion=(plan_id,over={})=>({plan_id,effective_on:'2026-11-01',status:'active',items:[{id:id(),weekday:1,label:'A',exercise:{source:'catalog',id:'leg-press'},target_seconds:600,target_sets:null,target_reps:null,target_load:null,target_load_unit:null}],goal:null,...over});

const {test}=require('node:test');
const {reviewedLabelComposition,labelDraftItem}=require('../build/vital/nutrition-f2/label-confirmation');
const {suggestLabelFields}=require('../build/vital/nutrition-f2/label-suggestions');
const {createMealController}=require('../build/vital/nutrition-f2/meal-controller');
const {createMealJourney}=require('../build/vital/nutrition-f2/meal-journey');
const {searchLocalLabels,reuseLocalLabel}=require('../build/vital/nutrition-f2/local-label-search');
const {totalsFor,gtin}=require('../build/vital/nutrition-f2/nutrition');
const {verifyMealEnvelope}=require('../build/vital/nutrition-f2/persistence');
const {submitMealStep}=require('../build/vital/nutrition-f2/remote-meal');
const {vitalWireRow}=require('../build/vital/cloud-transport');
const at='2026-11-24T14:00:00.000Z';
const barcode=gtin('7891000100103');assert.ok(barcode);
const field=(nutrient,raw,unit,state='value',observed=null)=>({nutrient,raw,unit,state,confirmed:true,observed});
const evidence=(over={})=>({schema:1,recordId:id(),versionId:id(),reviewedAt:at,name:'Iogurte natural',barcode,basis:'per100',base:{value:100,unit:'g'},fields:[field('protein_g','3,5','g'),field('calcium_mg','125','mg'),field('fiber_g','0','g'),field('vitamin_c_mg','','mg','unreadable')],capture:null,...over});
const meta={day:'2026-11-23',time:'12:30',kind:'lunch',custom_label:null,plan_version_id:null,notes:null};
const journey=(f,scope=A)=>createMealJourney(createMealController({repo:f.repo,drafts:f.drafts,now:()=>new Date(at)}),scope,()=>new Date(at));
async function start(j){return j.start(id(),id(),meta)};
async function one(f,e=evidence(),q={value:150,unit:'g'}){const j=journey(f);let s=await start(j),item=labelDraftItem(e,id(),q);s=await j.add(s,item);return {j,s,item};}
async function confirmOne(f,e=evidence(),q={value:150,unit:'g'}){let {j,s,item}=await one(f,e,q);s=await j.review(s,item.id,true);s=await j.seal(s);return j.confirm(s);}
const failEvidence=(over,rx)=>assert.throws(()=>reviewedLabelComposition(evidence(over)),rx);
const ocrToken=(text,x,y,w=28,h=12)=>({text,box:[x,y,x+w,y+h],confidence:null});
function ocr({extra=[],unit='g',tokens}={}){return {status:'ocr_review',text:'Tabela nutricional de teste',recognizer:'mlkit-latin-bundled',version:'16.0.1',imageWidth:400,imageHeight:200,geometry:'uncertain',imageRetention:'discard',tokens:tokens??[ocrToken(`100 ${unit}`,230,20,42),ocrToken(`30 ${unit}`,300,20,38),ocrToken('%VD',366,20,24),ocrToken('Proteínas',5,50,70),ocrToken('(g)',82,50,22),ocrToken('10',242,50,15),ocrToken('3',310,50,10),ocrToken('6',372,50,10),ocrToken('Sódio',5,75,48),ocrToken('(mg)',60,75,30),ocrToken('200',237,75,24),ocrToken('60',305,75,20),ocrToken('3',372,75,10),...extra]};}
// New tests only; fixture copied from exact label-meal-journey suite, historical suite unchanged.
async function editOne(f,out=undefined){out=out??await confirmOne(f);const j=journey(f);const s=await j.correct(out.row.id,out.row.revision,id(),'Quantidade corrigida');return {j,s,row:out.row,item:s.value.draft.items[0]};}
test('correction starts from canonical preimage with new operation and stable item ID',async()=>{const f=fixture(),{s,row,item}=await editOne(f);assert.equal(s.record.expected_revision,row.revision);assert.equal(s.record.id,row.id);assert.notEqual(s.value.draft.operationId,row.nutrition_f2.operation_id);assert.equal(item.id,row.items[0].id);assert.equal(item.reviewed,false);assert.deepEqual(item.composition,row.nutrition_f2.items[item.id].payload.composition);assert.equal(f.countQ(),1);});
test('correction requires reason, exact revision and same scope',async()=>{const f=fixture(),out=await confirmOne(f),j=journey(f);await assert.rejects(j.correct(out.row.id,2,id(),'Motivo'),/mudou/);await assert.rejects(j.correct(out.row.id,1,id(),' '),/obrigatório/);await assert.rejects(j.correct(out.row.id,1,out.row.nutrition_f2.operation_id,'Motivo'),/nova operação/);f.switch(A2);await assert.rejects(journey(f,A2).correct(out.row.id,1,id(),'Motivo'),/mudou/);});
test('retification atomically updates existing meal and audits old exact evidence',async()=>{const f=fixture(),{j,s:initial,row,item}=await editOne(f);let s=await j.quantity(initial,item.id,{value:250,unit:'g'});s=await j.review(s,item.id,true);s=await j.seal(s);const result=await j.confirm(s);assert.equal(result.row.id,row.id);assert.equal(result.row.revision,2);assert.equal(result.row.nutrition_f2.items[item.id].payload.totals.protein_g.amount,8.75);assert.equal((await f.repo.list(A,'vital_meals')).length,1);const audit=await f.repo.revisionHistory(A,'vital_meals',row.id);assert.equal(audit.length,1);assert.deepEqual(audit[0].previous.nutrition_f2,row.nutrition_f2);assert.equal(audit[0].reason,'Quantidade corrigida');});
test('retification stale concurrent writer refuses without losing sealed draft',async()=>{const f=fixture(),{j,s:initial,row,item}=await editOne(f);let s=await j.review(initial,item.id,true);s=await j.seal(s);await f.repo.archive(A,'vital_meals',row.id,row.revision,'Retirado');await assert.rejects(j.confirm(s));assert.equal((await j.resume(row.id)).value.phase,'sealed');});
test('cancel correction preserves original fact and audit',async()=>{const f=fixture(),{j,s,row}=await editOne(f);await j.discard(s);assert.deepEqual((await f.repo.list(A,'vital_meals'))[0],row);assert.equal((await f.repo.revisionHistory(A,'vital_meals',row.id)).length,0);});
test('correction refuses duplicate draft instead of replacing it',async()=>{const f=fixture(),{j,row,s}=await editOne(f);await assert.rejects(j.correct(row.id,row.revision,id(),'Outro'),/alterado/);assert.deepEqual(await j.resume(row.id),s);});
test('correction preserves mixed F1 qualitative items exactly',async()=>{const f=fixture();const j=journey(f);const item=labelDraftItem(evidence(),id(),{value:100,unit:'g'});const legacy={id:id(),food_id:null,name:'Alimento qualitativo',quantity:null,unit:null,nutrients:{},nutrient_source:null};const {prepareMealEnvelope}=require('../build/vital/nutrition-f2/persistence');const p=prepareMealEnvelope(A,{scope:A,mealId:id(),operationId:id(),items:[{...item,reviewed:true}]},at,[],[legacy]);const row=await f.repo.saveMealF2(A,{id:p.id,expected_revision:null,data:{...meta,items:p.items}},p.nutrition_f2);let s=await j.correct(row.id,row.revision,id(),'Corrigir');assert.deepEqual(s.value.legacy,[legacy]);s=await j.review(s,item.id,true);s=await j.seal(s);const out=await j.confirm(s);assert.deepEqual(out.row.items.find(x=>x.id===legacy.id),legacy);});
test('repeat makes a new unconfirmed draft with independent IDs and preserved composition',async()=>{const f=fixture(),out=await confirmOne(f),j=journey(f);const s=await j.repeat(out.row.id,out.row.revision,id,{...meta,time:null});assert.notEqual(s.record.id,out.row.id);assert.equal(s.record.expected_revision,null);assert.notEqual(s.value.draft.items[0].id,out.row.items[0].id);assert.deepEqual(s.value.draft.items[0].composition,Object.values(out.row.nutrition_f2.items)[0].payload.composition);assert.equal(s.value.draft.items[0].reviewed,false);assert.equal(f.countQ(),1);});
test('repeat rejects qualitative legacy rather than silently omitting it',async()=>{const f=fixture(),r=await f.repo.saveMeal(A,request(meal()));await assert.rejects(journey(f).repeat(r.id,r.revision,id,meta),/legados/);});
test('repeat requires review then commits independent meal',async()=>{const f=fixture(),out=await confirmOne(f),j=journey(f);let s=await j.repeat(out.row.id,out.row.revision,id,{...meta,time:null});await assert.rejects(j.seal(s),/revisado/);s=await j.review(s,s.value.draft.items[0].id,true);s=await j.seal(s);const result=await j.confirm(s);assert.notEqual(result.row.id,out.row.id);assert.equal(result.row.revision,1);assert.equal((await f.repo.list(A,'vital_meals')).length,2);});
const {prepareRecipeForm,recipeIngredientChoices}=require('../build/vital/nutrition-f2/recipe-authoring');
const {stageNativeNutrition}=require('../build/vital/nutrition-f2/health-connect-native');
const hcConnection={scope:A,revision:'1',nutritionReadGranted:true,origin:'com.sec.android.app.shealth'};
const range={start:'2026-11-20T00:00:00.000Z',end:'2026-11-24T00:00:00.000Z'};
const hcRecord={recordId:'record-1',origin:hcConnection.origin,type:'nutrition',start:'2026-11-21T12:00:00.000Z',end:'2026-11-21T12:30:00.000Z',lastModified:'2026-11-21T13:00:00.000Z',mealType:'lunch',mealName:null,nutrients:{protein_g:{state:'known',amount:20,unit:'g'},fiber_g:{state:'known',amount:0,unit:'g'}}};
const nativePage=(r=hcRecord,next=null)=>({records:[r],next,permission:true});
const stage=(read,current=async()=>hcConnection,r=range)=>stageNativeNutrition(hcConnection,current,{readNutritionPage:read},r,[],[],Date.parse(at));
test('native HC scope bound locally, no person identifiers sent, zero stays unknown',async()=>{let req;const r=await stage(async x=>{req=x;return nativePage();});assert.deepEqual(req,{...range,cursor:null});assert.deepEqual(r.candidates[0].record.scope,A);assert.equal(r.candidates[0].record.nutrients.fiber_g.state,'unknown');assert.equal(r.canDeleteMissing,false);});
test('native HC rejects foreign scope fields and outside fixed window',async()=>{await assert.rejects(stage(async()=>nativePage({...hcRecord,scope:A2})),/fora da consulta/);await assert.rejects(stage(async()=>nativePage({...hcRecord,start:'2026-11-19T00:00:00.000Z'})),/fora da consulta/);});
test('native HC rejects excessive, reversed or future intervals before read',async()=>{let called=false;for(const r of [{...range,start:'2026-10-01T00:00:00.000Z'},{start:range.end,end:range.start},{...range,end:'2026-12-01T00:00:00.000Z'}])await assert.rejects(stage(async()=>{called=true;return nativePage();},async()=>hcConnection,r),/Período/);assert.equal(called,false);});
test('native HC pagination preserves fixed window and rejects revoked permission',async()=>{const seen=[];const r=await stage(async x=>{seen.push(x);return x.cursor===null?nativePage(hcRecord,'next'):nativePage({...hcRecord,recordId:'record-2'});});assert.equal(r.candidates.length,2);assert.deepEqual(seen,[{...range,cursor:null},{...range,cursor:'next'}]);await assert.rejects(stage(async x=>x.cursor===null?nativePage(hcRecord,'next'):{...nativePage(),permission:false}),/revogada/);});
test('native HC rejects change of active person during native page',async()=>{let active=hcConnection;await assert.rejects(stage(async()=>{active={...active,scope:A2};return nativePage();},async()=>active),/revogada|mudou/);});
async function formFixture(){const f=fixture(),out=await confirmOne(f),r=out.row;const form={name:'Receita teste',kind:'recipe',favorite:false,finishedMass:'300',servings:'3',rawMass:'',yieldEvidence:'Pesado depois do preparo',ingredients:[{mealId:r.id,itemId:r.items[0].id,ingredientId:id(),quantity:{value:200,unit:'g'},reviewed:true}]};return {f,r,form};}
test('recipe form reuses canonical reviewed compositions, not legacy unknowns',async()=>{const {f,r,form}=await formFixture();const choices=recipeIngredientChoices(A,[r]);assert.equal(choices.length,1);const p=prepareRecipeForm(A,[r],form,at);assert.equal(p.version.ingredients[0].totals.protein_g.amount,7);assert.equal(p.version.servings,3);assert.equal(p.version.raw_edible_mass_g,null);assert.deepEqual(p.version.ingredients[0].composition,r.nutrition_f2.items[r.items[0].id].payload.composition);});
test('recipe form rejects unreviewed, missing source, absent yield evidence and incompatible conversion',async()=>{const {r,form}=await formFixture();const i=form.ingredients[0];for(const x of [{...form,ingredients:[{...i,reviewed:false}]},{...form,ingredients:[{...i,itemId:id()}]},{...form,yieldEvidence:''},{...form,finishedMass:'',servings:''},{...form,ingredients:[{...i,quantity:{value:1,unit:'mL'}}]}])assert.throws(()=>prepareRecipeForm(A,[r],x,at));});
test('recipe authoring rejects foreign scope, archived meals and duplicate ingredient identities',async()=>{const {r,form}=await formFixture();assert.throws(()=>prepareRecipeForm(A2,[r],form,at),/indisponível/);assert.throws(()=>prepareRecipeForm(A,[{...r,deleted_at:at}],form,at),/indisponível/);assert.throws(()=>prepareRecipeForm(A,[r],{...form,ingredients:[...form.ingredients,...form.ingredients]},at),/Revise/);});
