import pathlib,tempfile,shutil,subprocess,sys,json,unittest,xml.etree.ElementTree as ET
P=pathlib.Path; ROOT=P(__file__).resolve().parents[1]; POST=ROOT/'patch/postimage'; SCRIPT=POST/'scripts/prepare-android-nutrition-f2.py'; A='{http://schemas.android.com/apk/res/android}'
class Prepare(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.root=P(self.t.name);self.main=self.root/'android/app/src/main/java/com/alefejohsefe/vault/MainActivity.java';self.main.parent.mkdir(parents=True);self.main.write_text('class MainActivity { void onCreate() { registerPlugin(VaultHealthConnectPlugin.class); registerPlugin(VaultApkUpdaterPlugin.class); } }');self.gradle=self.root/'android/app/build.gradle';self.gradle.write_text('// VAULT_HEALTH_CONNECT_V113\n');self.man=self.root/'android/app/src/main/AndroidManifest.xml';self.man.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application><provider android:name="existing" android:authorities="existing" android:exported="false"/></application></manifest>');(self.root/'capacitor.config.json').write_text(json.dumps({'appId':'com.alefejohsefe.vault'}));shutil.copytree(POST/'native',self.root/'native')
 def tearDown(self):self.t.cleanup()
 def run_script(self,flag=True,hc=False):return subprocess.run([sys.executable,str(SCRIPT),'--root',str(self.root)]+(['--isolated-review'] if flag else [])+(['--health-connect-nutrition-review'] if hc else []),capture_output=True,text=True)
 def snapshot(self):return {str(p.relative_to(self.root)):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
 def failure(self,flag=True):before=self.snapshot();r=self.run_script(flag);self.assertNotEqual(r.returncode,0,r.stdout);self.assertEqual(before,self.snapshot())
 def test_generated_platform(self):
  self.assertEqual(self.run_script().returncode,0);self.assertIn('registerPlugin(VaultNutritionCapturePlugin.class);',self.main.read_text());self.assertIn('17.3.0',self.gradle.read_text());self.assertIn('16.0.1',self.gradle.read_text());m=ET.parse(self.man).getroot();providers=m.findall('application/provider');self.assertEqual(len(providers),2);self.assertEqual(providers[1].get(A+'exported'),'false');self.assertEqual(providers[1].get(A+'grantUriPermissions'),'true');self.assertEqual(providers[0].get(A+'name'),'existing');self.assertEqual(len(m.findall('uses-permission')),1);self.assertTrue((self.main.parent/'VaultNutritionCapturePlugin.java').exists());self.assertTrue((self.root/'android/app/src/main/res/xml/vault_nutrition_paths.xml').exists())
 def test_idempotent(self):self.assertEqual(self.run_script().returncode,0);before=self.snapshot();self.assertEqual(self.run_script().returncode,0);self.assertEqual(before,self.snapshot())
 def test_explicit_hc_permission(self):
  self.assertEqual(self.run_script(hc=True).returncode,0);m=ET.parse(self.man).getroot();self.assertEqual([p.get(A+'name') for p in m.findall('uses-permission')],['android.permission.INTERNET','android.permission.health.READ_NUTRITION']);before=self.snapshot();self.assertEqual(self.run_script(hc=True).returncode,0);self.assertEqual(before,self.snapshot())
 def test_hc_permission_drift(self):
  self.man.write_text(self.man.read_text().replace('<application>','<uses-permission android:name="android.permission.health.READ_NUTRITION" android:maxSdkVersion="32"/><application>'));before=self.snapshot();self.assertNotEqual(self.run_script(hc=True).returncode,0);self.assertEqual(before,self.snapshot())
 def test_hc_no_review_no_mutation(self):
  before=self.snapshot();self.assertNotEqual(self.run_script(flag=False,hc=True).returncode,0);self.assertEqual(before,self.snapshot())
 def test_hc_nutrient_mapping_contract(self):
  import re
  source=(POST/'native/health-connect/VaultHealthConnectPlugin.kt').read_text();rows=re.findall(r'put\("([a-z0-9_]+)",n\.\w+\?\.in\w+,"(\w+)"\)',source);self.assertEqual(len(rows),26);self.assertEqual(len(set(k for k,u in rows)),26);self.assertNotIn('added_sugar_g',dict(rows));self.assertNotIn('vitamin_a_rae_ug',dict(rows));self.assertEqual(dict(rows)['sodium_mg'],'mg');self.assertEqual(dict(rows)['vitamin_b12_ug'],'ug');self.assertIn('if(amount == 0.0) JSObject().put("state","unknown")',source)
 def test_requires_review(self):self.failure(False)
 def test_git_locked(self):(self.root/'.git').mkdir();self.failure()
 def test_wrong_app(self):(self.root/'capacitor.config.json').write_text('{"appId":"wrong"}');self.failure()
 def test_anchor_missing(self):self.main.write_text('class MainActivity {}');self.failure()
 def test_duplicate_anchor(self):self.main.write_text(self.main.read_text()+'registerPlugin(VaultApkUpdaterPlugin.class);');self.failure()
 def test_conflicting_dependency(self):self.gradle.write_text(self.gradle.read_text()+"\nimplementation 'com.google.mlkit:barcode-scanning:99.0.0'");self.failure()
 def test_provider_conflict(self):self.man.write_text(self.man.read_text().replace('android:authorities="existing"','android:authorities="${applicationId}.vaultnutritionprovider"'));self.failure()
 def test_target_drift(self):(self.main.parent/'VaultNutritionCapturePlugin.java').write_text('foreign');self.failure()
 def test_kotlin_main(self):k=self.main.with_suffix('.kt');self.main.unlink();k.write_text('class MainActivity { fun onCreate() { registerPlugin(VaultHealthConnectPlugin::class.java)\nregisterPlugin(VaultApkUpdaterPlugin::class.java) } }');self.assertEqual(self.run_script().returncode,0);self.assertIn('registerPlugin(VaultNutritionCapturePlugin::class.java)',k.read_text())
 def test_narrow_provider(self):root=ET.parse(POST/'native/nutrition/vault_nutrition_paths.xml').getroot();self.assertEqual([(x.tag,x.attrib) for x in root],[('cache-path',{'name':'nutrition_capture','path':'nutrition-capture/'})])
if __name__=='__main__':unittest.main(verbosity=2)
