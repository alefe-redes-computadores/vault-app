#!/usr/bin/env python3
"""Negative isolation tests; no command enters an authorized laboratory."""
from pathlib import Path
import os, subprocess, unittest, re, sys
ROOT=Path(__file__).resolve().parent.parent
REF='refs/heads/vault/lab/evolution03-20261126-r12'
class Isolation(unittest.TestCase):
 def test_exact_ref_agreement(self):
  files=['ci-prepare.sh','guardian-remote-lab.yml','launch-guardian-lab.sh','ci-r12-historical.py','ci-r12-global-gate.sh','ci-r12-catalog.sh','ci-r12-canonical-ui.cjs','ci-r12-consumer-ui.cjs']
  for f in files:
   with self.subTest(file=f):
    refs=re.findall(r'vault/lab/evolution03-20261126(?:-[a-z0-9]+)?',(ROOT/'tools'/f).read_text())
    self.assertTrue(refs);self.assertEqual(set(refs),{REF.removeprefix('refs/heads/')})
  workflow=(ROOT/'tools/guardian-remote-lab.yml').read_text()
  self.assertEqual(workflow.count("if: github.ref == '"+REF+"'"),3)
  self.assertNotIn('workflow_dispatch:',workflow)
  self.assertIn('contents: read',workflow)
 def test_fail_closed_wrong_branch_and_missing_ci(self):
  cmds=[['bash',str(ROOT/'tools'/f)] for f in ['ci-prepare.sh','ci-r12-global-gate.sh','ci-r12-catalog.sh']]+[[sys.executable,str(ROOT/'tools/ci-r12-historical.py')],['node',str(ROOT/'tools/ci-r12-canonical-ui.cjs')],['node',str(ROOT/'tools/ci-r12-consumer-ui.cjs')]]
  for cmd in cmds:
   for action,ref in [('true','refs/heads/main'),('true',REF[:-1]+'1'),('true',REF+'-other'),('true','refs/tags/vault/lab/evolution03-20261126-r12'),('',REF),('true','')]:
    with self.subTest(command=cmd[-1],action=action,ref=ref):
     env={**os.environ,'GITHUB_ACTIONS':action,'GITHUB_REF':ref,'PYTHONOPTIMIZE':'0'}
     r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=5)
     self.assertNotEqual(r.returncode,0);self.assertIn('STOP',r.stdout+r.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
