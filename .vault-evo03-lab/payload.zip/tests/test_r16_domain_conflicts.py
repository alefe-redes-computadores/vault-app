#!/usr/bin/env python3
"""Guard exact R15 writer predicates, privileges and SQL bodies; only deliberate domain error code changes."""
from pathlib import Path
import hashlib, unittest
ROOT=Path(__file__).resolve().parent.parent
ORIGINALS={'07-F2-MEAL-RPC-REVIEW-M03.sql': (6, '70f6809b822f418dcd4d69b4f92c2da312f4d7af05249570c746094faca2f569'), '10-RECIPE-RPC-REVIEW.sql': (8, '3cf06b4e2052459d77819b6fc6f13e4df3c80b8e658cd8bb04a34d3255142a03'), '15-PLAN-TARGETS-WRITER-LAB.sql': (1, 'a69258c224354816892b110acf0b40d91aa420247d02c17745f53f486dc2b771')}
class ConflictContract(unittest.TestCase):
 def test_sql_predicates_and_privileges_identical(self):
  for name,(count,old) in ORIGINALS.items():
   with self.subTest(name=name):
    data=(ROOT/'sql'/name).read_bytes()
    self.assertEqual(data.count(b"ERRCODE='PT409'"),count)
    self.assertNotIn(b"ERRCODE='40001'",data)
    self.assertEqual(hashlib.sha256(data.replace(b"ERRCODE='PT409'",b"ERRCODE='40001'")).hexdigest(),old)
 def test_history_concurrency_and_negative_cases_retained(self):
  client=(ROOT/'tools/ci-r16-client-http.cjs').read_text(); pg=(ROOT/'tools/ci-r16-pg17-docker.sh').read_text(); http=(ROOT/'tools/test-r16-postgrest-unix.py').read_text()
  for x in ["changedRetry.status,409","changedRetry.data?.code,'PT409'","await head(planTable,v1);await head(planTable,v2)","concurrent versions serialize at canonical root, only one winner","encrypted plan backup confirmed against actual remote history"]:self.assertIn(x,client)
  for x in ['stale meal CAS returns finite HTTP 409','stale recipe CAS returns finite HTTP 409','stale meal leaves head and audit unchanged','stale recipe leaves head and versions unchanged']:self.assertIn(x,http)
  self.assertIn("grep -q PT409",pg);self.assertIn('R16_PERMANENT_CONFLICT_SINGLE_REJECTION_PASS',pg)
if __name__=='__main__':unittest.main(verbosity=2)
