import pathlib,os,subprocess,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
REF='refs/heads/vault/lab/evolution03-20261126-r23'
class Isolation(unittest.TestCase):
 def test_wrong_branch_fails_closed(self):
  for cmd,file in [('bash','ci-prepare.sh'),('bash','ci-r23-pg17-docker.sh'),('node','ci-r23-catalog-http.cjs')]:
   for action,ref in [('true','refs/heads/main'),('true','refs/heads/vault/lab/evolution03-20261126-r191'),('true',REF+'-other'),('',REF),('true','')]:
    with self.subTest(file=file,ref=ref,action=action):
     p=subprocess.run([cmd,str(ROOT/'tools'/file)],cwd=ROOT,env={**os.environ,'GITHUB_ACTIONS':action,'GITHUB_REF':ref},capture_output=True,text=True,timeout=5)
     self.assertNotEqual(p.returncode,0);self.assertIn('STOP',p.stdout+p.stderr)
 def test_inherited_pg_env_stops(self):
  for k in ['PGHOST','PGHOSTADDR','PGSERVICE','PGSERVICEFILE','PGDATABASE','PGOPTIONS','PGUSER','PGPASSWORD','PGPASSFILE']:
   p=subprocess.run(['bash',str(ROOT/'tools/ci-r23-pg17-docker.sh')],cwd=ROOT,env={**os.environ,'GITHUB_ACTIONS':'true','GITHUB_REF':REF,k:'UNSAFE'},capture_output=True,text=True,timeout=5)
   self.assertNotEqual(p.returncode,0);self.assertIn('STOP inherited',p.stdout+p.stderr)
 def test_workflow_and_rollback(self):
  w=(ROOT/'tools/guardian-remote-lab.yml').read_text();s=(ROOT/'tools/ci-r23-pg17-docker.sh').read_text();l=(ROOT/'tools/launch-guardian-lab.sh').read_text();g=(ROOT/'tools/r23-batch.cjs').read_text()
  self.assertIn(REF,w);self.assertIn('contents: read',w);self.assertNotIn('workflow_dispatch:',w);self.assertNotIn('continue-on-error:',w);self.assertNotIn('secrets.',w);self.assertIn('--network none',s);self.assertIn('registry_before',s);self.assertIn('ROLLBACK;',g);self.assertIn('SET LOCAL ROLE vault_f2_meal_worker_lab',g);self.assertIn('bd6e92134920a1b00d4b18139fc68d4742a523ca',l);self.assertIn('git push "$origin" "HEAD:refs/heads/$branch"',l);self.assertNotIn('--force',l)
if __name__=='__main__':unittest.main(verbosity=2)
