import importlib.util,json,pathlib,tempfile,unittest
R=pathlib.Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('ledger',R/'tools/catalog-review-ledger.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);triage=R/'evidence/rodada-R12/catalog-triage'
class Review(unittest.TestCase):
 def test_exact_rows_and_no_activation(self):
  with tempfile.TemporaryDirectory() as d:
   f=pathlib.Path(d)/'ledger.jsonl';self.assertEqual(m.write_template(triage,f),1095);self.assertEqual(m.validate(triage,f)['decisions']['pending'],1095)
   rows=m.read_rows(f)
   def write(rs):f.write_text(''.join(json.dumps(x)+'\n' for x in rs))
   for patch in [{'name':'Changed'},{'sourceRecordSha256':'0'*64},{'decision':'approved'},{'decision':'retain_for_approval'},{'decision':'exclude','reviewerRef':'test','reason':None}]:
    with self.subTest(patch=patch):
     write([{**rows[0],**patch},*rows[1:]])
     with self.assertRaises(ValueError):m.validate(triage,f)
   write(rows[:-1]);self.assertRaises(ValueError,m.validate,triage,f)
   write([rows[0],*rows]);self.assertRaises(ValueError,m.validate,triage,f)
   write([{**rows[0],'decision':'retain_for_approval','reviewerRef':'synthetic test only','reason':'test'},*rows[1:]]);s=m.validate(triage,f);self.assertFalse(s['activation']);self.assertEqual(s['approved'],0);self.assertEqual(s['decisions']['retain_for_approval'],1)
if __name__=='__main__':unittest.main(verbosity=2)
