/** Local-first meal workflow. Uses existing Vital draft store and repository; no alternate writer. */
import type {Scope,MealData,MealRow} from '../model';
import type {VitalRepository} from '../repository';
import type {createVitalDraftStorage} from '../drafts';
import {civil,requireId,requireScope,time,oneOf,text,localDay} from '../validation';
import {draftAdd,type MealDraft} from './meal-draft';
import {prepareMealEnvelope,verifyMealEnvelope,type LegacyItem,type F2Envelope} from './persistence';
type Metadata=Omit<MealData,'items'>;
type Editing={version:1;phase:'editing';draft:MealDraft;metadata:Metadata;legacy:LegacyItem[];reason:string|null};
type Sealed={version:1;phase:'sealed';draft:MealDraft;metadata:Metadata;legacy:LegacyItem[];reason:string|null;reviewedAt:string;envelope:F2Envelope;items:LegacyItem[]};
export type MealEditor=Editing|Sealed;
type DraftPort=ReturnType<typeof createVitalDraftStorage>;
function must(ok:unknown,msg:string):asserts ok{if(!ok)throw Error(msg);}
const same=(a:unknown,b:unknown)=>JSON.stringify(a,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v)===JSON.stringify(b,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
function validate(raw:unknown,s:Scope,id:string):MealEditor{
 must(raw&&typeof raw==='object','Rascunho inválido');const x=raw as MealEditor;
 must(x.version===1&&(x.phase==='editing'||x.phase==='sealed')&&x.draft?.mealId===id&&x.draft.scope?.user_id===s.user_id&&x.draft.scope?.person_id===s.person_id,'Rascunho fora do escopo');
 requireId(x.draft.operationId);must(x.draft.operationId!==id&&Array.isArray(x.draft.items)&&Array.isArray(x.legacy)&&x.legacy.length+x.draft.items.length<=200,'Identidade/lote inválido');
 let d:MealDraft={...x.draft,items:[]};for(const i of x.draft.items){must(typeof i.reviewed==='boolean','Revisão inválida');d=draftAdd(d,i);}
 civil(x.metadata.day);time(x.metadata.time);const kind=oneOf(x.metadata.kind,['breakfast','lunch','snack','dinner','supper','custom'] as const);text(x.metadata.custom_label,80,kind==='custom');text(x.metadata.notes);if(x.metadata.plan_version_id!==null)requireId(x.metadata.plan_version_id);
 must(x.reason===null||typeof x.reason==='string'&&x.reason.length<=500,'Motivo inválido');
 if(x.phase==='sealed'){
  verifyMealEnvelope(s,x.items,x.envelope);const checked=prepareMealEnvelope(s,x.draft,x.reviewedAt,[],x.legacy);
  must(same(checked.items,x.items)&&same(checked.nutrition_f2,x.envelope),'Rascunho selado divergente');
 }
 return structuredClone(x);
}
/** Controller preserves exact sealed payload after interrupted confirmation. It cannot activate licensed sources or sync itself. */
export function createMealController(deps:{drafts:DraftPort;repo:Pick<VitalRepository,'saveMealF2'|'list'>;now?:()=>Date}){
 const now=deps.now??(()=>new Date());
 const load=async(s:Scope,id:string)=>deps.drafts.load(requireScope(s),requireId(id),'meal',p=>validate(p,s,id));
 async function saveEditing(s:Scope,p:Editing,base:number|null,revision:number|null){
  must(base===null||Number.isSafeInteger(base)&&base>0,'Revisão-base inválida');const id=p.draft.mealId;const prior=await load(s,id);
  must((prior?.record.draft_revision??null)===revision,'Rascunho alterado');
  must(!prior||prior.value.phase==='editing'&&prior.record.expected_revision===base&&prior.value.draft.operationId===p.draft.operationId,'Confirmação já selada ou identidade alterada');
  return deps.drafts.save(s,{id,kind:'meal',payload:validate(p,s,id),expected_revision:base,expected_draft_revision:revision});
 }
 async function seal(s:Scope,id:string,revision:number){
  const prior=await load(s,id);must(prior&&prior.record.draft_revision===revision,'Rascunho alterado ou expirado');if(prior.value.phase==='sealed')return prior.record;
  const p=prior.value;must(prior.record.expected_revision===null||!!p.reason?.trim(),'Informe o motivo da retificação');
  const stamp=now(),today=localDay(stamp),hhmm=`${String(stamp.getHours()).padStart(2,'0')}:${String(stamp.getMinutes()).padStart(2,'0')}`;must(p.metadata.day<today||p.metadata.day===today&&(!p.metadata.time||p.metadata.time<=hhmm),'Refeição futura não é fato realizado');const reviewedAt=stamp.toISOString(),result=prepareMealEnvelope(s,p.draft,reviewedAt,[],p.legacy);
  const sealed:Sealed={...p,phase:'sealed',reviewedAt,envelope:result.nutrition_f2,items:result.items};
  return deps.drafts.save(s,{id,kind:'meal',payload:validate(sealed,s,id),expected_revision:prior.record.expected_revision,expected_draft_revision:revision});
 }
 async function confirm(s:Scope,id:string,revision:number):Promise<{row:MealRow;status:'saved_locally';draft:'retained_for_explicit_cleanup'}>{
  const prior=await load(s,id);must(prior&&prior.record.draft_revision===revision&&prior.value.phase==='sealed','Revise e sele a confirmação antes de salvar');
  const p=prior.value;const row=await deps.repo.saveMealF2(s,{id,expected_revision:prior.record.expected_revision,data:{...p.metadata,items:p.items}},p.envelope,p.reason??undefined);
  // Keep the seal until explicit cleanup; process death between commit and UI response is recoverable.
  must(row.id===id&&row.nutrition_f2?.operation_id===p.envelope.operation_id&&same(row.nutrition_f2,p.envelope),'Gravação não confirmada');
  return {row,status:'saved_locally',draft:'retained_for_explicit_cleanup'};
 }
 async function cleanup(s:Scope,id:string,revision:number){const prior=await load(s,id);must(prior&&prior.record.draft_revision===revision&&prior.value.phase==='sealed','Rascunho alterado');const p=prior.value;const rows=await deps.repo.list(s,'vital_meals');const row=rows.find(x=>x.id===id);must(row&&same(row.nutrition_f2,p.envelope),'Não há confirmação local correspondente; preserve o rascunho');await deps.drafts.discard(s,id,revision);}
 return {load,saveEditing,seal,confirm,cleanup,async discardEditing(s:Scope,id:string,revision:number){const prior=await load(s,id);must(prior&&prior.record.draft_revision===revision&&prior.value.phase==='editing','Confirmação selada exige recuperação/revisão');await deps.drafts.discard(s,id,revision);}};
}
export function editingMeal(draft:MealDraft,metadata:Metadata,legacy:LegacyItem[]=[],reason:string|null=null):Editing{return {version:1,phase:'editing',draft:structuredClone(draft),metadata:structuredClone(metadata),legacy:structuredClone(legacy),reason};}
