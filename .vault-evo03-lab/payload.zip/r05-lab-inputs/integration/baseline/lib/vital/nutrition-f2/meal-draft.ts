/** Pure draft and preference projections. No store, network, or alternate meal writer. */
import {makeSnapshot,totalsFor,type Composition,type Quantity,type Scope,type Snapshot} from './nutrition';
export type FoodIdentity={provider:string;recordId:string;version:string;preparation:string;presentationId:string};
export type ConfirmedItem={scope:Scope;identity:FoodIdentity;quantity:Quantity;confirmedAt:string;itemId:string;state:'confirmed'|'draft'|'planned'|'deleted'};
const sameScope=(a:Scope,b:Scope)=>a.user_id===b.user_id&&a.person_id===b.person_id;
const key=(i:FoodIdentity)=>JSON.stringify([i.provider,i.recordId,i.version,i.preparation,i.presentationId]);
const validScope=(s:Scope)=>!!s.user_id.trim()&&!!s.person_id.trim();
const allowedUnits=['g','kg','mL','L','portion','unit'];
const validQty=(q:Quantity)=>Number.isFinite(q.value)&&q.value>0&&q.value<=1e6&&allowedUnits.includes(q.unit);
const identityValid=(i:FoodIdentity)=>[i.provider,i.recordId,i.version,i.preparation,i.presentationId].every(s=>typeof s==='string'&&s.trim());
/** Exact identity/version by default. Never transfer a household serving across a changed version or preparation. */
export function lastPortion(scope:Scope,identity:FoodIdentity,history:readonly ConfirmedItem[]):Quantity|null {
 if(!validScope(scope)||!identityValid(identity)) throw Error('Identidade inválida');
 const rows=history.filter(x=>sameScope(x.scope,scope)&&x.state==='confirmed'&&identityValid(x.identity)&&key(x.identity)===key(identity)&&validQty(x.quantity)&&Number.isFinite(Date.parse(x.confirmedAt))&&x.itemId.trim());
 rows.sort((a,b)=>Date.parse(b.confirmedAt)-Date.parse(a.confirmedAt)||b.itemId.localeCompare(a.itemId,'en'));
 return rows.length?structuredClone(rows[0].quantity):null;
}
export type DraftItem={id:string;identity:FoodIdentity;composition:Composition;quantity:Quantity;reviewed:boolean};
export type MealDraft={scope:Scope;mealId:string;operationId:string;items:readonly DraftItem[]};
const uuid=(x:string)=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x);
export function draftAdd(d:MealDraft,item:DraftItem):MealDraft {
 if(!validScope(d.scope)||!uuid(d.mealId)||!uuid(d.operationId)||!uuid(item.id)||!identityValid(item.identity)||!validQty(item.quantity)||d.items.length>=200||d.items.some(x=>x.id.toLowerCase()===item.id.toLowerCase()))throw Error('Rascunho inválido');
 if(item.identity.provider!==item.composition.source.provider||item.identity.recordId!==item.composition.source.recordId||item.identity.version!==item.composition.source.version||item.identity.preparation!==(item.composition.preparation??'unknown'))throw Error('Identidade divergente da composição');
 totalsFor(item.composition,item.quantity); // validation only; no write
 return {...structuredClone(d),items:[...structuredClone(d.items),structuredClone(item)]};
}
/** All-or-nothing validation before canonical saveMeal. Does not claim remote idempotence/atomicity. */
export function prepareBatch(active:Scope,d:MealDraft):Readonly<{mealId:string;operationId:string;scope:Scope;snapshots:readonly Snapshot[]}> {
 if(!sameScope(active,d.scope)||!validScope(active)||!uuid(d.mealId)||!uuid(d.operationId)||!d.items.length||d.items.length>200)throw Error('Escopo ou lote inválido');
 let checked:MealDraft={scope:active,mealId:d.mealId,operationId:d.operationId,items:[]};
 for(const item of d.items){if(!item.reviewed)throw Error('Item ainda não revisado');checked=draftAdd(checked,item);}
 return {mealId:d.mealId,operationId:d.operationId,scope:structuredClone(active),snapshots:checked.items.map(i=>makeSnapshot(active,i.id,i.composition,i.quantity))};
}
