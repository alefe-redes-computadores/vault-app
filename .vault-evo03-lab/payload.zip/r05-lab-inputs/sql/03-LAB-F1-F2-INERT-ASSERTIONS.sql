-- INCLUDE ONLY INSIDE THE R04 DISPOSABLE TRANSACTION, AFTER DDL, BEFORE ROLLBACK.
-- Synthetic data, no user data; intentionally fails if F1 schema/roles are not restored.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab(_[a-z0-9]+)?$' OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' THEN RAISE EXCEPTION 'STOP lab only'; END IF;
 IF inet_server_addr() IS NOT NULL THEN RAISE EXCEPTION 'STOP use unix socket'; END IF;
 IF md5(pg_get_functiondef('public.vital_evo_guard_row()'::regprocedure)) IS DISTINCT FROM '8cfe19e775fb15458a8ea03660049616' THEN RAISE EXCEPTION 'STOP F1 guard drift; reanchor'; END IF;
END $$;
-- UUIDs reserved in this lab. Never import actual user rows. If auth triggers require other fixture data, adapt fixture only after reviewing restored schema.
INSERT INTO auth.users(id) VALUES ('90000000-0000-4000-8000-000000000001'),('90000000-0000-4000-8000-000000000002');
INSERT INTO public.persons(id,user_id,name) VALUES
 ('90000000-0000-4000-8000-000000000011','90000000-0000-4000-8000-000000000001','LAB A1'),
 ('90000000-0000-4000-8000-000000000012','90000000-0000-4000-8000-000000000001','LAB A2'),
 ('90000000-0000-4000-8000-000000000021','90000000-0000-4000-8000-000000000002','LAB B1'),
 ('90000000-0000-4000-8000-000000000022','90000000-0000-4000-8000-000000000002','LAB B2');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','90000000-0000-4000-8000-000000000001',true);
SELECT set_config('request.jwt.claims','{"sub":"90000000-0000-4000-8000-000000000001","role":"authenticated"}',true);
DO $$ BEGIN IF auth.uid() IS DISTINCT FROM '90000000-0000-4000-8000-000000000001'::uuid THEN RAISE EXCEPTION 'STOP fixture auth mismatch'; END IF; END $$;
INSERT INTO public.vital_meals(id,user_id,person_id,created_at,updated_at,revision,day,kind,items) VALUES
 ('90000000-0000-4000-8000-000000000101','90000000-0000-4000-8000-000000000001','90000000-0000-4000-8000-000000000011','2026-11-25T12:00Z','2026-11-25T12:00Z',1,'2026-11-25','lunch','[{"id":"90000000-0000-4000-8000-000000000201","name":"LAB food","food_id":null,"quantity":null,"unit":null,"nutrients":{},"nutrient_source":null}]');
DO $$ DECLARE n integer; BEGIN
 UPDATE public.vital_meals SET notes='F1 correction',updated_at='2026-11-25T13:00Z',revision=2 WHERE id='90000000-0000-4000-8000-000000000101' AND revision=1;
 GET DIAGNOSTICS n=ROW_COUNT; IF n<>1 THEN RAISE EXCEPTION 'FAIL F1 CAS'; END IF;
 UPDATE public.vital_meals SET notes='stale' WHERE id='90000000-0000-4000-8000-000000000101' AND revision=1;
 GET DIAGNOSTICS n=ROW_COUNT; IF n<>0 THEN RAISE EXCEPTION 'FAIL stale CAS'; END IF;
 IF (SELECT nutrition_f2 IS NOT NULL FROM public.vital_meals WHERE id='90000000-0000-4000-8000-000000000101') THEN RAISE EXCEPTION 'FAIL legacy materialized fake snapshot'; END IF;
 BEGIN
  UPDATE public.vital_meals SET nutrition_f2='{"schema_version":1,"operation_id":"90000000-0000-4000-8000-000000000301","items":{},"legacy_item_ids":[]}',revision=3,updated_at='2026-11-25T14:00Z' WHERE id='90000000-0000-4000-8000-000000000101';
  RAISE EXCEPTION 'FAIL F2 activation unlocked';
 EXCEPTION WHEN raise_exception THEN IF SQLERRM<>'F2 activation locked' THEN RAISE; END IF; END;
 BEGIN
  INSERT INTO public.vital_meals(id,user_id,person_id,created_at,updated_at,revision,day,kind,items) SELECT '90000000-0000-4000-8000-000000000102',user_id,'90000000-0000-4000-8000-000000000021',created_at,updated_at,1,day,kind,items FROM public.vital_meals WHERE id='90000000-0000-4000-8000-000000000101';
  RAISE EXCEPTION 'FAIL cross-account person FK';
 EXCEPTION WHEN foreign_key_violation THEN NULL; END;
 BEGIN
  INSERT INTO public.vital_recipes(id,user_id,person_id,created_at,updated_at,revision,kind,name) VALUES ('90000000-0000-4000-8000-000000000401','90000000-0000-4000-8000-000000000001','90000000-0000-4000-8000-000000000011',now(),now(),1,'recipe','LAB');
  RAISE EXCEPTION 'FAIL recipe client write privilege';
 EXCEPTION WHEN insufficient_privilege THEN NULL; END;
 RAISE NOTICE 'LAB_F1_CAS_F2_LOCK_FK_GRANTS_PASS';
END $$;
RESET ROLE;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','90000000-0000-4000-8000-000000000002',true);
SELECT set_config('request.jwt.claims','{"sub":"90000000-0000-4000-8000-000000000002","role":"authenticated"}',true);
DO $$ DECLARE n int; BEGIN
 IF auth.uid() IS DISTINCT FROM '90000000-0000-4000-8000-000000000002'::uuid THEN RAISE EXCEPTION 'STOP fixture auth mismatch'; END IF;
 IF EXISTS(SELECT 1 FROM public.vital_meals WHERE id='90000000-0000-4000-8000-000000000101') THEN RAISE EXCEPTION 'FAIL cross-account SELECT'; END IF;
 UPDATE public.vital_meals SET notes='foreign' WHERE id='90000000-0000-4000-8000-000000000101'; GET DIAGNOSTICS n=ROW_COUNT; IF n<>0 THEN RAISE EXCEPTION 'FAIL cross-account UPDATE'; END IF;
 RAISE NOTICE 'LAB_CROSS_ACCOUNT_RLS_PASS';
END $$;
RESET ROLE;
-- Same-account A1/A2 visibility follows existing F1 policy; per-person active scope is a client/application contract and composite FK.
-- Not evidence for a stricter server-side delegated-person authorization, which is a distinct requirement to reconcile with Guardian.
