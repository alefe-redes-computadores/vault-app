-- EVOLUTION 03 / R04 REVISAO SOMENTE. NÃO INSTALAR. Não é migration versionada.
-- Sucessor do R03 01-DDL. Fase inerte, SEM ativação e SEM COMMIT.
-- Requer clone descartável do schema cumulativo e roles Supabase. Sem COMMIT.
-- Nenhuma gravação produtiva autorizada. Deliberadamente não ativa o escritor F2.
BEGIN;
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab(_[a-z0-9]+)?$' OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' THEN RAISE EXCEPTION 'STOP: disposable lab only'; END IF;
 IF current_setting('server_version_num')::int NOT BETWEEN 170600 AND 170699 THEN RAISE EXCEPTION 'STOP: PG17.6 required for this lab'; END IF;
 IF to_regclass('public.vital_meals') IS NULL OR to_regclass('public.vital_foods') IS NULL OR to_regclass('public.persons') IS NULL THEN RAISE EXCEPTION 'STOP: F1 schema not restored'; END IF;
END $$;
-- Federated physical boundaries. No shared materialized corpus; no TBCA namespace.
DO $$ DECLARE ns text; BEGIN
 FOREACH ns IN ARRAY ARRAY['vault_food_taco','vault_food_usda','vault_food_off'] LOOP
  EXECUTE format('CREATE SCHEMA %I',ns);
  EXECUTE format('REVOKE ALL ON SCHEMA %I FROM PUBLIC, anon, authenticated',ns);
  EXECUTE format($ddl$CREATE TABLE %I.releases(
   version text PRIMARY KEY CHECK(length(btrim(version))>0), official_url text NOT NULL,
   captured_at timestamptz NOT NULL, manifest_sha256 text NOT NULL CHECK(manifest_sha256~'^[a-f0-9]{64}$'),
   license text NOT NULL CHECK(length(btrim(license))>0), attribution text NOT NULL CHECK(length(btrim(attribution))>0),
   approval_ref text, can_query boolean NOT NULL DEFAULT false, can_cache boolean NOT NULL DEFAULT false,
   can_snapshot boolean NOT NULL DEFAULT false, can_distribute boolean NOT NULL DEFAULT false, can_images boolean NOT NULL DEFAULT false,
   CHECK(NOT(can_query OR can_cache OR can_snapshot OR can_distribute OR can_images) OR nullif(btrim(approval_ref),'') IS NOT NULL))$ddl$,ns);
  EXECUTE format($ddl$CREATE TABLE %I.food_versions(
   release_version text NOT NULL, source_id text NOT NULL CHECK(length(btrim(source_id))>0),
   display_name text NOT NULL CHECK(length(btrim(display_name))>0), search_key text NOT NULL,
   preparation text NOT NULL, brand text, market text, gtin text CHECK(gtin IS NULL OR gtin~'^([0-9]{8}|[0-9]{12,14})$'),
   base_quantity numeric NOT NULL CHECK(base_quantity>0 AND base_quantity<=1000000), base_unit text NOT NULL CHECK(base_unit IN ('g','kg','mL','L','portion','unit')),
   source_revision text, source_record_sha256 text NOT NULL CHECK(source_record_sha256~'^[a-f0-9]{64}$'),
   edible_basis text NOT NULL CHECK(edible_basis IN ('edible','as_purchased','unknown')),
   original_values jsonb NOT NULL CHECK(jsonb_typeof(original_values)='object'),
   normalized_values jsonb NOT NULL CHECK(jsonb_typeof(normalized_values)='object'),
   serving_evidence jsonb CHECK(serving_evidence IS NULL OR jsonb_typeof(serving_evidence)='object'),
   PRIMARY KEY(release_version,source_id), FOREIGN KEY(release_version) REFERENCES %I.releases(version) ON DELETE RESTRICT)$ddl$,ns,ns);
  EXECUTE format('CREATE INDEX ON %I.food_versions(gtin) WHERE gtin IS NOT NULL',ns);
  EXECUTE format('CREATE INDEX ON %I.food_versions(release_version,search_key text_pattern_ops)',ns);
  EXECUTE format('ALTER TABLE %I.releases ENABLE ROW LEVEL SECURITY',ns);
  EXECUTE format('ALTER TABLE %I.food_versions ENABLE ROW LEVEL SECURITY',ns);
  EXECUTE format('REVOKE ALL ON ALL TABLES IN SCHEMA %I FROM PUBLIC, anon, authenticated',ns);
  -- No policies and no client grants in draft. Later read adapter must gate every action by approved release and legal review.
 END LOOP;
END $$;
-- Extension on the same facts. NULL means legacy/unavailable, not zero.
ALTER TABLE public.vital_meals ADD COLUMN nutrition_f2 jsonb;
ALTER TABLE public.vital_meals ADD CONSTRAINT vital_meals_nutrition_f2_envelope_check CHECK(nutrition_f2 IS NULL OR (jsonb_typeof(nutrition_f2)='object' AND nutrition_f2 ? 'schema_version' AND nutrition_f2->'schema_version'='1'::jsonb AND nutrition_f2 ? 'operation_id' AND coalesce(nutrition_f2->>'operation_id','') ~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' AND nutrition_f2 ? 'legacy_item_ids' AND jsonb_typeof(nutrition_f2->'legacy_item_ids')='array' AND nutrition_f2 ? 'items' AND jsonb_typeof(nutrition_f2->'items')='object'));
CREATE UNIQUE INDEX vital_meals_f2_operation_candidate ON public.vital_meals(user_id,person_id,(nutrition_f2->>'operation_id')) WHERE nutrition_f2 IS NOT NULL;
ALTER TABLE public.vital_foods ADD COLUMN catalog_ref jsonb;
ALTER TABLE public.vital_foods ADD CONSTRAINT vital_foods_catalog_ref_shape CHECK(catalog_ref IS NULL OR (jsonb_typeof(catalog_ref)='object' AND catalog_ref ?& ARRAY['provider','source_id','version'] AND catalog_ref->>'provider' IN ('taco','usda','off')));
ALTER TABLE public.vital_nutrition_plan_versions ADD COLUMN targets_f2 jsonb CHECK(targets_f2 IS NULL OR jsonb_typeof(targets_f2)='object');
ALTER TABLE public.vital_nutrition_checkins ADD COLUMN daily_totals_f2 jsonb CHECK(daily_totals_f2 IS NULL OR jsonb_typeof(daily_totals_f2)='object');
-- External record identity stays attached to canonical meal; not a parallel diary. Unique even for tombstone.
CREATE UNIQUE INDEX vital_meals_hc_identity_candidate ON public.vital_meals(user_id,person_id,(nutrition_f2#>>'{external,origin}'),(nutrition_f2#>>'{external,record_id}')) WHERE nutrition_f2#>>'{external,kind}'='health_connect';
CREATE INDEX vital_meals_scope_day_candidate ON public.vital_meals(user_id,person_id,day) WHERE deleted_at IS NULL;
-- IMPORTANT: uniqueness protects current operation per fact, not arbitrary old replay.
-- Existing durable Vital ACK and CAS must remain canonical.
-- Recipe and saved-meal template share a versioned reusable entity, but never represent eaten meals.
CREATE TABLE public.vital_recipes(
 id uuid PRIMARY KEY,user_id uuid NOT NULL,person_id uuid NOT NULL,
 created_at timestamptz NOT NULL,updated_at timestamptz NOT NULL,deleted_at timestamptz,
 revision bigint NOT NULL CHECK(revision BETWEEN 1 AND 9007199254740991),
 kind text NOT NULL CHECK(kind IN ('recipe','meal_template')),name text NOT NULL CHECK(length(btrim(name)) BETWEEN 1 AND 160),
 favorite boolean NOT NULL DEFAULT false,active boolean NOT NULL DEFAULT true,
 UNIQUE(id,user_id,person_id),FOREIGN KEY(person_id,user_id) REFERENCES public.persons(id,user_id) ON DELETE CASCADE,
 CHECK(updated_at>=created_at),CHECK(deleted_at IS NULL OR deleted_at<=updated_at));
CREATE TABLE public.vital_recipe_versions(
 id uuid PRIMARY KEY,user_id uuid NOT NULL,person_id uuid NOT NULL,recipe_id uuid NOT NULL,
 version integer NOT NULL CHECK(version>0),revision bigint NOT NULL CHECK(revision=1),created_at timestamptz NOT NULL,updated_at timestamptz NOT NULL,deleted_at timestamptz CHECK(deleted_at IS NULL),
 name_snapshot text NOT NULL CHECK(length(btrim(name_snapshot)) BETWEEN 1 AND 160),
 ingredients jsonb NOT NULL CHECK(jsonb_typeof(ingredients)='array' AND jsonb_array_length(ingredients) BETWEEN 1 AND 200),
 raw_edible_mass_g numeric CHECK(raw_edible_mass_g>0 AND raw_edible_mass_g<=1000000),
 finished_mass_g numeric CHECK(finished_mass_g>0 AND finished_mass_g<=1000000),
 servings numeric CHECK(servings>0 AND servings<=1000000),
 yield_evidence text, retention_evidence jsonb CHECK(retention_evidence IS NULL OR jsonb_typeof(retention_evidence)='object'),
 UNIQUE(id,user_id,person_id), UNIQUE(recipe_id,user_id,person_id,version),
 FOREIGN KEY(person_id,user_id) REFERENCES public.persons(id,user_id) ON DELETE CASCADE,
 FOREIGN KEY(recipe_id,user_id,person_id) REFERENCES public.vital_recipes(id,user_id,person_id) ON DELETE CASCADE,
 CHECK(updated_at>=created_at),CHECK(finished_mass_g IS NULL OR nullif(btrim(yield_evidence),'') IS NOT NULL));
CREATE INDEX vital_recipes_scope_idx ON public.vital_recipes(user_id,person_id,updated_at);
CREATE INDEX vital_recipe_versions_scope_idx ON public.vital_recipe_versions(user_id,person_id,updated_at);
ALTER TABLE public.vital_recipes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vital_recipe_versions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.vital_recipes,public.vital_recipe_versions FROM PUBLIC,anon,authenticated;
-- Read policies target the established account ownership and composite FK. No client write grants in this phase.
CREATE POLICY vital_recipes_read ON public.vital_recipes FOR SELECT TO authenticated USING ((SELECT auth.uid())=user_id);
CREATE POLICY vital_recipe_versions_read ON public.vital_recipe_versions FOR SELECT TO authenticated USING ((SELECT auth.uid())=user_id);
-- Conservative inert phase guard: F2 data must not be created/changed through F1 writer before compatibility protocol exists.
-- Do not ship this guard as final F2 implementation; it intentionally blocks activation.
CREATE FUNCTION public.vital_f2_review_lock() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE j jsonb:=to_jsonb(NEW); oldj jsonb; f text;
BEGIN
 f:=CASE TG_TABLE_NAME WHEN 'vital_meals' THEN 'nutrition_f2' WHEN 'vital_foods' THEN 'catalog_ref' WHEN 'vital_nutrition_plan_versions' THEN 'targets_f2' WHEN 'vital_nutrition_checkins' THEN 'daily_totals_f2' END;
 IF f IS NULL THEN RAISE EXCEPTION 'unexpected target'; END IF;
 IF TG_OP='INSERT' THEN IF j->>f IS NOT NULL THEN RAISE EXCEPTION 'F2 activation locked'; END IF; RETURN NEW; END IF;
 oldj:=to_jsonb(OLD);
 IF j->f IS DISTINCT FROM oldj->f THEN RAISE EXCEPTION 'F2 activation locked'; END IF;
 IF oldj->>f IS NOT NULL AND j IS DISTINCT FROM oldj THEN RAISE EXCEPTION 'F2 legacy mutation locked'; END IF;
 RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.vital_f2_review_lock() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vital_f2_review_lock_meals BEFORE INSERT OR UPDATE ON public.vital_meals FOR EACH ROW EXECUTE FUNCTION public.vital_f2_review_lock();
CREATE TRIGGER vital_f2_review_lock_foods BEFORE INSERT OR UPDATE ON public.vital_foods FOR EACH ROW EXECUTE FUNCTION public.vital_f2_review_lock();
CREATE TRIGGER vital_f2_review_lock_plans BEFORE INSERT OR UPDATE ON public.vital_nutrition_plan_versions FOR EACH ROW EXECUTE FUNCTION public.vital_f2_review_lock();
CREATE TRIGGER vital_f2_review_lock_checkins BEFORE INSERT OR UPDATE ON public.vital_nutrition_checkins FOR EACH ROW EXECUTE FUNCTION public.vital_f2_review_lock();
-- Inert recipe data: explicit block even for a privileged caller during preparation.
CREATE FUNCTION public.vital_f2_recipe_review_lock() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN RAISE EXCEPTION 'F2 recipe activation locked' USING ERRCODE='55000'; END $$;
REVOKE ALL ON FUNCTION public.vital_f2_recipe_review_lock() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vital_f2_recipe_review_lock_head BEFORE INSERT OR UPDATE ON public.vital_recipes FOR EACH ROW EXECUTE FUNCTION public.vital_f2_recipe_review_lock();
CREATE TRIGGER vital_f2_recipe_review_lock_version BEFORE INSERT OR UPDATE ON public.vital_recipe_versions FOR EACH ROW EXECUTE FUNCTION public.vital_f2_recipe_review_lock();
-- STOP before enabling: canonical CAS/ACK, strict payload semantics, per-item mapping, license enforcement, audit target allowlist,
-- recipe immutable/version sequence, external identity validation, Realtime, client compatibility, and real PG 17.6 proof all pending.
-- No public grants, no service_role change, no publication membership or schema exposure changes here.
-- Structural assertions in the same disposable transaction. No clinical rows queried.
DO $$ DECLARE t text; n text; BEGIN
 FOREACH t IN ARRAY ARRAY['vital_recipes','vital_recipe_versions'] LOOP
  IF NOT EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace p ON p.oid=c.relnamespace WHERE p.nspname='public' AND c.relname=t AND c.relrowsecurity) THEN RAISE EXCEPTION 'RLS missing: %',t; END IF;
  IF has_table_privilege('anon','public.'||t,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE') OR has_table_privilege('authenticated','public.'||t,'INSERT,UPDATE,DELETE,TRUNCATE') THEN RAISE EXCEPTION 'Unexpected recipe grant: %',t; END IF;
 END LOOP;
 FOREACH n IN ARRAY ARRAY['vault_food_taco','vault_food_usda','vault_food_off'] LOOP
  IF has_schema_privilege('anon',n,'USAGE') OR has_schema_privilege('authenticated',n,'USAGE') THEN RAISE EXCEPTION 'Unexpected public catalog usage: %',n; END IF;
  FOREACH t IN ARRAY ARRAY['releases','food_versions'] LOOP
   IF has_table_privilege('anon',n||'.'||t,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE') OR has_table_privilege('authenticated',n||'.'||t,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE') THEN RAISE EXCEPTION 'Unexpected global grant'; END IF;
  END LOOP;
 END LOOP;
 IF to_regnamespace('vault_food_tbca') IS NOT NULL THEN RAISE EXCEPTION 'TBCA namespace must not exist'; END IF;
 IF NOT EXISTS(SELECT 1 FROM pg_trigger WHERE tgrelid='public.vital_meals'::regclass AND tgname='vital_guard_vital_meals' AND tgenabled<>'D') THEN RAISE EXCEPTION 'F1 guard not preserved'; END IF;
 RAISE NOTICE 'R04_STRUCTURAL_ASSERTIONS_PASS';
END $$;
ROLLBACK;
