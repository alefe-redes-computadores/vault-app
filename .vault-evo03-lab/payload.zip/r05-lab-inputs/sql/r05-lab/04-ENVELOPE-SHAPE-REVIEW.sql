-- Include inside disposable R04 transaction only. Structural validation, NOT full nutritional recomputation or activation.
-- Function has no client grants; intentionally not attached as a writer or exposed RPC.
CREATE FUNCTION public.vital_f2_envelope_review(p_user uuid,p_person uuid,p_legacy jsonb,p_env jsonb)
RETURNS boolean LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE i jsonb; r jsonb; p jsonb; sid text; seen text[]:='{}'; legacy_seen text[]:='{}'; n integer; key text; value jsonb; unit text; provider text;
BEGIN
 IF p_user IS NULL OR p_person IS NULL OR jsonb_typeof(p_legacy) IS DISTINCT FROM 'array' OR jsonb_typeof(p_env) IS DISTINCT FROM 'object' THEN RETURN false; END IF;
 IF jsonb_array_length(p_legacy) NOT BETWEEN 1 AND 200 OR p_env->'schema_version' IS DISTINCT FROM '1'::jsonb OR coalesce(p_env->>'operation_id','') !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' OR jsonb_typeof(p_env->'items') IS DISTINCT FROM 'object' OR jsonb_typeof(p_env->'legacy_item_ids') IS DISTINCT FROM 'array' THEN RETURN false; END IF;
 SELECT count(*) INTO n FROM jsonb_object_keys(p_env->'items');
 IF n=0 OR n+jsonb_array_length(p_env->'legacy_item_ids')<>jsonb_array_length(p_legacy) THEN RETURN false; END IF;
 FOR value IN SELECT x FROM jsonb_array_elements(p_env->'legacy_item_ids') AS t(x) LOOP
  IF jsonb_typeof(value) IS DISTINCT FROM 'string' THEN RETURN false; END IF;
  sid:=value#>>'{}'; IF sid=ANY(legacy_seen) THEN RETURN false; END IF; legacy_seen:=array_append(legacy_seen,sid);
 END LOOP;
 FOR i IN SELECT x FROM jsonb_array_elements(p_legacy) AS t(x) LOOP
  sid:=i->>'id'; IF sid IS NULL OR sid !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' OR sid=ANY(seen) THEN RETURN false; END IF; seen:=array_append(seen,sid);
  r:=p_env->'items'->sid;
  IF sid=ANY(legacy_seen) THEN IF r IS NOT NULL THEN RETURN false; END IF; CONTINUE; END IF;
  IF jsonb_typeof(r) IS DISTINCT FROM 'object' OR r->'schemaVersion' IS DISTINCT FROM '1'::jsonb THEN RETURN false; END IF;
  p:=r->'payload'; IF p->>'itemId' IS DISTINCT FROM sid OR p#>>'{scope,user_id}' IS DISTINCT FROM p_user::text OR p#>>'{scope,person_id}' IS DISTINCT FROM p_person::text THEN RETURN false; END IF;
  IF jsonb_typeof(p->'composition') IS DISTINCT FROM 'object' OR jsonb_typeof(p->'totals') IS DISTINCT FROM 'object' OR r#>>'{conversion,status}' IS DISTINCT FROM 'resolved' OR jsonb_typeof(p#>'{consumed,value}') IS DISTINCT FROM 'number' OR p#>'{consumed,value}' IS DISTINCT FROM i->'quantity' OR p#>>'{consumed,unit}' IS DISTINCT FROM i->>'unit' OR r->'food_id' IS DISTINCT FROM i->'food_id' OR p#>>'{composition,name}' IS NULL OR btrim(p#>>'{composition,name}') IS DISTINCT FROM i->>'name' THEN RETURN false; END IF;
  IF ((p#>>'{consumed,value}')::numeric<=0 OR (p#>>'{consumed,value}')::numeric>1000000) OR coalesce(p#>>'{consumed,unit}','') NOT IN ('g','kg','mL','L','portion','unit') THEN RETURN false; END IF;
  provider:=p#>>'{composition,source,provider}'; IF provider IS NULL OR provider NOT IN ('manual','label','taco','usda','off') OR r#>>'{identity,provider}' IS DISTINCT FROM provider OR r#>>'{identity,recordId}' IS DISTINCT FROM p#>>'{composition,source,recordId}' OR r#>>'{identity,version}' IS DISTINCT FROM p#>>'{composition,source,version}' OR r#>>'{identity,preparation}' IS DISTINCT FROM p#>>'{composition,preparation}' THEN RETURN false; END IF;
  IF coalesce(p#>>'{composition,source,recordId}','')='' OR coalesce(p#>>'{composition,source,version}','')='' OR coalesce(p#>>'{composition,source,license}','')='' OR coalesce(p#>>'{composition,source,attribution}','')='' THEN RETURN false; END IF;
  FOR key,value IN SELECT e.key,e.value FROM jsonb_each(p->'totals') e LOOP
   unit:=CASE WHEN key='energy_kcal' THEN 'kcal' WHEN key IN ('carbohydrate_g','protein_g','fat_g','fiber_g','sugar_g','added_sugar_g','saturated_fat_g','trans_fat_g') THEN 'g' WHEN key IN ('sodium_mg','calcium_mg','iron_mg','potassium_mg','magnesium_mg','vitamin_c_mg','zinc_mg','phosphorus_mg','vitamin_e_mg','vitamin_b6_mg','thiamin_mg','riboflavin_mg','niacin_mg') THEN 'mg' WHEN key IN ('vitamin_b12_ug','vitamin_d_ug','vitamin_k_ug','folate_ug','selenium_ug','vitamin_a_rae_ug') THEN 'ug' ELSE NULL END;
   IF unit IS NULL OR jsonb_typeof(value) IS DISTINCT FROM 'object' OR value->>'state' IS NULL THEN RETURN false; END IF;
   IF value->>'state' IN ('known','estimated') THEN
    IF jsonb_typeof(value->'amount') IS DISTINCT FROM 'number' OR (value->>'amount')::numeric<0 OR value->>'unit' IS DISTINCT FROM unit THEN RETURN false; END IF;
   ELSIF value->>'state'='declared_zero' THEN IF value ? 'amount' OR value->>'unit' IS DISTINCT FROM unit THEN RETURN false; END IF;
   ELSIF value->>'state' IN ('unknown','trace','not_analyzed','not_reported','illegible','not_applicable') THEN IF value ? 'amount' OR value ? 'unit' THEN RETURN false; END IF;
   ELSE RETURN false; END IF;
  END LOOP;
  IF jsonb_typeof(i->'nutrients') IS DISTINCT FROM 'object' THEN RETURN false; END IF;
  FOR key,value IN SELECT e.key,e.value FROM jsonb_each(i->'nutrients') e LOOP
   IF provider NOT IN ('manual','label') OR key NOT IN ('energy_kcal','carbohydrate_g','protein_g','fat_g','fiber_g') OR jsonb_typeof(value) IS DISTINCT FROM 'number' THEN RETURN false; END IF;
   IF (p->'totals'->key->>'state'='declared_zero' AND value='0'::jsonb) OR (p->'totals'->key->>'state'='known' AND p->'totals'->key->'amount'=value) THEN NULL; ELSE RETURN false; END IF;
  END LOOP;
 END LOOP;
 RETURN true;
END $$;
REVOKE ALL ON FUNCTION public.vital_f2_envelope_review(uuid,uuid,jsonb,jsonb) FROM PUBLIC,anon,authenticated;
-- No grant, no trigger activation, no write, no persistence. Review limitations documented.
