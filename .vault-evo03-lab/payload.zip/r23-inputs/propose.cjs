'use strict';
const fs=require('node:fs'),path=require('node:path'),a=require('node:assert/strict'),crypto=require('node:crypto');
const stable=x=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const hash=x=>sha(stable(x));
const key=x=>stable(x.identity);
const read=(file,pin)=>{const b=fs.readFileSync(file);a.equal(sha(b),pin);return b.toString('utf8').trimEnd().split('\n').map(JSON.parse);};
const pinned={r19:'1b083bde36d396e5c3ad35e2b77e79624f8fb26f81d958cdcbae739ff3d8165a',r21:'d4c194befe95e6348569f8680221881a9a1f65ec5580d4e2e0298af3be601ece'};
const isPositive=x=>typeof x==='number'&&Number.isFinite(x)&&x>0;
function propose(old,overlay){
 a.deepEqual(old.identity,overlay.identity);a.equal(old.compositionSha256,hash(old.composition));
 for(const f of ['compositionSha256','sourceRecordSha256','sourceArchiveSha256','name'])a.equal(old[f],overlay[f]);
 a.equal(old.productionApproved,false);a.equal(overlay.productionApproved,false);a.equal(overlay.approval,null);a.equal(old.activation,false);a.equal(overlay.activation,false);
 const {provider,release,id}=old.identity,c=old.composition,s=overlay.sourceSupplement,variants=[],blocks=[];
 a.equal(c.source.provider,provider);a.equal(c.source.version,release);a.equal(c.source.recordId,id);a.deepEqual(c.base,{unit:'g',value:100});
 const v=(kind,changes,evidence)=>{const next=structuredClone(c);next.source.version=`${release}+vault-r22-proposal-${kind}`;for(const [k,value] of Object.entries(changes)){if(k==='values')Object.assign(next.values,value);else next[k]=value;}const record={kind,identity:{provider,release:next.source.version,id},originalRelease:release,composition:next,compositionSha256:hash(next),parentCompositionSha256:old.compositionSha256,sourceRecordSha256:old.sourceRecordSha256,sourceArchiveSha256:old.sourceArchiveSha256,originalManifestSha256:old.manifestSha256,evidence,changes:Object.keys(changes).sort(),status:'PROPOSED_NOT_APPROVED',productionApproved:false,activation:false};record.proposalSha256=hash(record);variants.push(record);};
 let retainOriginal=false;
 if(overlay.status.startsWith('QUARANTINE'))blocks.push('QUARANTINE_CORE');
 else if(provider==='taco'){
  if(overlay.status==='DIVERGENCE_NAME_CORRECTION_PROPOSED'){
   const n=s.proposedNameCorrection;a.equal(id,'540');a.equal(n.from,c.name);a.equal(n.to,'Feijoada');a.equal(n.oldCompositionSha256,old.compositionSha256);v('name',{name:n.to},{nameCorrection:n});
  }else{
   retainOriginal=true;
   const f=s.secondary.proposedFields.saturated_fat_g;
   if(f){const fat=c.values.fat_g; a.equal(s.secondary.status,'EXACT_ID_AND_NAME');a.equal(s.secondary.row.id,id);a.equal(s.secondary.row.mirror,id);a.equal(s.secondary.row.name,c.name);a.equal(f.unit,'g');a.equal(f.basis,'100g_edible');a.ok(isPositive(f.amount));a.equal(f.amount,s.secondary.row.saturated);a.equal(s.secondary.row.saturatedFormula,null);a.equal(c.values.saturated_fat_g,undefined);
    if(fat?.state!=='known'||!Number.isFinite(fat.amount)){blocks.push('SATURATED_WITHOUT_KNOWN_TOTAL_FAT');retainOriginal=false;}
    else if(f.amount>fat.amount){blocks.push('SATURATED_EXCEEDS_TOTAL_FAT');retainOriginal=false;}
    else v('saturated',{values:{saturated_fat_g:{state:'known',amount:f.amount,unit:'g'}}},{secondary:s.secondary.row,proposedField:f});
   }
  }
 }else if(provider==='usda'){
  if(overlay.status==='RESTRICTED_ZERO_MOISTURE_REFERENCE')blocks.push('ZERO_MOISTURE_NOT_AS_CONSUMED');
  else if(overlay.status==='REVIEW_MISSING_FOUNDATION_METADATA')blocks.push('FOUNDATION_METADATA_PENDING');
  else{
   a.equal(overlay.status,'DOCUMENTED_BASIS_REVIEW_REQUIRED');a.equal(overlay.basisEvidence.metadataPresent,true);a.equal(c.edibleBasis,'unknown');a.equal(s.foundationMetadata.fdc_id,id);
   v('basis',{edibleBasis:'edible'},{basis:overlay.basisEvidence,metadata:s.foundationMetadata});
   // Do not overwrite a known legacy energy, and never choose between the methods.
   if(!['known','declared_zero','estimated'].includes(c.values.energy_kcal?.state))for(const m of s.energyMethods){
    if(!['2047','2048'].includes(m.nutrientId)||m.status!=='UNQUALIFIED_POSITIVE_SOURCE_VALUE')continue;
    a.equal(m.rows.length,1);const row=m.rows[0];a.equal(row.fdc_id,id);a.equal(row.nutrient_id,m.nutrientId);a.equal(m.definition.id,m.nutrientId);a.equal(m.definition.unit_name,'KCAL');a.ok(!row.footnote);const amount=Number(row.amount);a.ok(isPositive(amount));
    v(`basis-energy-${m.nutrientId}`,{edibleBasis:'edible',values:{energy_kcal:{state:'known',amount,unit:'kcal'}}},{basis:overlay.basisEvidence,metadata:s.foundationMetadata,energyMethod:m});
   }
  }
 }else throw Error('provider');
 a.ok(!blocks.length||(!variants.length&&!retainOriginal));
 const row={schema:'vault-evo03-r22-proposed-versions-v1',identity:old.identity,originalName:c.name,originalCompositionSha256:old.compositionSha256,sourceRecordSha256:old.sourceRecordSha256,overlaySha256:hash(overlay),documentaryStatus:overlay.status,retainOriginalForReview:retainOriginal,blocks,variants,approval:null,productionApproved:false,activation:false};row.reviewSha256=hash(row);return row;
}
function generate(r19,r21){const olds=new Map(r19.map(x=>[key(x),x])),seen=new Set();a.equal(olds.size,1095);a.equal(r21.length,1095);const rows=r21.map(o=>{const k=key(o);a.ok(!seen.has(k));seen.add(k);a.ok(olds.has(k));return propose(olds.get(k),o);});a.equal(seen.size,olds.size);return rows;}
function summarize(rows){const byKind={},blocks={},foodWithVariants=rows.filter(r=>r.variants.length).length;for(const r of rows){for(const v of r.variants)byKind[v.kind]=(byKind[v.kind]||0)+1;for(const b of r.blocks)blocks[b]=(blocks[b]||0)+1;}return {status:'REVIEW_OPTIONS_ONLY_NOT_RELEASE_AUTHORITY',records:rows.length,foodWithVariants,variants:Object.values(byKind).reduce((a,b)=>a+b,0),byKind,blocks,blockedFoods:rows.filter(r=>r.blocks.length).length,retainOriginalForReview:rows.filter(r=>r.retainOriginalForReview).length,productionApproved:0,activation:false};}
function main(){const [r19,r21,out]=process.argv.slice(2);if(!out)throw Error('Usage: propose.cjs r19 r21 output');const rows=generate(read(r19,pinned.r19),read(r21,pinned.r21));fs.mkdirSync(out,{recursive:true});const text=rows.map(stable).join('\n')+'\n';fs.writeFileSync(path.join(out,'proposed-versions.jsonl'),text);fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify({...summarize(rows),sha256:sha(text)},null,2)+'\n');const esc=x=>String(x??'').replace(/[\t\r\n]/g,' ');const index=[['provider','release','id','name','status','blocks','retain_original','options','review_sha256'],...rows.map(r=>[r.identity.provider,r.identity.release,r.identity.id,r.originalName,r.documentaryStatus,r.blocks.join('|'),r.retainOriginalForReview,r.variants.map(v=>v.kind+':'+v.proposalSha256).join('|'),r.reviewSha256])].map(x=>x.map(esc).join('\t')).join('\n')+'\n';fs.writeFileSync(path.join(out,'review-index.tsv'),index);console.log(summarize(rows));}
module.exports={stable,sha,hash,key,read,pinned,propose,generate,summarize};if(require.main===module)main();
