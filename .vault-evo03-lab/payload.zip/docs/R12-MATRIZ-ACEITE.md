# R12 — Matriz de aceite e bloqueadores reais

Status: **CANDIDATE_REVIEW_BLOCKED_NOT_INSTALLABLE**. GO laboratório, STOP publicação/DDL/DML/ativação. Base observada `bd8c23bf16e76ea7f362f80c50e8bdeb0ae9a14b`, ainda sem Stability final. R11 run 46008130698 aceito; 15/15 históricos com dependências reais. R10 run 46005347154: 84 F2 + 36 HC em componentes reais com adaptador sintético, 412 por fuso. As certificações não são transferidas para caminhos alterados sem teste novo.

| Área | Entrada e implementação verificável | Aceite disponível / pendência |
|---|---|---|
| Resumo, treino, evolução e planos F1 | `/saude/vital`, `/treinos`, `/evolucao`, `/planos`; Chrome e painéis existentes | R06: 69 cenários; schema host aditivo R12 exige novo teste de integração; APK físico final pendente |
| Nutrição F1 | `/saude/vital/nutricao` | fluxo F1 preservado, sem novo escritor |
| N01/N02 GTIN, OCR e rótulos | Nutrição F2, NativeCaptureReview, LabelReviewEditor | R10 aprovado local UI; câmera/OCR físico, fonte OCR no escritor remoto e consentimento final pendentes |
| N03 TACO e USDA | congelados R05, readers, triagem R12; busca oficial ainda não conectada a catálogo aprovado | 1095 linhas verificadas; não aprovar distribuição, nem fundir nomes, nem converter ausência em zero |
| N04/N05 porção, refeições e receitas | NutritionMealJourney, RecipePicker, histórico; schema V60 candidato registra receitas | R10 UI 84, R04 SQL de receitas; R12 canônico + restore preparados. `assertMealStepSupported` bloqueia consumo de receita no writer remoto atual; `remote-recipe` restringe ingredientes. F2 dormante |
| N06/N07 nutrientes e metas | NutritionHistory, VitalPlansPanel, comparação nutricional; 28 nutrientes | contratos aprovados; writer/read remoto de metas F2 explicitamente bloqueado (`canonical.ts`, `supabase-transport.ts`, `backup.ts`) |
| N08 Health Connect | configurações Vital, HealthConnectNutritionReview | R10 36 casos fonte sintética; dispositivo físico e writer remoto de refeição externa pendentes |
| N09 Brain | VitalEvidencePanel no BrainV7UniversalConsole | cobertura sem causalidade, tombstones corrigidos R12; 12 cenários de consumidores preparados |
| N10 Fênix/Avatar/Home/Hoje, Linha Clínica/CareFlow, Dossiê/Relatórios | VitalContextCard e VitalEvidencePanel; facts e projeções canônicas, rota minha-saude profileOnly | R12 novas entradas em erro/vazio; Dossiê A10 preservado; paridade em rotas reais cumulativas, notificações e busca após Stability não certificadas |
| N11 backup/sync | VitalRepository, fila única, recibos, pull, Supabase transport | R04 PG17.6/PostgREST; R12 fence de leitura antes de restore. Novo Chromium usa dois contextos e simulação explícita de leitura remota; sincronização real F2 integral ainda não comprovada |
| N12 acabamento | VitalChrome, painéis, jornadas F2 | telas internas R10 byte-idênticas; dois consumidores alterados sem remover funcionalidade; teste físico acessibilidade, rolagem/filtros e navegação Next integral pendentes |
| N13 entrega | gate global, reancoragem, homologação | 15/15 R11, integração preload candidato R12, execução integral pendente; sem publicação ou migração |

## ZERO DORMANT RELEASE — fail closed
- `certifiedVitalF2Release()` continua `null`. Não há autorização por ambiente ou artifício de UI. V60 apenas schema local candidato, não ativa escritor. A prova de laboratório usa flags explicitamente sintéticas nos repositórios de teste; não representa auth, fila, rede ou release real.
- `remote-meal.ts` `assertMealStepSupported`: receita, Health Connect, evidência de rótulo OCR e fontes oficiais não aceitas pelo writer base. `remote-recipe.ts` restringe fonte manual/rótulo sem evidência. SQL de revisão já comprovado não implica wiring do host. Completar a autoridade/protocolo cumulativo e a recomposição server-side, sem afrouxar guardas. `targets_f2` remoto bloqueado. Catálogo oficial ainda não conectado a jornada aprovada. TACO/USDA não aprovados por curador.
- Não autorizar UI funcional que dependa de fila incapaz de publicar os seus próprios dados. Testar todos os caminhos com capacidade efetiva no candidato isolado, depois rede real descartável, falha de ACK, reexecução e recuperação. Nenhuma publicação dormente deve ser promovida como entrega final.
- ZERO HIDDEN FEATURES permanece **aberto**, não certificado por inventário estático. Entradas globais/rotas, acesso físico, estados vazios e isolamento ainda exigem validação cumulativa com Stability.

## Reconciliação final
1. Confirmar `main` efetiva após publicação Stability e Macro02 final; verificar árvore e migrations reais, ordem, schema Dexie disponível, autoridades doses/estoque, rotas e gate global.
2. Não aplicar automaticamente os deltas sobre main avançada. R12 launcher falha fechado fora do pin. Recibos reancoram somente o alvo diagnóstico conhecido. `lib/db/index.ts` e `lib/types.ts` deltas aditivos com preimagem/pin/reversibilidade; colisão V60 exige conciliação nova. `scripts/vault-m2-test-alias-preload.cjs` preserva loader antigo para os demais testes. Não substituir arquivo inteiro nem remover contrato para agradar gate.
3. Validar todos os paths compartilhados, recibos R10/R11, TypeScript, gate completo e visual. Provar migração local V59→V60 em ambiente descartável e persistência; recertificar se versões mudarem. Reexecutar PG/Android quando o delta efetivo exigir.
4. Guardian revisa lacunas originais de 36 paths/23 contratos e os bloqueadores atuais. Só depois autorização explícita de migration, deploy, APK e capacidade F2; não aplicar Migration 03 Macro02 enquanto LOCKED.
