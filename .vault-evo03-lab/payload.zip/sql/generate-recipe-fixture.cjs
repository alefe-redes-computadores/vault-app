/* Synthetic fixture; no user records, no network. Generate from the exact TS recipe transport. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');const [build,out]=process.argv.slice(2);if(!build||!out)throw Error('paths required');
const {recipeRequest}=require(path.resolve(build,'vital/nutrition-f2/remote-recipe'));const {makeSnapshot}=require(path.resolve(build,'vital/nutrition-f2/nutrition'));
const id=n=>`90000000-0000-4000-8000-${String(n).padStart(12,'0')}`,scope={user_id:id(1),person_id:id(11)},at='2026-11-25T10:00:00.000Z',t2='2026-11-25T10:00:01.000Z',t3='2026-11-25T10:00:02.000Z';
const head={...scope,id:id(901),created_at:at,updated_at:at,deleted_at:null,revision:1,synced:false,kind:'recipe',name:'Receita sintética',favorite:false,active:true};
const c={name:'Ingrediente sintético',source:{provider:'manual',recordId:'fixture',version:'1',license:'private',retrievedAt:at,attribution:'fixture'},base:{value:100,unit:'g'},values:{protein_g:{state:'known',amount:10,unit:'g'},vitamin_c_mg:{state:'not_reported'}},preparation:'raw',edibleBasis:'edible'};
function version(n,v,qty){return {...scope,id:id(n),recipe_id:head.id,version:v,created_at:at,updated_at:at,deleted_at:null,revision:1,synced:false,name_snapshot:head.name,ingredients:[makeSnapshot(scope,id(911),c,{value:qty,unit:'g'})],raw_edible_mass_g:qty,finished_mass_g:150,servings:3,yield_evidence:'Peso declarado',retention_evidence:null,reviewed_at:at}}
const v1=version(902,1,200),va=version(903,2,220),vb=version(904,2,240);
const first=recipeRequest({scope,head,version:v1,audit:null,expectedHead:null,expectedLatest:null,operationId:v1.id});
const append=v=>recipeRequest({scope,head,version:v,audit:null,expectedHead:1,expectedLatest:v1.id,operationId:v.id});
const data=({id,user_id,person_id,created_at,updated_at,deleted_at,revision,synced,...x})=>x;
function change(previous,next,latest,n){const a={...scope,id:id(n),created_at:next.updated_at,updated_at:next.updated_at,deleted_at:null,revision:1,synced:false,target_table:'vital_recipes',target_id:head.id,previous_revision:previous.revision,reason:'Revisão sintética',previous:data(previous)};return recipeRequest({scope,head:next,version:null,audit:a,expectedHead:previous.revision,expectedLatest:latest.id,operationId:a.id})}
const edited={...head,name:'Receita renomeada',favorite:true,revision:2,updated_at:t2},archived={...edited,revision:3,updated_at:t3,deleted_at:t3};
function json(v){if(v===null)return 'NULL';const s=JSON.stringify(v);assert.ok(!s.includes('$recipe$'));return `$recipe$${s}$recipe$::jsonb`}
const uuid=x=>x===null?'NULL':`'${x}'::uuid`;
const call=p=>`public.vault_vital_recipe_f2_review(${uuid(p.p_person)},${uuid(p.p_operation)},${p.p_expected_head??'NULL'},${uuid(p.p_expected_latest)},${json(p.p_head)},${json(p.p_version)},${json(p.p_audit)},${json(p.p_proofs)})`;
const ok=(expr,name)=>`IF (${expr}) IS DISTINCT FROM true THEN RAISE EXCEPTION 'FAIL ${name}';END IF;`;
const expect=(expr,state,name)=>`BEGIN PERFORM ${expr}; RAISE EXCEPTION 'FAIL ${name}';EXCEPTION WHEN SQLSTATE '${state}' THEN NULL;END;`;
const user=(u=id(1))=>`SET LOCAL ROLE authenticated; SELECT set_config('request.jwt.claim.sub','${u}',true);`;
const bad=structuredClone(first);bad.p_proofs[0].snapshot.payload.totals.protein_g.amount=999;
const foreign=structuredClone(first);foreign.p_person=id(12);
const changed=structuredClone(first);changed.p_head.favorite=true;
const initial=`BEGIN; ${user()}\nDO $lab$ BEGIN\n${expect(call(bad),'23514','invalid ingredient proof')}\n${ok(`(${call(first)})->>'status'='applied'`,'initial recipe and version')}\n${ok(`(${call(first)})->>'status'='retry'`,'exact retry')}\n${expect(call(changed),'23505','same op altered request')}\n${expect(call(foreign),'42501','wrong person')}\nBEGIN UPDATE public.vital_recipes SET favorite=true WHERE id='${head.id}'; RAISE EXCEPTION 'FAIL direct update';EXCEPTION WHEN insufficient_privilege THEN NULL;END;\nEND $lab$;\n${user(id(2))}\nDO $lab$ BEGIN ${expect(call(first),'42501','foreign account')} ${ok(`NOT EXISTS(SELECT 1 FROM public.vital_recipes WHERE id='${head.id}')`,'foreign read')} END $lab$;\nCOMMIT;`;
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'recipe-initial.sql'),initial);
for(const [name,v] of [['recipe-race-a',va],['recipe-race-b',vb]])fs.writeFileSync(path.join(out,name+'.sql'),`\\set VERBOSITY verbose\nBEGIN; ${user()} SELECT (${call(append(v))})->>'status'; COMMIT;\n`);
const finish=v=>{const correction=change(head,edited,v,921),archive=change(edited,archived,v,922);return `${ok(`(${call(correction)})->>'status'='applied'`,'metadata correction')} ${ok(`(${call(archive)})->>'status'='applied'`,'archive')} ${ok(`(${call(first)})->>'status'='retry'`,'historical creation retry')} ${ok(`(${call(append(v))})->>'status'='retry'`,'historical append retry')} ${ok(`(${call(correction)})->>'status'='retry'`,'historical metadata retry')} ${ok(`(${call(archive)})->>'status'='retry'`,'exact archive retry')}`};
fs.writeFileSync(path.join(out,'recipe-verify.sql'),`BEGIN; ${user()}\nDO $lab$ BEGIN IF EXISTS(SELECT 1 FROM public.vital_recipe_versions WHERE id='${va.id}') THEN ${finish(va)} ELSE ${finish(vb)} END IF; END $lab$;\nRESET ROLE;\nDO $lab$ BEGIN ${ok(`(SELECT revision FROM public.vital_recipes WHERE id='${head.id}')=3`,'final head revision')} ${ok(`(SELECT deleted_at FROM public.vital_recipes WHERE id='${head.id}') IS NOT NULL`,'archived head')} ${ok(`(SELECT count(*) FROM public.vital_recipe_versions WHERE recipe_id='${head.id}')=2`,'two immutable versions')} ${ok(`(SELECT count(*) FROM public.vital_audit WHERE target_id='${head.id}')=2`,'two audits')} ${ok(`(SELECT count(*) FROM vault_nutrition_f2_review.recipe_receipts WHERE recipe_id='${head.id}')=4`,'four exact receipts')} RAISE NOTICE 'RECIPE_RPC_RACE_HISTORY_PASS';END $lab$; ROLLBACK;`);
console.log('Recipe cases generated: initial, exact retry, altered receipt, malformed proof, scope/ACL, two-session race, historical append/correction/archive; NOT EXECUTED');

fs.writeFileSync(path.join(out,'postgrest-recipe.json'),JSON.stringify(first));

for(const [name,v] of [['recipe-race-a',va],['recipe-race-b',vb]])fs.writeFileSync(path.join(out,'postgrest-'+name+'.json'),JSON.stringify(append(v)));
