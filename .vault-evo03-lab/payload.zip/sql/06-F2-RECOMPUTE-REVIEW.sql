-- LAB REVIEW ONLY. To be concatenated after R05 02-DDL (without ROLLBACK) and 04-ENVELOPE.
-- No COMMIT. No production migration number. Manual/label only; catalog and external HC facts remain gated.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int <> 170006 THEN RAISE EXCEPTION 'STOP: PG17.6 disposable socket-only lab'; END IF;
END $$;
CREATE SCHEMA vault_nutrition_f2_review;
REVOKE ALL ON SCHEMA vault_nutrition_f2_review FROM PUBLIC,anon,authenticated;
CREATE FUNCTION vault_nutrition_f2_review.factor(u text) RETURNS numeric LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$ SELECT CASE u WHEN 'g' THEN 1 WHEN 'mg' THEN .001 WHEN 'ug' THEN .000001 WHEN 'kg' THEN 1000 WHEN 'mL' THEN 1 WHEN 'L' THEN 1000 WHEN 'kcal' THEN 1 WHEN 'kJ' THEN 1::numeric/4.184 WHEN 'portion' THEN 1 WHEN 'unit' THEN 1 END $$;
CREATE FUNCTION vault_nutrition_f2_review.family(u text) RETURNS text LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$ SELECT CASE WHEN u IN ('g','mg','ug','kg') THEN 'mass' WHEN u IN ('mL','L') THEN 'volume' WHEN u IN ('kcal','kJ') THEN 'energy' WHEN u IN ('portion','unit') THEN u END $$;
CREATE FUNCTION vault_nutrition_f2_review.convert(q jsonb,target text) RETURNS numeric LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE n numeric; u text;
BEGIN
 IF jsonb_typeof(q) IS DISTINCT FROM 'object' OR jsonb_typeof(q->'value') IS DISTINCT FROM 'number' OR jsonb_typeof(q->'unit') IS DISTINCT FROM 'string' THEN RETURN NULL; END IF;
 n:=(q->>'value')::numeric;u:=q->>'unit';IF n<0 OR vault_nutrition_f2_review.family(u) IS NULL OR vault_nutrition_f2_review.family(u) IS DISTINCT FROM vault_nutrition_f2_review.family(target) THEN RETURN NULL;END IF;
 RETURN n*vault_nutrition_f2_review.factor(u)/vault_nutrition_f2_review.factor(target);
END $$;
CREATE FUNCTION vault_nutrition_f2_review.near(a jsonb,b numeric) RETURNS boolean LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$ SELECT CASE WHEN jsonb_typeof(a)='number' AND b IS NOT NULL THEN abs((a#>>'{}')::numeric-b)<=abs(b)*0.000000000001 ELSE false END $$;
CREATE FUNCTION vault_nutrition_f2_review.recompute(p_user uuid,p_person uuid,p_legacy jsonb,p_env jsonb) RETURNS boolean LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE item jsonb; snap jsonb; p jsonb; c jsonb; q jsonb; b jsonb; e jsonb; src jsonb; val jsonb; tot jsonb; cov jsonb; st text; k text; u text; bu text; qty numeric; ratio numeric; av numeric; known_n integer; unknown_n integer; na integer; amount numeric; estimate numeric; count_keys integer; counts jsonb; projection jsonb; expected jsonb; v jsonb; sid text; base_qty numeric; method text;
 units constant jsonb:='{"energy_kcal":"kcal","carbohydrate_g":"g","protein_g":"g","fat_g":"g","fiber_g":"g","sugar_g":"g","added_sugar_g":"g","saturated_fat_g":"g","trans_fat_g":"g","sodium_mg":"mg","calcium_mg":"mg","iron_mg":"mg","potassium_mg":"mg","magnesium_mg":"mg","vitamin_c_mg":"mg","vitamin_b12_ug":"ug","vitamin_d_ug":"ug","vitamin_k_ug":"ug","folate_ug":"ug","selenium_ug":"ug","zinc_mg":"mg","phosphorus_mg":"mg","vitamin_a_rae_ug":"ug","vitamin_e_mg":"mg","vitamin_b6_mg":"mg","thiamin_mg":"mg","riboflavin_mg":"mg","niacin_mg":"mg"}';
 states constant jsonb:='{"known":0,"declared_zero":0,"estimated":0,"trace":0,"not_analyzed":0,"not_reported":0,"illegible":0,"not_applicable":0,"unknown":0}';
BEGIN
 IF octet_length(p_env::text)>2000000 OR NOT public.vital_f2_envelope_review(p_user,p_person,p_legacy,p_env) OR (p_env-ARRAY['schema_version','operation_id','items','legacy_item_ids'])<>'{}'::jsonb THEN RETURN false; END IF;
 FOR item IN SELECT x FROM jsonb_array_elements(p_legacy) t(x) LOOP
  sid:=item->>'id';IF p_env->'legacy_item_ids' ? sid THEN CONTINUE; END IF;
  snap:=p_env->'items'->sid;p:=snap->'payload';c:=p->'composition';q:=p->'consumed';b:=c->'base';e:=c->'equivalence';src:=c->'source';
  IF (snap-ARRAY['schemaVersion','reviewedAt','payload','conversion','coverage','identity','food_id'])<>'{}'::jsonb OR (p-ARRAY['scope','itemId','composition','consumed','totals'])<>'{}'::jsonb OR p->'scope' IS DISTINCT FROM jsonb_build_object('user_id',p_user,'person_id',p_person) THEN RETURN false; END IF;
  IF coalesce(src->>'provider','') NOT IN ('manual','label') OR coalesce(c->>'preparation','') NOT IN ('raw','cooked','ready','unknown') OR coalesce(c->>'edibleBasis','') NOT IN ('edible','as_purchased','unknown') OR nullif(btrim(snap#>>'{identity,presentationId}'),'') IS NULL OR length(snap#>>'{identity,presentationId}')>160 OR length(btrim(c->>'name'))>120 OR nullif(btrim(src->>'recordId'),'') IS NULL OR nullif(btrim(src->>'version'),'') IS NULL OR nullif(btrim(src->>'license'),'') IS NULL OR nullif(btrim(src->>'attribution'),'') IS NULL THEN RETURN false; END IF;
  IF coalesce(snap->>'reviewedAt','') !~ '^\d{4}-\d\d-\d\dT.*(Z|[+-]\d\d:\d\d)$' OR coalesce(src->>'retrievedAt','') !~ '^\d{4}-\d\d-\d\dT.*(Z|[+-]\d\d:\d\d)$' THEN RETURN false;END IF;
  PERFORM (snap->>'reviewedAt')::timestamptz,(src->>'retrievedAt')::timestamptz;
  bu:=b->>'unit';IF bu IS NULL OR bu NOT IN ('g','kg','mL','L','portion','unit') OR q->>'unit' NOT IN ('g','kg','mL','L','portion','unit') OR jsonb_typeof(b->'value') IS DISTINCT FROM 'number' THEN RETURN false; END IF;
  base_qty:=(b->>'value')::numeric;IF base_qty<=0 OR base_qty>1000000 THEN RETURN false; END IF;
  qty:=vault_nutrition_f2_review.convert(q,bu);
  IF qty IS NULL THEN
   IF jsonb_typeof(e) IS DISTINCT FROM 'object' OR nullif(btrim(e->>'evidence'),'') IS NULL OR jsonb_typeof(e#>'{from,value}') IS DISTINCT FROM 'number' OR jsonb_typeof(e#>'{to,value}') IS DISTINCT FROM 'number' OR (e#>>'{from,value}')::numeric<=0 OR (e#>>'{to,value}')::numeric<=0 THEN RETURN false; END IF;
   qty:=vault_nutrition_f2_review.convert(q,e#>>'{from,unit}')/(e#>>'{from,value}')::numeric*vault_nutrition_f2_review.convert(e->'to',bu);
   IF qty IS NULL THEN qty:=vault_nutrition_f2_review.convert(q,e#>>'{to,unit}')/(e#>>'{to,value}')::numeric*vault_nutrition_f2_review.convert(e->'from',bu); END IF;
  END IF;
  IF qty IS NULL OR qty<=0 THEN RETURN false; END IF;ratio:=qty/base_qty;
  IF snap#>>'{conversion,status}' IS DISTINCT FROM 'resolved' OR snap#>>'{conversion,basisUnit}' IS DISTINCT FROM bu OR NOT vault_nutrition_f2_review.near(snap#>'{conversion,basisAmount}',qty) OR NOT vault_nutrition_f2_review.near(snap#>'{conversion,ratio}',ratio) OR (snap->'conversion'-ARRAY['status','basisAmount','basisUnit','ratio'])<>'{}'::jsonb THEN RETURN false; END IF;
  IF jsonb_typeof(c->'values') IS DISTINCT FROM 'object' OR jsonb_typeof(p->'totals') IS DISTINCT FROM 'object' OR jsonb_typeof(snap->'coverage') IS DISTINCT FROM 'object' THEN RETURN false; END IF;
  IF EXISTS(SELECT 1 FROM jsonb_object_keys(c->'values') t(x) WHERE NOT units ? x) OR EXISTS(SELECT 1 FROM jsonb_object_keys(p->'totals') t(x) WHERE NOT c->'values' ? x) OR EXISTS(SELECT 1 FROM jsonb_object_keys(snap->'coverage') t(x) WHERE NOT units ? x) THEN RETURN false;END IF;
  projection:='{}'::jsonb;
  FOR k,u IN SELECT key,value FROM jsonb_each_text(units) LOOP
   val:=c->'values'->k;tot:=p->'totals'->k;cov:=snap->'coverage'->k;amount:=NULL;estimate:=NULL;known_n:=0;na:=0;av:=NULL;
   IF val IS NULL THEN IF tot IS NOT NULL THEN RETURN false; END IF;st:='not_reported';
   ELSE
    st:=val->>'state';IF st IS NULL OR NOT states ? st OR jsonb_typeof(val) IS DISTINCT FROM 'object' OR jsonb_typeof(tot) IS DISTINCT FROM 'object' OR tot->>'state' IS DISTINCT FROM st THEN RETURN false; END IF;
    IF st IN ('known','estimated') THEN
     IF jsonb_typeof(val->'amount') IS DISTINCT FROM 'number' THEN RETURN false; END IF;
     av:=vault_nutrition_f2_review.convert(jsonb_build_object('value',val->'amount','unit',val->'unit'),u)*ratio;
     IF av IS NULL OR av<0 OR av>1.7976931348623157e308::numeric OR tot->>'unit' IS DISTINCT FROM u OR NOT vault_nutrition_f2_review.near(tot->'amount',av) THEN RETURN false;END IF;
     IF st='known' THEN IF (tot-ARRAY['state','amount','unit'])<>'{}'::jsonb THEN RETURN false;END IF;known_n:=1;amount:=(tot->>'amount')::numeric;
     ELSE method:=val->>'method';IF nullif(btrim(method),'') IS NULL OR tot->>'method' IS DISTINCT FROM method OR (tot-ARRAY['state','amount','unit','method'])<>'{}'::jsonb THEN RETURN false;END IF;estimate:=(tot->>'amount')::numeric;END IF;
    ELSIF st='declared_zero' THEN
     IF vault_nutrition_f2_review.convert(jsonb_build_object('value',0,'unit',val->'unit'),u) IS NULL OR tot IS DISTINCT FROM jsonb_build_object('state',st,'unit',u) THEN RETURN false; END IF;known_n:=1;amount:=0;
    ELSE
     IF tot IS DISTINCT FROM jsonb_build_object('state',st) THEN RETURN false;END IF;IF st='not_applicable' THEN na:=1;END IF;
    END IF;
   END IF;
   counts:=jsonb_set(states,ARRAY[st],'1');unknown_n:=1-na-known_n;
   expected:=jsonb_build_object('counts',counts,'amount',amount,'estimatedSubtotal',estimate,'known',known_n,'unknown',unknown_n,'notApplicable',na,'total',1,'complete',na=0 AND known_n=1,'scope','recorded_items_only');
   IF cov IS DISTINCT FROM expected THEN RETURN false; END IF;
   IF k IN ('energy_kcal','carbohydrate_g','protein_g','fat_g','fiber_g') AND (st='declared_zero' OR st='known' AND amount<=1000000) THEN projection:=projection||jsonb_build_object(k,amount); END IF;
  END LOOP;
  IF item->'nutrients' IS DISTINCT FROM projection OR item->>'nutrient_source' IS DISTINCT FROM (CASE WHEN projection='{}'::jsonb THEN NULL WHEN src->>'provider'='label' THEN 'label' ELSE 'declared' END) THEN RETURN false;END IF;
 END LOOP;
 RETURN true;
EXCEPTION WHEN data_exception OR invalid_parameter_value THEN RETURN false;
END $$;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA vault_nutrition_f2_review FROM PUBLIC,anon,authenticated;
-- No client grants yet; no change to production. The role-based RPC in 07 is a separate laboratory step.
