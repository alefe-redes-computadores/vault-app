#!/usr/bin/env python3
"""Generate exact-envelope diagnostic, only for the disposable lab. No connection."""
import json,sys,pathlib
root=pathlib.Path(__file__).resolve().parent
fixture=json.loads(pathlib.Path(sys.argv[1]).read_text()); row=fixture['p_row']; assert fixture['p_expected'] is None and fixture['p_audit'] is None
raw=json.dumps(row,ensure_ascii=False,separators=(',',':'));assert '$fixture$' not in raw
preamble=f"""DO $$ DECLARE p_row jsonb:=$fixture${raw}$fixture$::jsonb; incoming public.vital_meals%ROWTYPE; uid uuid:='{row['user_id']}'; p_person uuid:='{row['person_id']}'; p_expected bigint:=NULL; snap jsonb; predicates jsonb; failure_state text; failure_message text; old_result boolean; BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP isolated diagnostic'; END IF;
 incoming:=jsonb_populate_record(NULL::public.vital_meals,p_row);
 SELECT value INTO snap FROM jsonb_each(incoming.nutrition_f2->'items');
 predicates:=jsonb_build_object('id',incoming.id IS NOT NULL,'revision_present',incoming.revision IS NOT NULL,'revision_range',incoming.revision BETWEEN 1 AND 9007199254740991,'revision_json',p_row->'revision' IS NOT DISTINCT FROM to_jsonb(incoming.revision),'revision_next',incoming.revision=coalesce(p_expected,0)+1,'created_at',incoming.created_at IS NOT NULL,'updated_at',incoming.updated_at IS NOT NULL,'chronology',incoming.updated_at>=incoming.created_at,'future_limit',incoming.updated_at<=clock_timestamp()+interval '5 minutes','composition_present',incoming.nutrition_f2 IS NOT NULL,'envelope_shape',public.vital_f2_envelope_review(uid,p_person,incoming.items,incoming.nutrition_f2),'manual_not_external',NOT vault_nutrition_f2_review.has_external(p_row));
 RAISE NOTICE 'R04 predicates=%',predicates;
 IF EXISTS(SELECT 1 FROM jsonb_each(predicates) WHERE value IS DISTINCT FROM 'true'::jsonb) THEN RAISE EXCEPTION 'STOP independent predicate failed'; END IF;
"""
original=preamble+""" old_result:=vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,incoming.nutrition_f2);
 BEGIN PERFORM (snap->'conversion'-ARRAY['status','basisAmount','basisUnit','ratio']); EXCEPTION WHEN OTHERS THEN GET STACKED DIAGNOSTICS failure_state=RETURNED_SQLSTATE,failure_message=MESSAGE_TEXT; END;
 RAISE NOTICE 'R04 original recompute=% expression SQLSTATE=% message=%',old_result,failure_state,failure_message;
 IF old_result IS DISTINCT FROM false OR failure_state IS DISTINCT FROM '22P02' THEN RAISE EXCEPTION 'STOP root cause not reproduced; no correction certification'; END IF;
 IF ((snap->'conversion')-ARRAY['status','basisAmount','basisUnit','ratio']) IS DISTINCT FROM '{}'::jsonb THEN RAISE EXCEPTION 'STOP exact conversion keys'; END IF;
END $$;
"""
fixed=preamble+""" IF vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,incoming.nutrition_f2) IS DISTINCT FROM true THEN RAISE EXCEPTION 'STOP corrected recomputation failed'; END IF;
 snap:=jsonb_set(incoming.nutrition_f2,ARRAY['items',incoming.items->0->>'id','conversion','unexpected'],'true',true);
 IF vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,snap) IS DISTINCT FROM false THEN RAISE EXCEPTION 'STOP extra conversion key accepted'; END IF;
 snap:=jsonb_set(incoming.nutrition_f2,ARRAY['items',incoming.items->0->>'id','conversion','ratio'],'999',false);
 IF vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,snap) IS DISTINCT FROM false THEN RAISE EXCEPTION 'STOP invalid ratio accepted'; END IF;
 RAISE NOTICE 'R04 exact envelope recomputation and negative controls PASS';
END $$;
"""
old=(root/'06-F2-RECOMPUTE-R03-ORIGINAL.sql').read_text(); new=(root/'06-F2-RECOMPUTE-REVIEW-CANDIDATE.sql').read_text();needle="(snap->'conversion'-ARRAY[";assert old.count(needle)==1 and new==old.replace(needle,"((snap->'conversion')-ARRAY[")
start=new.index('CREATE FUNCTION vault_nutrition_f2_review.recompute(');end=new.index('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA',start)
# Same function identity and ACL; never modify the guard or grant. Install only after the independent proof.
print(original+new[start:end].replace('CREATE FUNCTION','CREATE OR REPLACE FUNCTION',1)+fixed)
