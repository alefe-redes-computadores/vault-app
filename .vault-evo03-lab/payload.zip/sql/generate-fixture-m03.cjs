/* Synthetic SQL from exact R05 JS writer. Usage: node generate-fixture.cjs R05/integration/baseline/build OUT_DIR */
const fs=require('node:fs'),path=require('node:path');const [build,out]=process.argv.slice(2);if(!build||!out)throw Error('paths required');
const {prepareMealEnvelope}=require(path.resolve(build,'vital/nutrition-f2/persistence'));const {vitalPayload}=require(path.resolve(build,'vital/cloud-transport'));
const id=n=>`90000000-0000-4000-8000-${String(n).padStart(12,'0')}`;const scope={user_id:id(1),person_id:id(11)},start='2026-11-25T10:00:00.000Z',stamp=n=>`2026-11-25T10:00:0${n-1}.000Z`;
function row(rev,op,qty){let d={scope,mealId:id(601),operationId:id(op),items:[{id:id(611),identity:{provider:'manual',recordId:'fixture',version:'1',preparation:'cooked',presentationId:'g'},composition:{name:'Synthetic',source:{provider:'manual',recordId:'fixture',version:'1',license:'private',retrievedAt:start,attribution:'fixture'},base:{value:100,unit:'g'},values:{protein_g:{state:'known',amount:3,unit:'g'},vitamin_c_mg:{state:'known',amount:2,unit:'mg'}},preparation:'cooked',edibleBasis:'edible'},quantity:{value:qty,unit:'g'},reviewed:true}]};let e=prepareMealEnvelope(scope,d,start,[]);return {...scope,id:id(601),revision:rev,created_at:start,updated_at:stamp(rev),deleted_at:null,synced:false,day:'2026-11-25',time:'09:30',kind:'breakfast',custom_label:null,plan_version_id:null,items:e.items,notes:null,nutrition_f2:e.nutrition_f2};}
const data=({id,user_id,person_id,created_at,updated_at,deleted_at,revision,synced,...d})=>d;
function audit(old,next,n){return {...scope,id:id(n),revision:1,created_at:next.updated_at,updated_at:next.updated_at,deleted_at:null,synced:false,target_table:'vital_meals',target_id:old.id,previous_revision:old.revision,reason:'fixture correction',previous:data(old)}}
const sqlJson=x=>x===null?'NULL':`$fixture$${JSON.stringify(x)}$fixture$::jsonb`;
function call(r,a,op,expected,person=scope.person_id,malicious=false){return `public.vault_vital_meal_f2_review('${person}','${op}',${expected??'NULL'},${sqlJson(malicious?(({synced,...row})=>row)(r):vitalPayload('vital_meals',r,scope))},${sqlJson(a?vitalPayload('vital_audit',a,scope):null)})`}
const one=row(1,621,100),two=row(2,622,120),other=row(2,623,140),a1=audit(one,two,631),a2=audit(one,other,632);
const asUser=(u=id(1))=>`SET LOCAL ROLE authenticated; SELECT set_config('request.jwt.claim.sub','${u}',true);`;
const check=(expr,msg)=>`IF (${expr}) IS DISTINCT FROM true THEN RAISE EXCEPTION 'FAIL ${msg}'; END IF;`;
const expect=(expr,state,msg)=>`BEGIN PERFORM ${expr}; RAISE EXCEPTION 'FAIL ${msg}'; EXCEPTION WHEN SQLSTATE '${state}' THEN NULL; END;`;
const startCall=call(one,null,id(621),null),wrong=structuredClone(two);wrong.nutrition_f2.items[id(611)].payload.totals.vitamin_c_mg.amount=999;
let init=`BEGIN; ${asUser()}\nDO $$ BEGIN ${check(`(${startCall})->>'status'='applied'`,'initial')} ${check(`(${startCall})->>'status'='retry'`,'retry')} ${expect(call(one,null,id(621),null,id(12)),'42501','wrong person')} ${expect(call(wrong,a1,id(631),1,scope.person_id,true),'23514','forged nutrient')} BEGIN UPDATE public.vital_meals SET notes='legacy',revision=2,updated_at='2026-11-25T10:00:01Z' WHERE id='${one.id}'; RAISE EXCEPTION 'FAIL legacy edit'; EXCEPTION WHEN insufficient_privilege THEN NULL; END; END $$;\n${asUser(id(2))}\nDO $$ BEGIN ${expect(startCall,'42501','foreign account')} IF EXISTS(SELECT 1 FROM public.vital_meals WHERE id='${one.id}') THEN RAISE EXCEPTION 'FAIL foreign read'; END IF; END $$;\nCOMMIT;`;
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'initial.sql'),init);
for(const [name,r,a] of [['race-a',two,a1],['race-b',other,a2]])fs.writeFileSync(path.join(out,name+'.sql'),`\\set VERBOSITY verbose\nBEGIN; ${asUser()} SELECT (${call(r,a,a.id,1)})->>'status'; COMMIT;\n`);
fs.writeFileSync(path.join(out,'verify.sql'),`DO $$ BEGIN IF (SELECT revision FROM public.vital_meals WHERE id='${one.id}') IS DISTINCT FROM 2::bigint OR (SELECT count(*) FROM public.vital_audit WHERE target_id='${one.id}')<>1 OR (SELECT count(*) FROM vault_nutrition_f2_review.meal_receipts WHERE meal_id='${one.id}')<>2 THEN RAISE EXCEPTION 'FAIL final concurrent meal/audit/receipt'; END IF; RAISE NOTICE 'F2_RACE_CONSISTENCY_PASS'; END $$;`);
// After the real two-connection race, the winning revision is known from its canonical audit.
// Advance to tombstone, then retry first AND winning historical revision. No new audit/receipt allowed.
const archive=(r)=>({...r,revision:3,updated_at:stamp(3),deleted_at:stamp(3)});
const lastA=archive(two),lastB=archive(other),aa=audit(two,lastA,641),ab=audit(other,lastB,642);
const verifyHistory=(r,a,last,ar)=>`${check(`(${call(last,ar,ar.id,2)})->>'status'='applied'`,'archive')} ${check(`(${startCall})->>'status'='retry'`,'historical first retry')} ${check(`((${startCall})->'meal'->>'revision')::bigint=1`,'historical first row')} ${check(`(${call(r,a,a.id,1)})->>'status'='retry'`,'historical correction retry')} ${check(`((${call(r,a,a.id,1)})->'meal'->>'revision')::bigint=2`,'historical correction row')} ${check(`((${call(r,a,a.id,1)})->'audit'->>'id')='${a.id}'`,'historical canonical audit')} ${check(`(${call(last,ar,ar.id,2)})->>'status'='retry'`,'exact archive retry')}`;
const changed={...one,notes:'different request same operation'};
const hist=`BEGIN; ${asUser()}
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.vital_audit WHERE id='${a1.id}') THEN ${verifyHistory(two,a1,lastA,aa)} ELSE ${verifyHistory(other,a2,lastB,ab)} END IF;
 ${expect(call(changed,null,id(621),null),'23505','forged historical request')}
END $$;
${asUser(id(2))}
DO $$ BEGIN ${expect(startCall,'42501','historical receipt cross account')} END $$;
RESET ROLE;
DO $$ BEGIN IF (SELECT revision FROM public.vital_meals WHERE id='${one.id}') IS DISTINCT FROM 3::bigint OR (SELECT deleted_at FROM public.vital_meals WHERE id='${one.id}') IS NULL OR (SELECT count(*) FROM public.vital_audit WHERE target_id='${one.id}')<>2 OR (SELECT count(*) FROM vault_nutrition_f2_review.meal_receipts WHERE meal_id='${one.id}')<>3 THEN RAISE EXCEPTION 'FAIL historical retry caused extra writes'; END IF; RAISE NOTICE 'F2_HISTORICAL_REPLAY_PASS'; END $$;
ROLLBACK;`;
fs.writeFileSync(path.join(out,'historical-retry.sql'),hist);

// Preserve the exact RPC envelope for independent PostgREST replay.
fs.writeFileSync(path.join(out,'postgrest-meal.json'),JSON.stringify({p_person:scope.person_id,p_operation:id(621),p_expected:null,p_row:vitalPayload('vital_meals',one,scope),p_audit:null}));
