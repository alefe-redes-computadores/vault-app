-- Disposable review only. Do not remove the F2 activation lock or enable any new remote writer.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable lab';END IF;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.plan_targets_valid(p jsonb) RETURNS boolean LANGUAGE plpgsql IMMUTABLE STRICT SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE k text; t jsonb; amount numeric; kind text;
 units constant jsonb:='{"sugar_g":"g","added_sugar_g":"g","saturated_fat_g":"g","trans_fat_g":"g","sodium_mg":"mg","calcium_mg":"mg","iron_mg":"mg","potassium_mg":"mg","magnesium_mg":"mg","vitamin_c_mg":"mg","vitamin_b12_ug":"ug","vitamin_d_ug":"ug","vitamin_k_ug":"ug","folate_ug":"ug","selenium_ug":"ug","zinc_mg":"mg","phosphorus_mg":"mg","vitamin_a_rae_ug":"ug","vitamin_e_mg":"mg","vitamin_b6_mg":"mg","thiamin_mg":"mg","riboflavin_mg":"mg","niacin_mg":"mg"}';
BEGIN
 IF jsonb_typeof(p) IS DISTINCT FROM 'object' THEN RETURN false;END IF;
 FOR k,t IN SELECT key,value FROM jsonb_each(p) LOOP
  IF NOT units ? k OR jsonb_typeof(t) IS DISTINCT FROM 'object' OR NOT (t ?& ARRAY['kind','amount','unit']) OR (t-ARRAY['kind','amount','unit'])<>'{}'::jsonb THEN RETURN false;END IF;
  IF jsonb_typeof(t->'amount') IS DISTINCT FROM 'number' OR t->>'unit' IS DISTINCT FROM units->>k OR jsonb_typeof(t->'kind') IS DISTINCT FROM 'string' THEN RETURN false;END IF;
  kind:=t->>'kind';amount:=(t->>'amount')::numeric;
  IF kind NOT IN ('exact','at_least','at_most') OR amount<0 OR amount>1000000 OR (amount>0 AND amount<0.000000000001) OR (amount=0 AND kind<>'at_most') THEN RETURN false;END IF;
 END LOOP;
 RETURN true;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.plan_targets_valid(jsonb) FROM PUBLIC,anon,authenticated;
-- A check uses an immutable, pure validator, no data access. Grant only the existing authenticated writer role
-- so the F1 null-extension check can be evaluated; no schema usage or write permission is added.
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.plan_targets_valid(jsonb) TO authenticated;
ALTER TABLE public.vital_nutrition_plan_versions ADD CONSTRAINT vital_plan_targets_f2_review_shape CHECK(targets_f2 IS NULL OR vault_nutrition_f2_review.plan_targets_valid(targets_f2));
DO $$ DECLARE v jsonb; BEGIN
 IF vault_nutrition_f2_review.plan_targets_valid('{}') IS DISTINCT FROM true OR vault_nutrition_f2_review.plan_targets_valid('{"iron_mg":{"kind":"at_least","amount":18,"unit":"mg"},"sodium_mg":{"kind":"at_most","amount":0,"unit":"mg"}}') IS DISTINCT FROM true THEN RAISE EXCEPTION 'valid plan targets rejected';END IF;
 FOR v IN SELECT x FROM jsonb_array_elements('[null,[],{"protein_g":{"kind":"exact","amount":1,"unit":"g"}},{"iron_mg":{"kind":"at_least","amount":0,"unit":"mg"}},{"iron_mg":{"kind":"exact","amount":"18","unit":"mg"}},{"iron_mg":{"kind":"exact","amount":18,"unit":"g"}},{"iron_mg":{"kind":"exact","amount":18,"unit":"mg","hidden":1}},{"iron_mg":{"kind":"exact","amount":-1,"unit":"mg"}},{"iron_mg":{"kind":"exact","amount":1000001,"unit":"mg"}}]') t(x) LOOP
  IF vault_nutrition_f2_review.plan_targets_valid(v) IS DISTINCT FROM false THEN RAISE EXCEPTION 'invalid targets accepted: %',v;END IF;
 END LOOP;
 IF NOT EXISTS(SELECT 1 FROM pg_trigger WHERE tgrelid='public.vital_nutrition_plan_versions'::regclass AND tgname='vital_f2_review_lock_plans' AND tgenabled='O') THEN RAISE EXCEPTION 'activation lock removed';END IF;
END $$;
-- No plan activation. Complete root/version transaction, receipts, RLS and authenticated PostgREST remain mandatory.
