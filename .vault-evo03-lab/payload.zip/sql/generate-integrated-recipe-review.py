#!/usr/bin/env python3
"""Materialize disposable recipe writer with reviewed-label recomputation; no execution."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'10-RECIPE-RPC-REVIEW.sql').read_text()
old=" OR i->'composition' ? 'labelEvidence' OR i#>>'{composition,source,license}'='private-user-label' OR NOT vault_nutrition_f2_review.recompute(uid,p_person,jsonb_build_array(proof->'item'),jsonb_build_object('schema_version',1,'operation_id',p_operation,'items',jsonb_build_object(sid,proof->'snapshot'),'legacy_item_ids','[]'::jsonb))"
new=" OR vault_nutrition_f2_review.recompute(uid,p_person,jsonb_build_array(proof->'item'),jsonb_build_object('schema_version',1,'operation_id',p_operation,'items',jsonb_build_object(sid,proof->'snapshot'),'legacy_item_ids','[]'::jsonb)) IS DISTINCT FROM true"
assert s.count(old)==1,'STOP recipe guard drift'
# Same restricted worker, RLS, receipts, immutable version and evidence recomputation. 09 must be applied first.
print(s.replace(old,new))
