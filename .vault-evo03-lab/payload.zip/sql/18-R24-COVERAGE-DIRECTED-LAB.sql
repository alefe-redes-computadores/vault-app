BEGIN;
SET LOCAL ROLE vault_f2_meal_worker_lab;
DO $$ DECLARE e jsonb:='{"amount":62.745999999999995,"estimatedSubtotal":null,"known":1,"unknown":0,"counts":{"known":1},"complete":true}'::jsonb; v jsonb; n int:=0; BEGIN
 IF vault_nutrition_f2_review.coverage_matches_r24(jsonb_set(e,'{amount}','62.746'),e) IS DISTINCT FROM true THEN RAISE EXCEPTION 'R24 exact regression'; END IF;n:=n+1;
 IF vault_nutrition_f2_review.coverage_matches_r24(e,e) IS DISTINCT FROM true THEN RAISE EXCEPTION 'R24 exact positive'; END IF;n:=n+1;
 FOR v IN SELECT x FROM jsonb_array_elements(jsonb_build_array(NULL::jsonb,'null'::jsonb,'[]'::jsonb,e-'amount',e-'estimatedSubtotal',e||'{"extra":1}',jsonb_set(e,'{amount}','63'),jsonb_set(e,'{amount}','0'),jsonb_set(e,'{amount}','-62.746'),jsonb_set(e,'{amount}','"62.746"'),jsonb_set(e,'{amount}','null'),jsonb_set(e,'{amount}','true'),jsonb_set(e,'{estimatedSubtotal}','0'),jsonb_set(e,'{known}','0'),jsonb_set(e,'{complete}','false'),jsonb_set(e,'{counts,known}','0'))) t(x) LOOP
  IF vault_nutrition_f2_review.coverage_matches_r24(v,e) IS DISTINCT FROM false THEN RAISE EXCEPTION 'R24 helper accepted invalid %',v; END IF;n:=n+1;
 END LOOP;
 e:='{"amount":null,"estimatedSubtotal":62.745999999999995,"known":0}'::jsonb;
 IF vault_nutrition_f2_review.coverage_matches_r24(jsonb_set(e,'{estimatedSubtotal}','62.746'),e) IS DISTINCT FROM true OR vault_nutrition_f2_review.coverage_matches_r24(jsonb_set(e,'{estimatedSubtotal}','63'),e) IS DISTINCT FROM false THEN RAISE EXCEPTION 'R24 estimate';END IF;n:=n+2;
 e:='{"amount":0,"estimatedSubtotal":null,"known":1}'::jsonb;
 IF vault_nutrition_f2_review.coverage_matches_r24(e,e) IS DISTINCT FROM true OR vault_nutrition_f2_review.coverage_matches_r24(jsonb_set(e,'{amount}','0.00000000000000001'),e) IS DISTINCT FROM false THEN RAISE EXCEPTION 'R24 zero';END IF;n:=n+2;
 IF n<>22 THEN RAISE EXCEPTION 'R24 helper count %',n; END IF;RAISE NOTICE 'R24_COVERAGE_DIRECTED_PASS %',n;
END $$;
RESET ROLE;
ROLLBACK;
