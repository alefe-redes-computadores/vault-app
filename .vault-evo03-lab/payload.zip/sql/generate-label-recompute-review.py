#!/usr/bin/env python3
"""Materialize a LAB-only variant. No SQL execution, no network. Exact guarded replacement."""
import pathlib,sys
p=pathlib.Path(__file__).resolve().parent
s=(p/'06-F2-RECOMPUTE-REVIEW-CANDIDATE.sql').read_text()
start=s.index('CREATE FUNCTION vault_nutrition_f2_review.recompute(')
end=s.index('REVOKE ALL ON ALL FUNCTIONS IN SCHEMA',start)
s=s[start:end].replace('CREATE FUNCTION','CREATE OR REPLACE FUNCTION',1)
old="  IF c ? 'labelEvidence' OR c ? 'recipeVersion' OR src->>'license'='private-user-label' THEN RETURN false; END IF;\n  IF (c-ARRAY['name','source','base','values','preparation','edibleBasis','equivalence'])<>'{}'::jsonb OR (src-ARRAY['provider','recordId','version','license','retrievedAt','attribution'])<>'{}'::jsonb THEN RETURN false; END IF;"
new="""  IF c ? 'recipeVersion' OR c ? 'externalMeal' THEN RETURN false;END IF;
  IF c ? 'labelEvidence' THEN
   IF NOT vault_nutrition_f2_review.label_review(c) THEN RETURN false;END IF;
  ELSIF src->>'license'='private-user-label' THEN RETURN false;END IF;
  IF (c-ARRAY['name','source','base','values','preparation','edibleBasis','equivalence','labelEvidence'])<>'{}'::jsonb OR (src-ARRAY['provider','recordId','version','license','retrievedAt','attribution'])<>'{}'::jsonb THEN RETURN false; END IF;"""
assert s.count(old)==1;s=s.replace(old,new)
# Do not revoke/regrant existing function, CREATE OR REPLACE retains ownership/ACL. The runner is migrator-only.
print((p/'09-REVIEWED-LABEL-RECOMPUTE-LAB.sql').read_text());print(s)
