-- Disposable PG17.6 review. Load after 06, before 07 variant. No deployment.
DO $$ BEGIN IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF; END $$;
-- Matches externalCanonicalId JS: compact JSON string array, first 16 SHA256 bytes, UUID v8 + RFC variant.
CREATE FUNCTION vault_nutrition_f2_review.external_id(u uuid,p uuid,o text,r text,part text) RETURNS uuid LANGUAGE plpgsql IMMUTABLE STRICT SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE b bytea; h text; j text;
BEGIN
 IF part NOT IN ('meal','item') THEN RAISE EXCEPTION 'invalid identity part'; END IF;
 j:='['||to_jsonb('vault-vital-nutrition-v1'::text)::text||','||to_jsonb(u::text)::text||','||to_jsonb(p::text)::text||','||to_jsonb(o)::text||','||to_jsonb(r)::text||','||to_jsonb(part)::text||']';
 b:=substring(sha256(convert_to(j,'UTF8')) FROM 1 FOR 16);b:=set_byte(b,6,(get_byte(b,6)&15)|128);b:=set_byte(b,8,(get_byte(b,8)&63)|128);h:=encode(b,'hex');RETURN h::uuid;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.has_external(rowj jsonb) RETURNS boolean LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
 SELECT EXISTS(SELECT 1 FROM jsonb_each(CASE WHEN jsonb_typeof(rowj#>'{nutrition_f2,items}')='object' THEN rowj#>'{nutrition_f2,items}' ELSE '{}'::jsonb END) t(k,v) WHERE v#>>'{payload,composition,source,provider}'='health_connect' OR (v#>'{payload,composition}') ? 'externalMeal')
$$;
CREATE FUNCTION vault_nutrition_f2_review.external_record(rowj jsonb) RETURNS jsonb LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
 SELECT rowj->'nutrition_f2'->'items'->(rowj#>>'{items,0,id}')#>'{payload,composition,externalMeal,record}'
$$;
CREATE FUNCTION vault_nutrition_f2_review.valid_external(u uuid,p uuid,rowj jsonb) RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE env jsonb; snap jsonb; payload jsonb; c jsonb; e jsonb; r jsonb; profile jsonb; i jsonb; v jsonb; k text; unit text; sid text; state text; amount numeric; known_n int; cov jsonb:='{}'::jsonb; offsetn numeric; shifted timestamp; ts text; kind text; source jsonb; expected jsonb;
 units constant jsonb:='{"energy_kcal":"kcal","carbohydrate_g":"g","protein_g":"g","fat_g":"g","fiber_g":"g","sugar_g":"g","added_sugar_g":"g","saturated_fat_g":"g","trans_fat_g":"g","sodium_mg":"mg","calcium_mg":"mg","iron_mg":"mg","potassium_mg":"mg","magnesium_mg":"mg","vitamin_c_mg":"mg","vitamin_b12_ug":"ug","vitamin_d_ug":"ug","vitamin_k_ug":"ug","folate_ug":"ug","selenium_ug":"ug","zinc_mg":"mg","phosphorus_mg":"mg","vitamin_a_rae_ug":"ug","vitamin_e_mg":"mg","vitamin_b6_mg":"mg","thiamin_mg":"mg","riboflavin_mg":"mg","niacin_mg":"mg"}';
 states constant jsonb:='{"known":0,"declared_zero":0,"estimated":0,"trace":0,"not_analyzed":0,"not_reported":0,"illegible":0,"not_applicable":0,"unknown":0}';
BEGIN
 IF u IS NULL OR p IS NULL OR rowj->>'user_id' IS DISTINCT FROM u::text OR rowj->>'person_id' IS DISTINCT FROM p::text OR jsonb_typeof(rowj->'items') IS DISTINCT FROM 'array' OR jsonb_array_length(rowj->'items')<>1 THEN RETURN false;END IF;
 env:=rowj->'nutrition_f2';i:=rowj->'items'->0;sid:=i->>'id';snap:=env->'items'->sid;payload:=snap->'payload';c:=payload->'composition';e:=c->'externalMeal';r:=e->'record';profile:=r->'nutrients';
 IF jsonb_typeof(e) IS DISTINCT FROM 'object' OR NOT e ?& ARRAY['schema','granularity','record','connectionRevision','reviewedAt','offsetMinutes','civilDay','civilTime','overlapConfirmed'] OR (e-ARRAY['schema','granularity','record','connectionRevision','reviewedAt','offsetMinutes','civilDay','civilTime','overlapConfirmed'])<>'{}'::jsonb OR e->'schema' IS DISTINCT FROM '1'::jsonb OR e->>'granularity' IS DISTINCT FROM 'meal_total' OR jsonb_typeof(e->'connectionRevision') IS DISTINCT FROM 'string' OR nullif(btrim(e->>'connectionRevision'),'') IS NULL OR length(e->>'connectionRevision')>256 OR jsonb_typeof(e->'overlapConfirmed') IS DISTINCT FROM 'boolean' OR jsonb_typeof(e->'offsetMinutes') IS DISTINCT FROM 'number' THEN RETURN false;END IF;
 offsetn:=(e->>'offsetMinutes')::numeric;IF offsetn NOT BETWEEN -840 AND 840 OR trunc(offsetn)<>offsetn THEN RETURN false;END IF;
 IF jsonb_typeof(r) IS DISTINCT FROM 'object' OR NOT r ?& ARRAY['scope','type','origin','recordId','start','end','lastModified','mealName','nutrients','mealType'] OR (r-ARRAY['scope','type','origin','recordId','start','end','lastModified','mealName','nutrients','mealType'])<>'{}'::jsonb OR r->'scope' IS DISTINCT FROM jsonb_build_object('user_id',u,'person_id',p) OR r->>'type' IS DISTINCT FROM 'nutrition' OR r->>'origin' IS DISTINCT FROM 'com.sec.android.app.shealth' OR jsonb_typeof(r->'recordId') IS DISTINCT FROM 'string' OR nullif(btrim(r->>'recordId'),'') IS NULL OR btrim(r->>'recordId')<>r->>'recordId' OR length(r->>'recordId')>256 OR coalesce(r->>'mealType','') NOT IN ('breakfast','lunch','dinner','snack','unknown') OR NOT (r->'mealName'='null'::jsonb OR jsonb_typeof(r->'mealName')='string' AND btrim(r->>'mealName')=r->>'mealName' AND length(r->>'mealName')<=200) THEN RETURN false;END IF;
 FOREACH ts IN ARRAY ARRAY[r->>'start',r->>'end',r->>'lastModified',e->>'reviewedAt'] LOOP
  IF coalesce(ts,'') !~ '^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$' OR to_char(ts::timestamptz AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') IS DISTINCT FROM ts THEN RETURN false;END IF;
 END LOOP;
 IF r->>'start'>=r->>'end' OR r->>'end'>e->>'reviewedAt' OR r->>'lastModified'>e->>'reviewedAt' OR (e->>'reviewedAt')::timestamptz>(rowj->>'updated_at')::timestamptz THEN RETURN false;END IF;
 shifted:=((r->>'start')::timestamptz AT TIME ZONE 'UTC')+make_interval(mins=>offsetn::int);
 IF e->>'civilDay' IS DISTINCT FROM to_char(shifted,'YYYY-MM-DD') OR e->>'civilTime' IS DISTINCT FROM to_char(shifted,'HH24:MI') THEN RETURN false;END IF;
 IF rowj->>'id' IS DISTINCT FROM vault_nutrition_f2_review.external_id(u,p,r->>'origin',r->>'recordId','meal')::text OR sid IS DISTINCT FROM vault_nutrition_f2_review.external_id(u,p,r->>'origin',r->>'recordId','item')::text OR coalesce(env->>'operation_id','') !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' OR env->>'operation_id' IN (sid,rowj->>'id') THEN RETURN false;END IF;
 IF jsonb_typeof(profile) IS DISTINCT FROM 'object' OR profile='{}'::jsonb OR EXISTS(SELECT 1 FROM jsonb_object_keys(profile) t(x) WHERE NOT units ? x) THEN RETURN false;END IF;
 FOR k,unit IN SELECT key,value FROM jsonb_each_text(units) LOOP
  v:=profile->k;amount:=NULL;known_n:=0;state:=coalesce(v->>'state','not_reported');
  IF v IS NOT NULL THEN
   IF state='known' THEN IF jsonb_typeof(v->'amount') IS DISTINCT FROM 'number' OR v->>'unit' IS DISTINCT FROM unit THEN RETURN false;END IF;amount:=(v->>'amount')::numeric;IF amount<=0 OR amount>1000000 OR v IS DISTINCT FROM jsonb_build_object('state','known','amount',amount,'unit',unit) THEN RETURN false;END IF;known_n:=1;
   ELSIF state NOT IN ('unknown','not_reported') OR v IS DISTINCT FROM jsonb_build_object('state',state) THEN RETURN false;END IF;
  END IF;
  cov:=cov||jsonb_build_object(k,jsonb_build_object('counts',jsonb_set(states,ARRAY[state],'1'),'amount',amount,'estimatedSubtotal',NULL,'known',known_n,'unknown',1-known_n,'notApplicable',0,'total',1,'complete',known_n=1,'scope','recorded_items_only'));
 END LOOP;
 source:=jsonb_build_object('provider','health_connect','recordId',r->>'recordId','version',r->>'lastModified','license','private-health-connect','retrievedAt',e->>'reviewedAt','attribution','Health Connect · origem Samsung Health · total da refeição');
 expected:=jsonb_build_object('name','Total importado da refeição','source',source,'base',jsonb_build_object('value',1,'unit','portion'),'values',profile,'preparation','unknown','edibleBasis','unknown','externalMeal',e);
 IF c IS DISTINCT FROM expected OR payload IS DISTINCT FROM jsonb_build_object('scope',jsonb_build_object('user_id',u,'person_id',p),'itemId',sid,'composition',expected,'consumed',jsonb_build_object('value',1,'unit','portion'),'totals',profile) OR snap IS DISTINCT FROM jsonb_build_object('schemaVersion',1,'reviewedAt',e->>'reviewedAt','payload',payload,'conversion',jsonb_build_object('status','resolved','basisAmount',1,'basisUnit','portion','ratio',1),'coverage',cov,'identity',jsonb_build_object('provider','health_connect','recordId',r->>'recordId','version',r->>'lastModified','preparation','unknown','presentationId','meal-total'),'food_id',NULL) OR env IS DISTINCT FROM jsonb_build_object('schema_version',1,'operation_id',env->>'operation_id','items',jsonb_build_object(sid,snap),'legacy_item_ids','[]'::jsonb) THEN RETURN false;END IF;
 IF i IS DISTINCT FROM jsonb_build_object('id',sid,'food_id',NULL,'name','Total importado da refeição','quantity',NULL,'unit',NULL,'nutrients','{}'::jsonb,'nutrient_source',NULL) THEN RETURN false;END IF;
 kind:=r->>'mealType';RETURN rowj->>'day'=e->>'civilDay' AND rowj->>'time'=e->>'civilTime' AND rowj->>'kind'=CASE WHEN kind='unknown' THEN 'custom' ELSE kind END AND rowj->'custom_label' IS NOT DISTINCT FROM CASE WHEN kind='unknown' THEN to_jsonb('Refeição importada'::text) ELSE 'null'::jsonb END AND rowj->'plan_version_id'='null'::jsonb AND rowj->'notes'='null'::jsonb;
EXCEPTION WHEN data_exception OR invalid_parameter_value THEN RETURN false;
END $$;
-- Only permit a genuinely newer revision of the same external source. Archive preserves exact old fact in original writer.
CREATE FUNCTION vault_nutrition_f2_review.external_transition(oldj jsonb,newj jsonb) RETURNS boolean LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE a jsonb; b jsonb;
BEGIN
 IF NOT vault_nutrition_f2_review.has_external(oldj) AND NOT vault_nutrition_f2_review.has_external(newj) THEN RETURN true;END IF;
 IF NOT vault_nutrition_f2_review.has_external(oldj) OR NOT vault_nutrition_f2_review.has_external(newj) THEN RETURN false;END IF;
 a:=vault_nutrition_f2_review.external_record(oldj);b:=vault_nutrition_f2_review.external_record(newj);
 RETURN a->>'origin'=b->>'origin' AND a->>'recordId'=b->>'recordId' AND oldj#>>'{items,0,id}'=newj#>>'{items,0,id}' AND (newj->>'deleted_at' IS NOT NULL AND a=b OR newj->>'deleted_at' IS NULL AND b->>'lastModified'>a->>'lastModified');
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.external_id(uuid,uuid,text,text,text),vault_nutrition_f2_review.has_external(jsonb),vault_nutrition_f2_review.external_record(jsonb),vault_nutrition_f2_review.valid_external(uuid,uuid,jsonb),vault_nutrition_f2_review.external_transition(jsonb,jsonb) FROM PUBLIC,anon,authenticated;
