-- PROPOSTA DE LABORATORIO. NAO E MIGRATION. Executar apos 06/07/08 apenas em PG17.6 descartavel.
-- Independent validation of user-reviewed nutrition label evidence. No image storage, no source activation.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int <> 170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.exact_keys(j jsonb,k text[]) RETURNS boolean LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$ SELECT coalesce(jsonb_typeof(j)='object' AND j ?& k AND (j-k)='{}'::jsonb,false) $$;
CREATE FUNCTION vault_nutrition_f2_review.label_decimal(s text) RETURNS numeric LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$ SELECT CASE WHEN length(s)<=80 AND btrim(s)~'^[0-9]+([,.][0-9]+)?$' THEN replace(btrim(s),',','.')::numeric END $$;
CREATE FUNCTION vault_nutrition_f2_review.gtin14(s text) RETURNS boolean LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE total int:=0; i int;
BEGIN
 IF s IS NULL OR s !~ '^[0-9]{14}$' OR s~'^0+$' THEN RETURN false;END IF;
 FOR i IN 1..13 LOOP total:=total+substr(s,i,1)::int*(CASE WHEN i%2=1 THEN 3 ELSE 1 END);END LOOP;
 RETURN (10-total%10)%10=right(s,1)::int;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.label_review(c jsonb) RETURNS boolean LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE e jsonb:=c->'labelEvidence';f jsonb;o jsonb;cap jsonb;src jsonb:=c->'source';b jsonb;v jsonb;box jsonb; k text; u text; state text; n numeric; converted numeric; seen text[]:='{}'; nfields int; at text;
 units constant jsonb:='{"energy_kcal":"kcal","carbohydrate_g":"g","protein_g":"g","fat_g":"g","fiber_g":"g","sugar_g":"g","added_sugar_g":"g","saturated_fat_g":"g","trans_fat_g":"g","sodium_mg":"mg","calcium_mg":"mg","iron_mg":"mg","potassium_mg":"mg","magnesium_mg":"mg","vitamin_c_mg":"mg","vitamin_b12_ug":"ug","vitamin_d_ug":"ug","vitamin_k_ug":"ug","folate_ug":"ug","selenium_ug":"ug","zinc_mg":"mg","phosphorus_mg":"mg","vitamin_a_rae_ug":"ug","vitamin_e_mg":"mg","vitamin_b6_mg":"mg","thiamin_mg":"mg","riboflavin_mg":"mg","niacin_mg":"mg"}';
BEGIN
 IF NOT vault_nutrition_f2_review.exact_keys(c,ARRAY['name','source','base','values','preparation','edibleBasis','labelEvidence']) OR NOT vault_nutrition_f2_review.exact_keys(e,ARRAY['schema','recordId','versionId','reviewedAt','name','barcode','basis','base','fields','capture']) OR e->'schema' IS DISTINCT FROM '1'::jsonb THEN RETURN false;END IF;
 IF NOT vault_nutrition_f2_review.exact_keys(src,ARRAY['provider','recordId','version','license','retrievedAt','attribution']) OR src->>'provider' IS DISTINCT FROM 'label' OR src->>'license' IS DISTINCT FROM 'private-user-label' OR src->>'attribution' IS DISTINCT FROM 'Rótulo revisado pelo usuário' OR c->>'preparation' IS DISTINCT FROM 'ready' OR c->>'edibleBasis' IS DISTINCT FROM 'unknown' THEN RETURN false;END IF;
 IF coalesce(e->>'recordId','') !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' OR coalesce(e->>'versionId','') !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' OR e->>'recordId'=e->>'versionId' OR src->'recordId' IS DISTINCT FROM e->'recordId' OR src->'version' IS DISTINCT FROM e->'versionId' THEN RETURN false;END IF;
 at:=e->>'reviewedAt';IF jsonb_typeof(e->'reviewedAt') IS DISTINCT FROM 'string' OR at!~'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$' OR to_char(at::timestamptz AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"') IS DISTINCT FROM at OR src->'retrievedAt' IS DISTINCT FROM e->'reviewedAt' THEN RETURN false;END IF;
 IF jsonb_typeof(e->'name') IS DISTINCT FROM 'string' OR nullif(btrim(e->>'name'),'') IS NULL OR e->>'name' IS DISTINCT FROM btrim(e->>'name') OR length(e->>'name')>120 OR c->'name' IS DISTINCT FROM e->'name' THEN RETURN false;END IF;
 IF e->'barcode'<>'null'::jsonb AND (jsonb_typeof(e->'barcode') IS DISTINCT FROM 'string' OR NOT vault_nutrition_f2_review.gtin14(e->>'barcode')) THEN RETURN false;END IF;
 b:=e->'base';IF NOT vault_nutrition_f2_review.exact_keys(b,ARRAY['value','unit']) OR jsonb_typeof(b->'value') IS DISTINCT FROM 'number' OR coalesce(b->>'unit','') NOT IN ('g','mL') OR ((b->>'value')::numeric<=0 OR (b->>'value')::numeric>1000000) OR c->'base' IS DISTINCT FROM b OR coalesce(e->>'basis','') NOT IN ('per100','portion') OR e->>'basis'='per100' AND b->'value' IS DISTINCT FROM '100'::jsonb THEN RETURN false;END IF;
 cap:=e->'capture';IF cap<>'null'::jsonb THEN
  IF NOT vault_nutrition_f2_review.exact_keys(cap,ARRAY['recognizer','version','originalText','imageWidth','imageHeight','retention']) OR cap->>'recognizer' IS DISTINCT FROM 'mlkit-latin-bundled' OR cap->>'version' IS DISTINCT FROM '16.0.1' OR cap->>'retention' IS DISTINCT FROM 'reviewed-text-only' OR jsonb_typeof(cap->'originalText') IS DISTINCT FROM 'string' OR nullif(btrim(cap->>'originalText'),'') IS NULL OR length(cap->>'originalText')>20000 OR jsonb_typeof(cap->'imageWidth') IS DISTINCT FROM 'number' OR jsonb_typeof(cap->'imageHeight') IS DISTINCT FROM 'number' OR (cap->>'imageWidth')::numeric NOT BETWEEN 1 AND 2560 OR (cap->>'imageHeight')::numeric NOT BETWEEN 1 AND 2560 OR trunc((cap->>'imageWidth')::numeric)<>(cap->>'imageWidth')::numeric OR trunc((cap->>'imageHeight')::numeric)<>(cap->>'imageHeight')::numeric THEN RETURN false;END IF;
 END IF;
 IF jsonb_typeof(e->'fields') IS DISTINCT FROM 'array' OR jsonb_typeof(c->'values') IS DISTINCT FROM 'object' THEN RETURN false;END IF;nfields:=jsonb_array_length(e->'fields');IF nfields NOT BETWEEN 1 AND 28 OR (SELECT count(*) FROM jsonb_object_keys(c->'values'))<>nfields THEN RETURN false;END IF;
 FOR f IN SELECT x FROM jsonb_array_elements(e->'fields') t(x) LOOP
  IF NOT vault_nutrition_f2_review.exact_keys(f,ARRAY['nutrient','raw','unit','state','confirmed','observed']) OR f->'confirmed' IS DISTINCT FROM 'true'::jsonb OR jsonb_typeof(f->'raw') IS DISTINCT FROM 'string' OR length(f->>'raw')>80 THEN RETURN false;END IF;
  k:=f->>'nutrient';u:=units->>k;state:=f->>'state';v:=c->'values'->k;IF u IS NULL OR k=ANY(seen) OR coalesce(f->>'unit','') NOT IN ('g','mg','ug','kcal','kJ') OR vault_nutrition_f2_review.convert(jsonb_build_object('value',0,'unit',f->'unit'),u) IS NULL THEN RETURN false;END IF;seen:=array_append(seen,k);
  o:=f->'observed';IF o<>'null'::jsonb THEN
   IF cap='null'::jsonb OR NOT vault_nutrition_f2_review.exact_keys(o,ARRAY['raw','unit','column','printedBase','box','confidence']) OR o->'column' IS DISTINCT FROM e->'basis' OR (o->'printedBase'='null'::jsonb AND e->>'basis'<>'portion') OR (o->'printedBase'<>'null'::jsonb AND o->'printedBase' IS DISTINCT FROM b->'value') OR jsonb_typeof(o->'raw') IS DISTINCT FROM 'string' OR vault_nutrition_f2_review.label_decimal(o->>'raw') IS NULL OR coalesce(o->>'unit','') NOT IN ('g','mg','ug','kcal','kJ') OR vault_nutrition_f2_review.convert(jsonb_build_object('value',0,'unit',o->'unit'),u) IS NULL THEN RETURN false;END IF;
   box:=o->'box';IF jsonb_typeof(box) IS DISTINCT FROM 'array' THEN RETURN false;END IF;IF jsonb_array_length(box)<>4 OR EXISTS(SELECT 1 FROM jsonb_array_elements(box) t(x) WHERE jsonb_typeof(x)<>'number') THEN RETURN false;END IF;
   IF (box->>0)::numeric<0 OR (box->>1)::numeric<0 OR (box->>2)::numeric>(cap->>'imageWidth')::numeric OR (box->>3)::numeric>(cap->>'imageHeight')::numeric OR (box->>2)::numeric<=(box->>0)::numeric OR (box->>3)::numeric<=(box->>1)::numeric OR (o->'confidence'<>'null'::jsonb AND (jsonb_typeof(o->'confidence') IS DISTINCT FROM 'number' OR (o->>'confidence')::numeric NOT BETWEEN 0 AND 1)) THEN RETURN false;END IF;
  END IF;
  IF state='value' THEN n:=vault_nutrition_f2_review.label_decimal(f->>'raw');IF n IS NULL OR n>1000000 THEN RETURN false;END IF;converted:=vault_nutrition_f2_review.convert(jsonb_build_object('value',n,'unit',f->'unit'),u);
   IF n=0 THEN IF v IS DISTINCT FROM jsonb_build_object('state','declared_zero','unit',u) THEN RETURN false;END IF;
   ELSE IF NOT vault_nutrition_f2_review.exact_keys(v,ARRAY['state','amount','unit']) OR v->>'state' IS DISTINCT FROM 'known' OR v->>'unit' IS DISTINCT FROM u OR NOT vault_nutrition_f2_review.near(v->'amount',converted) THEN RETURN false;END IF;END IF;
  ELSIF state IN ('unreadable','not_reported') THEN IF btrim(f->>'raw')<>'' OR v IS DISTINCT FROM jsonb_build_object('state',CASE WHEN state='unreadable' THEN 'illegible' ELSE 'not_reported' END) THEN RETURN false;END IF;
  ELSE RETURN false;END IF;
 END LOOP;
 RETURN true;
EXCEPTION WHEN data_exception OR invalid_parameter_value THEN RETURN false;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.exact_keys(jsonb,text[]),vault_nutrition_f2_review.label_decimal(text),vault_nutrition_f2_review.gtin14(text),vault_nutrition_f2_review.label_review(jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.exact_keys(jsonb,text[]),vault_nutrition_f2_review.label_decimal(text),vault_nutrition_f2_review.gtin14(text),vault_nutrition_f2_review.label_review(jsonb) TO vault_f2_meal_worker_lab;
-- The generator adds the strictly scoped recompute replacement AFTER this helper. Keep the v1 runner intact.
-- NO COMMIT and no capability activation. PG execution and Guardian review are mandatory.
