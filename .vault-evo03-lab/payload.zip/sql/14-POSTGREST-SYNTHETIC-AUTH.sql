-- Isolated PostgreSQL 17.6 laboratory ONLY. No production SQL or migration.
BEGIN;
DO $$ BEGIN
 IF current_database() <> 'vault_macro03_lab_f2' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int <> 170006 THEN RAISE EXCEPTION 'STOP disposable socket-only lab'; END IF;
 IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='vault_lab_authenticator') THEN RAISE EXCEPTION 'STOP authenticator already exists'; END IF;
END $$;
-- Emulate the production auth.uid() claim contract only inside the synthetic cluster.
-- Retain compatibility with direct psql fixtures; PostgREST 13 uses request.jwt.claims.
CREATE OR REPLACE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE SET search_path=pg_catalog AS $$
 SELECT coalesce(nullif(current_setting('request.jwt.claim.sub',true),''), nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub')::uuid
$$;
CREATE ROLE vault_lab_authenticator LOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
GRANT anon,authenticated TO vault_lab_authenticator WITH INHERIT FALSE, SET TRUE;
COMMIT;
