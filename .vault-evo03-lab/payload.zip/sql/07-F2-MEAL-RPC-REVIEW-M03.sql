-- LAB REVIEW ONLY. Execute after 06 in the disposable PG17.6 transaction. No COMMIT.
-- Same canonical meals and audit tables. Private receipts are operational ACK metadata, not a second diary.
-- This is not a migration for deployment; no schema exposure or real client activation authorized.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int <> 170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
 IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='vault_f2_meal_worker_lab') THEN RAISE EXCEPTION 'STOP unexpected role'; END IF;
END $$;
CREATE ROLE vault_f2_meal_worker_lab NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
DO $$ BEGIN EXECUTE format('GRANT vault_f2_meal_worker_lab TO %I WITH SET TRUE, INHERIT FALSE',current_user); END $$;
GRANT USAGE ON SCHEMA public,vault_nutrition_f2_review TO vault_f2_meal_worker_lab;
-- Managed Supabase migrator cannot GRANT USAGE on auth. A zero-argument private helper owned by migrator
-- reads auth.uid() only (no tables, no caller-supplied identity). No auth schema grant to worker.
CREATE FUNCTION vault_nutrition_f2_review.request_uid() RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$ SELECT auth.uid() $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.request_uid() FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.request_uid() TO vault_f2_meal_worker_lab;
GRANT EXECUTE ON FUNCTION public.vital_f2_envelope_review(uuid,uuid,jsonb,jsonb) TO vault_f2_meal_worker_lab;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb),vault_nutrition_f2_review.near(jsonb,numeric),vault_nutrition_f2_review.convert(jsonb,text),vault_nutrition_f2_review.factor(text),vault_nutrition_f2_review.family(text) TO vault_f2_meal_worker_lab;
GRANT SELECT,INSERT ON public.vital_meals,public.vital_audit TO vault_f2_meal_worker_lab;
GRANT UPDATE(updated_at,deleted_at,revision,day,time,kind,custom_label,plan_version_id,items,notes,nutrition_f2) ON public.vital_meals TO vault_f2_meal_worker_lab;
GRANT SELECT ON public.vital_foods,public.vital_nutrition_plan_versions TO vault_f2_meal_worker_lab;
CREATE POLICY f2_worker_meal_select ON public.vital_meals FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_meal_insert ON public.vital_meals FOR INSERT TO vault_f2_meal_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_meal_update ON public.vital_meals FOR UPDATE TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id) WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_audit_select ON public.vital_audit FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_audit_insert ON public.vital_audit FOR INSERT TO vault_f2_meal_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_food_select ON public.vital_foods FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_plan_select ON public.vital_nutrition_plan_versions FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE TABLE vault_nutrition_f2_review.meal_receipts(
 user_id uuid NOT NULL,person_id uuid NOT NULL,operation_id uuid NOT NULL,meal_id uuid NOT NULL,revision bigint NOT NULL CHECK(revision BETWEEN 1 AND 9007199254740991),
 audit_id uuid,snapshot_operation uuid,request_sha256 text NOT NULL CHECK(request_sha256~'^[0-9a-f]{64}$'),row_sha256 text NOT NULL CHECK(row_sha256~'^[0-9a-f]{64}$'),
 PRIMARY KEY(user_id,person_id,operation_id),UNIQUE(meal_id,revision),UNIQUE(user_id,person_id,snapshot_operation),
 FOREIGN KEY(meal_id,user_id,person_id) REFERENCES public.vital_meals(id,user_id,person_id) ON DELETE CASCADE,
 FOREIGN KEY(audit_id,user_id,person_id) REFERENCES public.vital_audit(id,user_id,person_id) ON DELETE CASCADE,
 CHECK((revision=1)=(audit_id IS NULL)),CHECK((audit_id IS NULL OR operation_id=audit_id)));
ALTER TABLE vault_nutrition_f2_review.meal_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE vault_nutrition_f2_review.meal_receipts FORCE ROW LEVEL SECURITY;
REVOKE ALL ON vault_nutrition_f2_review.meal_receipts FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT ON vault_nutrition_f2_review.meal_receipts TO vault_f2_meal_worker_lab;
CREATE POLICY f2_worker_receipt_select ON vault_nutrition_f2_review.meal_receipts FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_receipt_insert ON vault_nutrition_f2_review.meal_receipts FOR INSERT TO vault_f2_meal_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
-- Replace only the inert MEAL trigger in the lab. Keep the F1 guard and locks on other extensions.
DROP TRIGGER vital_f2_review_lock_meals ON public.vital_meals;
CREATE FUNCTION vault_nutrition_f2_review.guard_meal() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.nutrition_f2 IS NOT NULL OR (TG_OP='UPDATE' AND OLD.nutrition_f2 IS NOT NULL) THEN
  IF current_user<>'vault_f2_meal_worker_lab' OR NEW.nutrition_f2 IS NULL THEN RAISE EXCEPTION 'F2 requires compatible transactional writer' USING ERRCODE='42501'; END IF;
 END IF;
 RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.guard_meal() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vital_f2_meal_writer_guard BEFORE INSERT OR UPDATE ON public.vital_meals FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_meal();
CREATE FUNCTION vault_nutrition_f2_review.guard_audit() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.target_table='vital_meals' AND current_user<>'vault_f2_meal_worker_lab' AND (NEW.previous->>'nutrition_f2' IS NOT NULL OR EXISTS(SELECT 1 FROM public.vital_meals m WHERE m.id=NEW.target_id AND m.user_id=NEW.user_id AND m.person_id=NEW.person_id AND m.nutrition_f2 IS NOT NULL)) THEN RAISE EXCEPTION 'F2 audit must be committed with meal' USING ERRCODE='42501';END IF;RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.guard_audit() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vital_f2_audit_writer_guard BEFORE INSERT ON public.vital_audit FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_audit();
CREATE FUNCTION vault_nutrition_f2_review.write_meal(p_person uuid,p_operation uuid,p_expected bigint,p_row jsonb,p_audit jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE uid uuid; incoming public.vital_meals%ROWTYPE; current_row public.vital_meals%ROWTYPE; saved public.vital_meals%ROWTYPE; aud public.vital_audit%ROWTYPE; stored_audit public.vital_audit%ROWTYPE; receipt vault_nutrition_f2_review.meal_receipts%ROWTYPE; old_data jsonb; new_data jsonb; old_item jsonb; i jsonb; snap_id uuid; h text; rowhash text; scope_key text; operation_status text; existing boolean; key text;
BEGIN
 uid:=vault_nutrition_f2_review.request_uid();
 IF uid IS NULL OR p_person IS NULL OR p_operation IS NULL OR jsonb_typeof(p_row) IS DISTINCT FROM 'object' OR octet_length(p_row::text)>2400000 OR coalesce(octet_length(p_audit::text),0)>2400000 THEN RAISE EXCEPTION 'F2 invalid scope or payload' USING ERRCODE='42501';END IF;
 IF NOT (p_row ?& ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','day','time','kind','custom_label','plan_version_id','items','notes','nutrition_f2']) OR (p_row-ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','day','time','kind','custom_label','plan_version_id','items','notes','nutrition_f2'])<>'{}'::jsonb OR p_row->>'user_id' IS DISTINCT FROM uid::text OR p_row->>'person_id' IS DISTINCT FROM p_person::text OR jsonb_typeof(p_row->'revision') IS DISTINCT FROM 'number' THEN RAISE EXCEPTION 'F2 invalid row scope' USING ERRCODE='42501';END IF;
 incoming:=jsonb_populate_record(NULL::public.vital_meals,p_row);
 IF incoming.id IS NULL OR incoming.revision IS NULL OR incoming.revision NOT BETWEEN 1 AND 9007199254740991 OR p_row->'revision' IS DISTINCT FROM to_jsonb(incoming.revision) OR incoming.revision<>coalesce(p_expected,0)+1 OR incoming.created_at IS NULL OR incoming.updated_at IS NULL OR incoming.updated_at<incoming.created_at OR incoming.updated_at>clock_timestamp()+interval '5 minutes' OR incoming.nutrition_f2 IS NULL OR NOT vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,incoming.nutrition_f2) THEN RAISE EXCEPTION 'F2 revision, chronology or composition invalid' USING ERRCODE='23514';END IF;
 -- Serialize even first insert; row locks alone do not serialize absent rows. No timestamp determines revision.
 PERFORM pg_advisory_xact_lock(hashtextextended('vault_f2_meal:'||uid::text||':'||p_person::text||':'||incoming.id::text,0));
 h:=encode(sha256(convert_to(jsonb_build_object('expected',p_expected,'row',p_row,'audit',p_audit)::text,'UTF8')),'hex');
 SELECT * INTO receipt FROM vault_nutrition_f2_review.meal_receipts r WHERE r.user_id=uid AND r.person_id=p_person AND r.operation_id=p_operation;
 IF FOUND THEN
  IF receipt.meal_id<>incoming.id OR receipt.revision<>incoming.revision OR receipt.request_sha256<>h THEN RAISE EXCEPTION 'F2 operation identity conflict' USING ERRCODE='23505';END IF;
  SELECT * INTO saved FROM public.vital_meals m WHERE m.id=incoming.id AND m.user_id=uid AND m.person_id=p_person;
  -- Historical exact retries are read-only. The immutable receipt binds the request and the
  -- normalized row actually committed. Never return the newer head as the old ACK.
  IF NOT FOUND OR saved.revision<receipt.revision OR saved.created_at IS DISTINCT FROM incoming.created_at OR encode(sha256(convert_to(to_jsonb(incoming)::text,'UTF8')),'hex')<>receipt.row_sha256 OR (saved.revision=receipt.revision AND encode(sha256(convert_to(to_jsonb(saved)::text,'UTF8')),'hex')<>receipt.row_sha256) THEN RAISE EXCEPTION 'F2 receipt or canonical head diverges' USING ERRCODE='PT409';END IF;
  IF receipt.audit_id IS NOT NULL THEN
   SELECT * INTO stored_audit FROM public.vital_audit a WHERE a.id=receipt.audit_id AND a.user_id=uid AND a.person_id=p_person;
   IF NOT FOUND OR jsonb_typeof(p_audit) IS DISTINCT FROM 'object' OR to_jsonb(stored_audit) IS DISTINCT FROM to_jsonb(jsonb_populate_record(NULL::public.vital_audit,p_audit)) THEN RAISE EXCEPTION 'F2 missing or divergent canonical audit' USING ERRCODE='PT409';END IF;
  ELSIF p_audit IS NOT NULL AND p_audit<>'null'::jsonb THEN RAISE EXCEPTION 'F2 unexpected historical audit' USING ERRCODE='PT409';END IF;
  RETURN jsonb_build_object('status','retry','operation_id',p_operation,'meal',to_jsonb(incoming),'audit',CASE WHEN receipt.audit_id IS NULL THEN NULL ELSE to_jsonb(stored_audit) END);
 END IF;
 SELECT * INTO current_row FROM public.vital_meals m WHERE m.id=incoming.id AND m.user_id=uid AND m.person_id=p_person FOR UPDATE;existing:=FOUND;
 new_data:=to_jsonb(incoming)-ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision'];
 IF NOT existing THEN
  IF p_expected IS NOT NULL OR incoming.revision<>1 OR incoming.deleted_at IS NOT NULL OR incoming.updated_at<>incoming.created_at OR (p_audit IS NOT NULL AND p_audit<>'null'::jsonb) OR p_operation::text IS DISTINCT FROM incoming.nutrition_f2->>'operation_id' THEN RAISE EXCEPTION 'F2 initial write conflict' USING ERRCODE='PT409';END IF;
  snap_id:=p_operation;
 ELSE
  IF p_expected IS NULL OR current_row.revision<>p_expected OR current_row.deleted_at IS NOT NULL OR incoming.created_at<>current_row.created_at OR incoming.updated_at<=current_row.updated_at THEN RAISE EXCEPTION 'F2 compare-and-swap conflict' USING ERRCODE='PT409';END IF;
  old_data:=to_jsonb(current_row)-ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision'];IF current_row.nutrition_f2 IS NULL THEN old_data:=old_data-'nutrition_f2';END IF;
  IF jsonb_typeof(p_audit) IS DISTINCT FROM 'object' OR NOT (p_audit ?& ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','target_table','target_id','previous_revision','reason','previous']) OR (p_audit-ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','target_table','target_id','previous_revision','reason','previous'])<>'{}'::jsonb THEN RAISE EXCEPTION 'F2 exact audit required' USING ERRCODE='23514';END IF;
  aud:=jsonb_populate_record(NULL::public.vital_audit,p_audit);
  IF aud.id IS DISTINCT FROM p_operation OR aud.user_id IS DISTINCT FROM uid OR aud.person_id IS DISTINCT FROM p_person OR aud.target_table IS DISTINCT FROM 'vital_meals' OR aud.target_id IS DISTINCT FROM incoming.id OR aud.previous_revision IS DISTINCT FROM p_expected OR aud.revision IS DISTINCT FROM 1 OR aud.deleted_at IS NOT NULL OR aud.created_at IS DISTINCT FROM incoming.updated_at OR aud.updated_at IS DISTINCT FROM incoming.updated_at OR nullif(btrim(aud.reason),'') IS NULL OR length(aud.reason)>500 OR aud.previous IS DISTINCT FROM old_data THEN RAISE EXCEPTION 'F2 audit preimage mismatch' USING ERRCODE='23514';END IF;
  IF incoming.deleted_at IS NOT NULL THEN IF incoming.deleted_at<>incoming.updated_at OR current_row.nutrition_f2 IS NULL OR old_data IS DISTINCT FROM new_data THEN RAISE EXCEPTION 'F2 archive must preserve data' USING ERRCODE='23514'; END IF;snap_id:=NULL;
  ELSE IF current_row.nutrition_f2 IS NOT NULL AND current_row.nutrition_f2->>'operation_id'=incoming.nutrition_f2->>'operation_id' THEN RAISE EXCEPTION 'F2 correction requires new snapshot operation' USING ERRCODE='23514';END IF;snap_id:=(incoming.nutrition_f2->>'operation_id')::uuid;END IF;
 END IF;
 -- A historical legacy item may be preserved verbatim; new qualitative items must not bypass composition review.
 FOR i IN SELECT x FROM jsonb_array_elements(incoming.items) t(x) LOOP
  IF incoming.nutrition_f2->'legacy_item_ids' ? (i->>'id') THEN
   old_item:=NULL;IF existing THEN SELECT x INTO old_item FROM jsonb_array_elements(current_row.items) t(x) WHERE x->>'id'=i->>'id';END IF;
   IF existing AND current_row.nutrition_f2->'items' ? (i->>'id') OR (old_item IS NOT NULL AND old_item IS DISTINCT FROM i) OR (old_item IS NULL AND (i->'nutrients' IS DISTINCT FROM '{}'::jsonb OR i->>'nutrient_source' IS NOT NULL)) THEN RAISE EXCEPTION 'F2 legacy item downgrade or bypass' USING ERRCODE='23514';END IF;
  END IF;
 END LOOP;
 IF snap_id IS NOT NULL AND EXISTS(SELECT 1 FROM vault_nutrition_f2_review.meal_receipts r WHERE r.user_id=uid AND r.person_id=p_person AND r.snapshot_operation=snap_id) THEN RAISE EXCEPTION 'F2 historical operation already used' USING ERRCODE='23505';END IF;
 IF existing THEN
  UPDATE public.vital_meals SET updated_at=incoming.updated_at,deleted_at=incoming.deleted_at,revision=incoming.revision,day=incoming.day,time=incoming.time,kind=incoming.kind,custom_label=incoming.custom_label,plan_version_id=incoming.plan_version_id,items=incoming.items,notes=incoming.notes,nutrition_f2=incoming.nutrition_f2 WHERE id=incoming.id AND user_id=uid AND person_id=p_person AND revision=p_expected RETURNING * INTO saved;
  IF NOT FOUND THEN RAISE EXCEPTION 'F2 CAS refused' USING ERRCODE='PT409';END IF;
  INSERT INTO public.vital_audit(id,user_id,person_id,created_at,updated_at,deleted_at,revision,target_table,target_id,previous_revision,reason,previous) VALUES(aud.id,aud.user_id,aud.person_id,aud.created_at,aud.updated_at,aud.deleted_at,aud.revision,aud.target_table,aud.target_id,aud.previous_revision,aud.reason,aud.previous) RETURNING * INTO stored_audit;
 ELSE
  INSERT INTO public.vital_meals(id,user_id,person_id,created_at,updated_at,deleted_at,revision,day,time,kind,custom_label,plan_version_id,items,notes,nutrition_f2) VALUES(incoming.id,incoming.user_id,incoming.person_id,incoming.created_at,incoming.updated_at,incoming.deleted_at,incoming.revision,incoming.day,incoming.time,incoming.kind,incoming.custom_label,incoming.plan_version_id,incoming.items,incoming.notes,incoming.nutrition_f2) RETURNING * INTO saved;
 END IF;
 rowhash:=encode(sha256(convert_to(to_jsonb(saved)::text,'UTF8')),'hex');
 INSERT INTO vault_nutrition_f2_review.meal_receipts(user_id,person_id,operation_id,meal_id,revision,audit_id,snapshot_operation,request_sha256,row_sha256) VALUES(uid,p_person,p_operation,saved.id,saved.revision,CASE WHEN existing THEN stored_audit.id ELSE NULL END,snap_id,h,rowhash);
 RETURN jsonb_build_object('status','applied','operation_id',p_operation,'meal',to_jsonb(saved),'audit',CASE WHEN existing THEN to_jsonb(stored_audit) ELSE NULL END);
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.write_meal(uuid,uuid,bigint,jsonb,jsonb) FROM PUBLIC,anon,authenticated;
-- Grant before transfer (Stability PG28 lesson). No auth grants and no role membership for clients.
GRANT USAGE ON SCHEMA vault_nutrition_f2_review TO authenticated;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.write_meal(uuid,uuid,bigint,jsonb,jsonb) TO authenticated;
GRANT CREATE ON SCHEMA vault_nutrition_f2_review TO vault_f2_meal_worker_lab;
ALTER FUNCTION vault_nutrition_f2_review.write_meal(uuid,uuid,bigint,jsonb,jsonb) OWNER TO vault_f2_meal_worker_lab;
REVOKE CREATE ON SCHEMA vault_nutrition_f2_review FROM vault_f2_meal_worker_lab;
-- Public entry is invoker; private entry re-verifies UID and has RLS/explicit scope on every write.
CREATE FUNCTION public.vault_vital_meal_f2_review(p_person uuid,p_operation uuid,p_expected bigint,p_row jsonb,p_audit jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN IF auth.uid() IS NULL OR p_row->>'user_id' IS DISTINCT FROM auth.uid()::text OR p_row->>'person_id' IS DISTINCT FROM p_person::text THEN RAISE EXCEPTION 'F2 scope denied' USING ERRCODE='42501'; END IF;RETURN vault_nutrition_f2_review.write_meal(p_person,p_operation,p_expected,p_row,p_audit);END $$;
REVOKE ALL ON FUNCTION public.vault_vital_meal_f2_review(uuid,uuid,bigint,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.vault_vital_meal_f2_review(uuid,uuid,bigint,jsonb,jsonb) TO authenticated;
DO $$ BEGIN
 IF NOT has_function_privilege('authenticated','public.vault_vital_meal_f2_review(uuid,uuid,bigint,jsonb,jsonb)','EXECUTE') OR has_function_privilege('anon','public.vault_vital_meal_f2_review(uuid,uuid,bigint,jsonb,jsonb)','EXECUTE') OR has_function_privilege('anon','vault_nutrition_f2_review.write_meal(uuid,uuid,bigint,jsonb,jsonb)','EXECUTE') OR has_schema_privilege('vault_f2_meal_worker_lab','vault_nutrition_f2_review','CREATE') OR pg_has_role('authenticated','vault_f2_meal_worker_lab','MEMBER') OR pg_has_role('anon','vault_f2_meal_worker_lab','MEMBER') OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname='vault_f2_meal_worker_lab' AND (rolcanlogin OR rolbypassrls OR rolsuper OR rolcreaterole)) THEN RAISE EXCEPTION 'F2 role/ACL review failed'; END IF;
END $$;
-- Deliberately no deployment or capability publication. Tests must run in this transaction; rollback by default.
