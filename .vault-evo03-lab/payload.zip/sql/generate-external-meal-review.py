#!/usr/bin/env python3
"""Materialize optional HC-aware 07, before worker ownership transfer; no execution."""
from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'07-F2-MEAL-RPC-REVIEW-M03.sql').read_text()
def replace(old,new):
 global s
 assert s.count(old)==1, f'writer drift: {old}'
 s=s.replace(old,new)
replace('GRANT USAGE ON SCHEMA public,vault_nutrition_f2_review TO vault_f2_meal_worker_lab;', '''GRANT USAGE ON SCHEMA public,vault_nutrition_f2_review TO vault_f2_meal_worker_lab;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.external_id(uuid,uuid,text,text,text),vault_nutrition_f2_review.has_external(jsonb),vault_nutrition_f2_review.external_record(jsonb),vault_nutrition_f2_review.valid_external(uuid,uuid,jsonb),vault_nutrition_f2_review.external_transition(jsonb,jsonb) TO vault_f2_meal_worker_lab;''')
replace('NOT vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,incoming.nutrition_f2)',"(CASE WHEN vault_nutrition_f2_review.has_external(p_row) THEN vault_nutrition_f2_review.valid_external(uid,p_person,p_row) ELSE vault_nutrition_f2_review.recompute(uid,p_person,incoming.items,incoming.nutrition_f2) END) IS DISTINCT FROM true")
replace('old_data:=to_jsonb(current_row)-ARRAY', "IF vault_nutrition_f2_review.external_transition(to_jsonb(current_row),p_row) IS DISTINCT FROM true THEN RAISE EXCEPTION 'F2 external identity or version conflict' USING ERRCODE='23514';END IF;\n  old_data:=to_jsonb(current_row)-ARRAY")
# Scope-wide lock serializes F2 writes for overlap review; F1 writes do not participate and require separate review.
replace("PERFORM pg_advisory_xact_lock(hashtextextended('vault_f2_meal:'", "PERFORM pg_advisory_xact_lock(hashtextextended('vault_f2_meal_scope:'||uid::text||':'||p_person::text,0));\n PERFORM pg_advisory_xact_lock(hashtextextended('vault_f2_meal:'")
replace(' -- A historical legacy item', ''' -- Explicit distinction from a potentially overlapping meal; no automatic merge.
 IF vault_nutrition_f2_review.has_external(p_row) AND incoming.deleted_at IS NULL AND (p_row->'nutrition_f2'->'items'->(incoming.items->0->>'id')#>'{payload,composition,externalMeal,overlapConfirmed}') IS DISTINCT FROM 'true'::jsonb AND EXISTS(
 SELECT 1 FROM public.vital_meals m WHERE m.user_id=uid AND m.person_id=p_person AND m.id<>incoming.id AND m.deleted_at IS NULL AND (CASE WHEN vault_nutrition_f2_review.has_external(to_jsonb(m)) THEN (vault_nutrition_f2_review.external_record(to_jsonb(m))->>'start')::timestamptz < (vault_nutrition_f2_review.external_record(p_row)->>'end')::timestamptz AND (vault_nutrition_f2_review.external_record(to_jsonb(m))->>'end')::timestamptz > (vault_nutrition_f2_review.external_record(p_row)->>'start')::timestamptz ELSE m.day=incoming.day AND (m.kind=incoming.kind OR m.time IS NULL OR m.kind='custom' OR incoming.kind='custom') END)) THEN RAISE EXCEPTION 'F2 external overlap requires review' USING ERRCODE='23514';END IF;
 -- A historical legacy item''')
print((p/'11-EXTERNAL-MEAL-REVIEW.sql').read_text());print(s)
