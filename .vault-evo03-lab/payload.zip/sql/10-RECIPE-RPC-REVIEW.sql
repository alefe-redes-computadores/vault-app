-- OPTIONAL disposable review after 08; never apply to production. No COMMIT.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
 IF EXISTS(SELECT 1 FROM public.vital_recipes) OR EXISTS(SELECT 1 FROM public.vital_recipe_versions) THEN RAISE EXCEPTION 'STOP recipe preimage nonempty'; END IF;
END $$;
-- Reuse the already restricted worker and request_uid helper. No new role or auth grant.
GRANT SELECT,INSERT ON public.vital_recipes,public.vital_recipe_versions TO vault_f2_meal_worker_lab;
GRANT UPDATE(name,favorite,active,updated_at,deleted_at,revision) ON public.vital_recipes TO vault_f2_meal_worker_lab;
CREATE POLICY f2_worker_recipe_read ON public.vital_recipes FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_recipe_insert ON public.vital_recipes FOR INSERT TO vault_f2_meal_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_recipe_update ON public.vital_recipes FOR UPDATE TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id) WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_version_read ON public.vital_recipe_versions FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_version_insert ON public.vital_recipe_versions FOR INSERT TO vault_f2_meal_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE TABLE vault_nutrition_f2_review.recipe_receipts(
 user_id uuid NOT NULL,person_id uuid NOT NULL,operation_id uuid NOT NULL,recipe_id uuid NOT NULL,head_revision bigint NOT NULL CHECK(head_revision BETWEEN 1 AND 9007199254740991),
 version_id uuid,audit_id uuid,request_sha256 text NOT NULL CHECK(request_sha256~'^[0-9a-f]{64}$'),head_sha256 text NOT NULL CHECK(head_sha256~'^[0-9a-f]{64}$'),
 PRIMARY KEY(user_id,person_id,operation_id),UNIQUE(version_id),UNIQUE(audit_id),CHECK((version_id IS NULL)<>(audit_id IS NULL)),CHECK(operation_id=coalesce(version_id,audit_id)),
 FOREIGN KEY(recipe_id,user_id,person_id) REFERENCES public.vital_recipes(id,user_id,person_id) ON DELETE CASCADE,
 FOREIGN KEY(version_id,user_id,person_id) REFERENCES public.vital_recipe_versions(id,user_id,person_id) ON DELETE CASCADE,
 FOREIGN KEY(audit_id,user_id,person_id) REFERENCES public.vital_audit(id,user_id,person_id) ON DELETE CASCADE);
ALTER TABLE vault_nutrition_f2_review.recipe_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE vault_nutrition_f2_review.recipe_receipts FORCE ROW LEVEL SECURITY;
REVOKE ALL ON vault_nutrition_f2_review.recipe_receipts FROM PUBLIC,anon,authenticated;
GRANT SELECT,INSERT ON vault_nutrition_f2_review.recipe_receipts TO vault_f2_meal_worker_lab;
CREATE POLICY f2_worker_recipe_receipt_read ON vault_nutrition_f2_review.recipe_receipts FOR SELECT TO vault_f2_meal_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_worker_recipe_receipt_insert ON vault_nutrition_f2_review.recipe_receipts FOR INSERT TO vault_f2_meal_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
-- Preserve F1 guard exactly except the one new audit target. Refuse if its exact original token is missing or repeated.
DO $$ DECLARE f text; needle text:='''vital_training_plans'',''vital_nutrition_plans'') THEN RAISE EXCEPTION ''Vital audit invalid'''; patched text;
BEGIN
 f:=pg_get_functiondef('public.vital_evo_guard_row()'::regprocedure);
 IF length(f)-length(replace(f,needle,''))<>length(needle) THEN RAISE EXCEPTION 'STOP F1 audit guard drift';END IF;
 patched:=replace(f,needle,'''vital_training_plans'',''vital_nutrition_plans'',''vital_recipes'') THEN RAISE EXCEPTION ''Vital audit invalid''');
 EXECUTE patched;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.guard_recipe_audit() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN IF NEW.target_table='vital_recipes' AND current_user<>'vault_f2_meal_worker_lab' THEN RAISE EXCEPTION 'Recipe audit requires transactional writer' USING ERRCODE='42501'; END IF;RETURN NEW;END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.guard_recipe_audit() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vital_f2_recipe_audit_guard BEFORE INSERT ON public.vital_audit FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_recipe_audit();
CREATE FUNCTION vault_nutrition_f2_review.guard_recipe() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN
 IF current_user<>'vault_f2_meal_worker_lab' THEN RAISE EXCEPTION 'Recipe transactional writer required' USING ERRCODE='42501';END IF;
 IF TG_OP='UPDATE' THEN
  IF TG_TABLE_NAME='vital_recipe_versions' THEN RAISE EXCEPTION 'Recipe version immutable' USING ERRCODE='23514';END IF;
  IF OLD.deleted_at IS NOT NULL OR NEW.id<>OLD.id OR NEW.user_id<>OLD.user_id OR NEW.person_id<>OLD.person_id OR NEW.kind<>OLD.kind OR NEW.created_at<>OLD.created_at OR NEW.revision<>OLD.revision+1 OR NEW.updated_at<=OLD.updated_at THEN RAISE EXCEPTION 'Recipe identity or revision conflict' USING ERRCODE='23514';END IF;
 END IF;RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.guard_recipe() FROM PUBLIC,anon,authenticated;
DROP TRIGGER vital_f2_recipe_review_lock_head ON public.vital_recipes;
DROP TRIGGER vital_f2_recipe_review_lock_version ON public.vital_recipe_versions;
DROP TRIGGER vital_recipe_writer_review_lock ON public.vital_recipes;
DROP TRIGGER vital_recipe_version_writer_review_lock ON public.vital_recipe_versions;
CREATE TRIGGER vital_recipe_writer_guard BEFORE INSERT OR UPDATE ON public.vital_recipes FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_recipe();
CREATE TRIGGER vital_recipe_version_writer_guard BEFORE INSERT OR UPDATE ON public.vital_recipe_versions FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_recipe();
CREATE FUNCTION vault_nutrition_f2_review.write_recipe(p_person uuid,p_operation uuid,p_expected_head bigint,p_expected_latest uuid,p_head jsonb,p_version jsonb,p_audit jsonb,p_proofs jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE uid uuid; h public.vital_recipes%ROWTYPE; oldh public.vital_recipes%ROWTYPE; v public.vital_recipe_versions%ROWTYPE; savedv public.vital_recipe_versions%ROWTYPE; a public.vital_audit%ROWTYPE; saveda public.vital_audit%ROWTYPE; receipt vault_nutrition_f2_review.recipe_receipts%ROWTYPE; latest public.vital_recipe_versions%ROWTYPE; digest text; headhash text; i jsonb; proof jsonb; sid text; pos integer:=0; seen text[]:='{}'; exists_head boolean; has_version boolean:=p_version IS NOT NULL AND p_version<>'null'::jsonb; has_audit boolean:=p_audit IS NOT NULL AND p_audit<>'null'::jsonb; head_fields constant text[]:=ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','kind','name','favorite','active']; version_fields constant text[]:=ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','recipe_id','version','name_snapshot','ingredients','raw_edible_mass_g','finished_mass_g','servings','yield_evidence','retention_evidence','reviewed_at']; audit_fields constant text[]:=ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','target_table','target_id','previous_revision','reason','previous'];
BEGIN
 uid:=vault_nutrition_f2_review.request_uid();
 IF uid IS NULL OR p_person IS NULL OR p_operation IS NULL OR has_version=has_audit OR jsonb_typeof(p_head) IS DISTINCT FROM 'object' OR jsonb_typeof(p_proofs) IS DISTINCT FROM 'array' OR octet_length(jsonb_build_array(p_head,p_version,p_audit,p_proofs)::text)>5000000 OR NOT p_head ?& head_fields OR p_head-head_fields<>'{}'::jsonb OR p_head->>'user_id' IS DISTINCT FROM uid::text OR p_head->>'person_id' IS DISTINCT FROM p_person::text OR jsonb_typeof(p_head->'revision') IS DISTINCT FROM 'number' OR jsonb_typeof(p_head->'active') IS DISTINCT FROM 'boolean' OR jsonb_typeof(p_head->'favorite') IS DISTINCT FROM 'boolean' THEN RAISE EXCEPTION 'Recipe payload or scope denied' USING ERRCODE='42501';END IF;
 h:=jsonb_populate_record(NULL::public.vital_recipes,p_head);
 IF h.id IS NULL OR h.revision IS NULL OR h.revision NOT BETWEEN 1 AND 9007199254740991 OR p_head->'revision' IS DISTINCT FROM to_jsonb(h.revision) OR h.created_at IS NULL OR h.updated_at IS NULL OR h.updated_at<h.created_at OR h.updated_at>clock_timestamp()+interval '5 minutes' OR h.name IS NULL OR btrim(h.name)<>h.name OR length(h.name) NOT BETWEEN 1 AND 160 OR h.kind IS NULL OR h.kind NOT IN ('recipe','meal_template') OR (h.deleted_at IS NOT NULL AND h.deleted_at<>h.updated_at) THEN RAISE EXCEPTION 'Recipe head invalid' USING ERRCODE='23514';END IF;
 IF has_version THEN
  IF jsonb_typeof(p_version) IS DISTINCT FROM 'object' OR NOT p_version ?& version_fields OR p_version-version_fields<>'{}'::jsonb OR p_version->>'user_id' IS DISTINCT FROM uid::text OR p_version->>'person_id' IS DISTINCT FROM p_person::text OR jsonb_typeof(p_version->'version') IS DISTINCT FROM 'number' OR p_version->'revision' IS DISTINCT FROM '1'::jsonb THEN RAISE EXCEPTION 'Recipe version shape invalid' USING ERRCODE='23514';END IF;
  IF EXISTS(SELECT 1 FROM unnest(ARRAY['raw_edible_mass_g','finished_mass_g','servings']) t(k) WHERE p_version->k<>'null'::jsonb AND jsonb_typeof(p_version->k) IS DISTINCT FROM 'number') THEN RAISE EXCEPTION 'Recipe yield numeric shape invalid' USING ERRCODE='23514';END IF;
  v:=jsonb_populate_record(NULL::public.vital_recipe_versions,p_version);
  IF v.id IS DISTINCT FROM p_operation OR v.id=h.id OR v.recipe_id IS DISTINCT FROM h.id OR v.name_snapshot IS DISTINCT FROM h.name OR v.version IS NULL OR v.version<1 OR p_version->'version' IS DISTINCT FROM to_jsonb(v.version) OR v.deleted_at IS NOT NULL OR v.created_at IS NULL OR v.updated_at IS DISTINCT FROM v.created_at OR v.reviewed_at IS NULL OR v.reviewed_at>v.created_at OR v.created_at>clock_timestamp()+interval '5 minutes' OR v.retention_evidence IS NOT NULL OR NOT h.active OR h.deleted_at IS NOT NULL OR jsonb_typeof(v.ingredients) IS DISTINCT FROM 'array' OR jsonb_array_length(v.ingredients) NOT BETWEEN 1 AND 200 OR jsonb_array_length(p_proofs)<>jsonb_array_length(v.ingredients) THEN RAISE EXCEPTION 'Recipe version invalid' USING ERRCODE='23514';END IF;
  -- Validate proof payload against the exact canonical ingredient, then reuse the server nutrient recomputation.
  FOR i IN SELECT x FROM jsonb_array_elements(v.ingredients) t(x) LOOP
   proof:=p_proofs->pos;pos:=pos+1;sid:=i->>'itemId';
   IF sid IS NULL OR sid=ANY(seen) OR jsonb_typeof(proof) IS DISTINCT FROM 'object' OR (proof-ARRAY['item','snapshot'])<>'{}'::jsonb OR proof#>>'{snapshot,reviewedAt}' IS DISTINCT FROM p_version->>'reviewed_at' OR proof#>'{snapshot,payload}' IS DISTINCT FROM i OR proof#>>'{item,id}' IS DISTINCT FROM sid OR proof#>'{snapshot,food_id}' IS DISTINCT FROM 'null'::jsonb OR proof#>'{item,food_id}' IS DISTINCT FROM 'null'::jsonb OR coalesce(i#>>'{composition,source,provider}','') NOT IN ('manual','label') OR i->'composition' ? 'labelEvidence' OR i#>>'{composition,source,license}'='private-user-label' OR NOT vault_nutrition_f2_review.recompute(uid,p_person,jsonb_build_array(proof->'item'),jsonb_build_object('schema_version',1,'operation_id',p_operation,'items',jsonb_build_object(sid,proof->'snapshot'),'legacy_item_ids','[]'::jsonb)) THEN RAISE EXCEPTION 'Recipe ingredient proof invalid' USING ERRCODE='23514';END IF;seen:=array_append(seen,sid);
  END LOOP;
 ELSE
  IF jsonb_array_length(p_proofs)<>0 OR jsonb_typeof(p_audit) IS DISTINCT FROM 'object' OR NOT p_audit ?& audit_fields OR p_audit-audit_fields<>'{}'::jsonb OR p_audit->>'user_id' IS DISTINCT FROM uid::text OR p_audit->>'person_id' IS DISTINCT FROM p_person::text THEN RAISE EXCEPTION 'Recipe audit shape invalid' USING ERRCODE='23514';END IF;
  a:=jsonb_populate_record(NULL::public.vital_audit,p_audit);
  IF a.id IS DISTINCT FROM p_operation OR a.target_table IS DISTINCT FROM 'vital_recipes' OR a.target_id IS DISTINCT FROM h.id OR a.previous_revision IS DISTINCT FROM p_expected_head OR a.revision IS DISTINCT FROM 1 OR a.deleted_at IS NOT NULL OR a.created_at IS DISTINCT FROM h.updated_at OR a.updated_at IS DISTINCT FROM h.updated_at OR nullif(btrim(a.reason),'') IS NULL OR length(a.reason)>500 OR h.revision IS DISTINCT FROM p_expected_head+1 THEN RAISE EXCEPTION 'Recipe audit invalid' USING ERRCODE='23514';END IF;
 END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended('vault_f2_recipe:'||uid::text||':'||p_person::text||':'||h.id::text,0));
 digest:=encode(sha256(convert_to(jsonb_build_array(p_expected_head,p_expected_latest,p_head,p_version,p_audit,p_proofs)::text,'UTF8')),'hex');headhash:=encode(sha256(convert_to(to_jsonb(h)::text,'UTF8')),'hex');
 SELECT * INTO receipt FROM vault_nutrition_f2_review.recipe_receipts r WHERE r.user_id=uid AND r.person_id=p_person AND r.operation_id=p_operation;
 IF FOUND THEN
  IF receipt.recipe_id<>h.id OR receipt.head_revision<>h.revision OR receipt.request_sha256<>digest OR receipt.head_sha256<>headhash THEN RAISE EXCEPTION 'Recipe operation conflict' USING ERRCODE='23505';END IF;
  SELECT * INTO oldh FROM public.vital_recipes r WHERE r.id=h.id AND r.user_id=uid AND r.person_id=p_person;
  IF NOT FOUND OR oldh.created_at<>h.created_at OR oldh.revision<h.revision OR (oldh.revision=h.revision AND to_jsonb(oldh)<>to_jsonb(h)) THEN RAISE EXCEPTION 'Recipe head diverges' USING ERRCODE='40001';END IF;
  IF has_version THEN SELECT * INTO savedv FROM public.vital_recipe_versions r WHERE r.id=receipt.version_id AND r.user_id=uid AND r.person_id=p_person;IF NOT FOUND OR to_jsonb(savedv)<>to_jsonb(v) THEN RAISE EXCEPTION 'Recipe version diverges' USING ERRCODE='40001';END IF;
  ELSE SELECT * INTO saveda FROM public.vital_audit r WHERE r.id=receipt.audit_id AND r.user_id=uid AND r.person_id=p_person;IF NOT FOUND OR to_jsonb(saveda)<>to_jsonb(a) THEN RAISE EXCEPTION 'Recipe audit diverges' USING ERRCODE='40001';END IF;END IF;
  RETURN jsonb_build_object('status','retry','operation_id',p_operation,'head',to_jsonb(h),'version',CASE WHEN has_version THEN to_jsonb(savedv) ELSE NULL END,'audit',CASE WHEN has_audit THEN to_jsonb(saveda) ELSE NULL END);
 END IF;
 SELECT * INTO oldh FROM public.vital_recipes r WHERE r.id=h.id AND r.user_id=uid AND r.person_id=p_person FOR UPDATE;exists_head:=FOUND;
 SELECT * INTO latest FROM public.vital_recipe_versions r WHERE r.recipe_id=h.id AND r.user_id=uid AND r.person_id=p_person ORDER BY r.version DESC LIMIT 1;
 IF NOT exists_head THEN
  IF NOT has_version OR p_expected_head IS NOT NULL OR p_expected_latest IS NOT NULL OR h.revision<>1 OR h.created_at<>h.updated_at OR v.version<>1 THEN RAISE EXCEPTION 'Recipe creation conflict' USING ERRCODE='40001';END IF;
  INSERT INTO public.vital_recipes(id,user_id,person_id,created_at,updated_at,deleted_at,revision,kind,name,favorite,active) VALUES(h.id,h.user_id,h.person_id,h.created_at,h.updated_at,h.deleted_at,h.revision,h.kind,h.name,h.favorite,h.active);
 ELSE
  IF oldh.deleted_at IS NOT NULL OR p_expected_head IS DISTINCT FROM oldh.revision OR latest.id IS NULL OR p_expected_latest IS DISTINCT FROM latest.id THEN RAISE EXCEPTION 'Recipe CAS conflict' USING ERRCODE='40001';END IF;
  IF has_version THEN IF to_jsonb(h)<>to_jsonb(oldh) OR v.version<>latest.version+1 THEN RAISE EXCEPTION 'Recipe version CAS conflict' USING ERRCODE='40001';END IF;
  ELSE
   IF h.created_at<>oldh.created_at OR h.kind<>oldh.kind OR h.updated_at<=oldh.updated_at OR a.previous IS DISTINCT FROM (to_jsonb(oldh)-ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision']) OR (h.deleted_at IS NOT NULL AND (to_jsonb(h)-ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision']) IS DISTINCT FROM a.previous) THEN RAISE EXCEPTION 'Recipe audit preimage conflict' USING ERRCODE='40001';END IF;
   UPDATE public.vital_recipes SET name=h.name,favorite=h.favorite,active=h.active,updated_at=h.updated_at,deleted_at=h.deleted_at,revision=h.revision WHERE id=h.id AND user_id=uid AND person_id=p_person AND revision=p_expected_head;
   IF NOT FOUND THEN RAISE EXCEPTION 'Recipe CAS refused' USING ERRCODE='40001';END IF;
   INSERT INTO public.vital_audit(id,user_id,person_id,created_at,updated_at,deleted_at,revision,target_table,target_id,previous_revision,reason,previous) VALUES(a.id,a.user_id,a.person_id,a.created_at,a.updated_at,a.deleted_at,a.revision,a.target_table,a.target_id,a.previous_revision,a.reason,a.previous) RETURNING * INTO saveda;
  END IF;
 END IF;
 IF has_version THEN INSERT INTO public.vital_recipe_versions(id,user_id,person_id,recipe_id,version,revision,created_at,updated_at,deleted_at,name_snapshot,ingredients,raw_edible_mass_g,finished_mass_g,servings,yield_evidence,retention_evidence,reviewed_at) VALUES(v.id,v.user_id,v.person_id,v.recipe_id,v.version,v.revision,v.created_at,v.updated_at,v.deleted_at,v.name_snapshot,v.ingredients,v.raw_edible_mass_g,v.finished_mass_g,v.servings,v.yield_evidence,v.retention_evidence,v.reviewed_at) RETURNING * INTO savedv;END IF;
 INSERT INTO vault_nutrition_f2_review.recipe_receipts(user_id,person_id,operation_id,recipe_id,head_revision,version_id,audit_id,request_sha256,head_sha256) VALUES(uid,p_person,p_operation,h.id,h.revision,CASE WHEN has_version THEN v.id ELSE NULL END,CASE WHEN has_audit THEN a.id ELSE NULL END,digest,headhash);
 RETURN jsonb_build_object('status','applied','operation_id',p_operation,'head',to_jsonb(h),'version',CASE WHEN has_version THEN to_jsonb(savedv) ELSE NULL END,'audit',CASE WHEN has_audit THEN to_jsonb(saveda) ELSE NULL END);
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.write_recipe(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.write_recipe(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb) TO authenticated;
GRANT CREATE ON SCHEMA vault_nutrition_f2_review TO vault_f2_meal_worker_lab;
ALTER FUNCTION vault_nutrition_f2_review.write_recipe(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb) OWNER TO vault_f2_meal_worker_lab;
REVOKE CREATE ON SCHEMA vault_nutrition_f2_review FROM vault_f2_meal_worker_lab;
CREATE FUNCTION public.vault_vital_recipe_f2_review(p_person uuid,p_operation uuid,p_expected_head bigint,p_expected_latest uuid,p_head jsonb,p_version jsonb,p_audit jsonb,p_proofs jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN IF auth.uid() IS NULL OR p_head->>'user_id' IS DISTINCT FROM auth.uid()::text OR p_head->>'person_id' IS DISTINCT FROM p_person::text THEN RAISE EXCEPTION 'Recipe scope denied' USING ERRCODE='42501';END IF;RETURN vault_nutrition_f2_review.write_recipe(p_person,p_operation,p_expected_head,p_expected_latest,p_head,p_version,p_audit,p_proofs);END $$;
REVOKE ALL ON FUNCTION public.vault_vital_recipe_f2_review(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.vault_vital_recipe_f2_review(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb) TO authenticated;
GRANT SELECT ON public.vital_recipes,public.vital_recipe_versions TO authenticated;
DO $$ BEGIN
 IF has_table_privilege('anon','public.vital_recipes','SELECT') OR has_table_privilege('authenticated','public.vital_recipes','INSERT,UPDATE,DELETE,TRUNCATE') OR has_table_privilege('authenticated','public.vital_recipe_versions','INSERT,UPDATE,DELETE,TRUNCATE') OR has_function_privilege('anon','public.vault_vital_recipe_f2_review(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb)','EXECUTE') OR NOT has_function_privilege('authenticated','public.vault_vital_recipe_f2_review(uuid,uuid,bigint,uuid,jsonb,jsonb,jsonb,jsonb)','EXECUTE') OR has_schema_privilege('vault_f2_meal_worker_lab','vault_nutrition_f2_review','CREATE') THEN RAISE EXCEPTION 'Recipe ACL failed';END IF;
END $$;
