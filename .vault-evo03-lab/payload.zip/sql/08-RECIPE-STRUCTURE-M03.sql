-- LAB REVIEW ONLY. Append to the disposable PG17.6 review transaction AFTER 07.
-- Does not enable recipe persistence on server. Local writer proof is separate.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int <> 170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
 IF to_regclass('public.vital_recipes') IS NULL OR to_regclass('public.vital_recipe_versions') IS NULL THEN RAISE EXCEPTION 'STOP missing R04 recipe base';END IF;
 IF EXISTS(SELECT 1 FROM public.vital_recipes) OR EXISTS(SELECT 1 FROM public.vital_recipe_versions) THEN RAISE EXCEPTION 'STOP nonempty recipe review; do not invent review timestamp'; END IF;
END $$;
ALTER TABLE public.vital_recipe_versions ADD COLUMN reviewed_at timestamptz NOT NULL;
ALTER TABLE public.vital_recipe_versions ADD CONSTRAINT vital_recipe_version_review_time CHECK(reviewed_at<=created_at AND updated_at=created_at);
ALTER TABLE public.vital_recipe_versions ADD CONSTRAINT vital_recipe_version_yield_evidence CHECK((finished_mass_g IS NULL AND servings IS NULL) OR (nullif(btrim(yield_evidence),'') IS NOT NULL AND length(yield_evidence)<=500));
ALTER TABLE public.vital_recipe_versions ADD CONSTRAINT vital_recipe_version_retention_locked CHECK(retention_evidence IS NULL);
-- Inert activation lock. Replace only after verified writer, RLS and receipt proof; never drop data to enable.
CREATE FUNCTION vault_nutrition_f2_review.guard_recipe_inert() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN RAISE EXCEPTION 'F2 recipe transactional writer not activated' USING ERRCODE='42501'; END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.guard_recipe_inert() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER vital_recipe_writer_review_lock BEFORE INSERT OR UPDATE ON public.vital_recipes FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_recipe_inert();
CREATE TRIGGER vital_recipe_version_writer_review_lock BEFORE INSERT OR UPDATE ON public.vital_recipe_versions FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_recipe_inert();
REVOKE ALL ON public.vital_recipes,public.vital_recipe_versions FROM PUBLIC,anon,authenticated;
-- Read policies exist, but no API read grant until a separately certified capability.
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname IN ('vital_recipes','vital_recipe_versions') AND NOT c.relrowsecurity) THEN RAISE EXCEPTION 'FAIL recipe RLS';END IF;
 IF has_table_privilege('anon','public.vital_recipes','SELECT') OR has_table_privilege('authenticated','public.vital_recipes','INSERT') OR has_table_privilege('authenticated','public.vital_recipe_versions','UPDATE') OR has_table_privilege('authenticated','public.vital_recipe_versions','TRUNCATE') THEN RAISE EXCEPTION 'FAIL recipe ACL';END IF;
END $$;
