-- Disposable R17 laboratory ONLY. Registry holds two explicit experimental records, not release approvals.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
END $$;
CREATE TABLE vault_nutrition_f2_review.catalog_authority_lab (
 provider text NOT NULL CHECK(provider IN ('taco','usda')), release text NOT NULL, record_id text NOT NULL,
 record_sha256 text NOT NULL CHECK(record_sha256 ~ '^[a-f0-9]{64}$'), manifest_sha256 text NOT NULL CHECK(manifest_sha256 ~ '^[a-f0-9]{64}$'),
 composition jsonb NOT NULL CHECK(jsonb_typeof(composition)='object'),
 PRIMARY KEY(provider,release,record_id),
 CHECK(composition#>>'{source,provider}' IS NOT DISTINCT FROM provider AND composition#>>'{source,version}' IS NOT DISTINCT FROM release AND composition#>>'{source,recordId}' IS NOT DISTINCT FROM record_id),
 CHECK(composition->'base' = '{"value":100,"unit":"g"}'::jsonb)
);
ALTER TABLE vault_nutrition_f2_review.catalog_authority_lab ENABLE ROW LEVEL SECURITY;
CREATE POLICY lab_catalog_read ON vault_nutrition_f2_review.catalog_authority_lab FOR SELECT TO vault_f2_meal_worker_lab USING (true);
REVOKE ALL ON vault_nutrition_f2_review.catalog_authority_lab FROM PUBLIC,anon,authenticated,service_role,vault_f2_meal_worker_lab;
GRANT SELECT ON vault_nutrition_f2_review.catalog_authority_lab TO vault_f2_meal_worker_lab;
-- Preserve all certified R16 arithmetic; normalize only a verified ephemeral proof. Never persist the normalized copy.
ALTER FUNCTION vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb) RENAME TO recompute_r16;
CREATE FUNCTION vault_nutrition_f2_review.recompute(p_user uuid,p_person uuid,p_legacy jsonb,p_env jsonb) RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE item jsonb; snap jsonb; c jsonb; sid text; original jsonb; converted jsonb:=p_env; legacy jsonb:='[]'::jsonb; projection jsonb; k text; n jsonb;
BEGIN
 IF jsonb_typeof(p_legacy) IS DISTINCT FROM 'array' OR jsonb_typeof(p_env) IS DISTINCT FROM 'object' OR octet_length(p_env::text)>2000000 THEN RETURN false; END IF;
 FOR item IN SELECT x FROM jsonb_array_elements(p_legacy) t(x) LOOP
  sid:=item->>'id'; snap:=p_env->'items'->sid; c:=snap#>'{payload,composition}';
  IF c#>>'{source,provider}' IN ('taco','usda') THEN
   SELECT a.composition INTO original FROM vault_nutrition_f2_review.catalog_authority_lab a WHERE a.provider=c#>>'{source,provider}' AND a.release=c#>>'{source,version}' AND a.record_id=c#>>'{source,recordId}';
   IF NOT FOUND OR c IS DISTINCT FROM original OR snap->'food_id' IS DISTINCT FROM 'null'::jsonb OR item->'food_id' IS DISTINCT FROM 'null'::jsonb OR item->'nutrients' IS DISTINCT FROM '{}'::jsonb OR item->'nutrient_source' IS DISTINCT FROM 'null'::jsonb OR snap#>>'{identity,presentationId}' IS DISTINCT FROM 'catalog-100g' OR coalesce(snap#>>'{payload,consumed,unit}','') NOT IN ('g','kg') OR public.vital_f2_envelope_review(p_user,p_person,jsonb_build_array(item),jsonb_build_object('schema_version',p_env->'schema_version','operation_id',p_env->'operation_id','items',jsonb_build_object(sid,snap),'legacy_item_ids','[]'::jsonb)) IS DISTINCT FROM true THEN RETURN false; END IF;
   -- Match the old manual proof projection, only in memory, from the claimed totals. The R16 validator independently recomputes every value and rejects discrepancies.
   projection:='{}'::jsonb;
   FOREACH k IN ARRAY ARRAY['energy_kcal','carbohydrate_g','protein_g','fat_g','fiber_g'] LOOP
    n:=(snap#>'{payload,totals}')->k;
    IF n->>'state'='known' AND jsonb_typeof(n->'amount')='number' AND (n->>'amount')::numeric<=1000000 THEN projection:=projection||jsonb_build_object(k,n->'amount');
    ELSIF n->>'state'='declared_zero' THEN projection:=projection||jsonb_build_object(k,0); END IF;
   END LOOP;
   c:=jsonb_set(c,'{source,provider}','"manual"'::jsonb);
   snap:=jsonb_set(jsonb_set(snap,'{payload,composition}',c),'{identity,provider}','"manual"'::jsonb);
   item:=jsonb_set(jsonb_set(item,'{nutrients}',projection),'{nutrient_source}',CASE WHEN projection='{}'::jsonb THEN 'null'::jsonb ELSE '"declared"'::jsonb END);
   converted:=jsonb_set(converted,ARRAY['items',sid],snap);
  END IF;
  legacy:=legacy||jsonb_build_array(item);
 END LOOP;
 RETURN vault_nutrition_f2_review.recompute_r16(p_user,p_person,legacy,converted);
EXCEPTION WHEN data_exception OR invalid_parameter_value THEN RETURN false;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb) TO vault_f2_meal_worker_lab;
DO $$ BEGIN
 IF has_table_privilege('authenticated','vault_nutrition_f2_review.catalog_authority_lab','SELECT,INSERT,UPDATE,DELETE') OR has_table_privilege('anon','vault_nutrition_f2_review.catalog_authority_lab','SELECT,INSERT,UPDATE,DELETE') OR has_table_privilege('service_role','vault_nutrition_f2_review.catalog_authority_lab','SELECT,INSERT,UPDATE,DELETE') OR has_table_privilege('vault_f2_meal_worker_lab','vault_nutrition_f2_review.catalog_authority_lab','INSERT,UPDATE,DELETE') THEN RAISE EXCEPTION 'FAIL catalog authority ACL'; END IF;
END $$;
