#!/usr/bin/env bash
# Only local disposable PostgreSQL 17.6, no production or network. R05 archive is the immutable input.
set -euo pipefail
cd "$(dirname "$0")"; self=$PWD
for cmd in initdb pg_ctl psql postgres node tsc unzip sha256sum python3; do command -v "$cmd" >/dev/null || { echo "BLOCKED: $cmd absent"; exit 3; }; done
[[ $(id -u) != 0 ]] || { echo 'BLOCKED: PostgreSQL requires an unprivileged OS account'; exit 3; }
for v in PGHOST PGHOSTADDR PGSERVICE PGSERVICEFILE PGDATABASE PGOPTIONS PGUSER PGPASSWORD PGPASSFILE; do [[ -z "${!v:-}" ]] || { echo "STOP inherited $v"; exit 2; }; done
[[ $(postgres --version) =~ 17\.6([^0-9]|$) ]] || { echo 'BLOCKED: require exact PG17.6'; exit 3; }
zip=$(realpath "${1:?R05 original ZIP required}"); [[ ${2:-} == "" || ${2:-} == "--review-labels" || ${2:-} == "--review-integrated" ]] || { echo "STOP unknown lab option"; exit 2; }; [[ $(sha256sum "$zip" | cut -d' ' -f1) == 087529f489a28219e5f7661e8f7a4a42166ce072aed7c616ea03b94bd734825f ]] || { echo 'STOP R05 ZIP drift'; exit 2; }
root=$(mktemp -d); chmod 700 "$root"; db=vault_macro03_lab_f2; port=55464; mkdir "$root/socket" "$root/r05"
cleanup(){ pg_ctl -D "$root/data" -m immediate stop >/dev/null 2>&1 || true; rm -rf -- "$root"; }; trap cleanup EXIT
unzip -q "$zip" -d "$root/r05"; r=$root/r05; (cd "$r"; sha256sum -c SHA256SUMS.txt >/dev/null)
(cd "$r/integration/baseline"; mapfile -d '' files < <(find lib/vital -name '*.ts' -print0); tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}")
node "$self/generate-fixture-m03.cjs" "$r/integration/baseline/build" "$root/cases"
initdb -D "$root/data" -A trust --no-locale --encoding=UTF8 -U vault_lab_admin >/dev/null
pg_ctl -D "$root/data" -l "$root/postgres.log" -o "-c listen_addresses='' -c unix_socket_directories='$root/socket' -p $port" -w start
args=(-X --no-password --set=ON_ERROR_STOP=1 -h "$root/socket" -p "$port" -U vault_lab_admin)
psql "${args[@]}" -d postgres -c "CREATE DATABASE $db"
psql "${args[@]}" -d "$db" -c "SET vault.macro03_lab='on'" -f "$r/sql/r05-lab/00-SYNTHETIC-PREREQUISITES.sql"
psql "${args[@]}" -d "$db" -c "SET SESSION AUTHORIZATION vault_f2_migrator" -f "$r/sql/r05-lab/F1-EXACT-REFERENCE.sql"
# Narrow historical guard correction only, bound to exact original ZIP. Commit ONLY in disposable cluster for two-session race.
{ sed '$d' "$r/sql/02-DDL-R04-REVISAO.sql" | sed 's/NOT BETWEEN 170600 AND 170699/<> 170006/'; cat "$r/sql/03-LAB-F1-F2-INERT-ASSERTIONS.sql" "$r/sql/r05-lab/04-ENVELOPE-SHAPE-REVIEW.sql" "$r/sql/r05-lab/05-ENVELOPE-ASSERTIONS.sql" "$self/06-F2-RECOMPUTE-REVIEW-CANDIDATE.sql"; if [[ ${2:-} == --review-integrated ]]; then python3 "$self/generate-external-meal-review.py"; else cat "$self/07-F2-MEAL-RPC-REVIEW-M03.sql"; fi; cat "$self/08-RECIPE-STRUCTURE-M03.sql"; printf '\nCOMMIT;\n'; } > "$root/review.sql"
psql "${args[@]}" -d "$db" -c "SET SESSION AUTHORIZATION vault_f2_migrator" -c "SET vault.macro03_lab='on'" -f "$root/review.sql"
psql "${args[@]}" -d "$db" -f "$root/cases/initial.sql"
set +e
psql "${args[@]}" -d "$db" -f "$root/cases/race-a.sql" > "$root/a.log" 2>&1 & pa=$!
psql "${args[@]}" -d "$db" -f "$root/cases/race-b.sql" > "$root/b.log" 2>&1 & pb=$!
wait "$pa"; a=$?; wait "$pb"; b=$?
set -e
cat "$root/a.log" "$root/b.log"
if [[ $a == 0 && $b != 0 ]]; then grep -q '40001' "$root/b.log"; elif [[ $b == 0 && $a != 0 ]]; then grep -q '40001' "$root/a.log"; else echo 'FAIL expected exactly one winner'; exit 1; fi
psql "${args[@]}" -d "$db" -f "$root/cases/verify.sql"
psql "${args[@]}" -d "$db" -f "$root/cases/historical-retry.sql"
if [[ ${2:-} == --review-labels || ${2:-} == --review-integrated ]]; then
  command -v python3 >/dev/null || { echo 'BLOCKED python3 absent'; exit 3; }
  mkdir -p "$root/current/lib";cp -a "$self/../tests/fixture-lib/." "$root/current/lib/"
  (cd "$root/current"; mapfile -d '' files < <(find lib/vital -name '*.ts' -print0); tsc --strict --esModuleInterop --skipLibCheck --target ES2022 --module commonjs --moduleResolution node --outDir build --rootDir lib "${files[@]}")
  node "$self/generate-label-fixture.cjs" "$root/current/build" "$root/cases/labels.sql"
  { printf 'BEGIN;\n';python3 "$self/generate-label-recompute-review.py";printf '\nCOMMIT;\n'; } > "$root/label-review.sql"
  psql "${args[@]}" -d "$db" -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f "$root/label-review.sql"
  psql "${args[@]}" -d "$db" -f "$root/cases/labels.sql"
fi
if [[ ${2:-} == --review-integrated ]]; then
  node "$self/generate-recipe-fixture.cjs" "$root/current/build" "$root/cases"
  node "$self/generate-external-fixture.cjs" "$root/current/build" "$root/cases/external.sql"
  { printf 'BEGIN;\n'; cat "$self/10-RECIPE-RPC-REVIEW.sql"; printf '\nCOMMIT;\n'; } > "$root/recipe-review.sql"
  psql "${args[@]}" -d "$db" -c 'SET SESSION AUTHORIZATION vault_f2_migrator' -c "SET vault.macro03_lab='on'" -f "$root/recipe-review.sql"
  psql "${args[@]}" -d "$db" -f "$root/cases/recipe-initial.sql"
  set +e
  psql "${args[@]}" -d "$db" -f "$root/cases/recipe-race-a.sql" > "$root/ra.log" 2>&1 & ra=$!
  psql "${args[@]}" -d "$db" -f "$root/cases/recipe-race-b.sql" > "$root/rb.log" 2>&1 & rb=$!
  wait "$ra"; a=$?; wait "$rb"; b=$?
  set -e
  cat "$root/ra.log" "$root/rb.log"
  if [[ $a == 0 && $b != 0 ]]; then grep -q '40001' "$root/rb.log"; elif [[ $b == 0 && $a != 0 ]]; then grep -q '40001' "$root/ra.log"; else echo 'FAIL expected exactly one recipe version winner'; exit 1; fi
  psql "${args[@]}" -d "$db" -f "$root/cases/recipe-verify.sql"
  psql "${args[@]}" -d "$db" -f "$root/cases/external.sql"
fi
echo 'F2_DISPOSABLE_LAB_PASS; NOT_PRODUCTION_OR_POSTGREST'  
