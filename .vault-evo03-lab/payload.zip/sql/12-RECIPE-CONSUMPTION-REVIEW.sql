-- LAB ONLY; apply after 10 and after the reviewed-label variant. No numbered migration or activation.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
END $$;
-- Preserve the reviewed manual/label authority. The wrapper verifies recipe facts from stored immutable versions.
ALTER FUNCTION vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb) RENAME TO recompute_manual_label;
CREATE FUNCTION vault_nutrition_f2_review.recipe_legacy_name(n text) RETURNS text LANGUAGE plpgsql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE ch text; i int; width int:=0; prefix text:=''; total int:=0; step int;
BEGIN
 IF n IS NULL OR n='' THEN RETURN NULL;END IF;
 FOR i IN 1..char_length(n) LOOP ch:=substr(n,i,1);step:=CASE WHEN ascii(ch)>65535 THEN 2 ELSE 1 END;total:=total+step;IF width+step<=119 AND total<=119 THEN prefix:=prefix||ch;width:=width+step;END IF;END LOOP;
 RETURN CASE WHEN total<=120 THEN n ELSE rtrim(prefix,E' \t\n\r\f\v'||chr(160)||chr(5760)||chr(8192)||chr(8193)||chr(8194)||chr(8195)||chr(8196)||chr(8197)||chr(8198)||chr(8199)||chr(8200)||chr(8201)||chr(8202)||chr(8232)||chr(8233)||chr(8239)||chr(8287)||chr(12288)||chr(65279))||'…' END;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.recipe_composition(p_user uuid,p_person uuid,c jsonb,snap jsonb,item jsonb) RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE v public.vital_recipe_versions%ROWTYPE; evidence jsonb; expected jsonb; base jsonb; eq jsonb; src jsonb; k text; u text; n jsonb; st text; counts jsonb; applicable int; good int; sum numeric; i jsonb; a jsonb; target text; at text; v_id uuid; r_id uuid;
 units constant jsonb:='{"energy_kcal":"kcal","carbohydrate_g":"g","protein_g":"g","fat_g":"g","fiber_g":"g","sugar_g":"g","added_sugar_g":"g","saturated_fat_g":"g","trans_fat_g":"g","sodium_mg":"mg","calcium_mg":"mg","iron_mg":"mg","potassium_mg":"mg","magnesium_mg":"mg","vitamin_c_mg":"mg","vitamin_b12_ug":"ug","vitamin_d_ug":"ug","vitamin_k_ug":"ug","folate_ug":"ug","selenium_ug":"ug","zinc_mg":"mg","phosphorus_mg":"mg","vitamin_a_rae_ug":"ug","vitamin_e_mg":"mg","vitamin_b6_mg":"mg","thiamin_mg":"mg","riboflavin_mg":"mg","niacin_mg":"mg"}';
 states constant jsonb:='{"known":0,"declared_zero":0,"estimated":0,"trace":0,"not_analyzed":0,"not_reported":0,"illegible":0,"not_applicable":0,"unknown":0}';
BEGIN
 IF p_user IS NULL OR p_person IS NULL OR jsonb_typeof(c) IS DISTINCT FROM 'object' OR (c-ARRAY['name','source','base','values','preparation','edibleBasis','equivalence','recipeVersion'])<>'{}'::jsonb OR jsonb_typeof(c->'recipeVersion') IS DISTINCT FROM 'object' THEN RETURN false;END IF;
 v_id:=(c#>>'{source,version}')::uuid;r_id:=(c#>>'{source,recordId}')::uuid;
 SELECT * INTO v FROM public.vital_recipe_versions WHERE id=v_id AND recipe_id=r_id AND user_id=p_user AND person_id=p_person;
 IF NOT FOUND OR v.revision<>1 OR v.deleted_at IS NOT NULL OR v.retention_evidence IS NOT NULL OR (v.finished_mass_g IS NULL AND v.servings IS NULL) OR v.reviewed_at>(snap->>'reviewedAt')::timestamptz THEN RETURN false;END IF;
 at:=to_char(v.reviewed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"');
 evidence:=jsonb_build_object('id',v.id,'user_id',v.user_id,'person_id',v.person_id,'recipe_id',v.recipe_id,'version',v.version,'name_snapshot',v.name_snapshot,'ingredients',v.ingredients,'raw_edible_mass_g',v.raw_edible_mass_g,'finished_mass_g',v.finished_mass_g,'servings',v.servings,'yield_evidence',v.yield_evidence,'retention_evidence',NULL,'reviewed_at',at);
 IF c->'recipeVersion' IS DISTINCT FROM evidence THEN RETURN false;END IF;
 src:=jsonb_build_object('provider','recipe','recordId',v.recipe_id,'version',v.id,'license','private-derived-no-license-override','retrievedAt',at,'attribution','Receita do usuário; soma de ingredientes; retenção não avaliada');
 base:=CASE WHEN v.finished_mass_g IS NOT NULL THEN jsonb_build_object('value',v.finished_mass_g,'unit','g') ELSE jsonb_build_object('value',v.servings,'unit','portion') END;
 IF c->'source' IS DISTINCT FROM src OR c->'base' IS DISTINCT FROM base OR c->>'name' IS DISTINCT FROM v.name_snapshot OR c->>'preparation' IS DISTINCT FROM 'ready' OR c->>'edibleBasis' IS DISTINCT FROM 'unknown' OR snap->'food_id' IS DISTINCT FROM 'null'::jsonb OR item->'food_id' IS DISTINCT FROM 'null'::jsonb OR snap->'identity' IS DISTINCT FROM jsonb_build_object('provider','recipe','recordId',v.recipe_id,'version',v.id,'preparation','ready','presentationId',v.id) OR item->>'name' IS DISTINCT FROM vault_nutrition_f2_review.recipe_legacy_name(v.name_snapshot) OR item->'nutrients' IS DISTINCT FROM '{}'::jsonb OR item->'nutrient_source' IS DISTINCT FROM 'null'::jsonb THEN RETURN false;END IF;
 IF v.finished_mass_g IS NOT NULL AND v.servings IS NOT NULL THEN eq:=jsonb_build_object('from',jsonb_build_object('value',v.finished_mass_g,'unit','g'),'to',jsonb_build_object('value',v.servings,'unit','portion'),'evidence',v.yield_evidence);IF c->'equivalence' IS DISTINCT FROM eq THEN RETURN false;END IF;ELSIF c ? 'equivalence' THEN RETURN false;END IF;
 IF jsonb_typeof(c->'values') IS DISTINCT FROM 'object' OR (SELECT count(*) FROM jsonb_object_keys(c->'values'))<>28 THEN RETURN false;END IF;
 FOR k,u IN SELECT key,value FROM jsonb_each_text(units) LOOP
  counts:=states;sum:=0;applicable:=0;good:=0;
  FOR i IN SELECT x FROM jsonb_array_elements(v.ingredients) t(x) LOOP
   n:=i->'totals'->k;st:=coalesce(n->>'state','not_reported');IF NOT states ? st THEN RETURN false;END IF;
   counts:=jsonb_set(counts,ARRAY[st],to_jsonb((counts->>st)::int+1));
   IF st='not_applicable' THEN CONTINUE;END IF;applicable:=applicable+1;
   IF st='declared_zero' THEN good:=good+1;ELSIF st IN ('known','estimated') THEN IF n->>'unit' IS DISTINCT FROM u OR jsonb_typeof(n->'amount') IS DISTINCT FROM 'number' OR (n->>'amount')::numeric<0 THEN RETURN false;END IF;good:=good+1;sum:=sum+(n->>'amount')::numeric;END IF;
  END LOOP;
  a:=c->'values'->k;
  IF applicable=0 THEN expected:=jsonb_build_object('state','not_applicable');
  ELSIF good=applicable THEN
   IF NOT vault_nutrition_f2_review.exact_keys(a,ARRAY['state','amount','unit','method']) OR a->>'state' IS DISTINCT FROM 'estimated' OR a->>'unit' IS DISTINCT FROM u OR a->>'method' IS DISTINCT FROM 'recipe_ingredient_sum_no_retention_assessed' OR NOT vault_nutrition_f2_review.near(a->'amount',sum) THEN RETURN false;END IF;CONTINUE;
  ELSE target:='unknown';FOREACH st IN ARRAY ARRAY['trace','not_analyzed','not_reported','illegible','unknown'] LOOP IF (counts->>st)::int=applicable THEN target:=st;EXIT;END IF;END LOOP;expected:=jsonb_build_object('state',target);END IF;
  IF a IS DISTINCT FROM expected THEN RETURN false;END IF;
 END LOOP;
 RETURN true;
EXCEPTION WHEN data_exception OR invalid_parameter_value THEN RETURN false;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.recompute(p_user uuid,p_person uuid,p_legacy jsonb,p_env jsonb) RETURNS boolean LANGUAGE plpgsql STABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
DECLARE item jsonb; snap jsonb; c jsonb; sid text; converted jsonb:=p_env; legacy jsonb:='[]'::jsonb;
BEGIN
 IF jsonb_typeof(p_legacy) IS DISTINCT FROM 'array' OR jsonb_typeof(p_env) IS DISTINCT FROM 'object' OR octet_length(p_env::text)>2000000 THEN RETURN false;END IF;
 FOR item IN SELECT x FROM jsonb_array_elements(p_legacy) t(x) LOOP
  sid:=item->>'id';snap:=p_env->'items'->sid;c:=snap#>'{payload,composition}';
  IF c#>>'{source,provider}'='recipe' THEN
   IF vault_nutrition_f2_review.recipe_composition(p_user,p_person,c,snap,item) IS DISTINCT FROM true THEN RETURN false;END IF;
   -- Feed the SAME verified nutrient arithmetic into the existing engine. Only the in-memory proof
   -- is normalized; the original persisted envelope and legacy item never change.
   c:=jsonb_set(jsonb_set(c-'recipeVersion','{source,provider}','"manual"'::jsonb),'{name}',item->'name');
   snap:=jsonb_set(jsonb_set(snap,'{payload,composition}',c),'{identity,provider}','"manual"'::jsonb);
   converted:=jsonb_set(converted,ARRAY['items',sid],snap);
  END IF;
  legacy:=legacy||jsonb_build_array(item);
 END LOOP;
 RETURN vault_nutrition_f2_review.recompute_manual_label(p_user,p_person,legacy,converted);
EXCEPTION WHEN data_exception OR invalid_parameter_value THEN RETURN false;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.recipe_legacy_name(text),vault_nutrition_f2_review.recipe_composition(uuid,uuid,jsonb,jsonb,jsonb),vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.recipe_legacy_name(text),vault_nutrition_f2_review.recipe_composition(uuid,uuid,jsonb,jsonb,jsonb),vault_nutrition_f2_review.recompute(uuid,uuid,jsonb,jsonb) TO vault_f2_meal_worker_lab;
-- No change to client capability, no production migration. Role, grants, RLS and real cases required.
