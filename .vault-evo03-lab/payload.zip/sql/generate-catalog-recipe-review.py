#!/usr/bin/env python3
"""R17 lab only: extend existing reviewed recipe RPC to the two registry providers; no production SQL."""
from pathlib import Path
import subprocess,sys
p=Path(__file__).resolve().parent
s=subprocess.check_output([sys.executable,str(p/'generate-integrated-recipe-review.py')],text=True)
old="coalesce(i#>>'{composition,source,provider}','') NOT IN ('manual','label')"
assert s.count(old)==1
print(s.replace(old,"coalesce(i#>>'{composition,source,provider}','') NOT IN ('manual','label','taco','usda')"),end='')
