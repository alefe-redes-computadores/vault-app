-- R24 disposable PG17.6 only. Preserve the existing recomputer, exact registry and stored envelopes.
DO $$ BEGIN
 IF current_database()<>'vault_macro03_lab_f2' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable R24'; END IF;
END $$;
CREATE FUNCTION vault_nutrition_f2_review.coverage_matches_r24(actual jsonb, expected jsonb) RETURNS boolean LANGUAGE sql IMMUTABLE SECURITY INVOKER SET search_path=pg_catalog AS $$
 SELECT CASE WHEN jsonb_typeof(actual) IS DISTINCT FROM 'object' OR jsonb_typeof(expected) IS DISTINCT FROM 'object' THEN false
 WHEN NOT (actual ?& ARRAY['amount','estimatedSubtotal'] AND expected ?& ARRAY['amount','estimatedSubtotal']) THEN false
 WHEN (actual-ARRAY['amount','estimatedSubtotal']) IS DISTINCT FROM (expected-ARRAY['amount','estimatedSubtotal']) THEN false
 ELSE
  (CASE WHEN expected->'amount'='null'::jsonb THEN actual->'amount' IS NOT DISTINCT FROM 'null'::jsonb WHEN jsonb_typeof(expected->'amount')='number' THEN vault_nutrition_f2_review.near(actual->'amount',(expected->>'amount')::numeric) ELSE false END)
  AND
  (CASE WHEN expected->'estimatedSubtotal'='null'::jsonb THEN actual->'estimatedSubtotal' IS NOT DISTINCT FROM 'null'::jsonb WHEN jsonb_typeof(expected->'estimatedSubtotal')='number' THEN vault_nutrition_f2_review.near(actual->'estimatedSubtotal',(expected->>'estimatedSubtotal')::numeric) ELSE false END)
 END
$$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.coverage_matches_r24(jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.coverage_matches_r24(jsonb,jsonb) TO vault_f2_meal_worker_lab;
-- Only the one predicate in the underlying manual/label arithmetic engine changes. Keep its OID and ACL.
DO $$ DECLARE f oid:='vault_nutrition_f2_review.recompute_manual_label(uuid,uuid,jsonb,jsonb)'::regprocedure; old text:='IF cov IS DISTINCT FROM expected THEN RETURN false; END IF;'; new text:='IF vault_nutrition_f2_review.coverage_matches_r24(cov,expected) IS DISTINCT FROM true THEN RETURN false; END IF;'; def text; before_acl aclitem[]; before_owner oid; before_config text[]; before_security boolean; before_source text; BEGIN
 SELECT proacl,proowner,proconfig,prosecdef,prosrc INTO STRICT before_acl,before_owner,before_config,before_security,before_source FROM pg_proc WHERE oid=f;
 def:=pg_get_functiondef(f);
 IF md5(before_source)<>'bcc0e4b48df7de58c02d43cc2468b429' OR (length(def)-length(replace(def,old,'')))<>length(old) OR position(new in def)>0 OR before_security THEN RAISE EXCEPTION 'STOP R24 recompute preimage'; END IF;
 EXECUTE replace(def,old,new);
 IF NOT EXISTS(SELECT 1 FROM pg_proc WHERE oid=f AND proacl IS NOT DISTINCT FROM before_acl AND proowner=before_owner AND proconfig IS NOT DISTINCT FROM before_config AND prosecdef=before_security AND prosrc=replace(before_source,old,new)) THEN RAISE EXCEPTION 'STOP R24 identity/ACL changed'; END IF;
 IF has_function_privilege('authenticated','vault_nutrition_f2_review.coverage_matches_r24(jsonb,jsonb)','EXECUTE') OR has_function_privilege('anon','vault_nutrition_f2_review.coverage_matches_r24(jsonb,jsonb)','EXECUTE') OR has_function_privilege('service_role','vault_nutrition_f2_review.coverage_matches_r24(jsonb,jsonb)','EXECUTE') THEN RAISE EXCEPTION 'STOP R24 helper ACL';END IF;
 RAISE NOTICE 'R24_ONLY_COVERAGE_PREDICATE_PATCHED';
END $$;
