-- LAB ONLY. The existing immutable version is the receipt; no second nutrition table or queue.
-- The root is saved through F1 and must already exist. Its canonical row lock serializes F1/F2 version inserts.
DO $$ BEGIN
 IF current_database() !~ '^vault_macro03_lab_[a-z0-9]+$' OR inet_server_addr() IS NOT NULL OR current_setting('vault.macro03_lab',true) IS DISTINCT FROM 'on' OR current_setting('server_version_num')::int<>170006 THEN RAISE EXCEPTION 'STOP disposable lab'; END IF;
 IF EXISTS(SELECT 1 FROM pg_roles WHERE rolname='vault_f2_plan_worker_lab') THEN RAISE EXCEPTION 'STOP unexpected role'; END IF;
END $$;
CREATE ROLE vault_f2_plan_worker_lab NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
DO $$ BEGIN EXECUTE format('GRANT vault_f2_plan_worker_lab TO %I WITH SET TRUE, INHERIT FALSE',current_user);END $$;
GRANT USAGE ON SCHEMA public,vault_nutrition_f2_review TO vault_f2_plan_worker_lab;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.request_uid(),vault_nutrition_f2_review.plan_targets_valid(jsonb) TO vault_f2_plan_worker_lab;
GRANT SELECT,INSERT ON public.vital_nutrition_plan_versions TO vault_f2_plan_worker_lab;
GRANT SELECT ON public.vital_nutrition_plans,public.vital_nutrition_modalities TO vault_f2_plan_worker_lab;
-- The existing F1 sequence trigger uses SELECT FOR UPDATE on the root. Column privilege is needed
-- for row locking, but the WITH CHECK false policy forbids any actual update by the worker.
GRANT UPDATE(id) ON public.vital_nutrition_plans TO vault_f2_plan_worker_lab;
CREATE POLICY f2_target_root_read ON public.vital_nutrition_plans FOR SELECT TO vault_f2_plan_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_target_root_lock ON public.vital_nutrition_plans FOR UPDATE TO vault_f2_plan_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id) WITH CHECK(false);
CREATE POLICY f2_target_modality_read ON public.vital_nutrition_modalities FOR SELECT TO vault_f2_plan_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_target_version_read ON public.vital_nutrition_plan_versions FOR SELECT TO vault_f2_plan_worker_lab USING ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
CREATE POLICY f2_target_version_insert ON public.vital_nutrition_plan_versions FOR INSERT TO vault_f2_plan_worker_lab WITH CHECK ((SELECT vault_nutrition_f2_review.request_uid())=user_id);
-- Replace only the inert plan-version lock in this disposable transaction, retaining all F1 guards.
DROP TRIGGER vital_f2_review_lock_plans ON public.vital_nutrition_plan_versions;
CREATE FUNCTION vault_nutrition_f2_review.guard_targets() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.targets_f2 IS NOT NULL OR (TG_OP='UPDATE' AND OLD.targets_f2 IS NOT NULL) THEN
  IF TG_OP<>'INSERT' OR current_user<>'vault_f2_plan_worker_lab' OR NEW.targets_f2 IS NULL THEN RAISE EXCEPTION 'F2 targets require immutable version writer' USING ERRCODE='42501'; END IF;
 END IF;
 RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.guard_targets() FROM PUBLIC,anon,authenticated,service_role;
CREATE TRIGGER vital_f2_review_lock_plans BEFORE INSERT OR UPDATE ON public.vital_nutrition_plan_versions FOR EACH ROW EXECUTE FUNCTION vault_nutrition_f2_review.guard_targets();
CREATE FUNCTION vault_nutrition_f2_review.write_plan_targets(p_person uuid,p_row jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE uid uuid:=vault_nutrition_f2_review.request_uid(); incoming public.vital_nutrition_plan_versions%ROWTYPE; saved public.vital_nutrition_plan_versions%ROWTYPE; root public.vital_nutrition_plans%ROWTYPE;
 keys constant text[]:=ARRAY['id','user_id','person_id','created_at','updated_at','deleted_at','revision','plan_id','version','effective_on','status','plan_name','professional_id','modality_ids','modalities','custom_modality','rules','targets','origin','notes','targets_f2'];
BEGIN
 IF uid IS NULL OR p_person IS NULL OR p_row->>'user_id' IS DISTINCT FROM uid::text OR p_row->>'person_id' IS DISTINCT FROM p_person::text THEN RAISE EXCEPTION 'F2 target scope denied' USING ERRCODE='42501'; END IF;
 IF jsonb_typeof(p_row) IS DISTINCT FROM 'object' OR octet_length(p_row::text)>500000 OR NOT p_row ?& keys OR p_row-keys<>'{}'::jsonb OR p_row->'revision' IS DISTINCT FROM '1'::jsonb OR jsonb_typeof(p_row->'version') IS DISTINCT FROM 'number' OR p_row->'deleted_at' IS DISTINCT FROM 'null'::jsonb OR vault_nutrition_f2_review.plan_targets_valid(p_row->'targets_f2') IS DISTINCT FROM true THEN RAISE EXCEPTION 'F2 target shape invalid' USING ERRCODE='23514'; END IF;
 incoming:=jsonb_populate_record(NULL::public.vital_nutrition_plan_versions,p_row);
 IF incoming.id IS NULL OR incoming.plan_id IS NULL OR incoming.version IS NULL OR incoming.version<1 OR p_row->'version' IS DISTINCT FROM to_jsonb(incoming.version) OR incoming.created_at IS NULL OR incoming.updated_at IS DISTINCT FROM incoming.created_at OR incoming.created_at>clock_timestamp()+interval '5 minutes' THEN RAISE EXCEPTION 'F2 target immutable identity invalid' USING ERRCODE='23514'; END IF;
 -- Historical retry: immutable row is the exact persistent receipt; a newer plan version does not change it.
 PERFORM pg_advisory_xact_lock(hashtextextended('vault_f2_target:'||uid::text||':'||p_person::text||':'||incoming.id::text,0));
 SELECT * INTO saved FROM public.vital_nutrition_plan_versions WHERE id=incoming.id AND user_id=uid AND person_id=p_person;
 IF FOUND THEN
  IF to_jsonb(saved) IS DISTINCT FROM to_jsonb(incoming) THEN RAISE EXCEPTION 'F2 target immutable retry conflict' USING ERRCODE='PT409'; END IF;
  RETURN jsonb_build_object('status','retry','operation_id',saved.id,'version',to_jsonb(saved));
 END IF;
 SELECT * INTO root FROM public.vital_nutrition_plans WHERE id=incoming.plan_id AND user_id=uid AND person_id=p_person AND deleted_at IS NULL FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'F2 target plan outside scope or missing' USING ERRCODE='42501'; END IF;
 -- Existing canonical version sequence, date, modality and macro guards still execute.
 INSERT INTO public.vital_nutrition_plan_versions SELECT (incoming).* RETURNING * INTO saved;
 RETURN jsonb_build_object('status','applied','operation_id',saved.id,'version',to_jsonb(saved));
END $$;
REVOKE ALL ON FUNCTION vault_nutrition_f2_review.write_plan_targets(uuid,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION vault_nutrition_f2_review.write_plan_targets(uuid,jsonb) TO authenticated;
GRANT CREATE ON SCHEMA vault_nutrition_f2_review TO vault_f2_plan_worker_lab;
ALTER FUNCTION vault_nutrition_f2_review.write_plan_targets(uuid,jsonb) OWNER TO vault_f2_plan_worker_lab;
REVOKE CREATE ON SCHEMA vault_nutrition_f2_review FROM vault_f2_plan_worker_lab;
CREATE FUNCTION public.vault_vital_plan_targets_f2_review(p_person uuid,p_row jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY INVOKER SET search_path=pg_catalog AS $$
BEGIN
 IF auth.uid() IS NULL OR p_row->>'user_id' IS DISTINCT FROM auth.uid()::text OR p_row->>'person_id' IS DISTINCT FROM p_person::text THEN RAISE EXCEPTION 'F2 target scope denied' USING ERRCODE='42501'; END IF;
 RETURN vault_nutrition_f2_review.write_plan_targets(p_person,p_row);
END $$;
REVOKE ALL ON FUNCTION public.vault_vital_plan_targets_f2_review(uuid,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.vault_vital_plan_targets_f2_review(uuid,jsonb) TO authenticated;
DO $$ BEGIN
 IF has_function_privilege('anon','public.vault_vital_plan_targets_f2_review(uuid,jsonb)','EXECUTE') OR has_function_privilege('anon','vault_nutrition_f2_review.write_plan_targets(uuid,jsonb)','EXECUTE') OR has_schema_privilege('vault_f2_plan_worker_lab','vault_nutrition_f2_review','CREATE') OR pg_has_role('authenticated','vault_f2_plan_worker_lab','MEMBER') OR EXISTS(SELECT 1 FROM pg_roles WHERE rolname='vault_f2_plan_worker_lab' AND (rolcanlogin OR rolbypassrls OR rolsuper OR rolcreaterole)) THEN RAISE EXCEPTION 'F2 target ACL review failed';END IF;
END $$;
